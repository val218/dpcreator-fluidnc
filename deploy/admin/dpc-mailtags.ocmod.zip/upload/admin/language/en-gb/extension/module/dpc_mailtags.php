<?php
$_['heading_title'] = 'dpCREATOR Mailbox tags (UK / EU in the Inbox)';
