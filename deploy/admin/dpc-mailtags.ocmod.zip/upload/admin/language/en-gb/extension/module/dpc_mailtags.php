<?php
$_['heading_title'] = 'dpCREATOR UK / EU tags (Inbox and Workbench)';
