/* Marks each Inbox mailbox as UK (.co.uk) or EU (.eu). Works alongside dpc-inbox.js without changing it. */
(function () {
	'use strict';
	var region = function (e) { e = String(e || '').toLowerCase(); return /\.co\.uk$/.test(e) ? 'UK' : /\.eu$/.test(e) ? 'EU' : ''; };
	var st = document.createElement('style');
	st.textContent = '.dpcmt{display:inline-block;font-size:10px;font-weight:700;letter-spacing:.3px;border-radius:9px;padding:0 6px;margin-right:4px;vertical-align:1px;line-height:16px}'
		+ '.dpcmt.UK{background:#012169;color:#fff}.dpcmt.EU{background:#003399;color:#FFCC00}'
		+ '.dpci-row.dpcmt-UK{box-shadow:inset 0 -2px 0 #C8102E}';
	document.head.appendChild(st);

	var items = [];
	var of = window.fetch;
	window.fetch = function (input) {
		var url = String(input && input.url || input);
		var p = of.apply(this, arguments);
		if (/dpc_inbox\/threads/.test(url)) {
			var page = +((url.match(/[?&]page=(\d+)/) || [])[1] || 1);
			p.then(function (r) { return r.clone().json(); }).then(function (j) {
				items = page > 1 ? items.concat(j.items || []) : (j.items || []);
				setTimeout(mark, 0);
			}).catch(function () {});
		}
		return p;
	};

	function pill(reg) { var s = document.createElement('span'); s.className = 'dpcmt ' + reg; s.textContent = reg; return s; }

	function mark() {
		var root = document.getElementById('dpci');
		if (!root) return;
		// List rows: same order as the threads the page loaded
		root.querySelectorAll('.dpci-list .dpci-row').forEach(function (row, i) {
			var t = items[i];
			if (!t || row.getAttribute('data-dpcmt') === t.account) return;
			var reg = region(t.account);
			row.setAttribute('data-dpcmt', t.account);
			row.classList.remove('dpcmt-UK', 'dpcmt-EU');
			var old = row.querySelector('.dpcmt'); if (old) old.remove();
			if (!reg) return;
			row.classList.add('dpcmt-' + reg);
			var p = row.querySelector('.p');
			if (p) p.insertBefore(pill(reg), p.firstChild);
		});
		// Mailbox pickers (filter and the From field when writing)
		root.querySelectorAll('select option').forEach(function (o) {
			var reg = region(o.textContent.trim());
			if (reg && o.textContent.indexOf(reg + ' · ') !== 0) o.textContent = reg + ' · ' + o.textContent.trim();
		});
		// Open message header ("… · to info@dpcreator.co.uk")
		root.querySelectorAll('.dpci-view *').forEach(function (el) {
			if (el.children.length || el.getAttribute('data-dpcmt')) return;
			var m = el.textContent.match(/to ([\w.+-]+@[\w.-]+)\s*$/);
			if (!m) return;
			var reg = region(m[1]);
			if (!reg) return;
			el.setAttribute('data-dpcmt', '1');
			el.insertBefore(pill(reg), el.firstChild);
		});
	}

	document.addEventListener('DOMContentLoaded', function () {
		var root = document.getElementById('dpci');
		if (!root) return;
		new MutationObserver(function () { clearTimeout(mark.t); mark.t = setTimeout(mark, 30); }).observe(root, { childList: true, subtree: true });
		mark();
	});
})();
