/* Marks each Inbox mailbox as UK (.co.uk) or EU (.eu), and adds All / UK / EU tabs.
   Works alongside dpc-inbox.js without changing it: the UK and EU lists are the threads of that region's mailboxes, merged. */
(function () {
	'use strict';
	var region = function (e) { e = String(e || '').toLowerCase(); return /\.co\.uk$/.test(e) ? 'UK' : /\.eu$/.test(e) ? 'EU' : ''; };
	var st = document.createElement('style');
	st.textContent = '.dpcmt{display:inline-block;font-size:10px;font-weight:700;letter-spacing:.3px;border-radius:9px;padding:0 6px;margin-right:4px;vertical-align:1px;line-height:16px}'
		+ '.dpcmt.UK{background:#012169;color:#fff}.dpcmt.EU{background:#003399;color:#FFCC00}'
		+ '.dpci-row.dpcmt-UK{box-shadow:inset 0 -2px 0 #C8102E}'
		+ '.dpcmt-tabs button .dpcmt{margin:0 0 0 2px}';
	document.head.appendChild(st);

	var REG = 'all';
	try { REG = localStorage.getItem('dpcmt_region') || 'all'; } catch (e) {}
	var accounts = function () { return (window.DPCI_CONFIG && window.DPCI_CONFIG.accounts) || []; };
	var items = [];
	var of = window.fetch;

	window.fetch = function (input, init) {
		var url = String(input && input.url || input);
		if (!/dpc_inbox\/threads/.test(url)) return of.apply(this, arguments);
		var page = +((url.match(/[?&]page=(\d+)/) || [])[1] || 1);
		var acc = +((url.match(/[?&]account=(\d+)/) || [])[1] || 0);
		var p;
		var ids = accounts().filter(function (a) { return region(a.email) === REG; }).map(function (a) { return a.id; });
		if (REG !== 'all' && !acc && ids.length) {
			// One list for the region: ask for each of its mailboxes and merge, newest first
			p = Promise.all(ids.map(function (id) {
				var u = /[?&]account=/.test(url) ? url.replace(/([?&]account=)\d*/, '$1' + id) : url + '&account=' + id;
				return of.call(window, u, init).then(function (r) { return r.json(); });
			})).then(function (parts) {
				var m = { items: [], total: 0, counts: {} };
				parts.forEach(function (j) {
					m.items = m.items.concat(j.items || []);
					m.total += +j.total || 0;
					Object.keys(j.counts || {}).forEach(function (k) { m.counts[k] = (m.counts[k] || 0) + (+j.counts[k] || 0); });
					if (j.now) m.now = j.now;
				});
				m.items.sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
				return new Response(JSON.stringify(m), { status: 200, headers: { 'Content-Type': 'application/json' } });
			});
		} else {
			p = of.apply(this, arguments);
		}
		p.then(function (r) { return r.clone().json(); }).then(function (j) {
			items = page > 1 ? items.concat(j.items || []) : (j.items || []);
			setTimeout(mark, 0);
		}).catch(function () {});
		return p;
	};

	function pill(reg) { var s = document.createElement('span'); s.className = 'dpcmt ' + reg; s.textContent = reg; return s; }

	function tabs(root) {
		var bar = root.querySelector('.dpci-bar');
		var sel = bar && bar.querySelector('select');
		if (!bar || !sel) return;
		var t = bar.querySelector('.dpcmt-tabs');
		if (!t) {
			var regs = {};
			accounts().forEach(function (a) { var r = region(a.email); if (r) regs[r] = 1; });
			if (!regs.UK || !regs.EU) return;
			t = document.createElement('div');
			t.className = 'dpci-tabs dpcmt-tabs';
			t.setAttribute('role', 'group');
			t.setAttribute('aria-label', 'Show mail for');
			['all', 'UK', 'EU'].forEach(function (r) {
				var b = document.createElement('button');
				b.type = 'button';
				b.setAttribute('data-r', r);
				if (r === 'all') b.textContent = 'UK + EU'; else b.appendChild(pill(r));
				b.addEventListener('click', function () {
					REG = r;
					try { localStorage.setItem('dpcmt_region', r); } catch (e) {}
					// Reload the list through the Inbox itself: all mailboxes of the chosen region
					sel.value = '0';
					sel.dispatchEvent(new Event('change', { bubbles: true }));
					paint();
				});
				t.appendChild(b);
			});
			bar.insertBefore(t, sel);
			sel.addEventListener('change', function () { if (sel.value !== '0') { paint(); } });
		}
		paint();
		function paint() {
			var on = sel.value === '0' ? REG : region((sel.options[sel.selectedIndex] || {}).textContent);
			t.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-r') === (on || 'all') ? 'true' : 'false'); });
		}
	}

	function mark() {
		var root = document.getElementById('dpci');
		if (!root) return;
		tabs(root);
		root.querySelectorAll('.dpci-list .dpci-row').forEach(function (row, i) {
			var t = items[i];
			if (!t || row.getAttribute('data-dpcmt') === t.account) return;
			var reg = region(t.account);
			row.setAttribute('data-dpcmt', t.account);
			row.classList.remove('dpcmt-UK', 'dpcmt-EU');
			var old = row.querySelector('.dpcmt'); if (old) old.remove();
			if (!reg) return;
			row.classList.add('dpcmt-' + reg);
			var p = row.querySelector('.p');
			if (p) p.insertBefore(pill(reg), p.firstChild);
		});
		root.querySelectorAll('select option').forEach(function (o) {
			var reg = region(o.textContent.trim());
			if (reg && o.textContent.indexOf(reg + ' · ') !== 0) o.textContent = reg + ' · ' + o.textContent.trim();
		});
		root.querySelectorAll('.dpci-view *').forEach(function (el) {
			if (el.children.length || el.getAttribute('data-dpcmt')) return;
			var m = el.textContent.match(/to ([\w.+-]+@[\w.-]+)\s*$/);
			if (!m) return;
			var reg = region(m[1]);
			if (!reg) return;
			el.setAttribute('data-dpcmt', '1');
			el.insertBefore(pill(reg), el.firstChild);
		});
	}

	document.addEventListener('DOMContentLoaded', function () {
		var root = document.getElementById('dpci');
		if (!root) return;
		new MutationObserver(function () { clearTimeout(mark.t); mark.t = setTimeout(mark, 30); }).observe(root, { childList: true, subtree: true });
		mark();
	});
})();
