<?php
// Marks UK (.co.uk) and EU (.eu) mailboxes in the Inbox with a coloured tag. Separate from the Inbox add-on; it only adds a script on the Inbox pages.
class ControllerExtensionModuleDpcMailtags extends Controller {
	public function install() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_mailtags');
		$this->model_setting_event->addEvent('dpc_mailtags', 'admin/controller/common/header/after', 'extension/module/dpc_mailtags/inject');
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_mailtags', array('module_dpc_mailtags_status' => 1));
	}
	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_mailtags');
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_mailtags');
	}
	public function index() {
		$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
	}
	public function inject(&$route, &$args, &$output) {
		$r = isset($this->request->get['route']) ? $this->request->get['route'] : '';
		if (!is_string($output) || strpos($r, 'extension/module/dpc_inbox') !== 0 || !$this->config->get('module_dpc_mailtags_status')) {
			return;
		}
		$output = str_replace('</head>', '<script src="view/javascript/dpc-mailtags.js?v=1"></script>' . "\n</head>", $output);
	}
}
