<?php
// dpCREATOR Books: sends the deadline reminders once a day, even on days nobody opens the admin.
// Hooked to the shop footer; does one settings read on every other page view.
class ControllerExtensionModuleDpcBooksTick extends Controller {
	public function tick($route = '', $args = array()) {
		try {
			$r = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'module_dpc_books' AND `key` = 'module_dpc_books_last_tick' LIMIT 1");
			if ($r->num_rows && $r->row['value'] === date('Y-m-d')) {
				return null;
			}
			$file = dirname(DIR_APPLICATION) . '/admin/controller/extension/module/dpc_books.php';
			if (!is_file($file)) {
				return null;
			}
			require_once $file;
			if (!class_exists('ControllerExtensionModuleDpcBooks', false)) {
				return null;
			}
			$books = new ControllerExtensionModuleDpcBooks($this->registry);
			$books->remind();
		} catch (\Throwable $e) {
			// Never let the books get in the way of a shop page
		}
		return null;
	}
}
