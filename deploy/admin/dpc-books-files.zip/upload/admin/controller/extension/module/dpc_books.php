<?php
// dpCREATOR Books: double-entry bookkeeping for a one-person Latvian SIA, kept next to the shop.
//
// Where the entries come from:
//   shop orders (paid statuses)            -> sales, payment-provider balances, cost of goods sold
//   Purchases and stock: received invoices -> stock (parts, goods) and money owed to the supplier
//                        build batches     -> parts turned into finished products
//                        outside sales     -> sales on other channels (Elecrow ...)
//   Books: expense invoices (with the PDF), bank statements (camt.053 / CSV), dividends, manual entries
//
// What it prepares for VID (you check them and submit them in EDS yourself):
//   UIN declaration (DokUIENv5): December every year, other months only when there is something taxable
//   Annual report (DokGPv1, UGP): balance sheet, profit or loss (by function, PZA2), notes for a micro company
// and it keeps the deadline calendar and emails reminders.
//
// Nothing is ever deleted: a wrong document is voided, which posts a reversing entry.
// All money is EUR. Amounts in the VID files are whole euros.
class ControllerExtensionModuleDpcBooks extends Controller {
	private $P;
	private $S = null;

	public function __construct($registry) {
		parent::__construct($registry);
		$this->P = DB_PREFIX . 'dpc_bk_';
	}

	// ================================================================== install
	public function install() {
		$this->tables();
		$this->seedAccounts();
		$this->sdefaults();
		if (is_object($this->registry)) {
			$this->load->model('setting/event');
			$this->model_setting_event->deleteEventByCode('dpc_books_tick');
			$this->model_setting_event->addEvent('dpc_books_tick', 'catalog/controller/common/footer/before', 'extension/module/dpc_books_tick/tick');
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSettingValue('module_dpc_books', 'module_dpc_books_status', 1);
		}
	}

	public function uninstall() {
		// The books are records: tables and settings stay. Only the daily reminder hook is removed.
		if (is_object($this->registry)) {
			$this->load->model('setting/event');
			$this->model_setting_event->deleteEventByCode('dpc_books_tick');
		}
	}

	private function tables() {
		$P = $this->P;
		$q = function ($sql) { $this->db->query($sql); };
		$q("CREATE TABLE IF NOT EXISTS `{$P}account` (
			`code` VARCHAR(10) NOT NULL, `name` VARCHAR(160) NOT NULL, `name_en` VARCHAR(160) NOT NULL DEFAULT '', `type` CHAR(1) NOT NULL,
			`gp` VARCHAR(16) NOT NULL DEFAULT '', `tag` VARCHAR(16) NOT NULL DEFAULT '', `status` TINYINT NOT NULL DEFAULT 1, `sort` INT NOT NULL DEFAULT 0,
			PRIMARY KEY (`code`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}entry` (
			`entry_id` INT NOT NULL AUTO_INCREMENT, `date` DATE NOT NULL, `kind` VARCHAR(12) NOT NULL, `src` VARCHAR(64) NOT NULL,
			`ref` VARCHAR(128) NOT NULL DEFAULT '', `descr` VARCHAR(255) NOT NULL DEFAULT '', `hash` CHAR(32) NOT NULL DEFAULT '',
			`user` VARCHAR(64) NOT NULL DEFAULT '', `created` DATETIME NOT NULL,
			PRIMARY KEY (`entry_id`), UNIQUE KEY `src` (`src`), KEY `date` (`date`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}line` (
			`line_id` INT NOT NULL AUTO_INCREMENT, `entry_id` INT NOT NULL, `account` VARCHAR(10) NOT NULL,
			`debit` DECIMAL(15,2) NOT NULL DEFAULT 0, `credit` DECIMAL(15,2) NOT NULL DEFAULT 0, `partner` VARCHAR(160) NOT NULL DEFAULT '', `note` VARCHAR(255) NOT NULL DEFAULT '',
			PRIMARY KEY (`line_id`), KEY `entry_id` (`entry_id`), KEY `account` (`account`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}expense` (
			`expense_id` INT NOT NULL AUTO_INCREMENT, `date` DATE NOT NULL, `supplier` VARCHAR(160) NOT NULL DEFAULT '', `number` VARCHAR(64) NOT NULL DEFAULT '',
			`currency` VARCHAR(3) NOT NULL DEFAULT 'EUR', `amount` DECIMAL(15,2) NOT NULL DEFAULT 0, `rate` DECIMAL(15,8) NOT NULL DEFAULT 1, `amount_eur` DECIMAL(15,2) NOT NULL DEFAULT 0,
			`account` VARCHAR(10) NOT NULL, `paid` VARCHAR(10) NOT NULL DEFAULT '5310', `nonbiz` TINYINT NOT NULL DEFAULT 0,
			`file` VARCHAR(255) NOT NULL DEFAULT '', `file_name` VARCHAR(255) NOT NULL DEFAULT '', `note` TEXT, `status` VARCHAR(8) NOT NULL DEFAULT 'posted', `created` DATETIME NOT NULL,
			PRIMARY KEY (`expense_id`), KEY `date` (`date`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}bank` (
			`tx_id` INT NOT NULL AUTO_INCREMENT, `account` VARCHAR(10) NOT NULL, `date` DATE NOT NULL, `amount` DECIMAL(15,2) NOT NULL,
			`counterparty` VARCHAR(160) NOT NULL DEFAULT '', `iban` VARCHAR(40) NOT NULL DEFAULT '', `details` VARCHAR(500) NOT NULL DEFAULT '', `bank_ref` VARCHAR(64) NOT NULL DEFAULT '',
			`hash` CHAR(32) NOT NULL, `contra` VARCHAR(10) NOT NULL DEFAULT '', `doc` VARCHAR(64) NOT NULL DEFAULT '', `status` VARCHAR(8) NOT NULL DEFAULT 'open',
			`file` VARCHAR(160) NOT NULL DEFAULT '', `created` DATETIME NOT NULL,
			PRIMARY KEY (`tx_id`), UNIQUE KEY `hash` (`hash`), KEY `status` (`status`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}rule` (
			`rule_id` INT NOT NULL AUTO_INCREMENT, `match` VARCHAR(160) NOT NULL, `account` VARCHAR(10) NOT NULL, `created` DATETIME NOT NULL,
			PRIMARY KEY (`rule_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}dividend` (
			`dividend_id` INT NOT NULL AUTO_INCREMENT, `date` DATE NOT NULL, `amount` DECIMAL(15,2) NOT NULL, `note` VARCHAR(255) NOT NULL DEFAULT '', `status` VARCHAR(8) NOT NULL DEFAULT 'posted', `created` DATETIME NOT NULL,
			PRIMARY KEY (`dividend_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$q("CREATE TABLE IF NOT EXISTS `{$P}filing` (
			`filing_id` INT NOT NULL AUTO_INCREMENT, `kind` VARCHAR(8) NOT NULL, `period` VARCHAR(10) NOT NULL, `due` DATE NOT NULL,
			`status` VARCHAR(10) NOT NULL DEFAULT 'todo', `amount` DECIMAL(15,2) NOT NULL DEFAULT 0, `file` VARCHAR(160) NOT NULL DEFAULT '', `data` MEDIUMTEXT,
			`eds_no` VARCHAR(64) NOT NULL DEFAULT '', `reminded` VARCHAR(255) NOT NULL DEFAULT '', `generated` DATETIME NULL, `submitted` DATETIME NULL, `note` VARCHAR(255) NOT NULL DEFAULT '',
			PRIMARY KEY (`filing_id`), UNIQUE KEY `kp` (`kind`, `period`), KEY `due` (`due`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	private function ready() {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape($this->P . 'filing') . "'")->num_rows;
	}

	// Latvian chart of accounts, mapped to the annual report rows (BA = assets, BP = equity and liabilities,
	// PZ = profit or loss by function, PZA2) and to the UIN declaration where a cost is taxable.
	private function chart() {
		return array(
			array('1110', 'Programmatūra un licences', 'Software and licences', 'a', 'BA:R40', ''),
			array('1210', 'Datortehnika un iekārtas', 'Computers and equipment', 'a', 'BA:R190', ''),
			array('1290', 'Pamatlīdzekļu nolietojums', 'Depreciation so far (equipment)', 'a', 'BA:R190', ''),
			array('2110', 'Detaļas un materiāli', 'Parts and materials in stock', 'a', 'BA:R370', ''),
			array('2130', 'Gatavie ražojumi un preces', 'Finished products and goods in stock', 'a', 'BA:R390', ''),
			array('2190', 'Avansi par krājumiem', 'Prepaid stock orders', 'a', 'BA:R400', ''),
			array('2310', 'Pircēju parādi', 'Owed by customers and sales channels', 'a', 'BA:R470', 'recv'),
			array('2370', 'Nodokļu pārmaksa', 'Tax overpaid', 'a', 'BA:R500', ''),
			array('2380', 'Citi debitori', 'Other amounts owed to the company', 'a', 'BA:R500', ''),
			array('2390', 'Aizdevumi dalībniekiem un vadībai', 'Loans to you (owner, board)', 'a', 'BA:R520', 'loan'),
			array('2410', 'Nākamo periodu izmaksas', 'Costs paid in advance', 'a', 'BA:R530', ''),
			array('2510', 'Neapmaksātais pamatkapitāls', 'Share capital not paid in yet', 'a', 'BA:R510', ''),
			array('2610', 'Kase', 'Cash', 'a', 'BA:R620', 'money'),
			array('2620', 'Norēķinu konts bankā', 'Bank account', 'a', 'BA:R620', 'money'),
			array('2630', 'Stripe konts', 'Stripe balance', 'a', 'BA:R620', 'money'),
			array('2640', 'PayPal konts', 'PayPal balance', 'a', 'BA:R620', 'money'),
			array('3110', 'Pamatkapitāls', 'Share capital', 'e', 'BP:R660', ''),
			array('3410', 'Iepriekšējo gadu nesadalītā peļņa', 'Profit kept from earlier years', 'e', 'BP:R780', ''),
			array('5150', 'Neizmaksātās dividendes', 'Dividends declared, not paid yet', 'l', 'BP:R1150', 'div'),
			array('5210', 'Aizņēmums no dalībnieka', 'Loan from you (owner)', 'l', 'BP:R1060', ''),
			array('5310', 'Parādi piegādātājiem', 'Owed to suppliers', 'l', 'BP:R1080', 'pay'),
			array('5320', 'No pircējiem saņemtie avansi', 'Customer prepayments', 'l', 'BP:R1070', ''),
			array('5590', 'Parādi valdes loceklim (avansa norēķini)', 'Owed to you for company costs you paid', 'l', 'BP:R1130', 'owner'),
			array('5610', 'Darba alga', 'Wages to pay', 'l', 'BP:R1130', ''),
			array('5710', 'Nodokļi (vienotais nodokļu konts)', 'Taxes to pay (VID)', 'l', 'BP:R1120', 'tax'),
			array('5800', 'Uzkrātās saistības', 'Costs owed but not invoiced yet', 'l', 'BP:R1160', ''),
			array('5910', 'Pārējie kreditori', 'Other amounts owed', 'l', 'BP:R1130', ''),
			array('6110', 'Ieņēmumi: preces', 'Sales: goods', 'i', 'PZ:R30', ''),
			array('6120', 'Ieņēmumi: programmatūras licences', 'Sales: firmware and software licences', 'i', 'PZ:R30', ''),
			array('6130', 'Ieņēmumi: piegāde', 'Sales: shipping charged', 'i', 'PZ:R30', ''),
			array('6310', 'Pārējie ieņēmumi', 'Other income', 'i', 'PZ:R80', ''),
			array('6320', 'Valūtas kursa peļņa', 'Currency gains', 'i', 'PZ:R80', ''),
			array('7110', 'Pārdoto preču pašizmaksa', 'Cost of goods sold', 'x', 'PZ:R40', ''),
			array('7120', 'Ražošanas materiāli (filaments, iepakojums)', 'Production materials (filament, packaging)', 'x', 'PZ:R40', ''),
			array('7190', 'Krājumos iekļautās ražošanas izmaksas', 'Production costs moved into stock', 'x', 'PZ:R40', ''),
			array('7130', 'Piegādes izmaksas', 'Shipping to customers', 'x', 'PZ:R60', ''),
			array('7140', 'Tirdzniecības platformu komisijas', 'Marketplace fees', 'x', 'PZ:R60', ''),
			array('7150', 'Reklāma', 'Advertising', 'x', 'PZ:R60', ''),
			array('7210', 'Darba alga', 'Wages', 'x', 'PZ:R70', ''),
			array('7220', 'Darba devēja VSAOI', 'Employer social tax', 'x', 'PZ:R70', ''),
			array('7410', 'Nolietojums', 'Depreciation', 'x', 'PZ:R70', ''),
			array('7510', 'Bankas un maksājumu komisijas', 'Bank and payment fees', 'x', 'PZ:R70', ''),
			array('7520', 'Hostings, domēni, programmatūra', 'Hosting, domains, software', 'x', 'PZ:R70', ''),
			array('7530', 'Grāmatvedības un juridiskie pakalpojumi', 'Accounting and legal', 'x', 'PZ:R70', ''),
			array('7540', 'Biroja izdevumi un sakari', 'Office and phone', 'x', 'PZ:R70', ''),
			array('7550', 'Instrumenti un sīkinventārs', 'Tools and small equipment', 'x', 'PZ:R70', ''),
			array('7560', 'Komandējumi', 'Travel', 'x', 'PZ:R70', ''),
			array('7590', 'Citi saimnieciskās darbības izdevumi', 'Other business costs', 'x', 'PZ:R70', ''),
			array('7570', 'Valūtas kursa zaudējumi', 'Currency losses', 'x', 'PZ:R90', ''),
			array('7580', 'Ar saimniecisko darbību nesaistīti izdevumi', 'Costs not for the business', 'x', 'PZ:R90', 'R06_1'),
			array('7610', 'Soda un nokavējuma naudas', 'Fines and late-payment interest', 'x', 'PZ:R90', 'R06_1'),
			array('8110', 'Procentu ieņēmumi', 'Interest received', 'i', 'PZ:R190', ''),
			array('8210', 'Procentu maksājumi', 'Interest paid', 'x', 'PZ:R230', ''),
			array('8610', 'Uzņēmumu ienākuma nodoklis', 'Corporate income tax', 'x', 'PZ:R250', ''),
		);
	}

	private function seedAccounts() {
		$i = 0;
		foreach ($this->chart() as $a) {
			$i += 10;
			$this->db->query("INSERT IGNORE INTO `{$this->P}account` SET code = '" . $this->e($a[0]) . "', name = '" . $this->e($a[1]) . "', name_en = '" . $this->e($a[2]) . "', type = '" . $this->e($a[3]) . "', gp = '" . $this->e($a[4]) . "', tag = '" . $this->e($a[5]) . "', sort = '" . $i . "'");
		}
	}

	// ================================================================== settings (kept in oc_setting, read fresh)
	private function sdefaults() {
		$def = array(
			'company' => '', 'reg_no' => '', 'address' => '', 'registered' => '', 'email' => (string)$this->config->get('config_email'), 'phone' => '',
			'books_start' => date('Y-01-01'), 'fy_start' => 1, 'board_name' => '', 'board_title' => 'Valdes loceklis',
			'employees' => 0, 'vat' => 0, 'vat_no' => '', 'gp_months' => 5,
			'remind_email' => (string)$this->config->get('config_email'), 'remind_days' => '7,2,0', 'remind_on' => 1,
			'pay_map' => json_encode(array('stripe' => '2630', 'pp_express' => '2640', 'pp_standard' => '2640', 'paypal' => '2640', 'bank_transfer' => '2310', 'cod' => '2310')),
			'inv_other' => '7120', 'sync_shop' => 1, 'sync_stock' => 1, 'locked_until' => '', 'last_tick' => '',
			'policy' => 'Gada pārskats sagatavots saskaņā ar Gada pārskatu un konsolidēto gada pārskatu likumu, pieņemot, ka sabiedrība darbosies arī turpmāk. Krājumi novērtēti pēc iegādes izmaksām, izmantojot vidējo svērto metodi. Ieņēmumi atzīti, kad prece nodota pircējam vai pakalpojums sniegts. Izmaksas atzītas uzkrāšanas principā.',
		);
		foreach ($def as $k => $v) {
			if ($this->sget($k, null) === null) {
				$this->sset($k, $v);
			}
		}
	}

	private function sload() {
		if ($this->S === null) {
			$this->S = array();
			foreach ($this->db->query("SELECT `key`, `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'module_dpc_books'")->rows as $r) {
				$this->S[substr($r['key'], strlen('module_dpc_books_'))] = $r['value'];
			}
		}
		return $this->S;
	}
	private function sget($k, $def = '') { $s = $this->sload(); return array_key_exists($k, $s) ? $s[$k] : $def; }
	private function sset($k, $v) {
		$key = 'module_dpc_books_' . $k;
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'module_dpc_books' AND `key` = '" . $this->e($key) . "' AND store_id = 0");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = 0, `code` = 'module_dpc_books', `key` = '" . $this->e($key) . "', `value` = '" . $this->e((string)$v) . "', serialized = 0");
		$this->sload();
		$this->S[$k] = (string)$v;
	}

	// ================================================================== page
	public function index() {
		if (!$this->ready()) {
			$this->tables();
			$this->seedAccounts();
		}
		$this->sdefaults();
		$this->document->setTitle('Books');
		$token = 'user_token=' . $this->session->data['user_token'];
		$data['api'] = html_entity_decode($this->url->link('extension/module/dpc_books/api', $token, true), ENT_QUOTES, 'UTF-8');
		$data['file'] = html_entity_decode($this->url->link('extension/module/dpc_books/file', $token, true), ENT_QUOTES, 'UTF-8');
		$data['stock_file'] = html_entity_decode($this->url->link('extension/module/dpc_stock/file', $token, true), ENT_QUOTES, 'UTF-8');
		$data['desk'] = $this->url->link('extension/module/dpc_desk/desk', $token, true);
		$data['can_modify'] = $this->user->hasPermission('modify', 'extension/module/dpc_books') ? 1 : 0;
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_books', $data));
	}

	// ================================================================== helpers
	private function e($s) { return $this->db->escape((string)$s); }
	private function n($v) { return is_numeric($v) ? (float)$v : (float)str_replace(array(',', ' '), array('.', ''), (string)$v); }
	private function d($v) { $t = strtotime((string)$v); return $t ? date('Y-m-d', $t) : date('Y-m-d'); }
	private function m2($v) { return round((float)$v + 0.0, 2); }
	private function input() {
		$raw = file_get_contents('php://input');
		$j = json_decode($raw, true);
		return is_array($j) ? $j : $this->request->post;
	}
	private function in($in, $k, $def = '') { return isset($in[$k]) ? $in[$k] : $def; }
	private function out($x) {
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($x));
	}
	private function fail($msg) { $this->out(array('error' => $msg)); }
	private function hasTable($t) { return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e(DB_PREFIX . $t) . "'")->num_rows; }
	private function accounts() {
		$o = array();
		foreach ($this->db->query("SELECT * FROM `{$this->P}account` ORDER BY sort, code")->rows as $a) {
			$o[$a['code']] = $a;
		}
		return $o;
	}
	private function userName() { return method_exists($this->user, 'getUserName') ? (string)$this->user->getUserName() : ''; }

	// Financial year containing a date: array(start, end)
	private function fy($date) {
		$m = max(1, min(12, (int)$this->sget('fy_start', 1)));
		$t = strtotime($date);
		$y = (int)date('Y', $t);
		if ((int)date('n', $t) < $m) {
			$y--;
		}
		$s = sprintf('%04d-%02d-01', $y, $m);
		return array($s, date('Y-m-d', strtotime($s . ' +1 year -1 day')));
	}
	// The reporting period a date falls in; the first one starts on the day the SIA was registered
	private function period($date) {
		list($fs, $fe) = $this->fy($date);
		$reg = $this->sget('registered', '');
		if ($reg !== '' && $reg > $fs && $reg <= $fe) {
			$fs = $reg;
		}
		return array($fs, $fe);
	}

	private function fyLabel($start) {
		return (int)$this->sget('fy_start', 1) === 1 ? substr($start, 0, 4) : substr($start, 0, 7);
	}

	// ================================================================== the ledger
	// Posts an entry once per source key. If the source changed and its date is still open, the lines
	// are rewritten; if the period is locked, the difference is posted as a correction on the first open day.
	private function post($src, $date, $kind, $ref, $descr, $lines) {
		$lines = $this->normLines($lines);
		$date = $this->d($date);
		$hash = md5(json_encode($lines) . '|' . $date . '|' . $descr);
		$old = $this->db->query("SELECT * FROM `{$this->P}entry` WHERE src = '" . $this->e($src) . "'")->row;
		if ($old && $old['hash'] === $hash) {
			return (int)$old['entry_id'];
		}
		if (!$old) {
			if ($this->isLocked($date)) {
				$date = $this->firstOpenDay();
			}
			// An entry with no lines is kept as a marker, so the document is not posted again
			return $this->insertEntry($src, $date, $kind, $ref, $descr, $lines, $hash);
		}
		if (!$this->isLocked($old['date']) && !$this->isLocked($date)) {
			$this->db->query("DELETE FROM `{$this->P}line` WHERE entry_id = '" . (int)$old['entry_id'] . "'");
			$this->db->query("UPDATE `{$this->P}entry` SET date = '" . $this->e($date) . "', ref = '" . $this->e(mb_substr($ref, 0, 128)) . "', descr = '" . $this->e(mb_substr($descr !== '' ? $descr : $old['descr'], 0, 255)) . "', hash = '" . $this->e($hash) . "' WHERE entry_id = '" . (int)$old['entry_id'] . "'");
			$this->writeLines((int)$old['entry_id'], $lines);
			return (int)$old['entry_id'];
		}
		// The period is closed: post only the difference, dated on the first open day
		$was = $this->db->query("SELECT l.account, l.partner, SUM(l.debit - l.credit) AS net FROM `{$this->P}line` l JOIN `{$this->P}entry` e ON e.entry_id = l.entry_id WHERE e.src = '" . $this->e($src) . "' OR e.src LIKE '" . $this->e($src) . "#fix%' GROUP BY l.account, l.partner")->rows;
		$net = array();
		foreach ($was as $w) {
			$net[$w['account'] . '|' . $w['partner']] = -(float)$w['net'];
		}
		foreach ($lines as $l) {
			$k = $l['account'] . '|' . $l['partner'];
			$net[$k] = (isset($net[$k]) ? $net[$k] : 0) + $l['debit'] - $l['credit'];
		}
		$fix = array();
		foreach ($net as $k => $v) {
			if (abs($v) >= 0.005) {
				list($acc, $partner) = explode('|', $k, 2);
				$fix[] = array('account' => $acc, 'debit' => $v > 0 ? $v : 0, 'credit' => $v < 0 ? -$v : 0, 'partner' => $partner);
			}
		}
		$this->db->query("UPDATE `{$this->P}entry` SET hash = '" . $this->e($hash) . "' WHERE entry_id = '" . (int)$old['entry_id'] . "'");
		if ($fix) {
			$n = 1 + (int)$this->db->query("SELECT COUNT(*) AS n FROM `{$this->P}entry` WHERE src LIKE '" . $this->e($src) . "#fix%'")->row['n'];
			return $this->insertEntry($src . '#fix' . $n, $this->firstOpenDay(), 'fix', $ref, 'Correction: ' . ($descr !== '' ? $descr : $old['descr']), $fix, '');
		}
		return (int)$old['entry_id'];
	}

	private function insertEntry($src, $date, $kind, $ref, $descr, $lines, $hash) {
		$lines = $this->normLines($lines);
		$this->db->query("INSERT INTO `{$this->P}entry` SET date = '" . $this->e($date) . "', kind = '" . $this->e($kind) . "', src = '" . $this->e($src) . "', ref = '" . $this->e(mb_substr($ref, 0, 128)) . "', descr = '" . $this->e(mb_substr($descr, 0, 255)) . "', hash = '" . $this->e($hash) . "', user = '" . $this->e($this->userName()) . "', created = NOW()");
		$id = (int)$this->db->getLastId();
		$this->writeLines($id, $lines);
		return $id;
	}

	private function writeLines($id, $lines) {
		foreach ($lines as $l) {
			$this->db->query("INSERT INTO `{$this->P}line` SET entry_id = '" . (int)$id . "', account = '" . $this->e($l['account']) . "', debit = '" . $l['debit'] . "', credit = '" . $l['credit'] . "', partner = '" . $this->e(mb_substr($l['partner'], 0, 160)) . "', note = '" . $this->e(mb_substr($l['note'], 0, 255)) . "'");
		}
	}

	// Rounds to cents, drops zero lines, merges same account+partner, and checks the entry balances
	private function normLines($lines) {
		$m = array();
		foreach ($lines as $l) {
			$acc = (string)$l['account'];
			$partner = isset($l['partner']) ? (string)$l['partner'] : '';
			$note = isset($l['note']) ? (string)$l['note'] : '';
			$v = round((isset($l['debit']) ? (float)$l['debit'] : 0) - (isset($l['credit']) ? (float)$l['credit'] : 0), 2);
			$k = $acc . '|' . $partner . '|' . $note;
			$m[$k] = array('account' => $acc, 'partner' => $partner, 'note' => $note, 'v' => (isset($m[$k]) ? $m[$k]['v'] : 0) + $v);
		}
		$out = array();
		$sum = 0;
		foreach ($m as $x) {
			$v = round($x['v'], 2);
			if (abs($v) < 0.005) {
				continue;
			}
			$sum += $v;
			$out[] = array('account' => $x['account'], 'partner' => $x['partner'], 'note' => $x['note'], 'debit' => $v > 0 ? $v : 0, 'credit' => $v < 0 ? -$v : 0);
		}
		if (abs(round($sum, 2)) >= 0.005) {
			throw new Exception('The entry does not balance (difference ' . number_format($sum, 2, '.', '') . ' EUR).');
		}
		return $out;
	}

	private function isLocked($date) {
		$l = $this->sget('locked_until', '');
		return $l !== '' && $date <= $l;
	}
	private function firstOpenDay() {
		$l = $this->sget('locked_until', '');
		$d = date('Y-m-d');
		return ($l !== '' && $d <= $l) ? date('Y-m-d', strtotime($l . ' +1 day')) : $d;
	}

	// Net movement (debit - credit) per account between two dates (inclusive)
	private function movements($from, $to, $where = '') {
		$sql = "SELECT l.account, SUM(l.debit) AS d, SUM(l.credit) AS c FROM `{$this->P}line` l JOIN `{$this->P}entry` e ON e.entry_id = l.entry_id WHERE 1";
		if ($from) {
			$sql .= " AND e.date >= '" . $this->e($from) . "'";
		}
		if ($to) {
			$sql .= " AND e.date <= '" . $this->e($to) . "'";
		}
		$sql .= $where . " GROUP BY l.account";
		$o = array();
		foreach ($this->db->query($sql)->rows as $r) {
			$o[$r['account']] = array('d' => (float)$r['d'], 'c' => (float)$r['c'], 'net' => round((float)$r['d'] - (float)$r['c'], 2));
		}
		return $o;
	}

	// ================================================================== bringing in the shop and stock documents
	private function countedStatuses() {
		$saved = $this->config->get('dashboard_dpc_sales_statuses');
		if (is_array($saved) && $saved) {
			return array_values(array_filter(array_map('intval', $saved)));
		}
		$ids = array();
		foreach (array('config_processing_status', 'config_complete_status') as $key) {
			$v = $this->config->get($key);
			foreach ((is_array($v) ? $v : array($v)) as $id) {
				$ids[(int)$id] = true;
			}
		}
		unset($ids[(int)$this->config->get('config_order_status_id')], $ids[0]);
		return array_keys($ids);
	}

	private function sync() {
		$start = $this->sget('books_start', date('Y-01-01'));
		$n = 0;
		if ((int)$this->sget('sync_shop', 1) && $this->hasTable('order')) {
			$n += $this->syncOrders($start);
		}
		if ((int)$this->sget('sync_stock', 1) && $this->hasTable('dpc_inv_invoice')) {
			$n += $this->syncStock($start);
		}
		return $n;
	}

	private function syncOrders($start) {
		$P = DB_PREFIX;
		$counted = $this->countedStatuses();
		if (!$counted) {
			return 0;
		}
		$in = implode(',', array_map('intval', $counted));
		$map = json_decode($this->sget('pay_map', '{}'), true);
		$map = is_array($map) ? $map : array();
		$stockLinked = $this->hasTable('dpc_inv_item');
		$n = 0;
		// Orders that are (or were) counted as sales since the books started
		$posted = array();
		foreach ($this->db->query("SELECT src FROM `{$this->P}entry` WHERE src LIKE 'order:%'")->rows as $r) {
			$posted[$r['src']] = true;
		}
		$orders = $this->db->query("SELECT o.order_id, o.date_added, o.total, o.currency_code, o.payment_code, o.payment_method, o.order_status_id, o.firstname, o.lastname, o.payment_company
			FROM `{$P}order` o WHERE o.date_added >= '" . $this->e($start) . " 00:00:00' AND (o.order_status_id IN (" . $in . ") OR o.order_id IN (SELECT CAST(SUBSTRING(src, 7) AS UNSIGNED) FROM `{$this->P}entry` WHERE src LIKE 'order:%' AND src NOT LIKE '%:%:%'))")->rows;
		foreach ($orders as $o) {
			$id = (int)$o['order_id'];
			$isSale = in_array((int)$o['order_status_id'], $counted, true);
			// How many times this order was booked and reversed
			$k = 'order:' . $id;
			$ups = isset($posted[$k]) ? 1 : 0;
			$downs = 0;
			for ($i = 1; isset($posted[$k . ':rev' . $i]); $i++) {
				$downs++;
				if (isset($posted[$k . ':re' . $i])) {
					$ups++;
				}
			}
			$live = $ups > $downs;
			if ($isSale && !$live) {
				$lines = $this->orderLines($o, $map, $stockLinked);
				$src = $ups === 0 ? $k : $k . ':re' . $downs;
				$this->post($src, $ups === 0 ? substr($o['date_added'], 0, 10) : date('Y-m-d'), 'order', 'Order #' . $id, 'Shop order #' . $id . ' ' . trim($o['firstname'] . ' ' . $o['lastname']), $lines);
				$n++;
			} elseif (!$isSale && $live) {
				// Cancelled or refunded after it was booked: reverse what was booked
				$lines = array();
				foreach ($this->db->query("SELECT l.* FROM `{$this->P}line` l JOIN `{$this->P}entry` e ON e.entry_id = l.entry_id WHERE e.src = '" . $this->e($ups === 1 && $downs === 0 ? $k : $k . ':re' . $downs) . "'")->rows as $l) {
					$lines[] = array('account' => $l['account'], 'debit' => $l['credit'], 'credit' => $l['debit'], 'partner' => $l['partner'], 'note' => $l['note']);
				}
				$this->post($k . ':rev' . ($downs + 1), date('Y-m-d'), 'order', 'Order #' . $id, 'Order #' . $id . ' cancelled or refunded', $lines);
				$n++;
			}
		}
		return $n;
	}

	private function orderLines($o, $map, $stockLinked) {
		$P = DB_PREFIX;
		$id = (int)$o['order_id'];
		$code = strtolower(preg_replace('/\..*$/', '', (string)$o['payment_code']));
		$money = isset($map[$code]) && $map[$code] !== '' ? $map[$code] : '2310';
		$who = trim($o['firstname'] . ' ' . $o['lastname']) . ($o['payment_company'] ? ' (' . $o['payment_company'] . ')' : '');
		$total = (float)$o['total'];
		$goods = 0.0;
		$digital = 0.0;
		$cogs = 0.0;
		$hasShipFlag = (bool)$this->db->query("SHOW COLUMNS FROM `{$P}product` LIKE 'shipping'")->num_rows;
		$rows = $this->db->query("SELECT op.product_id, op.quantity, op.total, op.tax" . ($hasShipFlag ? ", p.shipping" : ", 1 AS shipping") . " FROM `{$P}order_product` op LEFT JOIN `{$P}product` p ON p.product_id = op.product_id WHERE op.order_id = '" . $id . "'")->rows;
		foreach ($rows as $r) {
			$v = (float)$r['total'];
			if ((int)$r['shipping'] === 0) {
				$digital += $v;
			} else {
				$goods += $v;
			}
			if ($stockLinked) {
				$it = $this->db->query("SELECT avg_cost FROM `{$P}dpc_inv_item` WHERE product_id = '" . (int)$r['product_id'] . "' AND status = 1 AND kind = 'product' LIMIT 1")->row;
				if ($it) {
					$cogs += (float)$it['avg_cost'] * (float)$r['quantity'];
				}
			}
		}
		$ship = 0.0;
		if ($this->hasTable('order_total')) {
			$s = $this->db->query("SELECT COALESCE(SUM(value), 0) AS v FROM `{$P}order_total` WHERE order_id = '" . $id . "' AND code = 'shipping'")->row;
			$ship = (float)$s['v'];
		}
		// Discounts, coupons and anything else in the total land on goods (or licences if there are no goods)
		$rest = round($total - $goods - $digital - $ship, 2);
		if ($goods > 0 || $digital <= 0) {
			$goods += $rest;
		} else {
			$digital += $rest;
		}
		$lines = array(
			array('account' => $money, 'debit' => $total, 'partner' => $who, 'note' => (string)$o['payment_method']),
			array('account' => '6110', 'credit' => $goods),
			array('account' => '6120', 'credit' => $digital),
			array('account' => '6130', 'credit' => $ship),
		);
		if ($cogs > 0) {
			$lines[] = array('account' => '7110', 'debit' => $cogs, 'note' => 'Cost of the units sold');
			$lines[] = array('account' => '2130', 'credit' => $cogs);
		}
		return $lines;
	}

	private function syncStock($start) {
		$P = DB_PREFIX . 'dpc_inv_';
		$n = 0;
		$other = $this->sget('inv_other', '7120');
		// Received supplier invoices -> stock, owed to the supplier
		foreach ($this->db->query("SELECT i.*, s.name AS supplier FROM `{$P}invoice` i LEFT JOIN `{$P}supplier` s ON s.supplier_id = i.supplier_id WHERE i.status = 'received' AND i.date >= '" . $this->e($start) . "'")->rows as $inv) {
			$lines = array();
			$sum = 0.0;
			foreach ($this->db->query("SELECT l.*, it.kind FROM `{$P}invoice_line` l LEFT JOIN `{$P}item` it ON it.item_id = l.item_id WHERE l.invoice_id = '" . (int)$inv['invoice_id'] . "'")->rows as $l) {
				if (!(int)$l['item_id']) {
					continue;
				}
				$v = round((float)$l['landed_eur'] * (float)$l['qty'], 2);
				$sum += $v;
				$lines[] = array('account' => $l['kind'] === 'product' ? '2130' : '2110', 'debit' => $v, 'note' => (string)$l['descr']);
			}
			$total = round((float)$inv['total_eur'], 2);
			$lines[] = array('account' => $other, 'debit' => round($total - $sum, 2), 'note' => 'Not stocked: lines without an item, rounding');
			$who = $inv['supplier'] ?: 'Supplier';
			$lines[] = array('account' => '5310', 'credit' => $total, 'partner' => $who);
			$this->post('inv:' . $inv['invoice_id'], $inv['date'], 'invoice', ($inv['number'] ? $inv['number'] : '#' . $inv['invoice_id']), 'Supplier invoice ' . $who . ' ' . $inv['number'], $lines);
			$n++;
		}
		// Build batches: parts out of stock, finished products in at their cash cost
		foreach ($this->db->query("SELECT b.*, it.name FROM `{$P}batch` b LEFT JOIN `{$P}item` it ON it.item_id = b.item_id WHERE b.date >= '" . $this->e($start) . "'")->rows as $b) {
			$cash = round((float)$b['cash_cost'], 2);
			$parts = round((float)$b['parts_cost'], 2);
			$this->post('batch:' . $b['batch_id'], $b['date'], 'batch', 'Batch #' . $b['batch_id'], 'Build batch #' . $b['batch_id'] . ' ' . $b['name'] . ' (' . (int)$b['passed'] . ' passed)', array(
				array('account' => '2130', 'debit' => $cash),
				array('account' => '2110', 'credit' => $parts),
				array('account' => '7190', 'credit' => round($cash - $parts, 2), 'note' => 'Printing, packaging and extras moved into stock'),
			));
			$n++;
		}
		// Sales outside the shop
		foreach ($this->db->query("SELECT s.*, it.name FROM `{$P}sale` s LEFT JOIN `{$P}item` it ON it.item_id = s.item_id WHERE s.date >= '" . $this->e($start) . "'")->rows as $s) {
			$rev = round((float)$s['qty'] * (float)$s['price_each'], 2);
			$fees = round((float)$s['fees'], 2);
			$ship = round((float)$s['shipping'], 2);
			$cost = round((float)$s['qty'] * (float)$s['unit_cost'], 2);
			$this->post('sale:' . $s['sale_id'], $s['date'], 'sale', $s['channel'], 'Sale on ' . $s['channel'] . ': ' . (float)$s['qty'] . ' x ' . $s['name'], array(
				array('account' => '2310', 'debit' => $rev - $fees - $ship, 'partner' => $s['channel']),
				array('account' => '7140', 'debit' => $fees),
				array('account' => '7130', 'debit' => $ship),
				array('account' => '6110', 'credit' => $rev),
				array('account' => '7110', 'debit' => $cost),
				array('account' => '2130', 'credit' => $cost),
			));
			$n++;
		}
		return $n;
	}

	// ================================================================== API
	public function api() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_books')) {
			return $this->fail('No access to Books.');
		}
		if (!$this->ready()) {
			$this->tables();
			$this->seedAccounts();
		}
		$this->sdefaults();
		$f = isset($this->request->get['f']) ? $this->request->get['f'] : 'state';
		$writes = array('settings', 'save_account', 'sync', 'save_expense', 'void_expense', 'upload', 'bank_import', 'bank_assign', 'bank_reopen', 'save_entry', 'reverse_entry', 'dividend', 'void_dividend', 'build', 'mark', 'rule_delete');
		if (in_array($f, $writes, true) && !$this->user->hasPermission('modify', 'extension/module/dpc_books')) {
			return $this->fail('You can look but not change the books.');
		}
		$m = 'f_' . $f;
		if (!method_exists($this, $m)) {
			return $this->fail('Unknown request.');
		}
		try {
			$this->$m();
		} catch (\Throwable $e) {
			$this->fail($e->getMessage());
		}
	}

	private function f_state() {
		$synced = 0;
		$err = '';
		try {
			$synced = $this->sync();
		} catch (\Throwable $e) {
			$err = $e->getMessage();
		}
		$this->plan();
		try {
			$this->remind();
		} catch (\Throwable $e) {
		}
		$today = date('Y-m-d');
		list($fs, $fe) = $this->fy($today);
		$acc = $this->accounts();
		$all = $this->movements('', $today);
		$year = $this->movements($fs, $today);
		$money = array();
		foreach ($acc as $code => $a) {
			if ($a['tag'] === 'money' || in_array($a['tag'], array('recv', 'pay', 'owner', 'tax', 'div'), true)) {
				$v = isset($all[$code]) ? $all[$code]['net'] : 0;
				if ($a['type'] !== 'a') {
					$v = -$v;
				}
				$money[] = array('code' => $code, 'name' => $a['name_en'], 'tag' => $a['tag'], 'balance' => round($v, 2));
			}
		}
		$pl = $this->plFrom($year, $acc);
		$filings = $this->db->query("SELECT filing_id, kind, period, due, status, amount, eds_no, generated, submitted, note, file FROM `{$this->P}filing` WHERE status IN ('todo','ready','check') OR (due >= '" . $this->e(date('Y-m-d', strtotime('-60 days'))) . "') ORDER BY due, kind LIMIT 60")->rows;
		foreach ($filings as &$fl) {
			$fl['title'] = $this->filingTitle($fl['kind'], $fl['period']);
			$fl['days'] = (int)floor((strtotime($fl['due']) - strtotime($today)) / 86400);
		}
		unset($fl);
		$this->out(array(
			'settings' => $this->publicSettings(),
			'accounts' => array_values($acc),
			'money' => $money,
			'year' => array('from' => $fs, 'to' => $fe, 'label' => $this->fyLabel($fs), 'pl' => $pl),
			'filings' => $filings,
			'todo' => array(
				'bank' => (int)$this->db->query("SELECT COUNT(*) AS n FROM `{$this->P}bank` WHERE status = 'open'")->row['n'],
				'drafts' => $this->hasTable('dpc_inv_invoice') ? (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_inv_invoice` WHERE status = 'draft'")->row['n'] : 0,
			),
			'limits' => $this->limits($today),
			'checks' => $this->checks($today),
			'synced' => $synced,
			'sync_error' => $err,
			'today' => $today,
		));
	}

	private function publicSettings() {
		$s = $this->sload();
		$s['pay_map'] = json_decode(isset($s['pay_map']) ? $s['pay_map'] : '{}', true) ?: array();
		unset($s['last_tick']);
		// Payment methods the shop has used, so they can be mapped to a money account
		$s['pay_codes'] = array();
		if ($this->hasTable('order')) {
			foreach ($this->db->query("SELECT payment_code, MAX(payment_method) AS name, COUNT(*) AS n FROM `" . DB_PREFIX . "order` WHERE payment_code <> '' GROUP BY payment_code ORDER BY n DESC LIMIT 20")->rows as $r) {
				$s['pay_codes'][] = array('code' => strtolower(preg_replace('/\..*$/', '', $r['payment_code'])), 'name' => html_entity_decode(strip_tags($r['name']), ENT_QUOTES, 'UTF-8'), 'n' => (int)$r['n']);
			}
		}
		return $s;
	}

	private function f_settings() {
		$in = $this->input();
		$keys = array('company', 'reg_no', 'address', 'registered', 'email', 'phone', 'books_start', 'fy_start', 'board_name', 'board_title', 'employees', 'vat', 'vat_no', 'gp_months', 'remind_email', 'remind_days', 'remind_on', 'inv_other', 'sync_shop', 'sync_stock', 'policy');
		foreach ($keys as $k) {
			if (!array_key_exists($k, $in)) {
				continue;
			}
			$v = is_string($in[$k]) ? trim($in[$k]) : $in[$k];
			if ($k === 'reg_no') {
				$v = preg_replace('/\D/', '', (string)$v);
				if ($v !== '' && strlen($v) !== 11) {
					return $this->fail('The registration number has 11 digits.');
				}
			}
			if (in_array($k, array('books_start', 'registered'), true) && $v !== '') {
				$v = $this->d($v);
			}
			if (in_array($k, array('fy_start', 'gp_months', 'employees', 'vat', 'remind_on', 'sync_shop', 'sync_stock'), true)) {
				$v = (int)$v;
			}
			$this->sset($k, $v);
		}
		if (isset($in['pay_map']) && is_array($in['pay_map'])) {
			$clean = array();
			foreach ($in['pay_map'] as $code => $acc) {
				$clean[preg_replace('/[^a-z0-9_]/', '', strtolower($code))] = preg_replace('/\D/', '', (string)$acc);
			}
			$this->sset('pay_map', json_encode($clean));
		}
		$this->plan(true);
		$this->out(array('ok' => 1, 'settings' => $this->publicSettings()));
	}

	private function f_save_account() {
		$in = $this->input();
		$code = preg_replace('/\D/', '', (string)$this->in($in, 'code'));
		if (strlen($code) < 4) {
			return $this->fail('Use a 4-digit account number.');
		}
		$type = (string)$this->in($in, 'type', 'x');
		if (!in_array($type, array('a', 'l', 'e', 'i', 'x'), true)) {
			return $this->fail('Unknown account type.');
		}
		$gp = (string)$this->in($in, 'gp', '');
		if ($gp !== '' && !preg_match('/^(BA|BP|PZ):R\d+$/', $gp)) {
			return $this->fail('Annual report row looks like BA:R620, BP:R1080 or PZ:R70.');
		}
		$name = trim((string)$this->in($in, 'name'));
		if ($name === '') {
			return $this->fail('Give the account a name.');
		}
		$this->db->query("INSERT INTO `{$this->P}account` SET code = '" . $this->e($code) . "', name = '" . $this->e($name) . "', name_en = '" . $this->e(trim((string)$this->in($in, 'name_en'))) . "', type = '" . $this->e($type) . "', gp = '" . $this->e($gp) . "', tag = '" . $this->e((string)$this->in($in, 'tag', '')) . "', status = '" . ((int)$this->in($in, 'status', 1) ? 1 : 0) . "', sort = '" . (int)$code . "'
			ON DUPLICATE KEY UPDATE name = VALUES(name), name_en = VALUES(name_en), gp = VALUES(gp), tag = VALUES(tag), status = VALUES(status)");
		$this->out(array('ok' => 1, 'accounts' => array_values($this->accounts())));
	}

	private function f_sync() {
		$n = $this->sync();
		$this->out(array('ok' => 1, 'posted' => $n));
	}

	// ------------------------------------------------------------------ expenses
	private function f_expenses() {
		$from = $this->d($this->in($this->request->get, 'from', date('Y-01-01')));
		$to = $this->d($this->in($this->request->get, 'to', date('Y-12-31')));
		$rows = $this->db->query("SELECT * FROM `{$this->P}expense` WHERE date BETWEEN '" . $this->e($from) . "' AND '" . $this->e($to) . "' ORDER BY date DESC, expense_id DESC LIMIT 500")->rows;
		$stock = array();
		if ($this->hasTable('dpc_inv_invoice')) {
			$stock = $this->db->query("SELECT i.invoice_id, i.date, i.number, i.total_eur, i.status, i.file, s.name AS supplier FROM `" . DB_PREFIX . "dpc_inv_invoice` i LEFT JOIN `" . DB_PREFIX . "dpc_inv_supplier` s ON s.supplier_id = i.supplier_id WHERE i.date BETWEEN '" . $this->e($from) . "' AND '" . $this->e($to) . "' ORDER BY i.date DESC LIMIT 200")->rows;
		}
		$this->out(array('expenses' => $rows, 'stock' => $stock));
	}

	private function f_save_expense() {
		$in = $this->input();
		$id = (int)$this->in($in, 'expense_id', 0);
		$date = $this->d($this->in($in, 'date'));
		$amount = $this->m2($this->n($this->in($in, 'amount', 0)));
		$cur = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', (string)$this->in($in, 'currency', 'EUR')), 0, 3)) ?: 'EUR';
		$rate = $cur === 'EUR' ? 1.0 : $this->n($this->in($in, 'rate', 0));
		if ($amount <= 0) {
			return $this->fail('Enter the invoice amount.');
		}
		if ($rate <= 0) {
			return $this->fail('Enter the exchange rate to EUR for ' . $cur . ' (from the ECB, for the invoice date).');
		}
		$acc = $this->accounts();
		$nonbiz = (int)$this->in($in, 'nonbiz', 0) ? 1 : 0;
		$account = $nonbiz ? '7580' : preg_replace('/\D/', '', (string)$this->in($in, 'account', '7590'));
		if (!isset($acc[$account])) {
			return $this->fail('Pick what the cost was for.');
		}
		$paid = preg_replace('/\D/', '', (string)$this->in($in, 'paid', '5310'));
		if (!isset($acc[$paid])) {
			return $this->fail('Pick how it was paid.');
		}
		if ($id) {
			$old = $this->db->query("SELECT * FROM `{$this->P}expense` WHERE expense_id = '" . $id . "'")->row;
			if (!$old) {
				return $this->fail('Expense not found.');
			}
			if ($old['status'] === 'void') {
				return $this->fail('This expense was voided. Add it again instead.');
			}
		}
		$eur = $this->m2($amount * $rate);
		$set = "date = '" . $this->e($date) . "', supplier = '" . $this->e(trim((string)$this->in($in, 'supplier'))) . "', number = '" . $this->e(trim((string)$this->in($in, 'number'))) . "', currency = '" . $this->e($cur) . "', amount = '" . $amount . "', rate = '" . (float)$rate . "', amount_eur = '" . $eur . "',
			account = '" . $this->e($account) . "', paid = '" . $this->e($paid) . "', nonbiz = '" . $nonbiz . "', file = '" . $this->e(basename((string)$this->in($in, 'file'))) . "', file_name = '" . $this->e((string)$this->in($in, 'file_name')) . "', note = '" . $this->e((string)$this->in($in, 'note')) . "'";
		if ($id) {
			$this->db->query("UPDATE `{$this->P}expense` SET " . $set . " WHERE expense_id = '" . $id . "'");
		} else {
			$this->db->query("INSERT INTO `{$this->P}expense` SET " . $set . ", status = 'posted', created = NOW()");
			$id = (int)$this->db->getLastId();
		}
		$e = $this->db->query("SELECT * FROM `{$this->P}expense` WHERE expense_id = '" . $id . "'")->row;
		$this->postExpense($e);
		$this->out(array('ok' => 1, 'expense_id' => $id));
	}

	private function postExpense($e) {
		$who = $e['supplier'] ?: 'Supplier';
		$lines = $e['status'] === 'void' ? array() : array(
			array('account' => $e['account'], 'debit' => (float)$e['amount_eur'], 'note' => $e['currency'] !== 'EUR' ? $e['amount'] . ' ' . $e['currency'] . ' @ ' . (float)$e['rate'] : ''),
			array('account' => $e['paid'], 'credit' => (float)$e['amount_eur'], 'partner' => $who),
		);
		$this->post('exp:' . $e['expense_id'], $e['date'], 'expense', $e['number'] ?: '#' . $e['expense_id'], 'Expense: ' . $who . ($e['number'] ? ' ' . $e['number'] : ''), $lines);
	}

	private function f_void_expense() {
		$in = $this->input();
		$id = (int)$this->in($in, 'expense_id', 0);
		$e = $this->db->query("SELECT * FROM `{$this->P}expense` WHERE expense_id = '" . $id . "'")->row;
		if (!$e) {
			return $this->fail('Expense not found.');
		}
		$this->db->query("UPDATE `{$this->P}expense` SET status = 'void' WHERE expense_id = '" . $id . "'");
		$e['status'] = 'void';
		$this->postExpense($e);
		$this->out(array('ok' => 1));
	}

	private function fileDir() {
		$dir = DIR_UPLOAD . 'dpc-books/';
		if (!is_dir($dir)) {
			mkdir($dir, 0755, true);
			file_put_contents($dir . 'index.html', '');
		}
		return $dir;
	}

	private function f_upload() {
		if (empty($this->request->files['file']['tmp_name']) || !is_uploaded_file($this->request->files['file']['tmp_name'])) {
			return $this->fail('No file arrived.');
		}
		$f = $this->request->files['file'];
		if ($f['size'] > 15 * 1024 * 1024) {
			return $this->fail('The file is larger than 15 MB.');
		}
		$name = basename(html_entity_decode($f['name'], ENT_QUOTES, 'UTF-8'));
		$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
		if (!in_array($ext, array('pdf', 'jpg', 'jpeg', 'png', 'webp'), true)) {
			return $this->fail('Use a PDF or a picture (JPG, PNG, WebP).');
		}
		$head = file_get_contents($f['tmp_name'], false, null, 0, 8);
		$ok = ($ext === 'pdf' && substr($head, 0, 4) === '%PDF') || (in_array($ext, array('jpg', 'jpeg'), true) && substr($head, 0, 2) === "\xFF\xD8") || ($ext === 'png' && substr($head, 0, 4) === "\x89PNG") || ($ext === 'webp' && substr($head, 0, 4) === 'RIFF');
		if (!$ok) {
			return $this->fail('The file does not look like a ' . strtoupper($ext) . '.');
		}
		$store = date('Ymd-His') . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
		move_uploaded_file($f['tmp_name'], $this->fileDir() . $store);
		$this->out(array('ok' => 1, 'file' => $store, 'file_name' => $name));
	}

	// Expense PDFs and generated VID files
	public function file() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_books')) {
			return;
		}
		$g = $this->request->get;
		$path = '';
		$name = '';
		$type = '';
		if (!empty($g['expense'])) {
			$e = $this->db->query("SELECT file, file_name FROM `{$this->P}expense` WHERE expense_id = '" . (int)$g['expense'] . "'")->row;
			if ($e && $e['file']) {
				$path = $this->fileDir() . basename($e['file']);
				$name = $e['file_name'] ?: basename($path);
			}
		} elseif (!empty($g['filing'])) {
			$fl = $this->db->query("SELECT file, kind, period FROM `{$this->P}filing` WHERE filing_id = '" . (int)$g['filing'] . "'")->row;
			if ($fl && $fl['file']) {
				$path = $this->fileDir() . basename($fl['file']);
				$name = basename($fl['file']);
				$type = 'application/xml';
			}
		}
		if (!$path || !is_file($path)) {
			$this->response->setOutput('File not found.');
			return;
		}
		$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
		$types = array('pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'xml' => 'application/xml');
		header('Content-Type: ' . ($type ?: (isset($types[$ext]) ? $types[$ext] : 'application/octet-stream')));
		header('Content-Disposition: ' . ($ext === 'xml' ? 'attachment' : 'inline') . '; filename="' . str_replace('"', '', $name) . '"');
		header('X-Content-Type-Options: nosniff');
		header('Content-Length: ' . filesize($path));
		readfile($path);
		exit;
	}

	// ------------------------------------------------------------------ bank statements
	private function f_bank_import() {
		$in = $this->input();
		$acct = preg_replace('/\D/', '', (string)$this->in($in, 'account', '2620'));
		$acc = $this->accounts();
		if (!isset($acc[$acct]) || $acc[$acct]['tag'] !== 'money') {
			return $this->fail('Pick which money account the statement is for.');
		}
		$text = (string)$this->in($in, 'content', '');
		$fname = basename((string)$this->in($in, 'name', 'statement'));
		if ($text === '') {
			return $this->fail('The file is empty.');
		}
		$rows = (strpos(ltrim($text), '<') === 0) ? $this->parseCamt($text) : $this->parseCsv($text);
		if (!$rows) {
			return $this->fail('No payments found in the file. Use the camt.053 (ISO 20022 XML) statement from your bank, or a CSV with date, amount and description columns.');
		}
		$added = 0;
		$dupes = 0;
		foreach ($rows as $r) {
			$hash = md5($acct . '|' . $r['date'] . '|' . number_format($r['amount'], 2, '.', '') . '|' . $r['bank_ref'] . '|' . $r['counterparty'] . '|' . $r['details']);
			if ($this->db->query("SELECT tx_id FROM `{$this->P}bank` WHERE hash = '" . $hash . "'")->num_rows) {
				$dupes++;
				continue;
			}
			$this->db->query("INSERT INTO `{$this->P}bank` SET account = '" . $this->e($acct) . "', date = '" . $this->e($r['date']) . "', amount = '" . round($r['amount'], 2) . "', counterparty = '" . $this->e(mb_substr($r['counterparty'], 0, 160)) . "', iban = '" . $this->e(mb_substr($r['iban'], 0, 40)) . "', details = '" . $this->e(mb_substr($r['details'], 0, 500)) . "', bank_ref = '" . $this->e(mb_substr($r['bank_ref'], 0, 64)) . "', hash = '" . $hash . "', status = 'open', file = '" . $this->e(mb_substr($fname, 0, 160)) . "', created = NOW()");
			$added++;
		}
		$auto = $this->autoMatch();
		$this->out(array('ok' => 1, 'added' => $added, 'duplicates' => $dupes, 'auto' => $auto));
	}

	private function parseCamt($xml) {
		$prev = libxml_use_internal_errors(true);
		$doc = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
		libxml_use_internal_errors($prev);
		if (!$doc) {
			throw new Exception('The XML file could not be read.');
		}
		$ns = current($doc->getDocNamespaces());
		if ($ns) {
			$doc->registerXPathNamespace('c', $ns);
		}
		$q = function ($node, $path) use ($ns) {
			if ($ns) {
				$node->registerXPathNamespace('c', $ns);
				$path = preg_replace('/(^|\/)(?!c:)([A-Za-z])/', '$1c:$2', $path);
			}
			$r = $node->xpath($path);
			return $r ? trim((string)$r[0]) : '';
		};
		$entries = $ns ? $doc->xpath('//c:Ntry') : $doc->xpath('//Ntry');
		$out = array();
		foreach ($entries ?: array() as $n) {
			$amt = (float)$q($n, 'Amt');
			$ccy = '';
			$a = $ns ? $n->xpath('c:Amt') : $n->xpath('Amt');
			if ($a) {
				$ccy = (string)$a[0]['Ccy'];
			}
			$sign = $q($n, 'CdtDbtInd') === 'DBIT' ? -1 : 1;
			$date = $q($n, 'BookgDt/Dt') ?: substr($q($n, 'BookgDt/DtTm'), 0, 10) ?: $q($n, 'ValDt/Dt');
			if ($sign < 0) {
				$cp = $q($n, 'NtryDtls/TxDtls/RltdPties/Cdtr/Nm') ?: $q($n, 'NtryDtls/TxDtls/RltdPties/Cdtr/Pty/Nm');
				$iban = $q($n, 'NtryDtls/TxDtls/RltdPties/CdtrAcct/Id/IBAN');
			} else {
				$cp = $q($n, 'NtryDtls/TxDtls/RltdPties/Dbtr/Nm') ?: $q($n, 'NtryDtls/TxDtls/RltdPties/Dbtr/Pty/Nm');
				$iban = $q($n, 'NtryDtls/TxDtls/RltdPties/DbtrAcct/Id/IBAN');
			}
			$det = $q($n, 'NtryDtls/TxDtls/RmtInf/Ustrd') ?: $q($n, 'NtryDtls/TxDtls/RmtInf/Strd/CdtrRefInf/Ref') ?: $q($n, 'AddtlNtryInf');
			$ref = $q($n, 'AcctSvcrRef') ?: $q($n, 'NtryDtls/TxDtls/Refs/AcctSvcrRef') ?: $q($n, 'NtryRef');
			if ($ccy && $ccy !== 'EUR') {
				$det = trim($det . ' [' . $ccy . ']');
			}
			if (!$date || !$amt) {
				continue;
			}
			$out[] = array('date' => $this->d($date), 'amount' => $sign * $amt, 'counterparty' => $cp, 'iban' => $iban, 'details' => $det, 'bank_ref' => $ref);
		}
		return $out;
	}

	private function parseCsv($text) {
		$text = preg_replace('/^\xEF\xBB\xBF/', '', $text);
		$lines = preg_split('/\r\n|\r|\n/', trim($text));
		if (count($lines) < 2) {
			return array();
		}
		$first = $lines[0];
		$delim = substr_count($first, ';') > substr_count($first, ',') ? ';' : (substr_count($first, "\t") > substr_count($first, ',') ? "\t" : ',');
		$head = array_map(function ($h) { return strtolower(trim($h)); }, str_getcsv($first, $delim));
		$find = function ($names) use ($head) {
			foreach ($head as $i => $h) {
				foreach ($names as $nm) {
					if ($h === $nm || strpos($h, $nm) !== false) {
						return $i;
					}
				}
			}
			return -1;
		};
		$iDate = $find(array('booking date', 'date', 'datums', 'completed date', 'started date'));
		$iAmt = $find(array('amount', 'summa', 'total amount'));
		$iIn = $find(array('credit', 'kredīts', 'paid in', 'money in'));
		$iOut = $find(array('debit', 'debets', 'paid out', 'money out'));
		$iCp = $find(array('counterparty', 'beneficiary', 'payee', 'name', 'partner', 'saņēmējs', 'maksātājs', 'description'));
		$iDet = $find(array('details', 'reference', 'description', 'detaļas', 'mērķis', 'payment purpose'));
		$iRef = $find(array('transaction id', 'id', 'archive', 'reference number', 'dokumenta'));
		$iCcy = $find(array('currency', 'valūta'));
		if ($iDate < 0 || ($iAmt < 0 && $iIn < 0 && $iOut < 0)) {
			throw new Exception('The CSV needs a date column and an amount column (or paid in / paid out).');
		}
		$num = function ($s) {
			$s = trim(str_replace(array("\xC2\xA0", ' ', '€'), '', (string)$s));
			if ($s === '') {
				return 0.0;
			}
			if (preg_match('/^-?[\d.]+,\d{1,2}$/', $s)) {
				$s = str_replace(array('.', ','), array('', '.'), $s);
			} else {
				$s = str_replace(',', '', $s);
			}
			return (float)$s;
		};
		$out = array();
		for ($i = 1; $i < count($lines); $i++) {
			if (trim($lines[$i]) === '') {
				continue;
			}
			$c = str_getcsv($lines[$i], $delim);
			$get = function ($k) use ($c) { return $k >= 0 && isset($c[$k]) ? trim($c[$k]) : ''; };
			$ds = $get($iDate);
			if (preg_match('/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})/', $ds, $m)) {
				$ds = $m[3] . '-' . str_pad($m[2], 2, '0', STR_PAD_LEFT) . '-' . str_pad($m[1], 2, '0', STR_PAD_LEFT);
			}
			if (!strtotime($ds)) {
				continue;
			}
			$amt = $iAmt >= 0 ? $num($get($iAmt)) : ($num($get($iIn)) - abs($num($get($iOut))));
			if (!$amt) {
				continue;
			}
			$det = $iDet !== $iCp ? $get($iDet) : '';
			$ccy = $get($iCcy);
			$out[] = array('date' => $this->d($ds), 'amount' => $amt, 'counterparty' => $get($iCp), 'iban' => '', 'details' => trim($det . ($ccy && strtoupper($ccy) !== 'EUR' ? ' [' . $ccy . ']' : '')), 'bank_ref' => $get($iRef));
		}
		return $out;
	}

	// Suggestions for an open bank row: rules, VID, bank fees, open documents with the same amount
	private function suggest($t) {
		$text = mb_strtolower($t['counterparty'] . ' ' . $t['details']);
		$amt = abs((float)$t['amount']);
		$s = array();
		foreach ($this->db->query("SELECT * FROM `{$this->P}rule` ORDER BY LENGTH(`match`) DESC")->rows as $r) {
			if ($r['match'] !== '' && mb_strpos($text, mb_strtolower($r['match'])) !== false) {
				$s[] = array('account' => $r['account'], 'doc' => '', 'why' => 'Your rule: "' . $r['match'] . '"');
				break;
			}
		}
		if (preg_match('/valsts ieņēmumu dienests|valsts ienemumu dienests|\bvid\b|vienotais nodokļu|LV\d\dTREL/i', $t['counterparty'] . ' ' . $t['iban'] . ' ' . $t['details'])) {
			$s[] = array('account' => (float)$t['amount'] < 0 ? '5710' : '2370', 'doc' => '', 'why' => 'Payment to or from VID');
		}
		if ((float)$t['amount'] < 0 && preg_match('/komisij|commission|fee|maksa par|service charge|monthly/i', $text) && $amt < 60) {
			$s[] = array('account' => '7510', 'doc' => '', 'why' => 'Looks like a bank fee');
		}
		$used = array();
		foreach ($this->db->query("SELECT doc FROM `{$this->P}bank` WHERE doc <> ''")->rows as $u) {
			$used[$u['doc']] = true;
		}
		$lo = $amt - 0.01;
		$hi = $amt + 0.01;
		if ((float)$t['amount'] < 0) {
			foreach ($this->db->query("SELECT expense_id, supplier, number, date FROM `{$this->P}expense` WHERE status = 'posted' AND paid = '5310' AND amount_eur BETWEEN '" . $lo . "' AND '" . $hi . "' ORDER BY ABS(DATEDIFF(date, '" . $this->e($t['date']) . "')) LIMIT 3")->rows as $e) {
				if (!isset($used['exp:' . $e['expense_id']])) {
					$s[] = array('account' => '5310', 'doc' => 'exp:' . $e['expense_id'], 'partner' => $e['supplier'], 'why' => 'Expense ' . $e['supplier'] . ' ' . $e['number'] . ' of ' . $e['date']);
				}
			}
			if ($this->hasTable('dpc_inv_invoice')) {
				foreach ($this->db->query("SELECT i.invoice_id, i.number, i.date, s.name FROM `" . DB_PREFIX . "dpc_inv_invoice` i LEFT JOIN `" . DB_PREFIX . "dpc_inv_supplier` s ON s.supplier_id = i.supplier_id WHERE i.status = 'received' AND i.total_eur BETWEEN '" . $lo . "' AND '" . $hi . "' LIMIT 3")->rows as $i) {
					if (!isset($used['inv:' . $i['invoice_id']])) {
						$s[] = array('account' => '5310', 'doc' => 'inv:' . $i['invoice_id'], 'partner' => $i['name'], 'why' => 'Supplier invoice ' . $i['name'] . ' ' . $i['number'] . ' of ' . $i['date']);
					}
				}
			}
			foreach ($this->db->query("SELECT dividend_id, date FROM `{$this->P}dividend` WHERE status = 'posted' AND amount BETWEEN '" . $lo . "' AND '" . $hi . "' LIMIT 2")->rows as $d) {
				if (!isset($used['div:' . $d['dividend_id']])) {
					$s[] = array('account' => '5150', 'doc' => 'div:' . $d['dividend_id'], 'why' => 'Dividend declared ' . $d['date']);
				}
			}
		} else {
			if ($this->hasTable('order') && preg_match_all('/\b(\d{1,7})\b/', $t['details'], $mm)) {
				foreach (array_unique($mm[1]) as $oid) {
					$o = $this->db->query("SELECT order_id, total, firstname, lastname FROM `" . DB_PREFIX . "order` WHERE order_id = '" . (int)$oid . "' AND ABS(total - " . $amt . ") < 0.02")->row;
					if ($o && !isset($used['order:' . $o['order_id']])) {
						$s[] = array('account' => '2310', 'doc' => 'order:' . $o['order_id'], 'partner' => trim($o['firstname'] . ' ' . $o['lastname']), 'why' => 'Shop order #' . $o['order_id']);
					}
				}
			}
			foreach (array('2630' => 'stripe', '2640' => 'paypal') as $acc => $word) {
				if (strpos($text, $word) !== false) {
					$s[] = array('account' => $acc, 'doc' => '', 'why' => 'Payout from ' . ucfirst($word));
				}
			}
			if ($this->hasTable('dpc_inv_sale')) {
				foreach ($this->db->query("SELECT channel FROM `" . DB_PREFIX . "dpc_inv_sale` GROUP BY channel")->rows as $c) {
					if ($c['channel'] !== '' && mb_strpos($text, mb_strtolower($c['channel'])) !== false) {
						$s[] = array('account' => '2310', 'doc' => '', 'partner' => $c['channel'], 'why' => 'Payout from ' . $c['channel']);
					}
				}
			}
		}
		return $s;
	}

	// Rows a rule or a unique open document explains are booked straight away
	private function autoMatch() {
		$n = 0;
		foreach ($this->db->query("SELECT * FROM `{$this->P}bank` WHERE status = 'open' ORDER BY date LIMIT 500")->rows as $t) {
			$s = $this->suggest($t);
			if ($s && strpos($s[0]['why'], 'Your rule') === 0) {
				$this->assign($t, $s[0]['account'], '', isset($s[0]['partner']) ? $s[0]['partner'] : '');
				$n++;
			}
		}
		return $n;
	}

	private function assign($t, $contra, $doc, $partner) {
		$acc = $this->accounts();
		if (!isset($acc[$contra])) {
			throw new Exception('Unknown account ' . $contra . '.');
		}
		if ($contra === $t['account']) {
			throw new Exception('Pick the other side of the payment, not the bank account itself.');
		}
		$amt = (float)$t['amount'];
		$who = $partner !== '' ? $partner : $t['counterparty'];
		$lines = array(
			array('account' => $t['account'], 'debit' => $amt > 0 ? $amt : 0, 'credit' => $amt < 0 ? -$amt : 0, 'partner' => $who),
			array('account' => $contra, 'debit' => $amt < 0 ? -$amt : 0, 'credit' => $amt > 0 ? $amt : 0, 'partner' => $who, 'note' => mb_substr($t['details'], 0, 255)),
		);
		$this->post('bank:' . $t['tx_id'], $t['date'], 'bank', $t['bank_ref'] ?: 'Bank', ($amt < 0 ? 'Paid to ' : 'Received from ') . ($who ?: 'unknown'), $lines);
		$this->db->query("UPDATE `{$this->P}bank` SET contra = '" . $this->e($contra) . "', doc = '" . $this->e($doc) . "', status = 'booked' WHERE tx_id = '" . (int)$t['tx_id'] . "'");
	}

	private function f_bank_rows() {
		$status = $this->in($this->request->get, 'status', 'open');
		$rows = $this->db->query("SELECT * FROM `{$this->P}bank` WHERE " . ($status === 'all' ? '1' : "status = '" . $this->e($status) . "'") . " ORDER BY date DESC, tx_id DESC LIMIT 300")->rows;
		foreach ($rows as &$r) {
			if ($r['status'] === 'open') {
				$r['suggest'] = $this->suggest($r);
			}
		}
		$this->out(array('rows' => $rows, 'rules' => $this->db->query("SELECT * FROM `{$this->P}rule` ORDER BY `match`")->rows));
	}

	private function f_bank_assign() {
		$in = $this->input();
		$t = $this->db->query("SELECT * FROM `{$this->P}bank` WHERE tx_id = '" . (int)$this->in($in, 'tx_id', 0) . "'")->row;
		if (!$t) {
			return $this->fail('Bank row not found.');
		}
		$contra = preg_replace('/\D/', '', (string)$this->in($in, 'account'));
		$this->assign($t, $contra, (string)$this->in($in, 'doc', ''), trim((string)$this->in($in, 'partner', '')));
		$rule = trim((string)$this->in($in, 'rule', ''));
		if ($rule !== '') {
			$this->db->query("DELETE FROM `{$this->P}rule` WHERE `match` = '" . $this->e(mb_substr($rule, 0, 160)) . "'");
			$this->db->query("INSERT INTO `{$this->P}rule` SET `match` = '" . $this->e(mb_substr($rule, 0, 160)) . "', account = '" . $this->e($contra) . "', created = NOW()");
			$this->autoMatch();
		}
		$this->out(array('ok' => 1));
	}

	// A booked row can be booked again differently: the entry for it is rewritten (or corrected if locked)
	private function f_bank_reopen() {
		$in = $this->input();
		$id = (int)$this->in($in, 'tx_id', 0);
		$this->db->query("UPDATE `{$this->P}bank` SET status = 'open', doc = '' WHERE tx_id = '" . $id . "'");
		$this->post('bank:' . $id, date('Y-m-d'), 'bank', '', '', array());
		$this->out(array('ok' => 1));
	}

	private function f_rule_delete() {
		$in = $this->input();
		$this->db->query("DELETE FROM `{$this->P}rule` WHERE rule_id = '" . (int)$this->in($in, 'rule_id', 0) . "'");
		$this->out(array('ok' => 1));
	}

	// ------------------------------------------------------------------ journal
	private function f_entries() {
		$g = $this->request->get;
		$from = $this->d($this->in($g, 'from', date('Y-01-01')));
		$to = $this->d($this->in($g, 'to', date('Y-12-31')));
		$acc = preg_replace('/\D/', '', (string)$this->in($g, 'account', ''));
		$sql = "SELECT e.* FROM `{$this->P}entry` e WHERE e.date BETWEEN '" . $this->e($from) . "' AND '" . $this->e($to) . "'";
		if ($acc !== '') {
			$sql .= " AND e.entry_id IN (SELECT entry_id FROM `{$this->P}line` WHERE account = '" . $this->e($acc) . "')";
		}
		$entries = $this->db->query($sql . " ORDER BY e.date DESC, e.entry_id DESC LIMIT 400")->rows;
		$ids = array_map(function ($e) { return (int)$e['entry_id']; }, $entries);
		$lines = array();
		if ($ids) {
			foreach ($this->db->query("SELECT * FROM `{$this->P}line` WHERE entry_id IN (" . implode(',', $ids) . ") ORDER BY line_id")->rows as $l) {
				$lines[$l['entry_id']][] = $l;
			}
		}
		foreach ($entries as &$e) {
			$e['lines'] = isset($lines[$e['entry_id']]) ? $lines[$e['entry_id']] : array();
			$e['locked'] = $this->isLocked($e['date']);
		}
		unset($e);
		$opening = null;
		if ($acc !== '') {
			$m = $this->movements('', date('Y-m-d', strtotime($from . ' -1 day')), " AND l.account = '" . $this->e($acc) . "'");
			$opening = isset($m[$acc]) ? $m[$acc]['net'] : 0;
		}
		$this->out(array('entries' => $entries, 'opening' => $opening));
	}

	private function f_save_entry() {
		$in = $this->input();
		$lines = array();
		$acc = $this->accounts();
		foreach ((array)$this->in($in, 'lines', array()) as $l) {
			$code = preg_replace('/\D/', '', (string)$this->in($l, 'account'));
			if ($code === '') {
				continue;
			}
			if (!isset($acc[$code])) {
				return $this->fail('Unknown account ' . $code . '.');
			}
			$lines[] = array('account' => $code, 'debit' => $this->n($this->in($l, 'debit', 0)), 'credit' => $this->n($this->in($l, 'credit', 0)), 'partner' => trim((string)$this->in($l, 'partner', '')), 'note' => trim((string)$this->in($l, 'note', '')));
		}
		if (count($lines) < 2) {
			return $this->fail('An entry needs at least two lines.');
		}
		$date = $this->d($this->in($in, 'date'));
		if ($this->isLocked($date)) {
			return $this->fail('The books are closed up to ' . $this->sget('locked_until') . '. Date the entry after that.');
		}
		$descr = trim((string)$this->in($in, 'descr', ''));
		if ($descr === '') {
			return $this->fail('Say what the entry is for.');
		}
		$kind = in_array($this->in($in, 'kind'), array('opening', 'manual', 'deprec', 'yearend'), true) ? $this->in($in, 'kind') : 'manual';
		$id = $this->insertEntry('man:' . date('YmdHis') . ':' . bin2hex(random_bytes(3)), $date, $kind, trim((string)$this->in($in, 'ref', '')), $descr, $lines, '');
		$this->out(array('ok' => 1, 'entry_id' => $id));
	}

	private function f_reverse_entry() {
		$in = $this->input();
		$e = $this->db->query("SELECT * FROM `{$this->P}entry` WHERE entry_id = '" . (int)$this->in($in, 'entry_id', 0) . "'")->row;
		if (!$e) {
			return $this->fail('Entry not found.');
		}
		if (strpos($e['src'], 'man:') !== 0) {
			return $this->fail('This entry comes from a document. Change or void the document instead.');
		}
		if ($this->db->query("SELECT entry_id FROM `{$this->P}entry` WHERE src = '" . $this->e('rev:' . $e['entry_id']) . "'")->num_rows) {
			return $this->fail('This entry is already reversed.');
		}
		$lines = array();
		foreach ($this->db->query("SELECT * FROM `{$this->P}line` WHERE entry_id = '" . (int)$e['entry_id'] . "'")->rows as $l) {
			$lines[] = array('account' => $l['account'], 'debit' => $l['credit'], 'credit' => $l['debit'], 'partner' => $l['partner'], 'note' => $l['note']);
		}
		$id = $this->insertEntry('rev:' . $e['entry_id'], $this->isLocked(date('Y-m-d')) ? $this->firstOpenDay() : date('Y-m-d'), 'manual', $e['ref'], 'Reversal of: ' . $e['descr'], $lines, '');
		$this->out(array('ok' => 1, 'entry_id' => $id));
	}

	// Declaring a dividend: taxable in the UIN declaration of the month it is declared
	private function f_dividend() {
		$in = $this->input();
		$amount = $this->m2($this->n($this->in($in, 'amount', 0)));
		if ($amount <= 0) {
			return $this->fail('Enter the dividend amount (what you will receive).');
		}
		$date = $this->d($this->in($in, 'date'));
		$this->db->query("INSERT INTO `{$this->P}dividend` SET date = '" . $this->e($date) . "', amount = '" . $amount . "', note = '" . $this->e((string)$this->in($in, 'note', '')) . "', status = 'posted', created = NOW()");
		$id = (int)$this->db->getLastId();
		$tax = round($amount / 0.8 * 0.2, 2);
		$this->post('div:' . $id, $date, 'dividend', 'Dividend #' . $id, 'Dividend declared', array(
			array('account' => '3410', 'debit' => $amount),
			array('account' => '5150', 'credit' => $amount, 'partner' => $this->sget('board_name', '')),
		));
		$this->post('divtax:' . $id, $date, 'dividend', 'Dividend #' . $id, 'Corporate income tax on the dividend (20/80)', array(
			array('account' => '8610', 'debit' => $tax),
			array('account' => '5710', 'credit' => $tax, 'partner' => 'VID'),
		));
		$this->plan(true);
		$this->out(array('ok' => 1, 'dividend_id' => $id, 'tax' => $tax));
	}

	private function f_void_dividend() {
		$in = $this->input();
		$id = (int)$this->in($in, 'dividend_id', 0);
		$d = $this->db->query("SELECT * FROM `{$this->P}dividend` WHERE dividend_id = '" . $id . "'")->row;
		if (!$d) {
			return $this->fail('Dividend not found.');
		}
		$this->db->query("UPDATE `{$this->P}dividend` SET status = 'void' WHERE dividend_id = '" . $id . "'");
		$this->post('div:' . $id, $d['date'], 'dividend', '', '', array());
		$this->post('divtax:' . $id, $d['date'], 'dividend', '', '', array());
		$this->out(array('ok' => 1));
	}

	private function f_dividends() {
		$this->out(array('dividends' => $this->db->query("SELECT * FROM `{$this->P}dividend` ORDER BY date DESC LIMIT 100")->rows));
	}

	// ------------------------------------------------------------------ reports
	private function plFrom($mv, $acc) {
		$rows = array('R30' => 0, 'R40' => 0, 'R60' => 0, 'R70' => 0, 'R80' => 0, 'R90' => 0, 'R190' => 0, 'R230' => 0, 'R250' => 0);
		$by = array();
		foreach ($mv as $code => $m) {
			if (!isset($acc[$code]) || !in_array($acc[$code]['type'], array('i', 'x'), true)) {
				continue;
			}
			$gp = $acc[$code]['gp'];
			$row = substr($gp, 0, 3) === 'PZ:' ? substr($gp, 3) : ($acc[$code]['type'] === 'i' ? 'R80' : 'R70');
			$v = $acc[$code]['type'] === 'i' ? -$m['net'] : $m['net'];
			// Income rows hold income; cost rows hold costs (both positive)
			$isIncomeRow = in_array($row, array('R30', 'R80', 'R190'), true);
			$val = $isIncomeRow ? -$m['net'] : $m['net'];
			$rows[$row] = (isset($rows[$row]) ? $rows[$row] : 0) + $val;
			$by[] = array('code' => $code, 'name' => $acc[$code]['name_en'], 'lv' => $acc[$code]['name'], 'row' => $row, 'amount' => round($val, 2));
		}
		foreach ($rows as $k => $v) {
			$rows[$k] = round($v, 2);
		}
		$gross = $rows['R30'] - $rows['R40'];
		$before = $gross - $rows['R60'] - $rows['R70'] + $rows['R80'] - $rows['R90'] + $rows['R190'] - $rows['R230'];
		return array('rows' => $rows, 'accounts' => $by, 'revenue' => $rows['R30'], 'gross' => round($gross, 2), 'before_tax' => round($before, 2), 'profit' => round($before - $rows['R250'], 2));
	}

	private function f_report() {
		$g = $this->request->get;
		$to = $this->d($this->in($g, 'to', date('Y-m-d')));
		list($fs, $fe) = $this->fy($to);
		$from = $this->d($this->in($g, 'from', $fs));
		$acc = $this->accounts();
		$mv = $this->movements($from, $to);
		$all = $this->movements('', $to);
		$tb = array();
		foreach ($acc as $code => $a) {
			$p = isset($mv[$code]) ? $mv[$code] : array('d' => 0, 'c' => 0, 'net' => 0);
			$b = isset($all[$code]) ? $all[$code]['net'] : 0;
			if (!$p['d'] && !$p['c'] && !$b) {
				continue;
			}
			$tb[] = array('code' => $code, 'name' => $a['name_en'], 'lv' => $a['name'], 'type' => $a['type'], 'gp' => $a['gp'], 'debit' => round($p['d'], 2), 'credit' => round($p['c'], 2), 'balance' => round($b, 2));
		}
		$bs = $this->balanceSheet($to);
		// Month by month for the chart
		$months = array();
		for ($t = strtotime(substr($from, 0, 7) . '-01'); $t <= strtotime($to); $t = strtotime('+1 month', $t)) {
			$ms = date('Y-m-01', $t);
			$me = date('Y-m-t', $t);
			$p = $this->plFrom($this->movements($ms, min($me, $to)), $acc);
			$months[] = array('month' => date('Y-m', $t), 'revenue' => $p['revenue'], 'profit' => $p['profit']);
		}
		$this->out(array('from' => $from, 'to' => $to, 'pl' => $this->plFrom($mv, $acc), 'tb' => $tb, 'bs' => $bs, 'months' => $months));
	}

	// Balance sheet rows (euros, not rounded) at a date, with profit of the year and earlier years derived from the ledger
	private function balanceSheet($at) {
		$acc = $this->accounts();
		list($fs, $fe) = $this->fy($at);
		$all = $this->movements('', $at);
		$rows = array();
		$plYear = 0.0;
		$plBefore = 0.0;
		$before = $this->movements('', date('Y-m-d', strtotime($fs . ' -1 day')));
		foreach ($acc as $code => $a) {
			if (in_array($a['type'], array('i', 'x'), true)) {
				$plYear += -(isset($all[$code]) ? $all[$code]['net'] : 0) + (isset($before[$code]) ? $before[$code]['net'] : 0);
				$plBefore += -(isset($before[$code]) ? $before[$code]['net'] : 0);
				continue;
			}
			$v = isset($all[$code]) ? $all[$code]['net'] : 0;
			$gp = $a['gp'] ?: ($a['type'] === 'a' ? 'BA:R500' : 'BP:R1130');
			$v = substr($gp, 0, 3) === 'BA:' ? $v : -$v;
			$rows[$gp] = (isset($rows[$gp]) ? $rows[$gp] : 0) + $v;
		}
		$rows['BP:R780'] = (isset($rows['BP:R780']) ? $rows['BP:R780'] : 0) + $plBefore;
		$rows['BP:R790'] = $plYear;
		$assets = 0;
		$pass = 0;
		foreach ($rows as $k => $v) {
			if (substr($k, 0, 3) === 'BA:') {
				$assets += $v;
			} else {
				$pass += $v;
			}
		}
		return array('rows' => $rows, 'assets' => round($assets, 2), 'liabilities' => round($pass, 2), 'diff' => round($assets - $pass, 2), 'profit_year' => round($plYear, 2));
	}

	// VAT registration limits: Latvian turnover, EU consumers outside Latvia, UK consumers
	private function limits($today) {
		$y = substr($today, 0, 4);
		$from = $y . '-01-01';
		$acc = $this->accounts();
		$p = $this->plFrom($this->movements($from, $today), $acc);
		$out = array('year' => $y, 'turnover' => $p['revenue'], 'lv_limit' => 50000, 'eu_b2c' => 0, 'eu_limit' => 10000, 'uk_b2c' => 0, 'uk_orders' => 0, 'by_country' => array());
		if (!$this->hasTable('order') || !$this->hasTable('country')) {
			return $out;
		}
		$eu = array('AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE');
		$counted = $this->countedStatuses();
		if (!$counted) {
			return $out;
		}
		$rows = $this->db->query("SELECT COALESCE(cs.iso_code_2, cp.iso_code_2) AS iso, SUM(o.total) AS t, COUNT(*) AS n, SUM(CASE WHEN o.payment_company <> '' THEN o.total ELSE 0 END) AS biz
			FROM `" . DB_PREFIX . "order` o LEFT JOIN `" . DB_PREFIX . "country` cs ON cs.country_id = o.shipping_country_id LEFT JOIN `" . DB_PREFIX . "country` cp ON cp.country_id = o.payment_country_id
			WHERE o.order_status_id IN (" . implode(',', array_map('intval', $counted)) . ") AND o.date_added >= '" . $this->e($from) . "' GROUP BY iso ORDER BY t DESC")->rows;
		foreach ($rows as $r) {
			$iso = strtoupper((string)$r['iso']);
			$b2c = (float)$r['t'] - (float)$r['biz'];
			if (in_array($iso, $eu, true)) {
				$out['eu_b2c'] += $b2c;
			}
			if ($iso === 'GB') {
				$out['uk_b2c'] += $b2c;
				$out['uk_orders'] += (int)$r['n'];
			}
			$out['by_country'][] = array('iso' => $iso ?: '?', 'total' => round((float)$r['t'], 2), 'orders' => (int)$r['n'], 'business' => round((float)$r['biz'], 2));
		}
		$out['eu_b2c'] = round($out['eu_b2c'], 2);
		$out['uk_b2c'] = round($out['uk_b2c'], 2);
		return $out;
	}

	// Things that would make the VID files wrong
	private function checks($today) {
		$c = array();
		if (strlen($this->sget('reg_no', '')) !== 11) {
			$c[] = 'Add the SIA registration number in Settings: it goes into every VID file.';
		}
		if ($this->sget('board_name', '') === '') {
			$c[] = 'Add the board member\'s name in Settings: the annual report names who keeps the books.';
		}
		$bs = $this->balanceSheet($today);
		if (abs($bs['diff']) >= 0.01) {
			$c[] = 'The balance sheet is off by ' . number_format($bs['diff'], 2, '.', '') . ' EUR. Look for an entry posted to an account without an annual report row.';
		}
		$neg = array();
		$acc = $this->accounts();
		$all = $this->movements('', $today);
		foreach (array('2610', '2620', '2110', '2130') as $code) {
			if (isset($all[$code]) && $all[$code]['net'] < -0.005) {
				$neg[] = $acc[$code]['name_en'];
			}
		}
		if ($neg) {
			$c[] = 'Below zero: ' . implode(', ', $neg) . '. Usually a bank statement or a stock invoice is missing.';
		}
		$owner = isset($all['2390']) ? $all['2390']['net'] : 0;
		if ($owner > 0.005) {
			$c[] = 'The company has lent you ' . number_format($owner, 2, '.', '') . ' EUR. Loans to the owner can be taxed as profit in the UIN declaration; check before the year ends.';
		}
		return $c;
	}

	// ================================================================== deadlines
	private function holidays($y) {
		$easter = function_exists('easter_date') ? date('Y-m-d', easter_date($y)) : $this->easter($y);
		$h = array("$y-01-01", "$y-05-01", "$y-06-23", "$y-06-24", "$y-12-24", "$y-12-25", "$y-12-26", "$y-12-31",
			date('Y-m-d', strtotime($easter . ' -2 days')), date('Y-m-d', strtotime($easter . ' +1 day')));
		foreach (array("$y-05-04", "$y-11-18") as $d) {
			$h[] = $d;
			$w = (int)date('N', strtotime($d));
			if ($w >= 6) {
				$h[] = date('Y-m-d', strtotime($d . ' next monday'));
			}
		}
		return $h;
	}
	private function easter($y) {
		$a = $y % 19; $b = intdiv($y, 100); $c = $y % 100; $d = intdiv($b, 4); $e = $b % 4; $f = intdiv($b + 8, 25); $g = intdiv($b - $f + 1, 3);
		$h = (19 * $a + $b - $d - $g + 15) % 30; $i = intdiv($c, 4); $k = $c % 4; $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7; $m = intdiv($a + 11 * $h + 22 * $l, 451);
		$month = intdiv($h + $l - 7 * $m + 114, 31); $day = (($h + $l - 7 * $m + 114) % 31) + 1;
		return sprintf('%04d-%02d-%02d', $y, $month, $day);
	}
	// A deadline on a weekend or public holiday moves to the next working day
	private function workday($date) {
		$t = strtotime($date);
		for ($i = 0; $i < 10; $i++) {
			$d = date('Y-m-d', $t);
			if ((int)date('N', $t) < 6 && !in_array($d, $this->holidays((int)date('Y', $t)), true)) {
				return $d;
			}
			$t = strtotime('+1 day', $t);
		}
		return date('Y-m-d', $t);
	}

	private function filingTitle($kind, $period) {
		$mn = array('', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
		if ($kind === 'UIN') {
			list($y, $m) = explode('-', $period);
			return 'UIN declaration, ' . $mn[(int)$m] . ' ' . $y;
		}
		if ($kind === 'GP') {
			return 'Annual report ' . $period;
		}
		if ($kind === 'DDZ') {
			list($y, $m) = explode('-', $period);
			return 'Employer report (DDZ), ' . $mn[(int)$m] . ' ' . $y;
		}
		if ($kind === 'SEC') {
			return 'Renew security.txt (expires 26 Oct ' . $period . ')';
		}
		if ($kind === 'PVN') {
			list($y, $m) = explode('-', $period);
			return 'VAT return, ' . $mn[(int)$m] . ' ' . $y;
		}
		return $kind . ' ' . $period;
	}

	// Keeps the calendar of what is due from the books start to a year ahead, and decides month by month
	// whether a UIN declaration is needed.
	private function plan($force = false) {
		$start = $this->sget('books_start', date('Y-01-01'));
		$today = date('Y-m-d');
		$end = date('Y-m-d', strtotime('+13 months'));
		$fym = (int)$this->sget('fy_start', 1);
		$want = array();
		for ($t = strtotime(substr($start, 0, 7) . '-01'); $t <= strtotime($end); $t = strtotime('+1 month', $t)) {
			$ym = date('Y-m', $t);
			$next = strtotime('+1 month', $t);
			$isLast = (int)date('n', $t) === (($fym + 10) % 12) + 1;
			$want[] = array('UIN', $ym, $this->workday(date('Y-m-20', $next)), $isLast ? 'todo' : 'check');
			if ((int)$this->sget('employees', 0)) {
				$want[] = array('DDZ', $ym, $this->workday(date('Y-m-17', $next)), 'todo');
			}
			if ((int)$this->sget('vat', 0)) {
				$want[] = array('PVN', $ym, $this->workday(date('Y-m-20', $next)), 'todo');
			}
			if ($isLast) {
				list($fs, $fe) = $this->fy(date('Y-m-d', $t));
				$months = max(1, (int)$this->sget('gp_months', 5));
				$due = date('Y-m-t', strtotime(substr($fe, 0, 7) . '-01 +' . $months . ' months'));
				$want[] = array('GP', $this->fyLabel($fs), $this->workday($due), 'todo');
			}
		}
		// security.txt on dpcreator.eu expires every year on 26 October: renew it a month before
		for ($y = max(2027, (int)date('Y')); $y <= (int)date('Y', strtotime($end)); $y++) {
			$want[] = array('SEC', (string)$y, $this->workday($y . '-09-26'), 'todo');
		}
		foreach ($want as $w) {
			$this->db->query("INSERT IGNORE INTO `{$this->P}filing` SET kind = '" . $w[0] . "', period = '" . $this->e($w[1]) . "', due = '" . $w[2] . "', status = '" . $w[3] . "'");
			if ($force) {
				$this->db->query("UPDATE `{$this->P}filing` SET due = '" . $w[2] . "' WHERE kind = '" . $w[0] . "' AND period = '" . $this->e($w[1]) . "' AND status IN ('todo','check','ready')");
			}
		}
		// Switched off: DDZ / VAT rows not done yet are set aside (kept, not deleted)
		if (!(int)$this->sget('employees', 0)) {
			$this->db->query("UPDATE `{$this->P}filing` SET status = 'off' WHERE kind = 'DDZ' AND status IN ('todo','check')");
		} else {
			$this->db->query("UPDATE `{$this->P}filing` SET status = 'todo' WHERE kind = 'DDZ' AND status = 'off'");
		}
		if (!(int)$this->sget('vat', 0)) {
			$this->db->query("UPDATE `{$this->P}filing` SET status = 'off' WHERE kind = 'PVN' AND status IN ('todo','check')");
		} else {
			$this->db->query("UPDATE `{$this->P}filing` SET status = 'todo' WHERE kind = 'PVN' AND status = 'off'");
		}
		// UIN months: the last month of the year always; other months only if something in them is taxable
		foreach ($this->db->query("SELECT * FROM `{$this->P}filing` WHERE kind = 'UIN' AND status IN ('check','todo','notneeded') AND period <= '" . $this->e(date('Y-m')) . "'")->rows as $f) {
			$ms = $f['period'] . '-01';
			$me = date('Y-m-t', strtotime($ms));
			list($fs, $fe) = $this->fy($ms);
			if ($me === $fe) {
				$status = 'todo';
			} else {
				$u = $this->uinFigures($f['period']);
				$taxable = $u['R01'] > 0 || $u['R06'] > 0;
				$status = $taxable ? 'todo' : ($me >= $today ? 'check' : 'notneeded');
			}
			if ($status !== $f['status']) {
				$this->db->query("UPDATE `{$this->P}filing` SET status = '" . $status . "' WHERE filing_id = '" . (int)$f['filing_id'] . "'");
			}
		}
	}

	private function f_filings() {
		$this->plan();
		$rows = $this->db->query("SELECT filing_id, kind, period, due, status, amount, eds_no, file, generated, submitted, note FROM `{$this->P}filing` ORDER BY due DESC, kind LIMIT 400")->rows;
		foreach ($rows as &$r) {
			$r['title'] = $this->filingTitle($r['kind'], $r['period']);
		}
		$this->out(array('filings' => $rows));
	}

	// ================================================================== UIN declaration (DokUIENv5)
	private function uinFigures($period) {
		$ms = $period . '-01';
		$me = date('Y-m-t', strtotime($ms));
		list($fs, $fe) = $this->fy($ms);
		$last = $me === $fe;
		$acc = $this->accounts();
		$mv = $this->movements($ms, $me);
		$nonbiz = 0.0;
		$items = array();
		foreach ($acc as $code => $a) {
			if ($a['tag'] === 'R06_1' && isset($mv[$code]) && abs($mv[$code]['net']) >= 0.005) {
				$nonbiz += $mv[$code]['net'];
				$items[] = array('code' => $code, 'name' => $a['name_en'], 'amount' => round($mv[$code]['net'], 2));
			}
		}
		$div = (float)$this->db->query("SELECT COALESCE(SUM(amount), 0) AS v FROM `{$this->P}dividend` WHERE status = 'posted' AND date BETWEEN '" . $this->e($ms) . "' AND '" . $this->e($me) . "'")->row['v'];
		$f = array('R01' => (int)round($div), 'R02' => 0, 'R05' => 0, 'R05_1' => 0, 'R05_2' => 0, 'R05_3' => 0, 'R06_1' => (int)round(max(0, $nonbiz)), 'R06_2' => 0, 'R06_3' => 0, 'R06_4' => 0, 'R06_5' => 0, 'R06_7' => 0, 'R06_8' => 0);
		$f['R06'] = $f['R06_1'] + $f['R06_2'] + $f['R06_3'] + $f['R06_4'] + $f['R06_5'] + $f['R06_7'] + $f['R06_8'];
		$loan = 0;
		if ($last) {
			$end = $this->movements('', $fe, " AND l.account = '2390'");
			$loan = isset($end['2390']) ? round($end['2390']['net'], 2) : 0;
		}
		list($ps, $pe) = $this->period($ms);
		return $f + array('items' => $items, 'last' => $last, 'from' => $ms, 'to' => $me, 'fy_from' => $ps, 'fy_to' => $pe, 'loan_owner' => $loan);
	}

	private function uinCompute($in) {
		$f = array();
		foreach (array('R01', 'R02', 'R05_1', 'R05_2', 'R05_3', 'R06_1', 'R06_2', 'R06_3', 'R06_4', 'R06_5', 'R06_7', 'R06_8') as $k) {
			$f[$k] = max(0, (int)round($this->n(isset($in[$k]) ? $in[$k] : 0)));
		}
		$f['R02'] = min($f['R02'], $f['R01']);
		$f['R03'] = (int)round(max(0, ($f['R01'] - $f['R02']) / 0.8));
		$f['R04'] = (int)round($f['R03'] * 0.2);
		$f['R05'] = $f['R05_1'] + $f['R05_2'] + $f['R05_3'];
		$f['R06'] = $f['R06_1'] + $f['R06_2'] + $f['R06_3'] + $f['R06_4'] + $f['R06_5'] + $f['R06_7'] + $f['R06_8'];
		$f['R07'] = (int)round(($f['R05'] + $f['R06']) / 0.8);
		$f['R08'] = 0;
		$f['R12'] = 0;
		$f['R13'] = max(0, $f['R04'] - $f['R08'] - $f['R12']);
		$f['R14'] = (int)round($f['R13'] / 0.2); // as in VID's own example: 25 tax -> 125 base
		$f['R15'] = 0;
		$f['R16'] = 0;
		$f['R17'] = max(0, $f['R14'] - $f['R15'] - $f['R16']);
		$f['R22'] = max(0, $f['R17'] + $f['R07']);
		$f['R23'] = (int)round($f['R22'] * 0.2);
		$f['R26'] = $f['R23'];
		$f['R29'] = $f['R26'];
		return $f;
	}

	private function x($s) { return htmlspecialchars((string)$s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); }

	private function uinXml($period, $f, $opt) {
		$ms = $period . '-01';
		list($fs, $fe) = $this->period($ms);
		$last = date('Y-m-t', strtotime($ms)) === $fe;
		$firstYear = $this->firstYear($fs, $fe);
		$el = function ($k, $v) { return '  <' . $k . '>' . $v . '</' . $k . ">\n"; };
		$nil = function ($k) { return '  <' . $k . ' xsi:nil="true" />' . "\n"; };
		$x = '<?xml version="1.0" encoding="utf-8"?>' . "\n";
		$x .= '<DokUIENv5 xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
		$x .= $el('Precizejums', !empty($opt['correction']) ? 'true' : 'false');
		$x .= $el('NmrKods', $this->x($this->sget('reg_no')));
		$x .= $el('ParskNo', $fs . 'T00:00:00');
		$x .= $el('ParskLidz', $fe . 'T00:00:00');
		$x .= $el('TaksGads', (int)substr($ms, 0, 4));
		$x .= $el('TaksMenesis', (int)substr($ms, 5, 2));
		$x .= $nil('TaksCeturksnis');
		$x .= $el('PedejaDeklaracija', $last ? 'true' : 'false');
		if ($last && $firstYear) {
			$x .= $el('MinNodoklis', 'false');
			$x .= $el('Pamatojums', 'REGISTRACIJA_UR');
		}
		if ($this->sget('email') !== '') {
			$x .= $el('Epasts', $this->x($this->sget('email')));
		}
		if ($this->sget('phone') !== '') {
			$x .= $el('Talrunis', $this->x($this->sget('phone')));
		}
		$x .= $el('IeprZaudejumi', 'false');
		$x .= $el('IzmaksatasUnNosacitasDividendes', $f['R01'] > 0 ? 1 : (($f['R05'] + $f['R06']) > 0 ? 2 : 0));
		$x .= $el('NodoklisArvalstis', 'false');
		$x .= $el('IrVeiktiZiedojumi', 0);
		$x .= $el('IzmaksasNavNodoklis', 0);
		$x .= $el('NodoklaParmaksa', 0);
		foreach (array('R01', 'R02', 'R03', 'R04', 'R05', 'R05_1', 'R05_2', 'R05_3', 'R06', 'R06_1') as $k) {
			$x .= $el($k, $f[$k]);
		}
		if ($last) {
			$x .= $el('R06_2', $f['R06_2']);
			$x .= $el('DebitoraParadaUzkrajums', 'false');
			$x .= $el('R06_3', $f['R06_3']);
			$x .= $el('R06_4', $f['R06_4']);
			$x .= $el('R06_5', $f['R06_5']);
			$x .= $el('R06_5_1', 0);
			$x .= $el('R06_5_2', 0);
			$x .= $el('R06_6', 0);
		}
		$x .= $el('R06_7', $f['R06_7']);
		$x .= $el('R06_8', $f['R06_8']);
		foreach (array('R07', 'R08', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17') as $k) {
			$x .= $el($k, $f[$k]);
		}
		foreach (array('R18', 'R19', 'R20', 'R21') as $k) {
			$x .= $el($k, 0);
		}
		$x .= $el('R22', $f['R22']);
		$x .= $el('R23', $f['R23']);
		$x .= $el('R24', 0);
		$x .= $el('R25', 0);
		$x .= $el('R26', $f['R26']);
		foreach (array('R27', 'R27_1', 'R27_2', 'R27_3', 'R28', 'R28_1', 'R28_2') as $k) {
			$x .= $el($k, 0);
		}
		$x .= $el('R29', $f['R29']);
		$x .= $el('R31', 0);
		$x .= $el('R31_1', 0);
		$x .= $el('R31_2', 0);
		foreach (array('Tab1_1', 'Tab1_2', 'Tab1_3', 'Tab02', 'Tab05_1', 'Tab06_2', 'Tab08', 'Tab09_1', 'Tab15', 'Tab16', 'Tab31_2', 'Pielikumi') as $t) {
			$x .= '  <' . $t . " />\n";
		}
		$x .= "</DokUIENv5>\n";
		return $x;
	}

	// ================================================================== annual report (DokGPv1, UGP)
	private function gpRows() {
		return array(
			'BA' => array('R30', 'R40', 'R50', 'R60', 'R70', 'R80', 'R100', 'R110', 'R120', 'R130', 'R140', 'R150', 'R160', 'R170', 'R180', 'R190', 'R200', 'R210', 'R220', 'R240', 'R250', 'R260', 'R270', 'R280', 'R290', 'R300', 'R310', 'R320', 'R330', 'R340', 'R370', 'R380', 'R390', 'R400', 'R410', 'R420', 'R430', 'R440', 'R450', 'R470', 'R480', 'R490', 'R500', 'R510', 'R520', 'R530', 'R540', 'R550', 'R570', 'R580', 'R590', 'R600', 'R610', 'R620', 'R630', 'R640'),
			'BP' => array('R660', 'R670', 'R680', 'R690', 'R710', 'R720', 'R730', 'R740', 'R760', 'R770', 'R780', 'R790', 'R800', 'R802', 'R804', 'R820', 'R830', 'R840', 'R850', 'R870', 'R880', 'R890', 'R900', 'R910', 'R920', 'R930', 'R940', 'R950', 'R960', 'R970', 'R980', 'R990', 'R1000', 'R1010', 'R1030', 'R1040', 'R1050', 'R1060', 'R1070', 'R1080', 'R1090', 'R1100', 'R1110', 'R1120', 'R1130', 'R1140', 'R1150', 'R1160', 'R1170', 'R1180', 'R1190'),
			'PZ' => array('R10', 'R20', 'R30', 'R40', 'R50', 'R60', 'R70', 'R80', 'R90', 'R100', 'R110', 'R120', 'R130', 'R140', 'R150', 'R160', 'R170', 'R180', 'R190', 'R200', 'R210', 'R220', 'R230', 'R240', 'R250', 'R260', 'R270', 'R280', 'R290'),
		);
	}

	// Whole-euro rows with the totals worked out as EDS works them out; rounding is absorbed so both sides match
	private function gpColumns($fyStart, $fyEnd) {
		$acc = $this->accounts();
		$bs = $this->balanceSheet($fyEnd);
		$pl = $this->plFrom($this->movements($fyStart, $fyEnd), $acc);
		$R = $this->gpRows();
		$ba = array_fill_keys($R['BA'], 0);
		$bp = array_fill_keys($R['BP'], 0);
		$pz = array_fill_keys($R['PZ'], 0);
		foreach ($bs['rows'] as $k => $v) {
			list($side, $row) = explode(':', $k);
			if ($side === 'BA' && isset($ba[$row])) {
				$ba[$row] += $v;
			} elseif ($side === 'BP' && isset($bp[$row])) {
				$bp[$row] += $v;
			}
		}
		foreach ($pl['rows'] as $row => $v) {
			if (isset($pz[$row])) {
				$pz[$row] += $v;
			}
		}
		foreach ($ba as $k => $v) { $ba[$k] = (int)round($v); }
		foreach ($bp as $k => $v) { $bp[$k] = (int)round($v); }
		foreach ($pz as $k => $v) { $pz[$k] = (int)round($v); }
		// Profit or loss (PZA2) totals
		$pz['R10'] = $pz['R20'] + $pz['R30'];
		$pz['R50'] = $pz['R10'] - $pz['R40'];
		$pz['R100'] = $pz['R110'] + $pz['R120'] + $pz['R130'];
		$pz['R140'] = $pz['R150'] + $pz['R160'];
		$pz['R170'] = $pz['R180'] + $pz['R190'];
		$pz['R210'] = $pz['R220'] + $pz['R230'];
		$pz['R240'] = $pz['R50'] - $pz['R60'] - $pz['R70'] + $pz['R80'] - $pz['R90'] + $pz['R100'] + $pz['R140'] + $pz['R170'] - $pz['R200'] - $pz['R210'];
		$pz['R260'] = $pz['R240'] - $pz['R250'];
		$pz['R290'] = $pz['R260'] + $pz['R270'] - $pz['R280'];
		$bp['R790'] = $pz['R290'];
		// Balance sheet totals
		$ba['R80'] = $ba['R30'] + $ba['R40'] + $ba['R50'] + $ba['R60'] + $ba['R70'];
		$ba['R100'] = $ba['R110'] + $ba['R120'];
		$ba['R130'] = $ba['R140'] + $ba['R150'];
		$ba['R220'] = $ba['R100'] + $ba['R130'] + $ba['R160'] + $ba['R170'] + $ba['R180'] + $ba['R190'] + $ba['R200'] + $ba['R210'];
		$ba['R330'] = $ba['R240'] + $ba['R250'] + $ba['R260'] + $ba['R270'] + $ba['R280'] + $ba['R290'] + $ba['R300'] + $ba['R310'] + $ba['R320'];
		$ba['R340'] = $ba['R80'] + $ba['R220'] + $ba['R330'];
		$ba['R410'] = $ba['R420'] + $ba['R430'];
		$ba['R450'] = $ba['R370'] + $ba['R380'] + $ba['R390'] + $ba['R400'] + $ba['R410'] + $ba['R440'];
		$ba['R550'] = $ba['R470'] + $ba['R480'] + $ba['R490'] + $ba['R500'] + $ba['R510'] + $ba['R520'] + $ba['R530'] + $ba['R540'];
		$ba['R610'] = $ba['R570'] + $ba['R580'] + $ba['R590'] + $ba['R600'];
		$ba['R630'] = $ba['R450'] + $ba['R550'] + $ba['R610'] + $ba['R620'];
		$ba['R640'] = $ba['R340'] + $ba['R630'];
		$tot = function () use (&$bp) {
			$bp['R770'] = $bp['R710'] + $bp['R720'] + $bp['R730'] + $bp['R740'] + $bp['R760'];
			$bp['R800'] = $bp['R660'] + $bp['R670'] + $bp['R680'] + $bp['R690'] + $bp['R770'] + $bp['R780'] + $bp['R790'];
			$bp['R850'] = $bp['R820'] + $bp['R830'] + $bp['R840'];
			$bp['R1010'] = $bp['R870'] + $bp['R880'] + $bp['R890'] + $bp['R900'] + $bp['R910'] + $bp['R920'] + $bp['R930'] + $bp['R940'] + $bp['R950'] + $bp['R960'] + $bp['R970'] + $bp['R980'] + $bp['R990'] + $bp['R1000'];
			$bp['R1180'] = $bp['R1030'] + $bp['R1040'] + $bp['R1050'] + $bp['R1060'] + $bp['R1070'] + $bp['R1080'] + $bp['R1090'] + $bp['R1100'] + $bp['R1110'] + $bp['R1120'] + $bp['R1130'] + $bp['R1140'] + $bp['R1150'] + $bp['R1160'] + $bp['R1170'];
			$bp['R1190'] = $bp['R800'] + $bp['R802'] + $bp['R850'] + $bp['R1010'] + $bp['R1180'];
		};
		$tot();
		$round = $ba['R640'] - $bp['R1190'];
		if ($round !== 0) {
			// Whole-euro rounding goes to other creditors (or other debtors when it would go below zero)
			if ($bp['R1130'] + $round >= 0) {
				$bp['R1130'] += $round;
				$tot();
			} else {
				$ba['R500'] -= $round;
				$ba['R550'] -= $round;
				$ba['R630'] -= $round;
				$ba['R640'] -= $round;
			}
		}
		return array('ba' => $ba, 'bp' => $bp, 'pz' => $pz, 'rounding' => $round, 'diff' => $bs['diff']);
	}

	private function gpXml($fyStart, $fyEnd, $opt) {
		$cur = $this->gpColumns($fyStart, $fyEnd);
		$ps = date('Y-m-d', strtotime($fyStart . ' -1 year'));
		$pe = date('Y-m-d', strtotime($fyStart . ' -1 day'));
		$hasPrev = $this->sget('books_start', $fyStart) <= $pe;
		$prev = $hasPrev ? $this->gpColumns($ps, $pe) : null;
		$R = $this->gpRows();
		$el = function ($k, $v, $ind = '  ') { return $ind . '<' . $k . '>' . $v . '</' . $k . ">\n"; };
		$block = function ($tag, $keys, $vals) use ($el) {
			$s = '      <' . $tag . ">\n";
			foreach ($keys as $k) {
				$s .= $el($k, $vals ? (int)$vals[$k] : 0, '        ');
			}
			return $s . '      </' . $tag . ">\n";
		};
		$staff = max(0, (int)(isset($opt['staff']) ? $opt['staff'] : 0));
		$x = '<?xml version="1.0" encoding="utf-8"?>' . "\n";
		$x .= '<DokGPv1 xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
		$x .= $el('Precizejums', !empty($opt['correction']) ? 'true' : 'false');
		$x .= $el('NmrKods', $this->x($this->sget('reg_no')));
		$x .= $el('TaksNo', $fyStart . 'T00:00:00');
		$x .= $el('TaksLidz', $fyEnd . 'T00:00:00');
		$x .= $el('Epasts', $this->x($this->sget('email')));
		$x .= $el('Talrunis', $this->x($this->sget('phone')));
		$x .= $el('GadaParskataVeids', 'UGP');
		$x .= "  <UGP>\n";
		$reg = $this->sget('registered', '');
		$months = (strtotime($fyEnd) - strtotime($fyStart)) / 86400 < 360;
		if ($months && $reg !== '' && $reg !== $fyStart && !empty($opt['short_reason'])) {
			$x .= $el('Pamatojums', $this->x($opt['short_reason']), '    ');
		}
		$x .= $el('Darbinieki', $staff, '    ');
		$x .= $el('UznemVeids', 1, '    ');
		$x .= $el('GramVeids', 3, '    ');
		$x .= $el('GramVardsUzvards', $this->x($this->sget('board_name')), '    ');
		$x .= $el('GramAmats', $this->x($this->sget('board_title', 'Valdes loceklis')), '    ');
		$x .= $el('DatumsPub', $this->d($opt['approved']) . 'T00:00:00', '    ');
		$x .= $el('AizpAmats', $this->x($this->sget('board_title', 'Valdes loceklis')), '    ');
		$x .= $el('IrSadalaNaudasPlusmasParskats', 'false', '    ');
		$x .= $el('IrSadalaKapitalaRezervjuIzmainuParskats', 'false', '    ');
		$x .= $el('IrSadalaPielikums', 'true', '    ');
		$x .= $el('IrSadalaRevidents', 'false', '    ');
		$x .= "    <BilancesAktivi>\n" . $block('BABeigas', $R['BA'], $cur['ba']) . $block('BASakums', $R['BA'], $prev ? $prev['ba'] : null) . "    </BilancesAktivi>\n";
		$x .= "    <BilancesPasivi>\n" . $block('BPBeigas', $R['BP'], $cur['bp']) . $block('BPSakums', $R['BP'], $prev ? $prev['bp'] : null) . "    </BilancesPasivi>\n";
		$x .= "    <PelnasZaudejumuAprekins>\n" . $el('PZAType', 2, '      ') . $block('PZA2Beigas', $R['PZ'], $cur['pz']) . $block('PZA2Sakums', $R['PZ'], $prev ? $prev['pz'] : null) . "    </PelnasZaudejumuAprekins>\n";
		// Notes a micro company gives (shown as notes under the balance sheet in EDS)
		$x .= "    <PielikumsPiezimes>\n";
		$x .= $el('RaditVisu', 'false', '      ');
		$x .= $el('Piezimes', 'true', '      ');
		$x .= $el('Saisinats', 'false', '      ');
		$x .= $el('R101', $staff, '      ');
		$x .= $el('R10201', 1, '      ');
		$x .= $el('R104', $this->x(isset($opt['policy']) && $opt['policy'] !== '' ? $opt['policy'] : $this->sget('policy')), '      ');
		foreach (array('R10801' => 'guarantees', 'R10802' => 'leases', 'R10803' => 'pledges') as $code => $k) {
			$v = isset($opt[$k]) && trim($opt[$k]) !== '' ? $opt[$k] : 'Nav';
			$x .= $el($code, $this->x($v), '      ');
		}
		$x .= $el('R109', $this->x(isset($opt['after']) && trim($opt['after']) !== '' ? $opt['after'] : 'Nav'), '      ');
		$x .= "    </PielikumsPiezimes>\n";
		$x .= "  </UGP>\n";
		$x .= "</DokGPv1>\n";
		return array('xml' => $x, 'cur' => $cur, 'prev' => $prev);
	}

	// ================================================================== building and marking filings
	private function f_preview() {
		$id = (int)$this->in($this->request->get, 'id', 0);
		$fl = $this->db->query("SELECT * FROM `{$this->P}filing` WHERE filing_id = '" . $id . "'")->row;
		if (!$fl) {
			return $this->fail('Not found.');
		}
		$saved = $fl['data'] ? json_decode($fl['data'], true) : array();
		$fl['title'] = $this->filingTitle($fl['kind'], $fl['period']);
		if ($fl['kind'] === 'UIN') {
			$u = $this->uinFigures($fl['period']);
			$inputs = isset($saved['inputs']) ? $saved['inputs'] : $u;
			$this->out(array('filing' => $fl, 'figures' => $u, 'inputs' => array_intersect_key($inputs, array_flip(array('R01', 'R02', 'R05_1', 'R05_2', 'R05_3', 'R06_1', 'R06_2', 'R06_3', 'R06_4', 'R06_5', 'R06_7', 'R06_8'))), 'computed' => $this->uinCompute($inputs), 'first_year' => $this->firstYear($u['fy_from'], $u['fy_to'])));
			return;
		}
		if ($fl['kind'] === 'GP') {
			list($fs, $fe) = $this->fyFromLabel($fl['period']);
			$cols = $this->gpColumns($fs, $fe);
			$opt = isset($saved['opt']) ? $saved['opt'] : array('approved' => '', 'staff' => (int)$this->sget('employees', 0), 'policy' => $this->sget('policy'), 'guarantees' => 'Nav', 'leases' => 'Nav', 'pledges' => 'Nav', 'after' => 'Nav', 'short_reason' => '');
			$this->out(array('filing' => $fl, 'columns' => $cols, 'opt' => $opt, 'from' => $fs, 'to' => $fe, 'unbooked' => (int)$this->db->query("SELECT COUNT(*) AS n FROM `{$this->P}bank` WHERE status = 'open' AND date <= '" . $this->e($fe) . "'")->row['n'], 'checks' => $this->checks($fe)));
			return;
		}
		$this->out(array('filing' => $fl, 'manual' => true));
	}

	private function firstYear($fs, $fe) {
		$reg = $this->sget('registered', '');
		return $reg !== '' && $reg >= $fs && $reg <= $fe;
	}


	private function fyFromLabel($label) {
		$m = max(1, min(12, (int)$this->sget('fy_start', 1)));
		$s = strlen($label) === 4 ? sprintf('%s-%02d-01', $label, $m) : $label . '-01';
		return $this->period($s);
	}

	private function f_build() {
		$in = $this->input();
		$fl = $this->db->query("SELECT * FROM `{$this->P}filing` WHERE filing_id = '" . (int)$this->in($in, 'filing_id', 0) . "'")->row;
		if (!$fl) {
			return $this->fail('Not found.');
		}
		if (strlen($this->sget('reg_no', '')) !== 11) {
			return $this->fail('Add the SIA registration number in Settings first.');
		}
		$opt = (array)$this->in($in, 'opt', array());
		if ($fl['kind'] === 'UIN') {
			$inputs = (array)$this->in($in, 'inputs', array());
			$f = $this->uinCompute($inputs);
			$xml = $this->uinXml($fl['period'], $f, $opt);
			$name = 'UIN_' . $this->sget('reg_no') . '_' . $fl['period'] . '.xml';
			$amount = $f['R29'];
			$data = array('inputs' => $inputs, 'computed' => $f, 'opt' => $opt);
		} elseif ($fl['kind'] === 'GP') {
			if (empty($opt['approved'])) {
				return $this->fail('Enter the date you (as the owner) approved the annual report.');
			}
			if ($this->sget('board_name', '') === '') {
				return $this->fail('Add the board member\'s name in Settings first.');
			}
			list($fs, $fe) = $this->fyFromLabel($fl['period']);
			$r = $this->gpXml($fs, $fe, $opt);
			if (abs($r['cur']['diff']) >= 1) {
				return $this->fail('The balance sheet is off by ' . $r['cur']['diff'] . ' EUR. Fix the books before building the annual report.');
			}
			$xml = $r['xml'];
			$name = 'GP_' . $this->sget('reg_no') . '_' . $fl['period'] . '.xml';
			$amount = $r['cur']['pz']['R290'];
			$data = array('opt' => $opt, 'cur' => $r['cur']);
		} else {
			return $this->fail('This one is filled in EDS directly for now. Mark it as submitted when it is done.');
		}
		// Well-formed check before it goes to EDS
		$prev = libxml_use_internal_errors(true);
		$ok = simplexml_load_string($xml);
		libxml_use_internal_errors($prev);
		if (!$ok) {
			return $this->fail('The file did not come out as valid XML.');
		}
		$store = date('Ymd-His') . '-' . $name;
		file_put_contents($this->fileDir() . $store, $xml);
		$status = $fl['status'] === 'submitted' ? 'submitted' : 'ready';
		$this->db->query("UPDATE `{$this->P}filing` SET file = '" . $this->e($store) . "', data = '" . $this->e(json_encode($data)) . "', amount = '" . (float)$amount . "', generated = NOW(), status = '" . $status . "' WHERE filing_id = '" . (int)$fl['filing_id'] . "'");
		// The year's corporate income tax goes into the books with the December declaration
		if ($fl['kind'] === 'UIN') {
			$divTax = (float)$this->db->query("SELECT COALESCE(SUM(l.debit - l.credit), 0) AS v FROM `{$this->P}line` l JOIN `{$this->P}entry` e ON e.entry_id = l.entry_id WHERE e.src LIKE 'divtax:%' AND l.account = '8610' AND e.date BETWEEN '" . $this->e($fl['period'] . '-01') . "' AND '" . $this->e(date('Y-m-t', strtotime($fl['period'] . '-01'))) . "'")->row['v'];
			$rest = round($f['R29'] - $divTax, 2);
			$this->post('uin:' . $fl['period'], date('Y-m-t', strtotime($fl['period'] . '-01')), 'tax', 'UIN ' . $fl['period'], 'Corporate income tax, ' . $fl['period'] . ' (besides tax already booked on dividends)', $rest > 0 ? array(
				array('account' => '8610', 'debit' => $rest),
				array('account' => '5710', 'credit' => $rest, 'partner' => 'VID'),
			) : array());
		}
		$this->out(array('ok' => 1, 'file' => $store, 'amount' => $amount, 'xml' => $xml));
	}

	private function f_mark() {
		$in = $this->input();
		$fl = $this->db->query("SELECT * FROM `{$this->P}filing` WHERE filing_id = '" . (int)$this->in($in, 'filing_id', 0) . "'")->row;
		if (!$fl) {
			return $this->fail('Not found.');
		}
		$status = (string)$this->in($in, 'status', 'submitted');
		if (!in_array($status, array('submitted', 'todo', 'notneeded'), true)) {
			return $this->fail('Unknown status.');
		}
		$this->db->query("UPDATE `{$this->P}filing` SET status = '" . $status . "', eds_no = '" . $this->e(mb_substr(trim((string)$this->in($in, 'eds_no', '')), 0, 64)) . "', note = '" . $this->e(mb_substr(trim((string)$this->in($in, 'note', '')), 0, 255)) . "', submitted = " . ($status === 'submitted' ? 'NOW()' : 'NULL') . " WHERE filing_id = '" . (int)$fl['filing_id'] . "'");
		// Submitting the annual report closes that year: later changes become dated corrections
		if ($status === 'submitted' && $fl['kind'] === 'GP') {
			list($fs, $fe) = $this->fyFromLabel($fl['period']);
			if ($this->sget('locked_until', '') < $fe) {
				$this->sset('locked_until', $fe);
			}
		}
		$this->out(array('ok' => 1));
	}

	// ================================================================== reminders
	// Runs at most once a day, from the admin page and from the shop footer (see the catalog side).
	public function remind($force = false) {
		if (!$this->ready() || !(int)$this->sget('remind_on', 1)) {
			return 0;
		}
		$today = date('Y-m-d');
		if (!$force && $this->sget('last_tick', '') === $today) {
			return 0;
		}
		$this->sset('last_tick', $today);
		$this->plan();
		$to = trim($this->sget('remind_email', ''));
		if ($to === '') {
			return 0;
		}
		$days = array_map('intval', array_filter(explode(',', $this->sget('remind_days', '7,2,0')), 'strlen'));
		$sent = 0;
		foreach ($this->db->query("SELECT * FROM `{$this->P}filing` WHERE status IN ('todo','ready') AND due <= '" . $this->e(date('Y-m-d', strtotime('+' . max($days ?: array(7)) . ' days'))) . "' ORDER BY due")->rows as $f) {
			$left = (int)floor((strtotime($f['due']) - strtotime($today)) / 86400);
			$tag = $left < 0 ? 'late' . intdiv(-$left, 7) : 'd' . $left;
			if ($left >= 0 && !in_array($left, $days, true)) {
				continue;
			}
			$done = $f['reminded'] !== '' ? explode(',', $f['reminded']) : array();
			if (in_array($tag, $done, true)) {
				continue;
			}
			$title = $this->filingTitle($f['kind'], $f['period']);
			$when = $left < 0 ? 'was due on ' . $f['due'] . ' (' . (-$left) . ' days ago)' : ($left === 0 ? 'is due today' : 'is due on ' . $f['due'] . ' (in ' . $left . ' days)');
			$body = $title . ' ' . $when . ".\n\n";
			if ($f['kind'] === 'UIN') {
				$body .= "Open Books > Returns in the dpcreator.eu admin, check the figures and download the XML. Upload it in EDS (eds.vid.gov.lv), sign and submit.\nAny tax is paid into the unified tax account (vienotais nodokļu konts) by the 23rd.\n";
			} elseif ($f['kind'] === 'GP') {
				$body .= "Make sure every bank statement of the year is booked, then open Books > Returns, enter the approval date and download the XML. Upload it in EDS, check the form, sign and submit.\n";
			} elseif ($f['kind'] === 'SEC') {
				$body .= "In /.well-known/security.txt on the site, change the Expires line to 26 October of next year and upload it with FileZilla. Check that https://dpcreator.eu/security still shows the right update period, then mark this as done in Books > Returns.\n";
			} elseif ($f['kind'] === 'DDZ') {
				$body .= "The employer report is filled in EDS. Pay the social tax and income tax into the unified tax account by the 23rd.\n";
			} else {
				$body .= "File it in EDS and mark it as submitted in Books > Returns.\n";
			}
			$body .= "\nThe dates are worked out by the books from VID's rules; check them against EDS if anything looks off.\n";
			if ($this->mail($to, 'Books: ' . $title . ' ' . ($left < 0 ? 'is late' : ($left === 0 ? 'is due today' : 'due ' . $f['due'])), $body)) {
				$done[] = $tag;
				$this->db->query("UPDATE `{$this->P}filing` SET reminded = '" . $this->e(implode(',', array_slice($done, -12))) . "' WHERE filing_id = '" . (int)$f['filing_id'] . "'");
				$sent++;
			}
		}
		return $sent;
	}

	private function mail($to, $subject, $text) {
		if (!class_exists('Mail')) {
			return false;
		}
		try {
			$mail = new Mail($this->config->get('config_mail_engine'));
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			$mail->setTo($to);
			$mail->setFrom($this->config->get('config_email'));
			$mail->setSender(html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
			$mail->setSubject($subject);
			$mail->setText($text);
			$mail->send();
			return true;
		} catch (\Throwable $e) {
			return false;
		}
	}

	private function f_test_reminder() {
		$to = trim($this->sget('remind_email', ''));
		if ($to === '') {
			return $this->fail('Add the reminder email in Settings.');
		}
		$ok = $this->mail($to, 'Books: test reminder', "This is how deadline reminders from the dpcreator.eu books will look.\n");
		$this->out($ok ? array('ok' => 1) : array('error' => 'The email could not be sent. Check System > Settings > Mail.'));
	}
}
