<?php
// One-off helper: makes dpcreator.co.uk serve the same shop files as dpcreator.eu, keeping the domain (and its mailboxes).
// The placeholder folders are renamed, not deleted. ?go=1 does it, ?undo=1 puts the placeholder back.
class ControllerExtensionModuleDpcUklink extends Controller {
	public function index() {
		$this->response->addHeader('Content-Type: application/json');
		if (!$this->user->isLogged() || !$this->user->hasPermission('modify', 'marketplace/installer')) {
			return $this->response->setOutput(json_encode(array('error' => 'no permission')));
		}
		$eu = rtrim(dirname(DIR_APPLICATION), '/');                 // .../domains/dpcreator.eu/public_html
		$uk = dirname(dirname($eu)) . '/dpcreator.co.uk';            // .../domains/dpcreator.co.uk
		$info = function ($p) {
			if (!file_exists($p) && !is_link($p)) return 'missing';
			$o = is_link($p) ? 'link -> ' . readlink($p) : (is_dir($p) ? 'dir: ' . implode(', ', array_slice(array_diff(scandir($p), array('.', '..')), 0, 12)) : 'file');
			$st = @lstat($p);
			return $o . ' (owner ' . ($st ? $st['uid'] : '?') . ')';
		};
		$out = array('eu' => $eu, 'uk' => $uk, 'php_uid' => function_exists('posix_geteuid') ? posix_geteuid() : getmyuid(), 'eu_owner' => fileowner($eu));
		$stamp = date('Ymd-His');
		if (!empty($this->request->get['go'])) {
			foreach (array('public_html', 'private_html') as $d) {
				$p = $uk . '/' . $d;
				if (is_link($p) && realpath($p) === realpath($eu)) { $out['did'][] = $d . ' already linked'; continue; }
				if (file_exists($p) || is_link($p)) {
					if (!rename($p, $uk . '/' . $d . '.placeholder-' . $stamp)) { $out['error'] = 'could not rename ' . $d; break; }
				}
				$out['did'][] = $d . (symlink($eu, $p) ? ' linked' : ' LINK FAILED');
			}
		} elseif (!empty($this->request->get['undo'])) {
			foreach (array('public_html', 'private_html') as $d) {
				$p = $uk . '/' . $d;
				$old = glob($uk . '/' . $d . '.placeholder-*');
				if (is_link($p) && $old) { unlink($p); rename(end($old), $p); $out['did'][] = $d . ' restored'; }
			}
		}
		foreach (array('public_html', 'private_html') as $d) {
			$out['now'][$d] = $info($uk . '/' . $d);
		}
		$this->response->setOutput(json_encode($out));
	}
}
