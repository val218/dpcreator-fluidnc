SmartTabUI pendant case, version 1
dpCREATOR - https://dpcreator.eu

For the SmartTabUI pendant: ESP32 board with a 2.8" touch screen.
The files are 3MF in millimetres, already turned the right way up for printing.

Parts
  1_Case_body.3mf            Case body                     97 x 192.5 x 24.3 mm   print 1
  2a_Top_plate_full.3mf      Top plate, closed             97 x 159 x 7.6 mm      print 1 of the two top plates
  2b_Top_plate_for_panel.3mf Top plate with a panel recess 97 x 159 x 7.6 mm
  3_Panel_2mm.3mf            2 mm front panel              93.2 x 155.2 x 1.9 mm  for top plate 2b
  4_IO_expander_clip.3mf     IO expander clip              18.8 x 81.9 x 10 mm    print 1
                             holds the IO expander board inside the case
  Render.png                 How the parts go together

Choose a top plate
  2a: a plain closed top.
  2b + 3: a top with a separate 2 mm panel. Print the panel in another colour,
          or use its outline to cut one from 2 mm acrylic or aluminium (SVG/DXF).

Material: PETG, as used for the assembled pendants.

Assembly, wiring and firmware: https://dpcreator.eu/docs/build-tabui-pendant
Pendant firmware: https://dpcreator.eu/firmware (Pendant firmware tab)

Tell us what to change
  This is version 1. If something is tight, loose, hard to print or awkward
  to hold, say so in the comments on the Printables or Thingiverse page, or
  email us from https://dpcreator.eu/contact. Your notes decide what goes
  into the next case. Photos of your print are very welcome.

Licence
  (c) 2026 dpCREATOR (digital project creator)
  Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)
  https://creativecommons.org/licenses/by-nc-sa/4.0/
  You may print, change and share these files. Credit dpCREATOR, don't sell
  the files or prints made from them, and share any changes under the same
  licence.
