<?php
// dpCREATOR sitemap.xml: every page Google should know about.
// Served at /sitemap.xml by OpenCart's .htaccess rule (route extension/feed/google_sitemap).
class ControllerExtensionFeedGoogleSitemap extends Controller {
	private $out = array();

	private function add($loc, $lastmod = '', $priority = '0.5') {
		$loc = str_replace('&amp;', '&', $loc);
		if (isset($this->out[$loc])) {
			return;
		}
		$this->out[$loc] = '<url><loc>' . htmlspecialchars($loc, ENT_XML1, 'UTF-8') . '</loc>' . ($lastmod ? '<lastmod>' . date('Y-m-d', strtotime($lastmod)) . '</lastmod>' : '') . '<priority>' . $priority . '</priority></url>';
	}

	private function hasTable($t) {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . $t) . "'")->num_rows;
	}

	public function index() {
		$store = (int)$this->config->get('config_store_id');
		$base = $this->config->get('config_secure') ? HTTPS_SERVER : HTTP_SERVER;
		$this->add($base, '', '1.0');

		$cats = $this->db->query("SELECT c.category_id, c.date_modified FROM `" . DB_PREFIX . "category` c JOIN `" . DB_PREFIX . "category_to_store` s ON s.category_id = c.category_id AND s.store_id = '" . $store . "' WHERE c.status = 1 ORDER BY c.sort_order");
		foreach ($cats->rows as $c) {
			$path = $this->db->query("SELECT GROUP_CONCAT(path_id ORDER BY level SEPARATOR '_') AS p FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$c['category_id'] . "'")->row;
			$this->add($this->url->link('product/category', 'path=' . ($path && $path['p'] ? $path['p'] : $c['category_id'])), $c['date_modified'], '0.8');
		}

		$prods = $this->db->query("SELECT p.product_id, p.date_modified FROM `" . DB_PREFIX . "product` p JOIN `" . DB_PREFIX . "product_to_store` s ON s.product_id = p.product_id AND s.store_id = '" . $store . "' WHERE p.status = 1 AND p.date_available <= NOW() ORDER BY p.sort_order, p.product_id");
		foreach ($prods->rows as $p) {
			$this->add($this->url->link('product/product', 'product_id=' . (int)$p['product_id']), $p['date_modified'], '0.9');
		}

		$infos = $this->db->query("SELECT i.information_id FROM `" . DB_PREFIX . "information` i JOIN `" . DB_PREFIX . "information_to_store` s ON s.information_id = i.information_id AND s.store_id = '" . $store . "' WHERE i.status = 1 AND i.information_id <> 11 ORDER BY i.sort_order");
		foreach ($infos->rows as $i) {
			$this->add($this->url->link('information/information', 'information_id=' . (int)$i['information_id']), '', '0.6');
		}
		$this->add($this->url->link('information/contact'), '', '0.4');

		// Journal blog (documentation)
		if ($this->hasTable('journal3_blog_post')) {
			$this->add($this->url->link('journal3/blog'), '', '0.7');
			$cols = array();
			foreach ($this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "journal3_blog_post`")->rows as $col) {
				$cols[] = $col['Field'];
			}
			$idCol = in_array('post_id', $cols) ? 'post_id' : (in_array('journal_blog_post_id', $cols) ? 'journal_blog_post_id' : $cols[0]);
			$dateCol = '';
			foreach (array('date_updated', 'date_modified', 'date_created', 'date_added', 'date') as $dc) {
				if (in_array($dc, $cols)) {
					$dateCol = $dc;
					break;
				}
			}
			$where = in_array('status', $cols) ? ' WHERE status = 1' : '';
			foreach ($this->db->query("SELECT `" . $idCol . "` AS id" . ($dateCol ? ", `" . $dateCol . "` AS d" : ", '' AS d") . " FROM `" . DB_PREFIX . "journal3_blog_post`" . $where)->rows as $b) {
				$this->add($this->url->link('journal3/blog/post', 'journal_blog_post_id=' . (int)$b['id']), $b['d'], '0.7');
			}
			if ($this->hasTable('journal3_blog_category')) {
				$ccols = array();
				foreach ($this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "journal3_blog_category`")->rows as $col) {
					$ccols[] = $col['Field'];
				}
				$cid = in_array('category_id', $ccols) ? 'category_id' : (in_array('journal_blog_category_id', $ccols) ? 'journal_blog_category_id' : $ccols[0]);
				$cw = in_array('status', $ccols) ? ' WHERE status = 1' : '';
				foreach ($this->db->query("SELECT `" . $cid . "` AS id FROM `" . DB_PREFIX . "journal3_blog_category`" . $cw)->rows as $c) {
					$this->add($this->url->link('journal3/blog', 'journal_blog_category_id=' . (int)$c['id']), '', '0.5');
				}
			}
		}

		// standalone pages outside OpenCart
		$this->add($base . 'demo/', '', '0.7');

		$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n" . implode("\n", $this->out) . "\n</urlset>";
		$this->response->addHeader('Content-Type: application/xml; charset=utf-8');
		$this->response->setOutput($xml);
	}
}
