<?php
// dpCREATOR follow-ups: the daily email of customers waiting too long.
// tick() runs from the shop footer on normal page views and sends at most once a day,
// after the hour set in the admin. index() is for a host cron job:
//   index.php?route=extension/module/dpc_followup_mail&key=<key shown in the admin settings>
require_once(DIR_SYSTEM . 'library/dpcfollowup.php');

class ControllerExtensionModuleDpcFollowupMail extends Controller {
	public function tick() {
		try {
			$this->run(false);
		} catch (\Throwable $e) {
			// never break a shop page
		}
	}

	public function index() {
		$key = (string)$this->config->get('dashboard_dpc_followup_mail_key');
		$this->response->addHeader('Content-Type: text/plain; charset=utf-8');
		if ($key === '' || !isset($this->request->get['key']) || !hash_equals($key, (string)$this->request->get['key'])) {
			$this->response->setOutput('wrong key');
			return;
		}
		$this->response->setOutput($this->run(true));
	}

	private function run($cron) {
		if (!$this->config->get('dashboard_dpc_followup_status') || $this->config->get('dashboard_dpc_followup_mail') === '0' || $this->config->get('dashboard_dpc_followup_mail') === 0) {
			return 'off';
		}
		$hour = $this->config->get('dashboard_dpc_followup_mail_hour');
		$hour = ($hour === null || $hour === '') ? 8 : (int)$hour;
		$today = date('Y-m-d');
		if ((int)date('G') < $hour) {
			return 'too early';
		}
		$stamp = DIR_STORAGE . 'dpc_followup_mail.txt';
		$fp = @fopen($stamp, 'c+');
		if (!$fp || !flock($fp, LOCK_EX | LOCK_NB)) {
			return 'busy';
		}
		$last = trim(stream_get_contents($fp));
		if ($last === $today) {
			flock($fp, LOCK_UN);
			fclose($fp);
			return 'already sent today';
		}
		ftruncate($fp, 0);
		rewind($fp);
		fwrite($fp, $today);
		fflush($fp);
		flock($fp, LOCK_UN);
		fclose($fp);

		$out = self::sendDigest($this->registry, false);
		return $out;
	}

	// Also used by the admin "Send a test email" button
	public static function sendDigest($registry, $always, $adminUrl = null) {
		$config = $registry->get('config');
		$db = $registry->get('db');
		$admin = $adminUrl ?: (defined('HTTPS_ADMIN') ? HTTPS_ADMIN : (($config->get('config_ssl') ?: $config->get('config_url')) . 'admin/'));
		$catalog = defined('HTTPS_CATALOG') ? HTTPS_CATALOG : ($config->get('config_ssl') ?: $config->get('config_url'));
		$cfg = function ($key) use ($config) { return $config->get($key); };
		$fmt = $db->query("SELECT code, symbol_left, symbol_right, decimal_place FROM `" . DB_PREFIX . "currency`")->rows;
		$cur = array();
		foreach ($fmt as $c) {
			$cur[$c['code']] = $c;
		}
		$lib = new DpcFollowup(
			$db,
			$cfg,
			function ($route, $query) use ($admin) { return $admin . 'index.php?route=' . $route . ($query !== '' ? '&' . $query : ''); },
			function ($amount, $code, $value) use ($cur) {
				$c = isset($cur[$code]) ? $cur[$code] : array('symbol_left' => '', 'symbol_right' => ' ' . $code, 'decimal_place' => 2);
				return $c['symbol_left'] . number_format((float)$amount * (float)$value, (int)$c['decimal_place'], '.', ',') . $c['symbol_right'];
			},
			$catalog
		);
		$items = $lib->getItems();
		$mail = DpcFollowup::digest($items, html_entity_decode((string)$config->get('config_name'), ENT_QUOTES, 'UTF-8'), $admin . 'index.php?route=common/dashboard', $always);
		if (!$mail) {
			return 'nothing overdue';
		}
		$to = trim((string)$config->get('dashboard_dpc_followup_mail_to')) ?: $config->get('config_email');
		$n = DpcFollowup::send($cfg, $to, $mail);
		return 'sent to ' . $n . ' address(es): ' . count($items['overdue']) . ' overdue';
	}
}
