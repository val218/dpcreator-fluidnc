<?php
// dpCREATOR: collects the product facts the structured-data fix needs (called from the footer).
require_once(DIR_SYSTEM . 'library/dpcschema.php');

class ControllerExtensionModuleDpcSchema extends Controller {
	public function ctx() {
		try {
			$route = isset($this->request->get['route']) ? $this->request->get['route'] : '';
			if ($route !== 'product/product' || empty($this->request->get['product_id'])) {
				return;
			}
			$this->load->model('catalog/product');
			$p = $this->model_catalog_product->getProduct((int)$this->request->get['product_id']);
			if (!$p) {
				return;
			}
			$from = '';
			foreach (array('date_available', 'date_added') as $k) {
				if (!empty($p[$k]) && strpos($p[$k], '0000') !== 0) {
					$from = date('Y-m-d', strtotime($p[$k]));
					break;
				}
			}
			DpcSchema::$ctx = array(
				'model' => trim($p['model']),
				'sku' => trim($p['sku']),
				'mpn' => trim($p['mpn']),
				'ean' => trim($p['ean']),
				'manufacturer' => isset($p['manufacturer']) ? $p['manufacturer'] : '',
				'shipping' => (int)$p['shipping'],
				'valid_from' => $from
			);
		} catch (\Throwable $e) {
			// never break a product page
		}
	}
}
