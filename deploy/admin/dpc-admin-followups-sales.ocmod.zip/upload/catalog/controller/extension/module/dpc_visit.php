<?php
// dpCREATOR Visitors: records page views (called from the footer) and the page-script beacon.
require_once(DIR_SYSTEM . 'library/dpcvisit.php');

class ControllerExtensionModuleDpcVisit extends Controller {
	public function log() {
		try {
			if (!isset($this->request->server['REQUEST_METHOD']) || $this->request->server['REQUEST_METHOD'] !== 'GET') {
				return;
			}
			if (!empty($this->request->server['HTTP_X_REQUESTED_WITH'])) {
				return;
			}
			$v = new DpcVisit($this->db);
			if (!$v->ready()) {
				$v->install();
			}
			$name = $this->config->get('session_name') ?: 'OCSESSID';
			$sess = $this->session->getId();
			$hasCookie = isset($this->request->cookie[$name]) && $this->request->cookie[$name] === $sess;
			$url = isset($this->request->server['REQUEST_URI']) ? html_entity_decode($this->request->server['REQUEST_URI'], ENT_QUOTES, 'UTF-8') : '';
			$ref = isset($this->request->server['HTTP_REFERER']) ? html_entity_decode($this->request->server['HTTP_REFERER'], ENT_QUOTES, 'UTF-8') : '';
			$v->log($sess, $hasCookie, $url, $ref, (int)$this->customer->getId(), !empty($this->session->data['user_id']), $this->cart->hasProducts());
		} catch (\Throwable $e) {
			// never break a shop page
		}
	}

	public function beacon() {
		try {
			$v = new DpcVisit($this->db);
			if ($v->ready()) {
				$p = $this->request->post;
				$v->beacon($this->session->getId(), array(
					'i' => !empty($p['i']),
					's' => isset($p['s']) ? (string)$p['s'] : '',
					'tz' => isset($p['tz']) ? (string)$p['tz'] : '',
					't' => isset($p['t']) ? html_entity_decode((string)$p['t'], ENT_QUOTES, 'UTF-8') : '',
					'u' => isset($p['u']) ? html_entity_decode((string)$p['u'], ENT_QUOTES, 'UTF-8') : ''
				));
			}
		} catch (\Throwable $e) {
		}
		$this->response->addHeader('Content-Type: text/plain');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput('ok');
	}
}
