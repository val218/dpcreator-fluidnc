<?php
// dpCREATOR light theme: serves the generated light stylesheet (built in the admin under Design → Light theme).
class ControllerExtensionModuleDpcTheme extends Controller {
	public function css() {
		$file = DIR_IMAGE . 'catalog/dpc-site/dpc-light.css';
		$css = is_file($file) ? file_get_contents($file) : '';
		$etag = '"' . md5($css) . '"';
		$this->response->addHeader('Content-Type: text/css; charset=utf-8');
		$this->response->addHeader('Cache-Control: public, max-age=600');
		$this->response->addHeader('ETag: ' . $etag);
		if (isset($this->request->server['HTTP_IF_NONE_MATCH']) && trim($this->request->server['HTTP_IF_NONE_MATCH']) === $etag) {
			$this->response->addHeader('HTTP/1.1 304 Not Modified');
			$this->response->setOutput('');
			return;
		}
		$this->response->setOutput($css);
	}
}
