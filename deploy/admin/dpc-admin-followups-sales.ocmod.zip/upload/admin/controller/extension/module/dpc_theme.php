<?php
// dpCREATOR light theme builder: reads the shop's styles in the browser and saves a light version.
class ControllerExtensionModuleDpcTheme extends Controller {
	public function install() {
	}

	public function index() {
		$this->document->setTitle('Light theme');
		$token = 'user_token=' . $this->session->data['user_token'];
		$data['breadcrumbs'] = array(
			array('text' => 'Home', 'href' => $this->url->link('common/dashboard', $token, true)),
			array('text' => 'Light theme', 'href' => $this->url->link('extension/module/dpc_theme', $token, true))
		);
		$file = DIR_IMAGE . 'catalog/dpc-site/dpc-light.css';
		$data['built'] = is_file($file) ? date('Y-m-d H:i', filemtime($file)) . ', ' . round(filesize($file) / 1024) . ' KB' : '';
		$data['save_url'] = html_entity_decode($this->url->link('extension/module/dpc_theme/save', $token, true), ENT_QUOTES, 'UTF-8');
		$data['shop'] = rtrim(HTTPS_CATALOG, '/');
		$data['can_edit'] = $this->user->hasPermission('modify', 'extension/module/dpc_theme');
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_theme', $data));
	}

	public function save() {
		$json = array();
		if (!$this->user->hasPermission('modify', 'extension/module/dpc_theme')) {
			$json['error'] = 'You do not have permission to change the light theme.';
		} elseif (!isset($this->request->post['css'])) {
			$json['error'] = 'Nothing to save.';
		} else {
			$css = html_entity_decode((string)$this->request->post['css'], ENT_QUOTES, 'UTF-8');
			$css = str_ireplace(array('</style', '<script', 'expression('), '', $css);
			if (strlen($css) > 900000) {
				$json['error'] = 'The light theme is too large (' . round(strlen($css) / 1024) . ' KB).';
			} else {
				$dir = DIR_IMAGE . 'catalog/dpc-site/';
				if (!is_dir($dir)) {
					@mkdir($dir, 0755, true);
				}
				$file = $dir . 'dpc-light.css';
				if (is_file($file)) {
					@copy($file, $dir . 'dpc-light.previous.css');
				}
				if (@file_put_contents($file, $css) === false) {
					$json['error'] = 'Could not write the file.';
				} else {
					$json['success'] = 'Saved: ' . round(strlen($css) / 1024) . ' KB.';
				}
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
