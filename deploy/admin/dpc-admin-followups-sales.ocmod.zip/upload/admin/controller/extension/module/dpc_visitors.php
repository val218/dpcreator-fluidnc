<?php
// dpCREATOR Visitors: who is on the shop, and whether they are people or bots.
require_once(DIR_SYSTEM . 'library/dpcvisit.php');

class ControllerExtensionModuleDpcVisitors extends Controller {
	private function lib() {
		return new DpcVisit($this->db);
	}

	public function install() {
		$this->lib()->install();
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_visitors', array('module_dpc_visitors_status' => 1));
	}

	public function uninstall() {
	}

	public function index() {
		$this->document->setTitle('Visitors');
		$this->lib()->install();
		$token = 'user_token=' . $this->session->data['user_token'];
		$data['breadcrumbs'] = array(
			array('text' => 'Home', 'href' => $this->url->link('common/dashboard', $token, true)),
			array('text' => 'Visitors', 'href' => $this->url->link('extension/module/dpc_visitors', $token, true))
		);
		$data['data_url'] = html_entity_decode($this->url->link('extension/module/dpc_visitors/data', $token, true), ENT_QUOTES, 'UTF-8');
		$data['hits_url'] = html_entity_decode($this->url->link('extension/module/dpc_visitors/hits', $token, true), ENT_QUOTES, 'UTF-8');
		$data['shop'] = rtrim(HTTPS_CATALOG, '/');
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_visitors', $data));
	}

	public function data() {
		$lib = $this->lib();
		$lib->install();
		$lib->resolveHosts(15);
		$period = isset($this->request->get['period']) ? $this->request->get['period'] : 'now';
		$since = array('now' => '-15 minutes', 'hour' => '-1 hour', 'today' => 'today', 'week' => '-7 days', 'month' => '-30 days');
		$from = date('Y-m-d H:i:s', strtotime(isset($since[$period]) ? $since[$period] : '-15 minutes'));
		$rows = $lib->visits($from, $period === 'month' || $period === 'week' ? 2000 : 600);
		$counts = array('human' => 0, 'customer' => 0, 'unknown' => 0, 'likely_bot' => 0, 'bot' => 0, 'you' => 0);
		$bots = array();
		$refs = array();
		$pages = array();
		$out = array();
		$cust = $this->url->link('customer/customer/edit', 'user_token=' . $this->session->data['user_token'], true);
		foreach ($rows as $v) {
			list($kind, $why) = DpcVisit::classify($v);
			$counts[$kind]++;
			if ($kind === 'bot') {
				$n = DpcVisit::botName($v['ua']);
				$bots[$n] = (isset($bots[$n]) ? $bots[$n] : 0) + 1;
			}
			if ($kind === 'human' || $kind === 'customer') {
				$host = $v['referer'] !== '' ? parse_url($v['referer'], PHP_URL_HOST) : '';
				$own = parse_url(HTTPS_CATALOG, PHP_URL_HOST);
				$host = $host && $host !== $own ? preg_replace('/^www\./', '', $host) : 'Direct or unknown';
				$refs[$host] = (isset($refs[$host]) ? $refs[$host] : 0) + 1;
				$pages[$v['landing']] = (isset($pages[$v['landing']]) ? $pages[$v['landing']] : 0) + 1;
			}
			$out[] = array(
				'id' => (int)$v['visit_id'], 'kind' => $kind, 'why' => $why, 'ip' => $v['ip'], 'host' => (string)$v['host'],
				'device' => $kind === 'bot' ? DpcVisit::botName($v['ua']) : DpcVisit::device($v['ua']), 'ua' => $v['ua'],
				'lang' => substr($v['lang'], 0, 20), 'tz' => $v['tz'], 'screen' => $v['screen'],
				'referer' => $v['referer'], 'landing' => $v['landing'], 'last_url' => $v['last_url'], 'hits' => (int)$v['hits'],
				'first' => $v['first_seen'], 'last' => $v['last_seen'], 'cart' => (bool)$v['cart'],
				'customer' => (int)$v['customer_id'] ? trim($v['firstname'] . ' ' . $v['lastname']) ?: $v['email'] : '',
				'customer_link' => (int)$v['customer_id'] ? html_entity_decode($cust, ENT_QUOTES, 'UTF-8') . '&customer_id=' . (int)$v['customer_id'] : ''
			);
		}
		arsort($bots);
		arsort($refs);
		arsort($pages);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode(array(
			'counts' => $counts, 'bots' => array_slice($bots, 0, 8, true), 'referers' => array_slice($refs, 0, 8, true), 'pages' => array_slice($pages, 0, 8, true),
			'visits' => $out, 'now' => date('Y-m-d H:i:s')
		), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
	}

	public function hits() {
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($this->lib()->hits(isset($this->request->get['visit_id']) ? (int)$this->request->get['visit_id'] : 0), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
	}
}
