<?php
// dpCREATOR sales on the admin dashboard, split into shipped goods and digital downloads.
// An order line is "shipped goods" when its product requires shipping, otherwise "digital".
// An order with both counts as a shipped-goods order; its money is split between the two by line value.
class ControllerExtensionDashboardDpcSales extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/dpc_sales');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$post = $this->request->post;
			if (!isset($post['dashboard_dpc_sales_statuses'])) {
				$post['dashboard_dpc_sales_statuses'] = array();
			}
			$this->model_setting_setting->editSetting('dashboard_dpc_sales', $post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$token = 'user_token=' . $this->session->data['user_token'];
		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $token, true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', $token . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/dpc_sales', $token, true))
		);
		$data['action'] = $this->url->link('extension/dashboard/dpc_sales', $token, true);
		$data['cancel'] = $this->url->link('marketplace/extension', $token . '&type=dashboard', true);

		foreach (array('width' => 12, 'status' => 1, 'sort_order' => 0) as $key => $default) {
			$name = 'dashboard_dpc_sales_' . $key;
			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}
		$data['columns'] = range(1, 12);

		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		$data['selected_statuses'] = array_map('strval', isset($this->request->post['dashboard_dpc_sales_statuses']) ? (array)$this->request->post['dashboard_dpc_sales_statuses'] : $this->countedStatuses());

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/dashboard/dpc_sales_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_sales')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}

	// Order statuses that count as a sale. Until saved: the shop's processing and complete
	// statuses, without the default "Pending" status and statuses that undo a sale.
	private function countedStatuses() {
		$saved = $this->config->get('dashboard_dpc_sales_statuses');
		if (is_array($saved)) {
			return array_values(array_filter(array_map('intval', $saved)));
		}
		$ids = array();
		foreach (array('config_processing_status', 'config_complete_status') as $key) {
			$v = $this->config->get($key);
			foreach ((is_array($v) ? $v : array($v)) as $id) {
				$ids[(int)$id] = true;
			}
		}
		unset($ids[(int)$this->config->get('config_order_status_id')], $ids[0]);
		if ($ids) {
			$q = $this->db->query("SELECT order_status_id, name FROM `" . DB_PREFIX . "order_status` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' AND order_status_id IN (" . implode(',', array_keys($ids)) . ")");
			foreach ($q->rows as $r) {
				if (preg_match('/revers|refund|cancel|chargeback|denied|fail|void|expired/i', $r['name'])) {
					unset($ids[(int)$r['order_status_id']]);
				}
			}
		}
		return array_keys($ids);
	}

	public function dashboard() {
		$this->load->language('extension/dashboard/dpc_sales');
		$statuses = $this->countedStatuses();
		$now = time();
		$today = date('Y-m-d', $now);
		$periods = array(
			'today' => $today,
			'week'  => date('Y-m-d', strtotime('-6 days', $now)),
			'month' => date('Y-m-d', strtotime('-29 days', $now)),
			'year'  => date('Y') . '-01-01'
		);
		$empty = array('orders' => 0, 'revenue' => 0.0, 'units' => 0);
		$sum = array();
		foreach ($periods as $p => $from) {
			$sum[$p] = array('ship' => $empty, 'dig' => $empty, 'mixed' => 0);
		}

		// Chart buckets: 12 months and 30 days
		$months = array();
		for ($i = 11; $i >= 0; $i--) {
			$m = date('Y-m', strtotime(date('Y-m-01', $now) . ' -' . $i . ' months'));
			$months[$m] = array('label' => date('M y', strtotime($m . '-01')), 'ship' => 0.0, 'dig' => 0.0, 'ship_n' => 0, 'dig_n' => 0);
		}
		$days = array();
		for ($i = 29; $i >= 0; $i--) {
			$d = date('Y-m-d', strtotime('-' . $i . ' days', $now));
			$days[$d] = array('label' => date('j M', strtotime($d)), 'ship' => 0.0, 'dig' => 0.0, 'ship_n' => 0, 'dig_n' => 0);
		}
		$top = array('ship' => array(), 'dig' => array());

		if ($statuses) {
			$from = min(array_keys($months)) . '-01';
			$from = min($from, $periods['year']);
			$rows = $this->db->query("SELECT o.order_id, o.date_added, o.total, o.shipping_method,
					(SELECT COALESCE(SUM(ot.value), 0) FROM `" . DB_PREFIX . "order_total` ot WHERE ot.order_id = o.order_id AND ot.code = 'shipping') AS ship_fee,
					op.product_id, op.name, op.quantity, (op.total + op.tax * op.quantity) AS line, p.shipping
				FROM `" . DB_PREFIX . "order` o
				JOIN `" . DB_PREFIX . "order_product` op ON op.order_id = o.order_id
				LEFT JOIN `" . DB_PREFIX . "product` p ON p.product_id = op.product_id
				WHERE o.order_status_id IN (" . implode(',', $statuses) . ") AND o.store_id = 0 AND o.date_added >= '" . $this->db->escape($from) . "'
				ORDER BY o.order_id")->rows;

			$orders = array();
			foreach ($rows as $r) {
				$id = (int)$r['order_id'];
				if (!isset($orders[$id])) {
					$orders[$id] = array('date' => substr($r['date_added'], 0, 10), 'total' => (float)$r['total'], 'fee' => (float)$r['ship_fee'], 'ship' => 0.0, 'dig' => 0.0, 'ship_u' => 0, 'dig_u' => 0, 'has_ship' => false, 'has_dig' => false, 'lines' => array());
				}
				$physical = $r['shipping'] === null ? ($r['shipping_method'] !== '') : ((int)$r['shipping'] === 1);
				$k = $physical ? 'ship' : 'dig';
				$orders[$id][$k] += (float)$r['line'];
				$orders[$id][$k . '_u'] += (int)$r['quantity'];
				$orders[$id]['has_' . $k] = true;
				$orders[$id]['lines'][] = array($k, (int)$r['product_id'], $r['name'], (int)$r['quantity']);
			}

			foreach ($orders as $o) {
				// Split what was paid: the shipping fee goes to shipped goods, the rest by line value
				$rest = max(0.0, $o['total'] - $o['fee']);
				$lines = $o['ship'] + $o['dig'];
				$ship = $o['has_ship'] ? $o['fee'] : 0.0;
				$dig = 0.0;
				if ($lines > 0) {
					$ship += $rest * $o['ship'] / $lines;
					$dig = $rest * $o['dig'] / $lines;
				} elseif ($o['has_ship']) {
					$ship += $rest;
				} else {
					$dig = $rest;
				}
				$kind = $o['has_ship'] ? 'ship' : 'dig';

				foreach ($periods as $p => $start) {
					if ($o['date'] >= $start) {
						$sum[$p][$kind]['orders']++;
						$sum[$p]['ship']['revenue'] += $ship;
						$sum[$p]['dig']['revenue'] += $dig;
						$sum[$p]['ship']['units'] += $o['ship_u'];
						$sum[$p]['dig']['units'] += $o['dig_u'];
						if ($o['has_ship'] && $o['has_dig']) {
							$sum[$p]['mixed']++;
						}
					}
				}
				$m = substr($o['date'], 0, 7);
				if (isset($months[$m])) {
					$months[$m]['ship'] += $ship;
					$months[$m]['dig'] += $dig;
					$months[$m][$kind . '_n']++;
				}
				if (isset($days[$o['date']])) {
					$days[$o['date']]['ship'] += $ship;
					$days[$o['date']]['dig'] += $dig;
					$days[$o['date']][$kind . '_n']++;
				}
				if ($o['date'] >= $periods['month']) {
					foreach ($o['lines'] as $l) {
						$key = $l[1] ?: $l[2];
						if (!isset($top[$l[0]][$key])) {
							$top[$l[0]][$key] = array('name' => $l[2], 'units' => 0);
						}
						$top[$l[0]][$key]['units'] += $l[3];
					}
				}
			}
		}

		$cur = $this->config->get('config_currency');
		$data['rows'] = array();
		foreach (array('today' => 'text_today', 'week' => 'text_week', 'month' => 'text_month', 'year' => 'text_year') as $p => $label) {
			$data['rows'][] = array(
				'label'       => $this->language->get($label),
				'ship_orders' => $sum[$p]['ship']['orders'],
				'ship_units'  => $sum[$p]['ship']['units'],
				'ship_rev'    => $this->currency->format($sum[$p]['ship']['revenue'], $cur),
				'dig_orders'  => $sum[$p]['dig']['orders'],
				'dig_units'   => $sum[$p]['dig']['units'],
				'dig_rev'     => $this->currency->format($sum[$p]['dig']['revenue'], $cur),
				'total_rev'   => $this->currency->format($sum[$p]['ship']['revenue'] + $sum[$p]['dig']['revenue'], $cur),
				'mixed'       => $sum[$p]['mixed']
			);
		}
		foreach (array('ship', 'dig') as $k) {
			uasort($top[$k], function ($a, $b) { return $b['units'] - $a['units']; });
			$data['top_' . $k] = array_slice(array_values($top[$k]), 0, 3);
		}

		$cinfo = $this->db->query("SELECT symbol_left, symbol_right, decimal_place FROM `" . DB_PREFIX . "currency` WHERE code = '" . $this->db->escape($cur) . "'")->row;
		$data['chart'] = json_encode(array(
			'months' => array_values($months),
			'days'   => array_values($days),
			'cur'    => array('l' => $cinfo ? $cinfo['symbol_left'] : '', 'r' => $cinfo ? $cinfo['symbol_right'] : '', 'd' => $cinfo ? (int)$cinfo['decimal_place'] : 2)
		), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
		$data['no_statuses'] = !$statuses;
		$data['settings'] = $this->url->link('extension/dashboard/dpc_sales', 'user_token=' . $this->session->data['user_token'], true);
		$data['orders_link'] = $this->url->link('sale/order', 'user_token=' . $this->session->data['user_token'], true);
		return $this->load->view('extension/dashboard/dpc_sales_info', $data);
	}
}
