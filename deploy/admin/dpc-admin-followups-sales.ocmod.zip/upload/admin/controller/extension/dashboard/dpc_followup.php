<?php
// dpCREATOR follow-ups: a dashboard list of customers waiting on the shop, a badge on every
// admin page, a check before logging out, and follow-up notes on the order page.
class ControllerExtensionDashboardDpcFollowup extends Controller {
	private $error = array();

	public function install() {
		$this->load->model('extension/dashboard/dpc_followup');
		$this->model_extension_dashboard_dpc_followup->install();
	}

	public function uninstall() {
		// The notes table is kept, so reinstalling keeps the history.
	}

	public function index() {
		$this->load->language('extension/dashboard/dpc_followup');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		$this->load->model('extension/dashboard/dpc_followup');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$post = $this->request->post;
			$post['dashboard_dpc_followup_mail_key'] = $this->config->get('dashboard_dpc_followup_mail_key') ?: bin2hex(random_bytes(16));
			$this->model_setting_setting->editSetting('dashboard_dpc_followup', $post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$token = 'user_token=' . $this->session->data['user_token'];
		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $token, true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', $token . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/dpc_followup', $token, true))
		);
		$data['action'] = $this->url->link('extension/dashboard/dpc_followup', $token, true);
		$data['cancel'] = $this->url->link('marketplace/extension', $token . '&type=dashboard', true);

		foreach (array('width' => 12, 'status' => 1, 'sort_order' => 0, 'logout' => 1, 'login' => 1, 'mail' => 1, 'mail_hour' => 8, 'mail_to' => $this->config->get('config_email')) as $key => $default) {
			$name = 'dashboard_dpc_followup_' . $key;
			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}
		$data['columns'] = range(1, 12);
		$data['hours'] = range(0, 23);
		$key = $this->config->get('dashboard_dpc_followup_mail_key');
		$data['cron_url'] = $key ? HTTPS_CATALOG . 'index.php?route=extension/module/dpc_followup_mail&key=' . $key : '';
		$data['test_url'] = html_entity_decode($this->url->link('extension/dashboard/dpc_followup/testmail', $token, true), ENT_QUOTES, 'UTF-8');
		$data['timezone'] = date_default_timezone_get() . ', now ' . date('H:i');
		$data['status_hours'] = $this->model_extension_dashboard_dpc_followup->statusHours();
		$data['other_hours'] = $this->model_extension_dashboard_dpc_followup->otherHours();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/dashboard/dpc_followup_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}

	public function dashboard() {
		$this->load->language('extension/dashboard/dpc_followup');
		$data['list_url'] = html_entity_decode($this->url->link('extension/dashboard/dpc_followup/items', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
		$data['act_url'] = html_entity_decode($this->url->link('extension/dashboard/dpc_followup/act', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
		$data['settings'] = $this->url->link('extension/dashboard/dpc_followup', 'user_token=' . $this->session->data['user_token'], true);
		return $this->load->view('extension/dashboard/dpc_followup_info', $data);
	}

	// GET: the open items as JSON. With &item=order:17 only that item, with its notes.
	public function items() {
		$this->load->model('extension/dashboard/dpc_followup');
		$m = $this->model_extension_dashboard_dpc_followup;
		$items = $m->getItems();
		$out = array(
			'enabled'  => (bool)$this->config->get('dashboard_dpc_followup_status'),
			'logout'   => $this->config->get('dashboard_dpc_followup_logout') === null ? true : (bool)$this->config->get('dashboard_dpc_followup_logout'),
			'login'    => $this->config->get('dashboard_dpc_followup_login') === null ? true : (bool)$this->config->get('dashboard_dpc_followup_login'),
			'can_edit' => $this->user->hasPermission('modify', 'extension/dashboard/dpc_followup'),
			'counts'   => array('overdue' => count($items['overdue']), 'waiting' => count($items['waiting']), 'snoozed' => count($items['snoozed'])),
			'dashboard' => html_entity_decode($this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8') . '#dpc-followup'
		);
		if (isset($this->request->get['item'])) {
			$key = (string)$this->request->get['item'];
			$out['item'] = null;
			foreach ($items as $list) {
				foreach ($list as $it) {
					if ($it['key'] === $key) {
						$out['item'] = $it;
					}
				}
			}
			$out['notes'] = $m->getNotes($key);
			foreach ($out['notes'] as &$n) {
				$n['ago'] = $m->ago(time() - strtotime($n['created']));
			}
			unset($n);
		} else {
			$out['items'] = $items;
		}
		foreach (array('overdue', 'waiting', 'snoozed') as $state) {
			if (isset($out['items'][$state])) {
				foreach ($out['items'][$state] as &$it) {
					$it['link'] = html_entity_decode($it['link'], ENT_QUOTES, 'UTF-8');
				}
				unset($it);
			}
		}
		if (!empty($out['item'])) {
			$out['item']['link'] = html_entity_decode($out['item']['link'], ENT_QUOTES, 'UTF-8');
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
	}

	// POST item, action (note|snooze), note, days
	public function act() {
		$json = array();
		if ($this->request->server['REQUEST_METHOD'] !== 'POST') {
			$json['error'] = 'POST only';
		} elseif (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			$json['error'] = 'You do not have permission to add follow-ups.';
		} else {
			$item = isset($this->request->post['item']) ? (string)$this->request->post['item'] : '';
			$action = isset($this->request->post['action']) ? (string)$this->request->post['action'] : '';
			$note = isset($this->request->post['note']) ? trim(html_entity_decode((string)$this->request->post['note'], ENT_QUOTES, 'UTF-8')) : '';
			$days = isset($this->request->post['days']) ? (float)$this->request->post['days'] : 0;
			if (!preg_match('/^(order|return|approval|review|rndp|rndu):\d+$/', $item)) {
				$json['error'] = 'Unknown item.';
			} elseif ($action === 'note' && $note === '') {
				$json['error'] = 'Write what you did, for example "Emailed the customer about the delay".';
			} elseif ($action === 'snooze' && ($days <= 0 || $days > 60)) {
				$json['error'] = 'Choose how long to snooze.';
			} elseif ($action !== 'note' && $action !== 'snooze') {
				$json['error'] = 'Unknown action.';
			} else {
				$this->load->model('extension/dashboard/dpc_followup');
				$until = $action === 'snooze' ? date('Y-m-d H:i:s', time() + (int)round($days * 86400)) : null;
				if ($action === 'snooze' && $note === '') {
					$note = 'Snoozed';
				}
				$this->model_extension_dashboard_dpc_followup->addAction($item, $action, $note, $until, $this->user->getId(), $this->user->getUserName());
				$json['success'] = $action === 'note' ? 'Note saved. The timer starts again from now.' : 'Snoozed until ' . date('D j M H:i', strtotime($until)) . '.';
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	// POST: send the daily email now, even when nothing is overdue
	public function testmail() {
		$json = array();
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			$json['error'] = 'You do not have permission to send the follow-up email.';
		} else {
			try {
				require_once(DIR_CATALOG . 'controller/extension/module/dpc_followup_mail.php');
				$json['success'] = 'Test email: ' . ControllerExtensionModuleDpcFollowupMail::sendDigest($this->registry, true, HTTPS_SERVER) . '.';
			} catch (\Throwable $e) {
				$json['error'] = 'The email could not be sent: ' . $e->getMessage();
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
