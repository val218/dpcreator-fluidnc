<?php
// dpCREATOR follow-ups: a dashboard list of customers waiting on the shop, a badge on every
// admin page, a check before logging out, and follow-up notes on the order page.
class ControllerExtensionDashboardDpcFollowup extends Controller {
	private $error = array();

	public function install() {
		$this->load->model('extension/dashboard/dpc_followup');
		$this->model_extension_dashboard_dpc_followup->install();
	}

	public function uninstall() {
		// The notes table is kept, so reinstalling keeps the history.
	}

	public function index() {
		$this->load->language('extension/dashboard/dpc_followup');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		$this->load->model('extension/dashboard/dpc_followup');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$post = $this->request->post;
			$post['dashboard_dpc_followup_mail_key'] = $this->config->get('dashboard_dpc_followup_mail_key') ?: bin2hex(random_bytes(16));
			$this->model_setting_setting->editSetting('dashboard_dpc_followup', $post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$token = 'user_token=' . $this->session->data['user_token'];
		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $token, true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', $token . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/dpc_followup', $token, true))
		);
		$data['action'] = $this->url->link('extension/dashboard/dpc_followup', $token, true);
		$data['cancel'] = $this->url->link('marketplace/extension', $token . '&type=dashboard', true);

		foreach (array('width' => 12, 'status' => 1, 'sort_order' => 0, 'logout' => 1, 'login' => 1, 'mail' => 1, 'mail_hour' => 8, 'mail_to' => $this->config->get('config_email')) as $key => $default) {
			$name = 'dashboard_dpc_followup_' . $key;
			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}
		$data['columns'] = range(1, 12);
		$data['hours'] = range(0, 23);
		$key = $this->config->get('dashboard_dpc_followup_mail_key');
		$data['cron_url'] = $key ? HTTPS_CATALOG . 'index.php?route=extension/module/dpc_followup_mail&key=' . $key : '';
		$data['test_url'] = html_entity_decode($this->url->link('extension/dashboard/dpc_followup/testmail', $token, true), ENT_QUOTES, 'UTF-8');
		$data['timezone'] = date_default_timezone_get() . ', now ' . date('H:i');
		$data['status_hours'] = $this->model_extension_dashboard_dpc_followup->statusHours();
		$data['other_hours'] = $this->model_extension_dashboard_dpc_followup->otherHours();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/dashboard/dpc_followup_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}

	public function dashboard() {
		$this->load->language('extension/dashboard/dpc_followup');
		$data['list_url'] = html_entity_decode($this->url->link('extension/dashboard/dpc_followup/items', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
		$data['act_url'] = html_entity_decode($this->url->link('extension/dashboard/dpc_followup/act', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
		$data['settings'] = $this->url->link('extension/dashboard/dpc_followup', 'user_token=' . $this->session->data['user_token'], true);
		return $this->load->view('extension/dashboard/dpc_followup_info', $data);
	}

	// GET: the open items as JSON. With &item=order:17 only that item, with its notes.
	public function items() {
		$inbox = null;
		if (is_file(DIR_SYSTEM . 'library/dpcinbox.php')) {
			require_once(DIR_SYSTEM . 'library/dpcinbox.php');
			$inbox = new DpcInbox($this->db);
			if ($inbox->ready()) {
				$last = $inbox->lastSync();
				if ($last === null || strtotime($last) < time() - 300) {
					try {
						$inbox->sync(6);
					} catch (\Exception $e) {
					}
				}
			} else {
				$inbox = null;
			}
		}
		$this->load->model('extension/dashboard/dpc_followup');
		$m = $this->model_extension_dashboard_dpc_followup;
		$items = $m->getItems();
		$out = array(
			'enabled'  => (bool)$this->config->get('dashboard_dpc_followup_status'),
			'logout'   => $this->config->get('dashboard_dpc_followup_logout') === null ? true : (bool)$this->config->get('dashboard_dpc_followup_logout'),
			'login'    => $this->config->get('dashboard_dpc_followup_login') === null ? true : (bool)$this->config->get('dashboard_dpc_followup_login'),
			'can_edit' => $this->user->hasPermission('modify', 'extension/dashboard/dpc_followup'),
			'counts'   => array('overdue' => count($items['overdue']), 'waiting' => count($items['waiting']), 'snoozed' => count($items['snoozed'])),
			'dashboard' => html_entity_decode($this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8') . '#dpc-followup'
		);
		if ($inbox && $this->user->hasPermission('access', 'extension/module/dpc_inbox')) {
			$c = $inbox->counts();
			$out['inbox'] = array('url' => html_entity_decode($this->url->link('extension/module/dpc_inbox', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8'), 'reply' => $c['reply'], 'unread' => $c['unread']);
		}
		if (isset($this->request->get['item'])) {
			$key = (string)$this->request->get['item'];
			if (!empty($out['inbox']) && preg_match('/^order:(\d+)$/', $key, $om)) {
				$o = $this->db->query("SELECT order_id, email, firstname, lastname FROM `" . DB_PREFIX . "order` WHERE order_id = '" . (int)$om[1] . "'")->row;
				if ($o && $o['email']) {
					$out['compose'] = $out['inbox']['url'] . '&to=' . rawurlencode($o['email']) . '&subject=' . rawurlencode('Your order #' . $o['order_id']) . '&order_id=' . (int)$o['order_id'] . '&name=' . rawurlencode(trim($o['firstname'] . ' ' . $o['lastname']));
				}
			}
			$out['item'] = null;
			foreach ($items as $list) {
				foreach ($list as $it) {
					if ($it['key'] === $key) {
						$out['item'] = $it;
					}
				}
			}
			$out['notes'] = $m->getNotes($key);
			foreach ($out['notes'] as &$n) {
				$n['ago'] = $m->ago(time() - strtotime($n['created']));
			}
			unset($n);
		} else {
			$out['items'] = $items;
		}
		foreach (array('overdue', 'waiting', 'snoozed') as $state) {
			if (isset($out['items'][$state])) {
				foreach ($out['items'][$state] as &$it) {
					$it['link'] = html_entity_decode($it['link'], ENT_QUOTES, 'UTF-8');
				}
				unset($it);
			}
		}
		if (!empty($out['item'])) {
			$out['item']['link'] = html_entity_decode($out['item']['link'], ENT_QUOTES, 'UTF-8');
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
	}

	// POST item, action (note|snooze), note, days
	public function act() {
		$json = array();
		if ($this->request->server['REQUEST_METHOD'] !== 'POST') {
			$json['error'] = 'POST only';
		} elseif (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			$json['error'] = 'You do not have permission to add follow-ups.';
		} else {
			$item = isset($this->request->post['item']) ? (string)$this->request->post['item'] : '';
			$action = isset($this->request->post['action']) ? (string)$this->request->post['action'] : '';
			$note = isset($this->request->post['note']) ? trim(html_entity_decode((string)$this->request->post['note'], ENT_QUOTES, 'UTF-8')) : '';
			$days = isset($this->request->post['days']) ? (float)$this->request->post['days'] : 0;
			if (!preg_match('/^(order|return|approval|review|rndp|rndu|mail|ticket|form):\d+$/', $item)) {
				$json['error'] = 'Unknown item.';
			} elseif ($action === 'note' && $note === '') {
				$json['error'] = 'Write what you did, for example "Emailed the customer about the delay".';
			} elseif ($action === 'snooze' && ($days <= 0 || $days > 60)) {
				$json['error'] = 'Choose how long to snooze.';
			} elseif ($action !== 'note' && $action !== 'snooze' && $action !== 'done') {
				$json['error'] = 'Unknown action.';
			} else {
				$this->load->model('extension/dashboard/dpc_followup');
				$until = $action === 'snooze' ? date('Y-m-d H:i:s', time() + (int)round($days * 86400)) : null;
				if ($action === 'snooze' && $note === '') {
					$note = 'Snoozed';
				}
				if ($action === 'done' && $note === '') {
					$note = 'Done';
				}
				if ($action === 'done' && strpos($item, 'mail:') === 0 && is_file(DIR_SYSTEM . 'library/dpcinbox.php')) {
					require_once(DIR_SYSTEM . 'library/dpcinbox.php');
					$inbox = new DpcInbox($this->db);
					$inbox->setState((int)substr($item, 5), 'done');
				}
				$this->model_extension_dashboard_dpc_followup->addAction($item, $action, $note, $until, $this->user->getId(), $this->user->getUserName());
				$json['success'] = $action === 'note' ? 'Note saved. The timer starts again from now.' : ($action === 'done' ? 'Marked done.' : 'Snoozed until ' . date('D j M H:i', strtotime($until)) . '.');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	// POST: send the daily email now, even when nothing is overdue
	public function testmail() {
		$json = array();
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			$json['error'] = 'You do not have permission to send the follow-up email.';
		} else {
			try {
				require_once(DIR_CATALOG . 'controller/extension/module/dpc_followup_mail.php');
				$json['success'] = 'Test email: ' . ControllerExtensionModuleDpcFollowupMail::sendDigest($this->registry, true, HTTPS_SERVER) . '.';
			} catch (\Throwable $e) {
				$json['error'] = 'The email could not be sent: ' . $e->getMessage();
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	// GET: table layout of the other sources (support tickets, Journal form e-mails), for setup checks
	public function diag() {
		$out = array();
		if ($this->user->hasPermission('modify', 'extension/dashboard/dpc_followup')) {
			foreach ($this->db->query("SHOW TABLES")->rows as $r) {
				$t = reset($r);
				if (preg_match('/support|ticket|message|journal3_message|form/i', $t)) {
					$cols = array();
					foreach ($this->db->query("SHOW COLUMNS FROM `" . $t . "`")->rows as $c) {
						$cols[] = $c['Field'] . ' ' . $c['Type'];
					}
					$out[$t] = array('rows' => (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . $t . "`")->row['n'], 'cols' => $cols);
				}
			}
			$out['php'] = PHP_VERSION;
			$out['ext'] = array('imap' => extension_loaded('imap'), 'openssl' => extension_loaded('openssl'), 'mbstring' => extension_loaded('mbstring'), 'iconv' => extension_loaded('iconv'));
			foreach (array('mail.dpcreator.eu') as $host) {
				$ctx = stream_context_create(array('ssl' => array('verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host)));
				$fp = @stream_socket_client('ssl://' . $host . ':993', $e, $m, 8, STREAM_CLIENT_CONNECT, $ctx);
				$out['cert_verified'][$host] = $fp ? 'OK' : 'FAILED';
				if ($fp) fclose($fp);
				$ctx = stream_context_create(array('ssl' => array('verify_peer' => false, 'verify_peer_name' => false, 'capture_peer_cert' => true)));
				$fp = @stream_socket_client('ssl://' . $host . ':993', $e, $m, 8, STREAM_CLIENT_CONNECT, $ctx);
				if ($fp) {
					$p = stream_context_get_params($fp);
					$c = openssl_x509_parse($p['options']['ssl']['peer_certificate']);
					$out['cert'][$host] = array('cn' => isset($c['subject']['CN']) ? $c['subject']['CN'] : '', 'san' => isset($c['extensions']['subjectAltName']) ? $c['extensions']['subjectAltName'] : '', 'until' => date('Y-m-d', $c['validTo_time_t']), 'issuer' => isset($c['issuer']['O']) ? $c['issuer']['O'] : '');
					fclose($fp);
				}
			}
			foreach (array('ssl://mail.dpcreator.eu:993', 'tcp://mail.dpcreator.eu:587', 'ssl://mail.dpcreator.eu:465') as $h) {
				$e = 0; $m = '';
				$fp = @stream_socket_client($h, $e, $m, 5);
				$out['net'][$h] = $fp ? trim(fgets($fp, 512)) : 'ERR ' . $m;
				if ($fp) fclose($fp);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($out));
	}
}
