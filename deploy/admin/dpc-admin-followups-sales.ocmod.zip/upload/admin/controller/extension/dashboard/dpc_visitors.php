<?php
// dpCREATOR Studio users on the admin dashboard. Counts come from studio.php
// (tables <prefix>dpc_visitors_day), which Studio pings about once a day.
class ControllerExtensionDashboardDpcVisitors extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/dpc_visitors');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('dashboard_dpc_visitors', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/dpc_visitors', 'user_token=' . $this->session->data['user_token'], true))
		);
		$data['action'] = $this->url->link('extension/dashboard/dpc_visitors', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		foreach (array('width' => 3, 'status' => 1, 'sort_order' => 4) as $key => $default) {
			$name = 'dashboard_dpc_visitors_' . $key;
			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}
		$data['columns'] = range(1, 12);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/dashboard/dpc_visitors_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_visitors')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}

	public function dashboard() {
		$lib = new DpcVisit($this->db);
		$data = array('now' => 0, 'today' => 0, 'bots' => 0, 'customers' => 0, 'carts' => 0, 'ready' => $lib->ready());
		if ($data['ready']) {
			$now = date('Y-m-d H:i:s', strtotime('-15 minutes'));
			foreach ($lib->visits(date('Y-m-d 00:00:00'), 3000) as $v) {
				list($kind) = DpcVisit::classify($v);
				$person = $kind === 'human' || $kind === 'customer';
				if ($person) {
					$data['today']++;
					if ($v['last_seen'] >= $now) {
						$data['now']++;
					}
					if ((int)$v['cart']) {
						$data['carts']++;
					}
				}
				if ($kind === 'customer') {
					$data['customers']++;
				}
				if ($kind === 'bot' || $kind === 'likely_bot') {
					$data['bots']++;
				}
			}
		}
		$data['link'] = $this->url->link('extension/module/dpc_visitors', 'user_token=' . $this->session->data['user_token'], true);
		return $this->load->view('extension/dashboard/dpc_visitors_info', $data);
	}
}
