<?php
// dpCREATOR Studio users on the admin dashboard. Counts come from studio.php
// (tables <prefix>dpc_visitors_day), which Studio pings about once a day.
class ControllerExtensionDashboardDpcVisitorsList extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/dpc_visitors_list');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('dashboard_dpc_visitors', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/dpc_visitors_list', 'user_token=' . $this->session->data['user_token'], true))
		);
		$data['action'] = $this->url->link('extension/dashboard/dpc_visitors_list', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		foreach (array('width' => 12, 'status' => 1, 'sort_order' => 20) as $key => $default) {
			$name = 'dashboard_dpc_visitors_list_' . $key;
			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}
		$data['columns'] = range(1, 12);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/dashboard/dpc_visitors_list_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/dpc_visitors_list')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}

	public function dashboard() {
		$lib = new DpcVisit($this->db);
		$data['rows'] = array();
		$data['ready'] = $lib->ready();
		$labels = array('human' => array('Person', '#2E7D4F'), 'customer' => array('Customer', '#1F6FB8'), 'unknown' => array('Not sure', '#8A7A55'), 'likely_bot' => array('Likely bot', '#B26A00'), 'bot' => array('Bot', '#C42B1C'), 'you' => array('You', '#7A6FB0'));
		$rank = array('customer' => 0, 'human' => 1, 'unknown' => 2, 'you' => 3, 'likely_bot' => 4, 'bot' => 5);
		$data['window'] = '15 minutes';
		if ($data['ready']) {
			$rows = $lib->visits(date('Y-m-d H:i:s', strtotime('-15 minutes')), 200);
			$list = array();
			foreach ($rows as $v) {
				list($kind, $why) = DpcVisit::classify($v);
				$list[] = array(
					'rank' => $rank[$kind], 'last' => $v['last_seen'],
					'label' => $labels[$kind][0], 'color' => $labels[$kind][1],
					'ip' => $v['ip'], 'host' => (string)$v['host'],
					'who' => (int)$v['customer_id'] ? trim($v['firstname'] . ' ' . $v['lastname']) : '',
					'device' => $kind === 'bot' ? DpcVisit::botName($v['ua']) : DpcVisit::device($v['ua']),
					'page' => preg_replace('~^https?://[^/]+~', '', $v['last_url']) ?: '/',
					'pages' => (int)$v['hits'], 'cart' => (bool)$v['cart'],
					'ago' => max(0, (int)round((time() - strtotime($v['last_seen'])) / 60)),
					'why' => implode('; ', $why)
				);
			}
			// people first, bots last; newest first within each group
			usort($list, function ($a, $b) { return $a['rank'] === $b['rank'] ? strcmp($b['last'], $a['last']) : $a['rank'] - $b['rank']; });
			$data['rows'] = array_slice($list, 0, 25);
			$data['more'] = max(0, count($list) - 25);
		}
		$data['link'] = $this->url->link('extension/module/dpc_visitors', 'user_token=' . $this->session->data['user_token'], true);
		$data['shop'] = rtrim(HTTPS_CATALOG, '/');
		return $this->load->view('extension/dashboard/dpc_visitors_list_info', $data);
	}
}
