<?php
$_['heading_title'] = 'dpCREATOR light theme';
