<?php
$_['heading_title']    = 'dpCREATOR visitors: people or bots';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: you have modified the visitors dashboard!';
$_['text_edit']        = 'Edit visitors dashboard';
$_['entry_width']      = 'Width';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify the visitors dashboard!';
