<?php
$_['heading_title'] = 'dpCREATOR Visitors (people or bots)';
