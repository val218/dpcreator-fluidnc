<?php
$_['heading_title']    = 'Inbox';
$_['heading_settings'] = 'Inbox settings';
$_['text_extension']   = 'Extensions';
$_['text_saved']       = 'Inbox settings saved.';
$_['error_permission'] = 'Warning: You do not have permission to change the Inbox!';
