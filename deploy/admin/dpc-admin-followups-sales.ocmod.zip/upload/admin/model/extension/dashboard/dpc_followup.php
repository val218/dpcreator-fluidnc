<?php
// dpCREATOR follow-ups for the admin. The rules live in system/library/dpcfollowup.php,
// shared with the daily email.
require_once(DIR_SYSTEM . 'library/dpcfollowup.php');

class ModelExtensionDashboardDpcFollowup extends Model {
	private $lib;

	private function lib() {
		if (!$this->lib) {
			$config = $this->config;
			$url = $this->url;
			$currency = $this->currency;
			$token = isset($this->session->data['user_token']) ? 'user_token=' . $this->session->data['user_token'] : '';
			$this->lib = new DpcFollowup(
				$this->db,
				function ($key) use ($config) { return $config->get($key); },
				function ($route, $query) use ($url, $token) { return $url->link($route, $token . ($query !== '' ? '&' . $query : ''), true); },
				function ($amount, $code, $value) use ($currency) { return $currency->format($amount, $code, $value); },
				HTTPS_CATALOG
			);
		}
		return $this->lib;
	}

	public function install() { $this->lib()->install(); }
	public function statusHours() { return $this->lib()->statusHours(); }
	public function otherHours() { return $this->lib()->otherHours(); }
	public function addAction($item, $action, $note, $until, $user_id, $username) { $this->lib()->addAction($item, $action, $note, $until, $user_id, $username); }
	public function getNotes($item, $limit = 20) { return $this->lib()->getNotes($item, $limit); }
	public function getItems() { return $this->lib()->getItems(); }
	public function ago($s) { return $this->lib()->ago($s); }
}
