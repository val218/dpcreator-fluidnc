/* dpCREATOR light theme generator.
   Reads the shop's stylesheets and writes overrides under html.dpc-light: dark backgrounds become
   light, light text becomes dark, brand accents stay. Runs in the admin; the result is saved as one file. */
(function (global) {
	function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
	var NAMED = {white: [255, 255, 255], black: [0, 0, 0]};

	function parse(c) {
		c = c.trim().toLowerCase();
		var m;
		if ((m = c.match(/^#([0-9a-f]{3,8})$/))) {
			var h = m[1];
			if (h.length === 3 || h.length === 4) h = h.split('').map(function (x) { return x + x; }).join('');
			return {r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1};
		}
		if ((m = c.match(/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/))) {
			var a = m[4] === undefined ? 1 : (m[4].slice(-1) === '%' ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
			return {r: +m[1], g: +m[2], b: +m[3], a: a};
		}
		if (NAMED[c]) return {r: NAMED[c][0], g: NAMED[c][1], b: NAMED[c][2], a: 1};
		return null;
	}

	function toHsl(c) {
		var r = c.r / 255, g = c.g / 255, b = c.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, s = 0, d = mx - mn;
		if (d) {
			s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
			h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
			h /= 6;
		}
		return {h: h, s: s, l: l, a: c.a};
	}

	function fromHsl(o) {
		var h = o.h, s = o.s, l = o.l, r, g, b;
		if (!s) { r = g = b = l; } else {
			var f = function (p, q, t) { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; };
			var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
			r = f(p, q, h + 1 / 3); g = f(p, q, h); b = f(p, q, h - 1 / 3);
		}
		var R = Math.round(r * 255), G = Math.round(g * 255), B = Math.round(b * 255);
		if (o.a < 1) return 'rgba(' + R + ',' + G + ',' + B + ',' + (Math.round(o.a * 1000) / 1000) + ')';
		return '#' + [R, G, B].map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
	}

	// role: bg | text | border | shadow | var
	function mapColor(str, role) {
		var c = parse(str);
		if (!c) return null;
		var o = toHsl(c);
		var white = c.r > 200 && c.g > 200 && c.b > 200, black = c.r < 40 && c.g < 40 && c.b < 40;
		// translucent overlays: white haze on dark becomes dark haze on light
		if (c.a < 0.6) {
			if (white || (o.l > 0.7 && o.s < 0.5)) return fromHsl({h: 0.58, s: 0.25, l: 0.15, a: clamp(c.a * 1.25, 0.04, 0.5)});
			if (black && role === 'shadow') return fromHsl({h: 0.58, s: 0.3, l: 0.2, a: clamp(c.a * 0.35, 0.03, 0.25)});
			if (black && role === 'bg') return fromHsl({h: 0.58, s: 0.2, l: 0.97, a: c.a});
			if (o.l < 0.35 && role === 'bg') return fromHsl({h: o.h, s: o.s * 0.5, l: 0.96, a: c.a});
			return null;
		}
		if (role === 'shadow') {
			if (o.l < 0.2) return fromHsl({h: 0.58, s: 0.3, l: 0.25, a: 0.18});
			return null;
		}
		var neutral = o.s < 0.32 || o.l < 0.2;
		if (role === 'bg' || role === 'var-bg') {
			if (o.l < 0.36) {
				var nl = 0.985 - (o.l / 0.36) * 0.11;
				return fromHsl({h: o.h, s: neutral ? Math.min(o.s, 0.25) * 0.8 : o.s * 0.55, l: nl, a: c.a});
			}
			return null;
		}
		if (role === 'text') {
			if (o.l > 0.55) {
				if (neutral || o.s < 0.4) return fromHsl({h: o.h, s: Math.min(o.s, 0.3), l: clamp(0.12 + (1 - o.l) * 0.75, 0.1, 0.46), a: c.a});
				return fromHsl({h: o.h, s: Math.min(1, o.s * 1.05), l: Math.min(o.l, 0.38), a: c.a});
			}
			return null;
		}
		if (role === 'border') {
			if (o.l < 0.42 && (neutral || o.s < 0.45)) return fromHsl({h: o.h, s: Math.min(o.s, 0.25), l: clamp(0.88 - o.l * 0.25, 0.78, 0.9), a: c.a});
			return null;
		}
		return null;
	}

	var COLOR_RE = /#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)|\b(?:white|black)\b/g;
	function mapValue(v, role) {
		var changed = false;
		var out = v.replace(COLOR_RE, function (m) {
			var r = mapColor(m, role);
			if (r && r !== m) { changed = true; return r; }
			return m;
		});
		return changed ? out : null;
	}

	function roleOf(prop, value) {
		if (/^--/.test(prop)) {
			// guess from the value: dark values are backgrounds, light neutral values are text
			var c = parse((value.match(COLOR_RE) || [''])[0] || '');
			if (!c) return null;
			var o = toHsl(c);
			if (c.a < 0.6) return 'bg';
			if (o.l < 0.36) return 'bg';
			if (o.l > 0.55 && (o.s < 0.4)) return 'text';
			return null; // accents stay
		}
		if (/^background/.test(prop)) return 'bg';
		if (prop === 'color' || prop === '-webkit-text-fill-color' || prop === 'caret-color') return 'text';
		if (/^border|^outline|column-rule-color/.test(prop)) return 'border';
		if (/shadow$/.test(prop)) return 'shadow';
		if (prop === 'fill' || prop === 'stop-color') return 'bg';
		if (prop === 'stroke') return 'border';
		return null;
	}

	// the site header (top bar, logo, menu) stays dark in light mode
	var KEEP = ':not(header):not(header *)';
	function keep(s) {
		var m = s.match(/(::?(?:before|after|first-line|first-letter|placeholder|selection|marker|backdrop|-webkit-[\w-]+|-moz-[\w-]+)(?:\([^)]*\))?)$/i);
		return m ? s.slice(0, s.length - m[1].length) + KEEP + m[1] : s + KEEP;
	}
	function scope(sel) {
		return sel.split(',').map(function (s) {
			s = s.trim();
			if (!s) return s;
			if (/^:root\b/.test(s)) return s.replace(/^:root/, 'html.dpc-light');
			if (/^html\b/.test(s)) return /^html\S*$/.test(s) ? s.replace(/^html/, 'html.dpc-light') : keep(s.replace(/^html/, 'html.dpc-light'));
			return 'html.dpc-light ' + keep(s);
		}).join(',');
	}

	function walk(rules, out, skipSel) {
		for (var i = 0; i < rules.length; i++) {
			var r = rules[i];
			if (r.type === 1) { // style rule
				if (skipSel && skipSel.test(r.selectorText)) continue;
				var decl = [];
				for (var j = 0; j < r.style.length; j++) {
					var p = r.style[j], v = r.style.getPropertyValue(p), imp = r.style.getPropertyPriority(p);
					var role = roleOf(p, v);
					if (!role) continue;
					var nv = mapValue(v, role);
					if (nv) decl.push(p + ':' + nv + (imp ? ' !important' : ''));
				}
				if (decl.length) out.push(scope(r.selectorText) + '{' + decl.join(';') + '}');
			} else if (r.cssRules && (r.type === 4 || r.type === 12 || (r.constructor && /Container|Supports|Layer/.test(r.constructor.name)))) {
				var inner = [];
				walk(r.cssRules, inner, skipSel);
				if (inner.length) {
					var head = r.type === 4 ? '@media ' + r.conditionText : (r.cssText.slice(0, r.cssText.indexOf('{')).trim());
					out.push(head + '{' + inner.join('\n') + '}');
				}
			}
		}
	}

	global.dpcBuildLight = function (cssTexts, skipSel) {
		var out = [];
		cssTexts.forEach(function (t) {
			try {
				var sh = new CSSStyleSheet();
				sh.replaceSync(t.replace(/@import[^;]+;/g, ''));
				walk(sh.cssRules, out, skipSel);
			} catch (e) {}
		});
		// de-duplicate identical lines
		var seen = {}, res = [];
		out.forEach(function (l) { if (!seen[l]) { seen[l] = 1; res.push(l); } });
		return res;
	};
	global.dpcMapColor = mapColor;
})(window);
