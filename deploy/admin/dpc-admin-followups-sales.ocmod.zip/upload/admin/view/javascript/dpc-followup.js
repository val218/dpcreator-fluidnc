/* dpCREATOR follow-ups: badge on every admin page, check before logout, list after login,
   follow-up box on the order page and the dashboard list. Data: extension/dashboard/dpc_followup/items */
(function () {
	if (window.DPCF) return;
	window.DPCF = true;
	var token = (location.search.match(/[?&]user_token=([^&]+)/) || [])[1];
	if (!token) return;
	var route = (location.search.match(/[?&]route=([^&]+)/) || [])[1] || 'common/dashboard';
	route = decodeURIComponent(route);
	var BASE = 'index.php?route=extension/dashboard/dpc_followup/';
	var LIST = BASE + 'items&user_token=' + token, ACT = BASE + 'act&user_token=' + token;
	var CACHE = 'dpcf_' + token, SEEN = 'dpcf_seen_' + token;
	var KIND = {ship: 'Shipped goods', dig: 'Digital'};
	var data = null;

	var css = '' +
		'.dpcf{--red:#C42B1C;--red-bg:#FDECEA;--amb:#B26A00;--amb-bg:#FFF4E0;--ink:#1E2A35;--mut:#6B7885;--line:#E3E8ED;--ship:#1F6FB8;--dig:#D9730D}' +
		'.dpcf-bell{position:relative}.dpcf-bell .badge{position:relative;top:-1px;margin-left:4px;font-size:11px;padding:3px 7px}' +
		'.dpcf-bell.over .badge{background:#C42B1C}.dpcf-bell.wait .badge{background:#B26A00}.dpcf-bell.ok .badge{background:#2E7D4F}' +
		'.dpcf-list{list-style:none;margin:0;padding:0}' +
		'.dpcf-it{display:grid;grid-template-columns:1fr auto;gap:4px 16px;padding:12px 14px 12px 16px;border:1px solid var(--line);border-left:4px solid var(--amb);border-radius:4px;margin-bottom:8px;background:#fff}' +
		'.dpcf-it.overdue{border-left-color:var(--red);background:linear-gradient(90deg,var(--red-bg),#fff 40%)}' +
		'.dpcf-it.snoozed{border-left-color:#AEB8C2;opacity:.85}' +
		'.dpcf-it h4{margin:0;font-size:14px;font-weight:600;color:var(--ink)}.dpcf-it h4 a{color:inherit}' +
		'.dpcf-who{color:var(--mut);font-size:12.5px}' +
		'.dpcf-hint{grid-column:1/-1;color:var(--ink);font-size:13px}' +
		'.dpcf-when{text-align:right;font-size:12.5px;white-space:nowrap}.dpcf-when b{display:block;font-size:13px}' +
		'.dpcf-it.overdue .dpcf-when b{color:var(--red)}.dpcf-it.waiting .dpcf-when b{color:var(--amb)}' +
		'.dpcf-tag{display:inline-block;font-size:11px;font-weight:600;padding:1px 7px;border-radius:10px;margin-right:6px;vertical-align:1px;color:#fff}' +
		'.dpcf-tag.ship{background:var(--ship)}.dpcf-tag.dig{background:var(--dig)}' +
		'.dpcf-note{grid-column:1/-1;font-size:12.5px;color:var(--mut);border-left:2px solid var(--line);padding-left:8px}' +
		'.dpcf-act{grid-column:1/-1;display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:4px}' +
		'.dpcf-act input[type=text]{flex:1 1 260px;min-width:180px;height:30px;font-size:13px}' +
		'.dpcf-act select{height:30px;font-size:12.5px;width:auto}' +
		'.dpcf-head{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.dpcf-head .panel-title{flex:1 1 auto;font-weight:600}' +
		'.dpcf-chip{display:inline-block;font-size:12px;font-weight:600;padding:2px 9px;border-radius:10px;border:1px solid}' +
		'.dpcf-chip.r{color:var(--red);border-color:#F1B8B1;background:var(--red-bg)}.dpcf-chip.a{color:var(--amb);border-color:#F2D29C;background:var(--amb-bg)}.dpcf-chip.g{color:var(--mut);border-color:var(--line)}' +
		'.dpcf-empty{padding:18px;text-align:center;color:#2E7D4F;font-weight:600}' +
		'.dpcf-sec{font-size:12px;font-weight:600;color:var(--mut);margin:14px 0 6px}' +
		'.dpcf details>summary{cursor:pointer;font-size:12.5px;color:var(--mut);margin-top:10px}' +
		'.dpcf-order{margin:0 0 16px}.dpcf-order .panel-heading{font-weight:600}' +
		'.dpcf-order.overdue .panel-heading{background:#FDECEA;color:#8E1E14;border-color:#F1B8B1}.dpcf-order.overdue{border-color:#F1B8B1}' +
		'.dpcf-order.waiting .panel-heading{background:#FFF4E0;color:#7A4900;border-color:#F2D29C}.dpcf-order.waiting{border-color:#F2D29C}' +
		'.dpcf-notes{list-style:none;padding:0;margin:8px 0 0;font-size:12.5px}.dpcf-notes li{padding:4px 0;border-top:1px solid var(--line)}.dpcf-notes span{color:var(--mut)}' +
		'#dpcf-modal .dpcf-it{grid-template-columns:1fr auto}';
	var st = document.createElement('style');
	st.textContent = css;
	(document.head || document.documentElement).appendChild(st);

	function el(tag, cls, text) {
		var e = document.createElement(tag);
		if (cls) e.className = cls;
		if (text != null) e.textContent = text;
		return e;
	}

	function load(fresh) {
		if (!fresh) {
			try {
				var c = JSON.parse(sessionStorage.getItem(CACHE) || 'null');
				if (c && Date.now() - c.t < 60000) return Promise.resolve(c.d);
			} catch (e) {}
		}
		return fetch(LIST, {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
			.then(function (r) { return r.json(); })
			.then(function (d) {
				try { sessionStorage.setItem(CACHE, JSON.stringify({t: Date.now(), d: d})); } catch (e) {}
				return d;
			});
	}

	function post(body) {
		var fd = new FormData();
		for (var k in body) fd.append(k, body[k]);
		return fetch(ACT, {method: 'POST', body: fd, credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
			.then(function (r) { return r.json(); })
			.then(function (j) {
				try { sessionStorage.removeItem(CACHE); } catch (e) {}
				return j;
			});
	}

	// One item row: title, who, how long, next step, last note, actions
	function row(it, opts) {
		opts = opts || {};
		var li = el('li', 'dpcf-it ' + it.state);
		var left = el('div');
		var h = el('h4');
		if (it.tag) h.appendChild(el('span', 'dpcf-tag ' + it.tag, KIND[it.tag]));
		var a = el('a', null, it.title);
		a.href = it.link;
		if (/^https?:/.test(it.link) && it.link.indexOf(location.origin + '/admin') !== 0) { a.target = '_blank'; a.rel = 'noopener'; }
		h.appendChild(a);
		left.appendChild(h);
		left.appendChild(el('div', 'dpcf-who', [it.who, it.email && it.email !== it.who ? it.email : '', it.amount].filter(Boolean).join('  ·  ')));
		li.appendChild(left);
		var when = el('div', 'dpcf-when');
		when.appendChild(el('b', null, it.due_text));
		when.appendChild(el('span', null, 'waiting ' + it.since_text));
		li.appendChild(when);
		li.appendChild(el('div', 'dpcf-hint', it.hint));
		if (it.note) li.appendChild(el('div', 'dpcf-note', 'Last note (' + it.note.by + ', ' + it.note.when + ' ago): ' + it.note.text));
		if (opts.actions && data && data.can_edit) li.appendChild(actions(it, opts.onDone));
		return li;
	}

	function actions(it, onDone, here) {
		var box = el('div', 'dpcf-act');
		if (!here) {
			var open = el('a', 'btn btn-default btn-sm', 'Open');
			open.href = it.link;
			box.appendChild(open);
		}
		var inp = el('input', 'form-control');
		inp.type = 'text';
		inp.placeholder = 'What did you do? e.g. Emailed the customer about the delay';
		inp.setAttribute('aria-label', 'Follow-up note for ' + it.title);
		inp.maxLength = 1000;
		box.appendChild(inp);
		var save = el('button', 'btn btn-primary btn-sm', 'Save note');
		save.type = 'button';
		box.appendChild(save);
		var doneB = el('button', 'btn btn-default btn-sm', it.kind === 'order' ? 'Handled' : 'Done');
		doneB.type = 'button';
		doneB.title = 'Nothing more to do now. It comes back if something changes.';
		box.appendChild(doneB);
		var sn = el('select', 'form-control');
		sn.setAttribute('aria-label', 'Snooze ' + it.title);
		[['', 'Snooze…'], ['1', '1 day'], ['3', '3 days'], ['7', '1 week'], ['14', '2 weeks']].forEach(function (o) {
			var op = el('option', null, o[1]);
			op.value = o[0];
			sn.appendChild(op);
		});
		box.appendChild(sn);
		var msg = el('span', 'dpcf-who');
		box.appendChild(msg);
		function done(j) {
			if (j.error) { msg.textContent = j.error; msg.style.color = '#C42B1C'; return; }
			msg.style.color = '#2E7D4F';
			msg.textContent = j.success;
			if (onDone) setTimeout(onDone, 700);
		}
		save.addEventListener('click', function () {
			save.disabled = true;
			post({item: it.key, action: 'note', note: inp.value}).then(done).catch(function () { msg.textContent = 'Not saved. Check you are still logged in.'; }).then(function () { save.disabled = false; });
		});
		inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); save.click(); } });
		doneB.addEventListener('click', function () {
			doneB.disabled = true;
			post({item: it.key, action: 'done', note: inp.value}).then(done).catch(function () { msg.textContent = 'Not saved. Check you are still logged in.'; }).then(function () { doneB.disabled = false; });
		});
		sn.addEventListener('change', function () {
			if (!sn.value) return;
			post({item: it.key, action: 'snooze', days: sn.value, note: inp.value}).then(done);
		});
		return box;
	}

	// Badge in the top bar
	function badge(d) {
		var nav = document.querySelector('#header .navbar-right') || document.querySelector('.navbar-right');
		if (!nav || !d.enabled) return;
		var li = document.getElementById('dpcf-bell') || el('li');
		li.id = 'dpcf-bell';
		li.textContent = '';
		var n = d.counts.overdue, w = d.counts.waiting;
		var a = el('a', 'dpcf-bell ' + (n ? 'over' : w ? 'wait' : 'ok'));
		a.href = d.dashboard;
		a.title = n ? n + ' overdue, ' + w + ' waiting' : w ? w + ' waiting, nothing overdue' : 'Nobody is waiting on you';
		a.appendChild(el('i', 'fa fa-bell'));
		a.appendChild(el('span', 'hidden-xs hidden-sm', ' Follow-ups'));
		a.appendChild(el('span', 'badge', String(n || w || '✓')));
		li.appendChild(a);
		if (!li.parentNode) nav.insertBefore(li, nav.firstChild);
		if (d.inbox) {
			var ib = document.getElementById('dpcf-inbox') || el('li');
			ib.id = 'dpcf-inbox';
			ib.textContent = '';
			var ia = el('a', 'dpcf-bell ' + (d.inbox.reply ? 'wait' : 'ok'));
			ia.href = d.inbox.url;
			ia.title = d.inbox.reply ? d.inbox.reply + ' emails waiting for a reply' : 'Inbox';
			ia.appendChild(el('i', 'fa fa-envelope'));
			ia.appendChild(el('span', 'hidden-xs hidden-sm', ' Inbox'));
			if (d.inbox.reply) ia.appendChild(el('span', 'badge', String(d.inbox.reply)));
			ib.appendChild(ia);
			if (!ib.parentNode) nav.insertBefore(ib, li);
		}
		if (n && !/^\(\d+\) /.test(document.title)) document.title = '(' + n + ') ' + document.title;
	}

	// Modal with the overdue list (after login, before logout)
	function modal(d, mode, logoutHref) {
		if (!window.jQuery || !jQuery.fn.modal) return false;
		var old = document.getElementById('dpcf-modal');
		if (old) jQuery(old).remove();
		var n = d.counts.overdue;
		var m = el('div', 'modal fade dpcf');
		m.id = 'dpcf-modal';
		m.tabIndex = -1;
		m.setAttribute('role', 'dialog');
		var dlg = el('div', 'modal-dialog modal-lg'), ct = el('div', 'modal-content');
		var hd = el('div', 'modal-header');
		var x = el('button', 'close', '×');
		x.type = 'button';
		x.setAttribute('data-dismiss', 'modal');
		x.setAttribute('aria-label', 'Close');
		hd.appendChild(x);
		hd.appendChild(el('h4', 'modal-title', mode === 'logout'
			? (n === 1 ? '1 customer is still waiting on you' : n + ' customers are still waiting on you')
			: (n === 1 ? '1 customer has been waiting too long' : n + ' customers have been waiting too long')));
		ct.appendChild(hd);
		var bd = el('div', 'modal-body');
		bd.appendChild(el('p', null, mode === 'logout'
			? 'Before you go: deal with these, or add a note saying what you did, or snooze them to a day you will.'
			: 'These need an answer. Open each one, or add a note saying what you did.'));
		var ul = el('ul', 'dpcf-list');
		d.items.overdue.slice(0, 8).forEach(function (it) { ul.appendChild(row(it)); });
		bd.appendChild(ul);
		if (n > 8) bd.appendChild(el('p', 'dpcf-who', 'And ' + (n - 8) + ' more on the dashboard.'));
		ct.appendChild(bd);
		var ft = el('div', 'modal-footer');
		var go = el('a', 'btn btn-primary', 'Show the list');
		go.href = d.dashboard;
		go.addEventListener('click', function () { jQuery(m).modal('hide'); });
		if (mode === 'logout') {
			var out = el('a', 'btn btn-default', 'Log out anyway');
			out.href = logoutHref;
			out.setAttribute('data-dpcf-ok', '1');
			ft.appendChild(out);
		} else {
			var later = el('button', 'btn btn-default', 'Later');
			later.type = 'button';
			later.setAttribute('data-dismiss', 'modal');
			ft.appendChild(later);
		}
		ft.appendChild(go);
		ct.appendChild(ft);
		dlg.appendChild(ct);
		m.appendChild(dlg);
		document.body.appendChild(m);
		jQuery(m).modal('show');
		return true;
	}

	// Dashboard list
	function tile(d) {
		var box = document.getElementById('dpc-followup');
		if (!box) return;
		var head = box.querySelector('.dpcf-chips'), body = box.querySelector('.dpcf-body');
		head.textContent = '';
		var c = d.counts;
		head.appendChild(el('span', 'dpcf-chip ' + (c.overdue ? 'r' : 'g'), c.overdue + ' overdue'));
		head.appendChild(el('span', 'dpcf-chip ' + (c.waiting ? 'a' : 'g'), c.waiting + ' waiting'));
		if (c.snoozed) head.appendChild(el('span', 'dpcf-chip g', c.snoozed + ' snoozed'));
		body.textContent = '';
		var refresh = function () { load(true).then(function (x) { data = x; tile(x); badge(x); }); };
		if (!c.overdue && !c.waiting) {
			body.appendChild(el('div', 'dpcf-empty', 'Nobody is waiting on you.'));
		}
		[['overdue', 'Overdue: answer these first'], ['waiting', 'Waiting, not overdue yet']].forEach(function (s) {
			var list = d.items[s[0]];
			if (!list.length) return;
			body.appendChild(el('div', 'dpcf-sec', s[1]));
			var ul = el('ul', 'dpcf-list');
			list.forEach(function (it) { ul.appendChild(row(it, {actions: true, onDone: refresh})); });
			body.appendChild(ul);
		});
		if (d.items.snoozed.length) {
			var det = el('details');
			det.appendChild(el('summary', null, 'Snoozed (' + d.items.snoozed.length + ')'));
			var ul2 = el('ul', 'dpcf-list');
			d.items.snoozed.forEach(function (it) { ul2.appendChild(row(it, {actions: true, onDone: refresh})); });
			det.appendChild(ul2);
			body.appendChild(det);
		}
		if (location.hash === '#dpc-followup' && !box.dataset.scrolled) { box.dataset.scrolled = '1'; box.scrollIntoView(); }
	}

	// Order page: show the follow-up state and notes, and ask before leaving an overdue order untouched
	var guard = false, bound = false;
	function orderBox() {
		var id = (location.search.match(/[?&]order_id=(\d+)/) || [])[1];
		var at = document.querySelector('#content > .container-fluid:not(:first-child)') || document.querySelector('#content .container-fluid + .container-fluid');
		if (!id || !at) return;
		fetch(LIST + '&item=order:' + id, {credentials: 'same-origin'}).then(function (r) { return r.json(); }).then(function (d) {
			var old = document.getElementById('dpcf-order');
			if (old) old.remove();
			if (d.compose && !document.getElementById('dpcf-compose')) {
				var bar = document.querySelector('#content .page-header .pull-right');
				if (bar) {
					var cb = el('a', 'btn btn-default', null);
					cb.id = 'dpcf-compose';
					cb.href = d.compose;
					cb.title = 'Email the customer from the Inbox';
					cb.appendChild(el('i', 'fa fa-envelope'));
					cb.appendChild(document.createTextNode(' Email customer'));
					bar.insertBefore(cb, bar.firstChild);
					bar.insertBefore(document.createTextNode(' '), cb.nextSibling);
				}
			}
			if (!d.enabled || (!d.item && !d.notes.length)) { guard = false; return; }
			var it = d.item;
			var p = el('div', 'panel panel-default dpcf dpcf-order ' + (it ? it.state : ''));
			p.id = 'dpcf-order';
			var ph = el('div', 'panel-heading');
			ph.appendChild(el('i', 'fa fa-bell'));
			ph.appendChild(document.createTextNode(' ' + (it ? (it.state === 'overdue' ? 'This customer has waited too long: ' : it.state === 'snoozed' ? 'Follow-up snoozed ' : 'Follow-up: ') + it.due_text + ' (waiting ' + it.since_text + ')' : 'Follow-up notes')));
			p.appendChild(ph);
			var pb = el('div', 'panel-body');
			if (it) {
				pb.appendChild(el('p', null, it.hint + ' A history entry below or a follow-up note starts the timer again.'));
				if (d.can_edit) pb.appendChild(actions(it, function () { guard = false; orderBox(); }, true));
			}
			if (d.notes.length) {
				var ul = el('ul', 'dpcf-notes');
				d.notes.forEach(function (n) {
					var li = el('li');
					li.appendChild(el('span', null, n.ago + ' ago, ' + n.username + (n.action === 'snooze' ? ' (snoozed to ' + n.until.slice(0, 16) + ')' : '') + ': '));
					li.appendChild(document.createTextNode(n.note));
					ul.appendChild(li);
				});
				pb.appendChild(el('div', 'dpcf-sec', 'Follow-up notes (only the shop sees these)'));
				pb.appendChild(ul);
			}
			p.appendChild(pb);
			at.insertBefore(p, at.firstChild);
			guard = !!(it && it.state === 'overdue');
		});
		if (bound) return;
		bound = true;
		window.addEventListener('beforeunload', function (e) {
			if (!guard) return;
			e.preventDefault();
			e.returnValue = 'This customer is still waiting. Add a history entry or a follow-up note before you leave.';
			return e.returnValue;
		});
		// A new order history entry counts as the action
		if (window.jQuery) {
			jQuery(document).ajaxSuccess(function (ev, xhr, s) {
				if (s && /api\/order\/history/.test(s.url || '')) {
					var j = xhr.responseJSON || {};
					try { if (!j.success && xhr.responseText) j = JSON.parse(xhr.responseText); } catch (e) {}
					if (j.success) {
						guard = false;
						try { sessionStorage.removeItem(CACHE); } catch (e) {}
						setTimeout(orderBox, 400);
					}
				}
			});
		}
	}

	function start() {
		var onDash = route === 'common/dashboard';
		load(onDash || route === 'sale/order/info').then(function (d) {
			if (!d || !d.counts) return;
			data = d;
			badge(d);
			if (onDash) tile(d);
			if (d.enabled && d.login && d.counts.overdue) {
				var seen = null;
				try { seen = sessionStorage.getItem(SEEN); } catch (e) {}
				if (!seen) {
					try { sessionStorage.setItem(SEEN, '1'); } catch (e) {}
					modal(d, 'login');
				}
			}
		}).catch(function () {});
		if (route === 'sale/order/info') orderBox();

		// Check before logging out
		document.addEventListener('click', function (e) {
			var a = e.target.closest && e.target.closest('a[href*="route=common/logout"]');
			if (!a || a.getAttribute('data-dpcf-ok')) return;
			if (!data || !data.enabled || !data.logout || !data.counts.overdue) return;
			e.preventDefault();
			load(true).then(function (d) {
				data = d;
				if (!d.counts.overdue || !modal(d, 'logout', a.href)) location.href = a.href;
			}).catch(function () { location.href = a.href; });
		}, true);
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
	else start();
})();
