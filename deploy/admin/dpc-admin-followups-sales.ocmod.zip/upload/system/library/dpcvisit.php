<?php
// dpCREATOR Visitors: one row per visit (session) and one per page view, with the clues that
// tell people from bots. Visit data is kept for 30 days.
class DpcVisit {
	private $db;
	private $p;

	const BOTS = '~(googlebot|google-inspectiontool|googleother|adsbot-google|mediapartners-google|storebot-google|bingbot|bingpreview|msnbot|yandex|baiduspider|duckduckbot|applebot|slurp|facebookexternalhit|facebookcatalog|meta-externalagent|twitterbot|linkedinbot|pinterest|whatsapp|telegrambot|discordbot|slackbot|skypeuripreview|ahrefs|semrush|mj12bot|dotbot|petalbot|bytespider|gptbot|chatgpt-user|oai-searchbot|claudebot|claude-user|anthropic|perplexity|ccbot|amazonbot|dataforseo|serpstat|seznambot|sogou|exabot|ia_archiver|archive\.org|uptimerobot|pingdom|statuscake|site24x7|crawler|spider|scraper|bot[/;\s)]|\bbot$|curl/|wget/|python|go-http-client|java/|okhttp|axios|node-fetch|httpclient|libwww|scrapy|headlesschrome|phantomjs|puppeteer|playwright|lighthouse|pagespeed|gtmetrix)~i';
	const CLOUD = '~(amazonaws|compute\.internal|googleusercontent|bc\.googleusercontent|cloudfront|azure|microsoft\.com$|hetzner|your-server\.de|ovh|kimsufi|digitalocean|linode|akamai|contabo|vultr|choopa|scaleway|online\.net|leaseweb|hostinger|oraclecloud|alibaba|aliyun|tencent|huawei|m247|datacamp|cdn77|\bvps|dedicated|colocation|cloud)~i';

	public function __construct($db) {
		$this->db = $db;
		$this->p = DB_PREFIX . 'dpc_visit';
	}

	private function e($s) {
		return $this->db->escape((string)$s);
	}

	public function install() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->p . "` (
			`visit_id` INT(11) NOT NULL AUTO_INCREMENT,
			`sess` VARCHAR(64) NOT NULL,
			`ip` VARCHAR(45) NOT NULL,
			`host` VARCHAR(255) NULL,
			`ua` VARCHAR(500) NOT NULL DEFAULT '',
			`lang` VARCHAR(64) NOT NULL DEFAULT '',
			`referer` VARCHAR(500) NOT NULL DEFAULT '',
			`landing` VARCHAR(500) NOT NULL DEFAULT '',
			`last_url` VARCHAR(500) NOT NULL DEFAULT '',
			`hits` INT(11) NOT NULL DEFAULT 0,
			`js` TINYINT(1) NOT NULL DEFAULT 0,
			`interact` TINYINT(1) NOT NULL DEFAULT 0,
			`screen` VARCHAR(20) NOT NULL DEFAULT '',
			`tz` VARCHAR(64) NOT NULL DEFAULT '',
			`customer_id` INT(11) NOT NULL DEFAULT 0,
			`admin` TINYINT(1) NOT NULL DEFAULT 0,
			`cart` TINYINT(1) NOT NULL DEFAULT 0,
			`first_seen` DATETIME NOT NULL,
			`last_seen` DATETIME NOT NULL,
			PRIMARY KEY (`visit_id`),
			UNIQUE KEY `sess` (`sess`),
			KEY `last_seen` (`last_seen`),
			KEY `ip` (`ip`, `last_seen`)
		) DEFAULT CHARSET=utf8mb4");
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->p . "_hit` (
			`hit_id` INT(11) NOT NULL AUTO_INCREMENT,
			`visit_id` INT(11) NOT NULL,
			`url` VARCHAR(500) NOT NULL DEFAULT '',
			`title` VARCHAR(255) NOT NULL DEFAULT '',
			`created` DATETIME NOT NULL,
			PRIMARY KEY (`hit_id`),
			KEY `visit` (`visit_id`, `created`),
			KEY `created` (`created`)
		) DEFAULT CHARSET=utf8mb4");
	}

	public function ready() {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e($this->p) . "'")->num_rows;
	}

	public static function ip() {
		$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
		return substr($ip, 0, 45);
	}

	// Record one page view. $sess: the shop session id, or '' for clients that refuse cookies.
	public function log($sess, $hasCookie, $url, $referer, $customerId, $isAdmin, $hasCart) {
		$ip = self::ip();
		$ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 500) : '';
		$lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 64) : '';
		$url = substr($url, 0, 500);
		// a visitor that never keeps the session cookie gets a new session on every page:
		// group those by IP + browser for 30 minutes instead
		$key = $hasCookie ? 's:' . $sess : 'n:' . sha1($ip . '|' . $ua . '|' . floor(time() / 1800));
		$row = $this->db->query("SELECT `visit_id`, `last_seen` FROM `" . $this->p . "` WHERE `sess` = '" . $this->e($key) . "'")->row;
		if (!$row && $hasCookie) {
			// the first page of a visit has no cookie yet: join it to the cookie-less row from a moment ago
			$nk = 'n:' . sha1($ip . '|' . $ua . '|' . floor(time() / 1800));
			$prev = $this->db->query("SELECT `visit_id` FROM `" . $this->p . "` WHERE `sess` = '" . $this->e($nk) . "' AND `hits` = 1 AND `last_seen` > NOW() - INTERVAL 10 MINUTE")->row;
			if ($prev) {
				$this->db->query("UPDATE `" . $this->p . "` SET `sess` = '" . $this->e($key) . "' WHERE `visit_id` = '" . (int)$prev['visit_id'] . "'");
				$row = array('visit_id' => $prev['visit_id']);
			}
		}
		if ($row) {
			$id = (int)$row['visit_id'];
			$this->db->query("UPDATE `" . $this->p . "` SET `hits` = `hits` + 1, `last_url` = '" . $this->e($url) . "', `last_seen` = NOW(), `customer_id` = GREATEST(`customer_id`, " . (int)$customerId . "), `admin` = GREATEST(`admin`, " . ($isAdmin ? 1 : 0) . "), `cart` = GREATEST(`cart`, " . ($hasCart ? 1 : 0) . ") WHERE `visit_id` = '" . $id . "'");
		} else {
			$this->db->query("INSERT INTO `" . $this->p . "` SET `sess` = '" . $this->e($key) . "', `ip` = '" . $this->e($ip) . "', `ua` = '" . $this->e($ua) . "', `lang` = '" . $this->e($lang) . "', `referer` = '" . $this->e(substr($referer, 0, 500)) . "', `landing` = '" . $this->e($url) . "', `last_url` = '" . $this->e($url) . "', `hits` = 1, `customer_id` = '" . (int)$customerId . "', `admin` = '" . ($isAdmin ? 1 : 0) . "', `cart` = '" . ($hasCart ? 1 : 0) . "', `first_seen` = NOW(), `last_seen` = NOW()");
			$id = (int)$this->db->getLastId();
		}
		$this->db->query("INSERT INTO `" . $this->p . "_hit` SET `visit_id` = '" . $id . "', `url` = '" . $this->e($url) . "', `created` = NOW()");
		if (mt_rand(1, 200) === 1) {
			$this->cleanup();
		}
		return $id;
	}

	// The page's script ran (and maybe the visitor moved, scrolled or touched)
	public function beacon($sess, $data) {
		$ip = self::ip();
		$ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 500) : '';
		$keys = array("'s:" . $this->e($sess) . "'", "'n:" . $this->e(sha1($ip . '|' . $ua . '|' . floor(time() / 1800))) . "'");
		$set = array('`js` = 1');
		if (!empty($data['i'])) {
			$set[] = '`interact` = 1';
		}
		if (!empty($data['s']) && preg_match('/^\d{2,5}x\d{2,5}$/', $data['s'])) {
			$set[] = "`screen` = '" . $this->e($data['s']) . "'";
		}
		if (!empty($data['tz']) && preg_match('~^[A-Za-z_]+(/[A-Za-z0-9_+-]+){0,2}$~', $data['tz'])) {
			$set[] = "`tz` = '" . $this->e($data['tz']) . "'";
		}
		$this->db->query("UPDATE `" . $this->p . "` SET " . implode(', ', $set) . " WHERE `sess` IN (" . implode(',', $keys) . ") AND `last_seen` > NOW() - INTERVAL 2 HOUR");
		if (!empty($data['t']) && !empty($data['u'])) {
			$this->db->query("UPDATE `" . $this->p . "_hit` h JOIN `" . $this->p . "` v ON v.visit_id = h.visit_id SET h.`title` = '" . $this->e(mb_substr((string)$data['t'], 0, 255)) . "' WHERE v.`sess` IN (" . implode(',', $keys) . ") AND h.`url` = '" . $this->e(substr((string)$data['u'], 0, 500)) . "' AND h.`title` = '' AND h.`created` > NOW() - INTERVAL 1 HOUR");
		}
	}

	public function cleanup() {
		$this->db->query("DELETE h FROM `" . $this->p . "_hit` h WHERE h.`created` < NOW() - INTERVAL 30 DAY");
		$this->db->query("DELETE FROM `" . $this->p . "` WHERE `last_seen` < NOW() - INTERVAL 30 DAY");
	}

	// ---- admin side

	public static function botName($ua) {
		if ($ua === '') {
			return 'No browser name';
		}
		$names = array('googlebot' => 'Google', 'google-inspectiontool' => 'Google', 'googleother' => 'Google', 'adsbot-google' => 'Google Ads', 'storebot-google' => 'Google Shopping', 'bingbot' => 'Bing', 'yandex' => 'Yandex', 'baiduspider' => 'Baidu', 'duckduckbot' => 'DuckDuckGo', 'applebot' => 'Apple', 'facebookexternalhit' => 'Facebook link preview', 'meta-externalagent' => 'Meta AI', 'twitterbot' => 'X/Twitter', 'linkedinbot' => 'LinkedIn', 'whatsapp' => 'WhatsApp link preview', 'telegrambot' => 'Telegram', 'discordbot' => 'Discord', 'ahrefs' => 'Ahrefs (SEO)', 'semrush' => 'Semrush (SEO)', 'mj12bot' => 'Majestic (SEO)', 'dotbot' => 'Moz (SEO)', 'petalbot' => 'Huawei Petal', 'bytespider' => 'ByteDance', 'gptbot' => 'OpenAI', 'chatgpt-user' => 'ChatGPT', 'oai-searchbot' => 'OpenAI search', 'claudebot' => 'Anthropic', 'claude-user' => 'Claude', 'perplexity' => 'Perplexity', 'ccbot' => 'Common Crawl', 'amazonbot' => 'Amazon', 'uptimerobot' => 'UptimeRobot', 'lighthouse' => 'Lighthouse test', 'headlesschrome' => 'Headless Chrome', 'curl/' => 'curl script', 'wget/' => 'wget script', 'python' => 'Python script', 'go-http-client' => 'Go script', 'scrapy' => 'Scrapy scraper');
		foreach ($names as $k => $n) {
			if (stripos($ua, $k) !== false) {
				return $n;
			}
		}
		return 'Crawler';
	}

	public static function device($ua) {
		$os = 'Other';
		foreach (array('Windows' => 'Windows', 'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Android' => 'Android', 'Mac OS X' => 'Mac', 'CrOS' => 'ChromeOS', 'Linux' => 'Linux') as $k => $v) {
			if (stripos($ua, $k) !== false) {
				$os = $v;
				break;
			}
		}
		$br = 'Other';
		foreach (array('Edg/' => 'Edge', 'OPR/' => 'Opera', 'SamsungBrowser' => 'Samsung', 'YaBrowser' => 'Yandex', 'Firefox/' => 'Firefox', 'CriOS' => 'Chrome', 'Chrome/' => 'Chrome', 'Safari/' => 'Safari') as $k => $v) {
			if (stripos($ua, $k) !== false) {
				$br = $v;
				break;
			}
		}
		$mobile = preg_match('/Mobi|iPhone|Android.+Mobile/i', $ua) ? 'phone' : (preg_match('/iPad|Tablet|Android/i', $ua) ? 'tablet' : 'computer');
		return $br . ' on ' . $os . ' (' . $mobile . ')';
	}

	// kind: you | customer | bot | human | likely_bot | unknown, with the reasons
	public static function classify($v) {
		$why = array();
		$dur = strtotime($v['last_seen']) - strtotime($v['first_seen']);
		if ((int)$v['admin']) {
			return array('you', array('Logged in to the shop admin'));
		}
		if ($v['ua'] === '' || preg_match(self::BOTS, $v['ua'])) {
			return array('bot', array('Says it is a bot: ' . self::botName($v['ua'])));
		}
		if ((int)$v['customer_id']) {
			return array('customer', array('Logged in to a customer account'));
		}
		if ((int)$v['interact']) {
			$why[] = 'Page script ran';
			$why[] = 'Moved, scrolled or touched the page';
			if ((int)$v['cart']) {
				$why[] = 'Put something in the cart';
			}
			return array('human', $why);
		}
		$cloud = $v['host'] && preg_match(self::CLOUD, $v['host']);
		if ($cloud) {
			$why[] = 'Comes from a server network (' . $v['host'] . ')';
		}
		if (!(int)$v['js']) {
			if ((int)$v['hits'] >= 3) {
				$why[] = 'Opened ' . (int)$v['hits'] . ' pages without running the page script';
			} elseif ($dur > 20 || strtotime($v['last_seen']) < time() - 120) {
				$why[] = 'The page script never ran';
			}
			if ($v['lang'] === '') {
				$why[] = 'Browser sends no language';
			}
		}
		if ((int)$v['hits'] >= 5 && $dur > 0 && $dur / max(1, (int)$v['hits'] - 1) < 2) {
			$why[] = 'Pages less than 2 seconds apart';
		}
		if ($why && (!(int)$v['js'] || $cloud)) {
			return array('likely_bot', $why);
		}
		if ((int)$v['js']) {
			return array('unknown', array('Page script ran, but no mouse, scroll or touch yet'));
		}
		return array('unknown', array('Only just arrived'));
	}

	public function resolveHosts($limit = 15) {
		$rows = $this->db->query("SELECT DISTINCT `ip` FROM `" . $this->p . "` WHERE `host` IS NULL AND `last_seen` > NOW() - INTERVAL 7 DAY ORDER BY `last_seen` DESC LIMIT " . (int)$limit)->rows;
		$start = microtime(true);
		foreach ($rows as $r) {
			if (microtime(true) - $start > 4) {
				break;
			}
			$h = @gethostbyaddr($r['ip']);
			$h = ($h === false || $h === $r['ip']) ? '' : substr($h, 0, 255);
			$this->db->query("UPDATE `" . $this->p . "` SET `host` = '" . $this->e($h) . "' WHERE `ip` = '" . $this->e($r['ip']) . "' AND `host` IS NULL");
		}
	}

	public function visits($since, $limit = 300) {
		return $this->db->query("SELECT v.*, c.firstname, c.lastname, c.email FROM `" . $this->p . "` v LEFT JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = v.customer_id WHERE v.`last_seen` >= '" . $this->e($since) . "' ORDER BY v.`last_seen` DESC LIMIT " . (int)$limit)->rows;
	}

	public function hits($visitId) {
		return $this->db->query("SELECT `url`, `title`, `created` FROM `" . $this->p . "_hit` WHERE `visit_id` = '" . (int)$visitId . "' ORDER BY `created` ASC, `hit_id` ASC LIMIT 300")->rows;
	}
}
