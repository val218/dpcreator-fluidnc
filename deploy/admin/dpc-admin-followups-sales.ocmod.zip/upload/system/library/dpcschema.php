<?php
// dpCREATOR: completes the Product structured data that the theme prints, for Google merchant listings.
// The product page footer fills DpcSchema::$ctx; Response::output() then calls DpcSchema::fix() on the page.
class DpcSchema {
	public static $ctx = null;

	// Where the return policy applies (EU countries, ISO 3166-1 alpha-2)
	public static $countries = array('AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE');

	// Shipping rates for shippingDetails, filled in once the carriers and prices are set.
	// Each entry: array('country' => 'LV', 'cost' => 6.50, 'currency' => 'EUR', 'handling' => array(1, 3), 'transit' => array(1, 3))
	public static $shipping = array();

	public static function fix($html) {
		if (!self::$ctx || strpos($html, 'application/ld+json') === false) {
			return $html;
		}
		return preg_replace_callback('#(<script type="application/ld\+json">)(.*?)(</script>)#s', function ($m) {
			$j = json_decode(html_entity_decode($m[2], ENT_QUOTES, 'UTF-8'), true);
			if (!is_array($j) || (isset($j['@type']) ? $j['@type'] : '') !== 'Product') {
				return $m[0];
			}
			$j = DpcSchema::product($j, DpcSchema::$ctx);
			return $m[1] . json_encode($j, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . $m[3];
		}, $html);
	}

	public static function product($j, $c) {
		$brand = 'dpCREATOR';
		if (isset($j['brand']['name']) && $j['brand']['name'] !== '') {
			$brand = $j['brand']['name'];
		} elseif (!empty($c['manufacturer'])) {
			$brand = $c['manufacturer'];
		}
		$j['brand'] = array('@type' => 'Brand', 'name' => $brand);
		if (empty($j['sku']) && !empty($c['sku'])) {
			$j['sku'] = $c['sku'];
		} elseif (empty($j['sku']) && !empty($c['model'])) {
			$j['sku'] = $c['model'];
		}
		if (empty($j['mpn']) && !empty($c['mpn'])) {
			$j['mpn'] = $c['mpn'];
		} elseif (empty($j['mpn']) && !empty($c['model'])) {
			$j['mpn'] = $c['model'];
		}
		foreach (array('gtin', 'gtin8', 'gtin12', 'gtin13', 'gtin14') as $g) {
			if (isset($j[$g]) && $j[$g] === '') {
				unset($j[$g]);
			}
		}
		if (!empty($c['ean']) && preg_match('/^\d{8,14}$/', $c['ean'])) {
			$j['gtin'] = $c['ean'];
		}
		if (isset($j['offers'])) {
			if (isset($j['offers']['@type'])) {
				$j['offers'] = self::offer($j['offers'], $c);
			} elseif (is_array($j['offers'])) {
				foreach ($j['offers'] as $k => $o) {
					$j['offers'][$k] = self::offer($o, $c);
				}
			}
		}
		return $j;
	}

	private static function offer($o, $c) {
		if (empty($o['validFrom']) && !empty($c['valid_from'])) {
			$o['validFrom'] = $c['valid_from'];
		}
		$policy = array('@type' => 'MerchantReturnPolicy', 'applicableCountry' => self::$countries);
		if (!empty($c['shipping'])) {
			// hardware: 14-day right of withdrawal, sent back by post, buyer pays the return
			$policy['returnPolicyCategory'] = 'https://schema.org/MerchantReturnFiniteReturnWindow';
			$policy['merchantReturnDays'] = 14;
			$policy['returnMethod'] = 'https://schema.org/ReturnByMail';
			$policy['returnFees'] = 'https://schema.org/ReturnFeesCustomerResponsibility';
		} else {
			// digital products: no withdrawal once delivery has started
			$policy['returnPolicyCategory'] = 'https://schema.org/MerchantReturnNotPermitted';
		}
		$o['hasMerchantReturnPolicy'] = $policy;
		if (!empty($c['shipping']) && self::$shipping) {
			$list = array();
			foreach (self::$shipping as $s) {
				$list[] = array(
					'@type' => 'OfferShippingDetails',
					'shippingRate' => array('@type' => 'MonetaryAmount', 'value' => $s['cost'], 'currency' => $s['currency']),
					'shippingDestination' => array('@type' => 'DefinedRegion', 'addressCountry' => $s['country']),
					'deliveryTime' => array(
						'@type' => 'ShippingDeliveryTime',
						'handlingTime' => array('@type' => 'QuantitativeValue', 'minValue' => $s['handling'][0], 'maxValue' => $s['handling'][1], 'unitCode' => 'DAY'),
						'transitTime' => array('@type' => 'QuantitativeValue', 'minValue' => $s['transit'][0], 'maxValue' => $s['transit'][1], 'unitCode' => 'DAY')
					)
				);
			}
			$o['shippingDetails'] = count($list) === 1 ? $list[0] : $list;
		} elseif (empty($c['shipping'])) {
			// digital: delivered online, nothing to pay for shipping
			$o['shippingDetails'] = array(
				'@type' => 'OfferShippingDetails',
				'shippingRate' => array('@type' => 'MonetaryAmount', 'value' => 0, 'currency' => isset($o['priceCurrency']) ? $o['priceCurrency'] : 'EUR'),
				'shippingDestination' => array('@type' => 'DefinedRegion', 'addressCountry' => self::$countries),
				'deliveryTime' => array(
					'@type' => 'ShippingDeliveryTime',
					'handlingTime' => array('@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 0, 'unitCode' => 'DAY'),
					'transitTime' => array('@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 0, 'unitCode' => 'DAY')
				)
			);
		}
		return $o;
	}
}
