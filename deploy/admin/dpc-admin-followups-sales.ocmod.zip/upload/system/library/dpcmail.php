<?php
// dpCREATOR Inbox: a small IMAP reader, MIME parser, message builder and SMTP sender.
// Plain PHP 7.4+, needs openssl, mbstring or iconv. No IMAP extension required.

class DpcMailError extends \Exception {}

class DpcImap {
	private $fp;
	private $tag = 0;
	public $greeting = '';

	public function connect($host, $port, $secure, $verify, $timeout = 15) {
		$ctx = stream_context_create(array('ssl' => array(
			'verify_peer' => (bool)$verify,
			'verify_peer_name' => (bool)$verify,
			'allow_self_signed' => !$verify,
			'SNI_enabled' => true,
			'peer_name' => $host
		)));
		$scheme = $secure === 'ssl' ? 'ssl' : 'tcp';
		$errno = 0;
		$errstr = '';
		$this->fp = @stream_socket_client($scheme . '://' . $host . ':' . (int)$port, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $ctx);
		if (!$this->fp) {
			throw new DpcMailError('Could not connect to ' . $host . ':' . $port . ' (' . ($errstr ?: 'connection failed') . ')' . (stripos($errstr, 'certificate') !== false || $errstr === '' ? '. If the server certificate is for another name, turn off "Check the server certificate" or use the name it is issued for.' : ''));
		}
		stream_set_timeout($this->fp, $timeout);
		$this->greeting = $this->line();
		if (strpos($this->greeting, '* OK') !== 0 && strpos($this->greeting, '* PREAUTH') !== 0) {
			throw new DpcMailError('Unexpected IMAP greeting: ' . substr($this->greeting, 0, 120));
		}
		if ($secure === 'tls') {
			$this->command('STARTTLS');
			if (!@stream_socket_enable_crypto($this->fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
				throw new DpcMailError('STARTTLS failed. Check the certificate setting.');
			}
		}
	}

	public function login($user, $pass) {
		try {
			$this->command('AUTHENTICATE PLAIN ' . base64_encode("\0" . $user . "\0" . $pass));
		} catch (DpcMailError $e) {
			// Servers without SASL-IR: fall back to LOGIN
			try {
				$this->command('LOGIN ' . $this->quote($user) . ' ' . $this->quote($pass));
			} catch (DpcMailError $e2) {
				throw new DpcMailError('Login failed for ' . $user . '. Check the username and password.');
			}
		}
	}

	public function quote($s) {
		return '"' . str_replace(array('\\', '"'), array('\\\\', '\\"'), $s) . '"';
	}

	private function line() {
		$l = fgets($this->fp, 65536);
		if ($l === false) {
			$meta = stream_get_meta_data($this->fp);
			throw new DpcMailError($meta['timed_out'] ? 'The mail server stopped answering (timeout).' : 'The mail server closed the connection.');
		}
		return $l;
	}

	private function read($n) {
		$out = '';
		while (strlen($out) < $n) {
			$chunk = fread($this->fp, min(65536, $n - strlen($out)));
			if ($chunk === false || $chunk === '') {
				$meta = stream_get_meta_data($this->fp);
				if ($meta['timed_out'] || feof($this->fp)) {
					throw new DpcMailError('The mail server stopped sending data.');
				}
				continue;
			}
			$out .= $chunk;
		}
		return $out;
	}

	// Sends a command; returns the untagged responses as array of array('text' => ..., 'lit' => array(...))
	public function command($cmd, $literal = null) {
		$tag = 'D' . (++$this->tag);
		if ($literal !== null) {
			fwrite($this->fp, $tag . ' ' . $cmd . ' {' . strlen($literal) . "}\r\n");
			$l = $this->line();
			if ($l[0] !== '+') {
				throw new DpcMailError('Server refused: ' . trim($l));
			}
			fwrite($this->fp, $literal . "\r\n");
		} else {
			fwrite($this->fp, $tag . ' ' . $cmd . "\r\n");
		}
		$out = array();
		while (true) {
			$l = $this->line();
			if (strpos($l, $tag . ' ') === 0) {
				$rest = substr($l, strlen($tag) + 1);
				if (stripos($rest, 'OK') !== 0) {
					throw new DpcMailError(trim($rest));
				}
				return $out;
			}
			$cur = array('text' => $l, 'lit' => array());
			// literals: "{123}\r\n" then 123 bytes, then the rest of the response
			while (preg_match('/\{(\d+)\}\r?\n$/', $cur['text'], $m)) {
				$cur['lit'][] = $this->read((int)$m[1]);
				$cur['text'] = substr($cur['text'], 0, -strlen($m[0])) . '{LIT' . (count($cur['lit']) - 1) . '}';
				$cur['text'] .= $this->line();
			}
			$out[] = $cur;
		}
	}

	public function select($folder) {
		$res = $this->command('SELECT ' . $this->quote($folder));
		$info = array('exists' => 0, 'uidvalidity' => 0, 'uidnext' => 0);
		foreach ($res as $r) {
			if (preg_match('/\* (\d+) EXISTS/', $r['text'], $m)) {
				$info['exists'] = (int)$m[1];
			}
			if (preg_match('/UIDVALIDITY (\d+)/', $r['text'], $m)) {
				$info['uidvalidity'] = (int)$m[1];
			}
			if (preg_match('/UIDNEXT (\d+)/', $r['text'], $m)) {
				$info['uidnext'] = (int)$m[1];
			}
		}
		return $info;
	}

	public function uidSearch($criteria) {
		$uids = array();
		foreach ($this->command('UID SEARCH ' . $criteria) as $r) {
			if (preg_match('/^\* SEARCH(.*)$/s', trim($r['text']), $m)) {
				foreach (preg_split('/\s+/', trim($m[1])) as $u) {
					if ($u !== '') {
						$uids[] = (int)$u;
					}
				}
			}
		}
		sort($uids);
		return $uids;
	}

	// Returns array(uid => array('raw' => ..., 'flags' => array, 'date' => ...))
	public function fetch(array $uids) {
		if (!$uids) {
			return array();
		}
		$out = array();
		foreach ($this->command('UID FETCH ' . implode(',', $uids) . ' (UID FLAGS INTERNALDATE BODY.PEEK[])') as $r) {
			if (!preg_match('/UID (\d+)/', $r['text'], $m)) {
				continue;
			}
			$uid = (int)$m[1];
			$flags = array();
			if (preg_match('/FLAGS \(([^)]*)\)/', $r['text'], $m)) {
				$flags = preg_split('/\s+/', trim($m[1]));
			}
			$date = preg_match('/INTERNALDATE "([^"]+)"/', $r['text'], $m) ? $m[1] : '';
			$raw = '';
			if (preg_match('/BODY\[\] \{LIT(\d+)\}/', $r['text'], $m)) {
				$raw = $r['lit'][(int)$m[1]];
			} elseif (preg_match('/BODY\[\] "((?:[^"\\\\]|\\\\.)*)"/s', $r['text'], $m)) {
				$raw = stripcslashes($m[1]);
			}
			$out[$uid] = array('raw' => $raw, 'flags' => $flags, 'date' => $date);
		}
		return $out;
	}

	public function addFlag($uid, $flag) {
		$this->command('UID STORE ' . (int)$uid . ' +FLAGS.SILENT (' . $flag . ')');
	}

	public function append($folder, $raw) {
		$this->command('APPEND ' . $this->quote($folder) . ' (\\Seen)', $raw);
	}

	// Folder names with their attributes
	public function folders() {
		$out = array();
		foreach ($this->command('LIST "" "*"') as $r) {
			if (preg_match('/^\* LIST \(([^)]*)\) (?:"[^"]*"|NIL) (.+)$/s', trim($r['text']), $m)) {
				$name = trim($m[2]);
				if (preg_match('/^\{LIT(\d+)\}$/', $name, $l)) {
					$name = $r['lit'][(int)$l[1]];
				} elseif ($name[0] === '"') {
					$name = stripcslashes(substr($name, 1, -1));
				}
				$out[$name] = $m[1];
			}
		}
		return $out;
	}

	public function sentFolder() {
		$folders = $this->folders();
		foreach ($folders as $name => $attr) {
			if (stripos($attr, '\\Sent') !== false) {
				return $name;
			}
		}
		foreach (array('INBOX.Sent', 'Sent', 'INBOX/Sent', 'Sent Items', 'Sent Messages', 'INBOX.Sent Items') as $n) {
			if (isset($folders[$n])) {
				return $n;
			}
		}
		return '';
	}

	public function logout() {
		if ($this->fp) {
			try {
				$this->command('LOGOUT');
			} catch (\Exception $e) {
			}
			fclose($this->fp);
			$this->fp = null;
		}
	}
}

class DpcMime {
	public static function utf8($s, $charset) {
		$charset = strtolower(trim((string)$charset, " \"'"));
		if ($charset === '' || $charset === 'us-ascii' || $charset === 'utf-8' || $charset === 'utf8') {
			$out = $s;
		} else {
			if ($charset === 'ks_c_5601-1987') {
				$charset = 'cp949';
			} elseif ($charset === 'windows-874') {
				$charset = 'cp874';
			}
			$out = false;
			if (function_exists('mb_convert_encoding') && in_array(strtoupper($charset), array_map('strtoupper', mb_list_encodings()), true)) {
				$out = @mb_convert_encoding($s, 'UTF-8', $charset);
			}
			if ($out === false && function_exists('iconv')) {
				$out = @iconv($charset, 'UTF-8//IGNORE', $s);
			}
			if ($out === false) {
				$out = $s;
			}
		}
		// drop invalid UTF-8
		if (function_exists('mb_convert_encoding')) {
			$out = mb_convert_encoding($out, 'UTF-8', 'UTF-8');
		}
		return $out;
	}

	public static function header($v) {
		$v = preg_replace('/\r?\n[ \t]+/', ' ', (string)$v);
		if (strpos($v, '=?') === false) {
			return self::utf8($v, 'utf-8');
		}
		// join adjacent encoded words
		$v = preg_replace('/(=\?[^?]+\?[QqBb]\?[^?]*\?=)\s+(?==\?)/', '$1', $v);
		return preg_replace_callback('/=\?([^?]+)\?([QqBb])\?([^?]*)\?=/', function ($m) {
			$cs = preg_replace('/\*.*$/', '', $m[1]);
			if (strtoupper($m[2]) === 'B') {
				$t = base64_decode($m[3]);
			} else {
				$t = quoted_printable_decode(str_replace('_', ' ', $m[3]));
			}
			return DpcMime::utf8($t, $cs);
		}, $v);
	}

	// Split raw message into header array (lowercase name => list of raw values) and body
	public static function split($raw) {
		$pos = strpos($raw, "\r\n\r\n");
		$sep = 4;
		$p2 = strpos($raw, "\n\n");
		if ($pos === false || ($p2 !== false && $p2 < $pos)) {
			$pos = $p2;
			$sep = 2;
		}
		if ($pos === false) {
			$head = $raw;
			$body = '';
		} else {
			$head = substr($raw, 0, $pos);
			$body = substr($raw, $pos + $sep);
		}
		$head = preg_replace('/\r?\n[ \t]+/', ' ', $head);
		$headers = array();
		foreach (preg_split('/\r?\n/', $head) as $line) {
			$c = strpos($line, ':');
			if ($c === false) {
				continue;
			}
			$headers[strtolower(trim(substr($line, 0, $c)))][] = trim(substr($line, $c + 1));
		}
		return array($headers, $body);
	}

	public static function param($value, $name) {
		// RFC 2231 continuations and plain params
		if (preg_match('/(?:^|;)\s*' . preg_quote($name, '/') . '\*0\*?=/i', $value)) {
			$parts = array();
			$enc = false;
			preg_match_all('/(?:^|;)\s*' . preg_quote($name, '/') . '\*(\d+)(\*?)=("([^"]*)"|[^;]*)/i', $value, $mm, PREG_SET_ORDER);
			foreach ($mm as $m) {
				$parts[(int)$m[1]] = isset($m[4]) && $m[4] !== '' ? $m[4] : trim($m[3], '"');
				if ($m[2] === '*') {
					$enc = true;
				}
			}
			ksort($parts);
			$v = implode('', $parts);
			if ($enc && preg_match("/^([^']*)'[^']*'(.*)$/", $v, $e)) {
				return self::utf8(rawurldecode($e[2]), $e[1]);
			}
			return $enc ? rawurldecode($v) : self::header($v);
		}
		if (preg_match('/(?:^|;)\s*' . preg_quote($name, '/') . "\*=([^']*)'[^']*'([^;]*)/i", $value, $m)) {
			return self::utf8(rawurldecode(trim($m[2])), $m[1]);
		}
		if (preg_match('/(?:^|;)\s*' . preg_quote($name, '/') . '\s*=\s*("((?:[^"\\\\]|\\\\.)*)"|[^;\s]*)/i', $value, $m)) {
			return self::header(isset($m[2]) && $m[2] !== '' ? stripcslashes($m[2]) : trim($m[1], '"'));
		}
		return '';
	}

	public static function decodeBody($body, $enc) {
		$enc = strtolower(trim($enc));
		if ($enc === 'base64') {
			return base64_decode(preg_replace('/[^A-Za-z0-9+\/=]/', '', $body));
		}
		if ($enc === 'quoted-printable') {
			return quoted_printable_decode(str_replace("\r\n", "\n", $body));
		}
		return $body;
	}

	// Parse into text, html, attachments
	public static function parse($raw) {
		$msg = array('text' => '', 'html' => '', 'attachments' => array(), 'headers' => array());
		list($headers, $body) = self::split($raw);
		$msg['headers'] = $headers;
		self::walk($headers, $body, $msg, 0);
		return $msg;
	}

	private static function walk($headers, $body, &$msg, $depth) {
		$ct = isset($headers['content-type'][0]) ? $headers['content-type'][0] : 'text/plain';
		$type = strtolower(trim(strtok($ct, ';')));
		$enc = isset($headers['content-transfer-encoding'][0]) ? $headers['content-transfer-encoding'][0] : '';
		$disp = isset($headers['content-disposition'][0]) ? $headers['content-disposition'][0] : '';
		$fname = self::param($disp, 'filename') ?: self::param($ct, 'name');
		if (strpos($type, 'multipart/') === 0 && $depth < 12) {
			$b = self::param($ct, 'boundary');
			if ($b === '') {
				return;
			}
			$parts = preg_split('/\r?\n--' . preg_quote($b, '/') . '(?:--)?[ \t]*(?=\r?\n|$)/', "\n" . $body);
			array_shift($parts);
			foreach ($parts as $p) {
				$p = preg_replace('/^\r?\n/', '', $p);
				if (trim($p) === '' || trim($p) === '--') {
					continue;
				}
				list($h, $bd) = self::split($p);
				self::walk($h, $bd, $msg, $depth + 1);
			}
			return;
		}
		$data = self::decodeBody($body, $enc);
		$isAttach = stripos($disp, 'attachment') === 0 || ($fname !== '' && $type !== 'text/plain' && $type !== 'text/html') || ($fname !== '' && stripos($disp, 'attachment') === 0);
		if (!$isAttach && $type === 'text/plain' && $msg['text'] === '') {
			$msg['text'] = self::utf8($data, self::param($ct, 'charset'));
			return;
		}
		if (!$isAttach && $type === 'text/html' && $msg['html'] === '') {
			$msg['html'] = self::utf8($data, self::param($ct, 'charset'));
			return;
		}
		if (!$isAttach && ($type === 'text/plain' || $type === 'text/html')) {
			// a second text part (e.g. inline forwarded text): append
			$t = self::utf8($data, self::param($ct, 'charset'));
			if ($type === 'text/plain') {
				$msg['text'] .= "\n\n" . $t;
			} else {
				$msg['html'] .= $t;
			}
			return;
		}
		if ($fname === '') {
			$fname = $type === 'message/rfc822' ? 'message.eml' : 'attachment';
		}
		$cid = isset($headers['content-id'][0]) ? trim($headers['content-id'][0], '<> ') : '';
		$msg['attachments'][] = array('name' => $fname, 'type' => $type, 'data' => $data, 'cid' => $cid, 'inline' => stripos($disp, 'inline') === 0 || ($cid !== '' && stripos($disp, 'attachment') !== 0));
	}

	// "Name <a@b>, c@d" -> list of array(name, email)
	public static function addresses($v) {
		$v = self::header($v);
		$out = array();
		// split on commas outside quotes and angle brackets
		$parts = array();
		$buf = '';
		$q = false;
		$a = false;
		for ($i = 0, $n = strlen($v); $i < $n; $i++) {
			$c = $v[$i];
			if ($c === '"') {
				$q = !$q;
			} elseif ($c === '<' && !$q) {
				$a = true;
			} elseif ($c === '>' && !$q) {
				$a = false;
			}
			if (($c === ',' || $c === ';') && !$q && !$a) {
				$parts[] = $buf;
				$buf = '';
			} else {
				$buf .= $c;
			}
		}
		$parts[] = $buf;
		foreach ($parts as $p) {
			$p = trim($p);
			if ($p === '') {
				continue;
			}
			if (preg_match('/^(.*)<([^>]+)>\s*$/', $p, $m)) {
				$name = trim(trim($m[1]), '"\' ');
				$email = trim($m[2]);
			} else {
				$name = '';
				$email = trim(preg_replace('/\(.*\)/', '', $p));
			}
			if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$out[] = array('name' => $name, 'email' => strtolower($email));
			}
		}
		return $out;
	}

	public static function ids($v) {
		preg_match_all('/<([^<>\s]+)>/', (string)$v, $m);
		return $m[1];
	}

	public static function encodeHeader($s) {
		if (!preg_match('/[^\x20-\x7E]/', $s)) {
			return $s;
		}
		$out = array();
		// chunk by characters so each encoded word stays short
		$chars = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY);
		$cur = '';
		foreach ($chars as $c) {
			if (strlen(base64_encode($cur . $c)) > 45) {
				$out[] = '=?UTF-8?B?' . base64_encode($cur) . '?=';
				$cur = '';
			}
			$cur .= $c;
		}
		if ($cur !== '') {
			$out[] = '=?UTF-8?B?' . base64_encode($cur) . '?=';
		}
		return implode("\r\n ", $out);
	}

	public static function address($email, $name = '') {
		if ($name === '') {
			return $email;
		}
		$n = preg_match('/[^\x20-\x7E]/', $name) ? self::encodeHeader($name) : '"' . str_replace(array('\\', '"'), array('\\\\', '\\"'), $name) . '"';
		return $n . ' <' . $email . '>';
	}

	// Build a message. $m: from, from_name, to (list of array(email,name)), cc, subject, text, html, in_reply_to, references (array), attachments (name,type,data), domain
	public static function build($m) {
		$domain = isset($m['domain']) ? $m['domain'] : 'localhost';
		$id = bin2hex(random_bytes(12)) . '@' . $domain;
		$h = array();
		$h[] = 'Date: ' . date('r');
		$h[] = 'From: ' . self::address($m['from'], $m['from_name']);
		$to = array();
		foreach ($m['to'] as $a) {
			$to[] = self::address($a['email'], isset($a['name']) ? $a['name'] : '');
		}
		$h[] = 'To: ' . implode(",\r\n ", $to);
		if (!empty($m['cc'])) {
			$cc = array();
			foreach ($m['cc'] as $a) {
				$cc[] = self::address($a['email'], isset($a['name']) ? $a['name'] : '');
			}
			$h[] = 'Cc: ' . implode(",\r\n ", $cc);
		}
		$h[] = 'Subject: ' . self::encodeHeader($m['subject']);
		$h[] = 'Message-ID: <' . $id . '>';
		if (!empty($m['in_reply_to'])) {
			$h[] = 'In-Reply-To: <' . $m['in_reply_to'] . '>';
		}
		if (!empty($m['references'])) {
			$h[] = 'References: ' . implode("\r\n ", array_map(function ($r) { return '<' . $r . '>'; }, array_slice($m['references'], -20)));
		}
		$h[] = 'MIME-Version: 1.0';
		$h[] = 'X-Mailer: dpCREATOR Inbox';
		$alt = 'alt_' . bin2hex(random_bytes(8));
		$altBody = '--' . $alt . "\r\n"
			. "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n"
			. quoted_printable_encode(str_replace(array("\r\n", "\r"), "\n", $m['text'])) . "\r\n"
			. '--' . $alt . "\r\n"
			. "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n"
			. quoted_printable_encode($m['html']) . "\r\n"
			. '--' . $alt . "--\r\n";
		if (empty($m['attachments'])) {
			$h[] = 'Content-Type: multipart/alternative; boundary="' . $alt . '"';
			$body = $altBody;
		} else {
			$mix = 'mix_' . bin2hex(random_bytes(8));
			$h[] = 'Content-Type: multipart/mixed; boundary="' . $mix . '"';
			$body = '--' . $mix . "\r\nContent-Type: multipart/alternative; boundary=\"" . $alt . "\"\r\n\r\n" . $altBody;
			foreach ($m['attachments'] as $a) {
				$fn = str_replace(array('"', "\r", "\n"), '', $a['name']);
				$fnh = preg_match('/[^\x20-\x7E]/', $fn) ? "filename*=UTF-8''" . rawurlencode($fn) : 'filename="' . $fn . '"';
				$body .= '--' . $mix . "\r\n"
					. 'Content-Type: ' . ($a['type'] ?: 'application/octet-stream') . "\r\n"
					. "Content-Transfer-Encoding: base64\r\n"
					. 'Content-Disposition: attachment; ' . $fnh . "\r\n\r\n"
					. chunk_split(base64_encode($a['data']), 76, "\r\n");
			}
			$body .= '--' . $mix . "--\r\n";
		}
		$raw = implode("\r\n", $h) . "\r\n\r\n" . $body;
		$raw = preg_replace("/(?<!\r)\n/", "\r\n", $raw);
		return array($raw, $id);
	}
}

class DpcSmtp {
	private $fp;

	private function line() {
		$out = '';
		while (true) {
			$l = fgets($this->fp, 4096);
			if ($l === false) {
				throw new DpcMailError('The mail server closed the connection.');
			}
			$out .= $l;
			if (strlen($l) < 4 || $l[3] !== '-') {
				break;
			}
		}
		return $out;
	}

	private function cmd($c, $expect) {
		fwrite($this->fp, $c . "\r\n");
		$r = $this->line();
		if (!in_array((int)substr($r, 0, 3), (array)$expect, true)) {
			$shown = strpos($c, 'AUTH') === 0 ? 'AUTH' : $c;
			throw new DpcMailError('The mail server refused ' . strtok($shown, ' ') . ': ' . trim($r));
		}
		return $r;
	}

	// $secure: ssl (465) | tls (587 STARTTLS) | none
	public function send($host, $port, $secure, $verify, $user, $pass, $from, array $rcpts, $raw, $timeout = 20) {
		$ctx = stream_context_create(array('ssl' => array('verify_peer' => (bool)$verify, 'verify_peer_name' => (bool)$verify, 'allow_self_signed' => !$verify, 'peer_name' => $host)));
		$errno = 0;
		$errstr = '';
		$this->fp = @stream_socket_client(($secure === 'ssl' ? 'ssl' : 'tcp') . '://' . $host . ':' . (int)$port, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $ctx);
		if (!$this->fp) {
			throw new DpcMailError('Could not connect to ' . $host . ':' . $port . ' (' . ($errstr ?: 'connection failed') . ')');
		}
		stream_set_timeout($this->fp, $timeout);
		try {
			$r = $this->line();
			if ((int)substr($r, 0, 3) !== 220) {
				throw new DpcMailError('Unexpected greeting: ' . trim($r));
			}
			$me = isset($_SERVER['SERVER_NAME']) && $_SERVER['SERVER_NAME'] ? $_SERVER['SERVER_NAME'] : 'localhost';
			$this->cmd('EHLO ' . $me, 250);
			if ($secure === 'tls') {
				$this->cmd('STARTTLS', 220);
				if (!@stream_socket_enable_crypto($this->fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
					throw new DpcMailError('STARTTLS failed. Check the certificate setting.');
				}
				$this->cmd('EHLO ' . $me, 250);
			}
			if ($user !== '') {
				$this->cmd('AUTH PLAIN ' . base64_encode("\0" . $user . "\0" . $pass), 235);
			}
			$this->cmd('MAIL FROM:<' . $from . '>', 250);
			foreach ($rcpts as $r) {
				$this->cmd('RCPT TO:<' . $r . '>', array(250, 251));
			}
			$this->cmd('DATA', 354);
			$data = preg_replace('/^\./m', '..', $raw);
			fwrite($this->fp, $data . (substr($data, -2) === "\r\n" ? '' : "\r\n") . ".\r\n");
			$r = $this->line();
			if ((int)substr($r, 0, 3) !== 250) {
				throw new DpcMailError('The mail server did not accept the message: ' . trim($r));
			}
			fwrite($this->fp, "QUIT\r\n");
		} finally {
			fclose($this->fp);
		}
	}

	// Connect and log in only (for the settings test)
	public function test($host, $port, $secure, $verify, $user, $pass) {
		$ctx = stream_context_create(array('ssl' => array('verify_peer' => (bool)$verify, 'verify_peer_name' => (bool)$verify, 'allow_self_signed' => !$verify, 'peer_name' => $host)));
		$this->fp = @stream_socket_client(($secure === 'ssl' ? 'ssl' : 'tcp') . '://' . $host . ':' . (int)$port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
		if (!$this->fp) {
			throw new DpcMailError('Could not connect to ' . $host . ':' . $port . ' (' . ($errstr ?: 'connection failed') . ')');
		}
		stream_set_timeout($this->fp, 15);
		try {
			$this->line();
			$me = isset($_SERVER['SERVER_NAME']) && $_SERVER['SERVER_NAME'] ? $_SERVER['SERVER_NAME'] : 'localhost';
			$this->cmd('EHLO ' . $me, 250);
			if ($secure === 'tls') {
				$this->cmd('STARTTLS', 220);
				if (!@stream_socket_enable_crypto($this->fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
					throw new DpcMailError('STARTTLS failed. Check the certificate setting.');
				}
				$this->cmd('EHLO ' . $me, 250);
			}
			$this->cmd('AUTH PLAIN ' . base64_encode("\0" . $user . "\0" . $pass), 235);
			fwrite($this->fp, "QUIT\r\n");
		} finally {
			fclose($this->fp);
		}
	}
}
