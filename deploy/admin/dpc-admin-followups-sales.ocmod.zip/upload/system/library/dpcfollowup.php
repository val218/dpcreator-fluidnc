<?php
// dpCREATOR follow-ups: everything a customer is waiting on, with how long it has waited.
// Used by the admin dashboard (admin/model/extension/dashboard/dpc_followup.php) and by the
// daily email (dpc-followup-mail.php). An item's clock starts at its last change (order history,
// return history, sign-up, R&D submission) or at the last follow-up note, whichever is later.
class DpcFollowup {
	private $db;
	private $cfg;
	private $link;
	private $money;
	private $catalog;

	// $cfg: function($key) returning a setting; $link: function($route, $query) returning a URL;
	// $money: function($amount, $currency_code, $currency_value) returning text
	public function __construct($db, $cfg, $link, $money, $catalog) {
		$this->db = $db;
		$this->cfg = $cfg;
		$this->link = $link;
		$this->money = $money;
		$this->catalog = $catalog;
	}

	private function cfg($key) {
		return call_user_func($this->cfg, $key);
	}

	private function link($route, $query) {
		return call_user_func($this->link, $route, $query);
	}

	private function money($amount, $code, $value) {
		return call_user_func($this->money, $amount, $code, $value);
	}

	public function install() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_followup` (
			`followup_id` INT(11) NOT NULL AUTO_INCREMENT,
			`item` VARCHAR(40) NOT NULL,
			`action` VARCHAR(10) NOT NULL,
			`note` VARCHAR(1000) NOT NULL DEFAULT '',
			`until` DATETIME NULL,
			`user_id` INT(11) NOT NULL DEFAULT 0,
			`username` VARCHAR(64) NOT NULL DEFAULT '',
			`created` DATETIME NOT NULL,
			PRIMARY KEY (`followup_id`),
			KEY `item` (`item`, `created`)
		) DEFAULT CHARSET=utf8mb4");
	}

	private function hasTable($name) {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . $name) . "'")->num_rows;
	}

	// Hours an order may sit in each status before it is overdue (0 = not followed up)
	public function statusHours() {
		$saved = $this->cfg('dashboard_dpc_followup_hours');
		$q = $this->db->query("SELECT order_status_id, name FROM `" . DB_PREFIX . "order_status` WHERE language_id = '" . (int)$this->cfg('config_language_id') . "' ORDER BY name");
		$out = array();
		foreach ($q->rows as $r) {
			$id = (int)$r['order_status_id'];
			if (is_array($saved)) {
				$h = isset($saved[$id]) ? (float)$saved[$id] : 0;
			} elseif ($id == (int)$this->cfg('config_order_status_id') || preg_match('/^pending/i', $r['name'])) {
				$h = 24;
			} elseif (preg_match('/^processing/i', $r['name'])) {
				$h = 24;
			} elseif (preg_match('/^processed/i', $r['name'])) {
				$h = 48;
			} elseif (preg_match('/^shipped/i', $r['name'])) {
				$h = 21 * 24;
			} else {
				$h = 0;
			}
			$out[$id] = array('name' => $r['name'], 'hours' => $h);
		}
		return $out;
	}

	public function otherHours() {
		$out = array();
		foreach (array('return' => 24, 'approval' => 24, 'rnd' => 48, 'review' => 48, 'ticket' => 24, 'form' => 24) as $k => $default) {
			$v = $this->cfg('dashboard_dpc_followup_' . $k . '_hours');
			$out[$k] = ($v === null || $v === '') ? $default : (float)$v;
		}
		return $out;
	}

	public function addAction($item, $action, $note, $until, $user_id, $username) {
		$this->install();
		$this->db->query("INSERT INTO `" . DB_PREFIX . "dpc_followup` SET
			`item` = '" . $this->db->escape($item) . "',
			`action` = '" . $this->db->escape($action) . "',
			`note` = '" . $this->db->escape(mb_substr($note, 0, 1000)) . "',
			`until` = " . ($until ? "'" . $this->db->escape($until) . "'" : 'NULL') . ",
			`user_id` = '" . (int)$user_id . "',
			`username` = '" . $this->db->escape($username) . "',
			`created` = NOW()");
	}

	public function getNotes($item, $limit = 20) {
		if (!$this->hasTable('dpc_followup')) {
			return array();
		}
		return $this->db->query("SELECT `action`, `note`, `until`, `username`, `created` FROM `" . DB_PREFIX . "dpc_followup` WHERE `item` = '" . $this->db->escape($item) . "' ORDER BY `created` DESC, `followup_id` DESC LIMIT " . (int)$limit)->rows;
	}

	// All open items. Each: key, kind, title, who, hint, since, limit_h, state (overdue|waiting|snoozed) ...
	public function getItems() {
		$now = time();
		$lang = (int)$this->cfg('config_language_id');
				$raw = array();

		// Orders in a followed-up status
		$hours = array();
		foreach ($this->statusHours() as $id => $s) {
			if ($s['hours'] > 0) {
				$hours[$id] = $s;
			}
		}
		if ($hours) {
			$rows = $this->db->query("SELECT o.order_id, o.order_status_id, o.firstname, o.lastname, o.email, o.total, o.currency_code, o.currency_value, o.date_added, o.shipping_method,
					(SELECT MAX(h.date_added) FROM `" . DB_PREFIX . "order_history` h WHERE h.order_id = o.order_id) AS last_h,
					(SELECT MAX(IFNULL(p.shipping, 1)) FROM `" . DB_PREFIX . "order_product` op LEFT JOIN `" . DB_PREFIX . "product` p ON p.product_id = op.product_id WHERE op.order_id = o.order_id) AS phys
				FROM `" . DB_PREFIX . "order` o
				WHERE o.order_status_id IN (" . implode(',', array_keys($hours)) . ")
				ORDER BY o.order_id DESC LIMIT 500")->rows;
			$pending = (int)$this->cfg('config_order_status_id');
			foreach ($rows as $r) {
				$sid = (int)$r['order_status_id'];
				$phys = (int)$r['phys'] === 1 || ($r['phys'] === null && $r['shipping_method'] !== '');
				$name = $hours[$sid]['name'];
				if ($sid === $pending || preg_match('/^pending/i', $name)) {
					$hint = 'Check the payment arrived, then set the order to Processing (or Canceled).';
				} elseif (preg_match('/^shipped/i', $name)) {
					$hint = 'Check the parcel arrived, then set the order to Complete.';
				} elseif ($phys) {
					$hint = 'Pack and ship it, then set the order to Shipped with the tracking number.';
				} else {
					$hint = 'Check the customer has the download or licence, then set the order to Complete.';
				}
				$raw[] = array(
					'key'    => 'order:' . (int)$r['order_id'],
					'kind'   => 'order',
					'tag'    => $phys ? 'ship' : 'dig',
					'title'  => 'Order #' . (int)$r['order_id'] . ' · ' . $name,
					'who'    => trim($r['firstname'] . ' ' . $r['lastname']) ?: $r['email'],
					'email'  => $r['email'],
					'amount' => $this->money($r['total'], $r['currency_code'], $r['currency_value']),
					'hint'   => $hint,
					'since'  => $r['last_h'] ?: $r['date_added'],
					'limit'  => $hours[$sid]['hours'],
					'link'   => $this->link('sale/order/info', 'order_id=' . (int)$r['order_id'])
				);
			}
		}

		$other = $this->otherHours();

		// Returns still in the shop's "new return" status
		if ($other['return'] > 0) {
			$rows = $this->db->query("SELECT r.return_id, r.order_id, r.firstname, r.lastname, r.email, r.product, r.date_added,
					(SELECT MAX(rh.date_added) FROM `" . DB_PREFIX . "return_history` rh WHERE rh.return_id = r.return_id) AS last_h
				FROM `" . DB_PREFIX . "return` r WHERE r.return_status_id = '" . (int)$this->cfg('config_return_status_id') . "' ORDER BY r.return_id DESC LIMIT 200")->rows;
			foreach ($rows as $r) {
				$raw[] = array(
					'key' => 'return:' . (int)$r['return_id'], 'kind' => 'return', 'tag' => null,
					'title' => 'Return #' . (int)$r['return_id'] . ' · ' . $r['product'],
					'who' => trim($r['firstname'] . ' ' . $r['lastname']) ?: $r['email'], 'email' => $r['email'], 'amount' => '',
					'hint' => 'Reply to the customer and move the return to its next status.',
					'since' => $r['last_h'] ?: $r['date_added'], 'limit' => $other['return'],
					'link' => $this->link('sale/return/edit', 'return_id=' . (int)$r['return_id'])
				);
			}
		}

		// Customer accounts waiting for approval
		if ($other['approval'] > 0) {
			$rows = $this->db->query("SELECT ca.customer_approval_id, ca.customer_id, ca.type, ca.date_added, c.firstname, c.lastname, c.email
				FROM `" . DB_PREFIX . "customer_approval` ca LEFT JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = ca.customer_id ORDER BY ca.date_added DESC LIMIT 200")->rows;
			foreach ($rows as $r) {
				$raw[] = array(
					'key' => 'approval:' . (int)$r['customer_approval_id'], 'kind' => 'approval', 'tag' => null,
					'title' => ($r['type'] === 'affiliate' ? 'Affiliate' : 'Customer account') . ' waiting for approval',
					'who' => trim($r['firstname'] . ' ' . $r['lastname']) ?: $r['email'], 'email' => $r['email'], 'amount' => '',
					'hint' => 'Approve or deny the account.',
					'since' => $r['date_added'], 'limit' => $other['approval'],
					'link' => $this->link('customer/customer_approval', 'filter_email=' . urlencode((string)$r['email']))
				);
			}
		}

		// Reviews waiting to be published
		if ($other['review'] > 0) {
			$rows = $this->db->query("SELECT r.review_id, r.author, r.date_added, pd.name FROM `" . DB_PREFIX . "review` r
				LEFT JOIN `" . DB_PREFIX . "product_description` pd ON pd.product_id = r.product_id AND pd.language_id = '" . $lang . "'
				WHERE r.status = 0 ORDER BY r.review_id DESC LIMIT 200")->rows;
			foreach ($rows as $r) {
				$raw[] = array(
					'key' => 'review:' . (int)$r['review_id'], 'kind' => 'review', 'tag' => null,
					'title' => 'Review of ' . $r['name'], 'who' => $r['author'], 'email' => '', 'amount' => '',
					'hint' => 'Publish the review or delete it.',
					'since' => $r['date_added'], 'limit' => $other['review'],
					'link' => $this->link('catalog/review/edit', 'review_id=' . (int)$r['review_id'])
				);
			}
		}

		// R&D Club: profiles and build updates waiting for review (tables from rnd.php)
		if ($other['rnd'] > 0 && $this->hasTable('dpc_rnd_member')) {
			$rnd = $this->catalog . 'rnd.php?f=admin';
			$rows = $this->db->query("SELECT m.customer_id, m.updated_at, m.invited_at, c.firstname, c.lastname, c.email FROM `" . DB_PREFIX . "dpc_rnd_member` m
				LEFT JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = m.customer_id WHERE m.pending = 1 AND m.status <> 'removed'")->rows;
			foreach ($rows as $r) {
				$raw[] = array(
					'key' => 'rndp:' . (int)$r['customer_id'], 'kind' => 'rnd', 'tag' => null,
					'title' => 'R&D Club profile to review', 'who' => trim($r['firstname'] . ' ' . $r['lastname']) ?: $r['email'], 'email' => $r['email'], 'amount' => '',
					'hint' => 'Approve the profile or reject it with a note.',
					'since' => $r['updated_at'] ?: $r['invited_at'], 'limit' => $other['rnd'], 'link' => $rnd
				);
			}
			if ($this->hasTable('dpc_rnd_update')) {
				$rows = $this->db->query("SELECT u.id, u.title, u.created, c.firstname, c.lastname, c.email FROM `" . DB_PREFIX . "dpc_rnd_update` u
					LEFT JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = u.customer_id WHERE u.status = 'pending'")->rows;
				foreach ($rows as $r) {
					$raw[] = array(
						'key' => 'rndu:' . (int)$r['id'], 'kind' => 'rnd', 'tag' => null,
						'title' => 'R&D build update: ' . $r['title'], 'who' => trim($r['firstname'] . ' ' . $r['lastname']) ?: $r['email'], 'email' => $r['email'], 'amount' => '',
						'hint' => 'Approve the update, give feedback or reject it with a note.',
						'since' => $r['created'], 'limit' => $other['rnd'], 'link' => $rnd
					);
				}
			}
		}

		// Emails waiting for a reply in the Inbox
		$inboxActive = false;
		if (is_file(DIR_SYSTEM . 'library/dpcinbox.php') && $this->hasTable('dpc_mail_thread')) {
			require_once(DIR_SYSTEM . 'library/dpcinbox.php');
			$inbox = new DpcInbox($this->db);
			$inboxActive = (bool)$this->db->query("SELECT 1 FROM `" . DB_PREFIX . "dpc_mail_account` WHERE `status` = 1 AND `password` IS NOT NULL AND `password` <> '' LIMIT 1")->num_rows;
			$rh = $this->cfg('module_dpc_inbox_reply_hours');
			$rh = ($rh === null || $rh === '') ? 24 : (float)$rh;
			if ($inboxActive && $rh > 0) {
				foreach ($inbox->waiting() as $t) {
					$raw[] = array(
						'key' => 'mail:' . (int)$t['thread_id'], 'kind' => 'mail', 'tag' => null,
						'title' => 'Email: ' . ($t['subject'] !== '' ? $t['subject'] : '(no subject)'),
						'who' => $t['contact_name'] ?: $t['contact_email'], 'email' => $t['contact_email'], 'amount' => '',
						'hint' => 'Reply in the Inbox, or mark it done there if it needs no reply.',
						'since' => $t['last_in'], 'limit' => $rh,
						'link' => $this->link('extension/module/dpc_inbox', 'thread_id=' . (int)$t['thread_id'])
					);
				}
			}
		}

		// Support tickets waiting for us (tables from the dpCREATOR support module)
		if ($other['ticket'] > 0 && $this->hasTable('dpc_ticket')) {
			$hasMsg = $this->hasTable('dpc_ticket_message');
			$rows = $this->db->query("SELECT t.ticket_id, t.name, t.email, t.subject, t.date_added, t.date_modified" . ($hasMsg ? ", (SELECT MAX(m.date_added) FROM `" . DB_PREFIX . "dpc_ticket_message` m WHERE m.ticket_id = t.ticket_id) AS last_msg" : ", NULL AS last_msg") . "
				FROM `" . DB_PREFIX . "dpc_ticket` t WHERE t.status = 'open' ORDER BY t.ticket_id DESC LIMIT 200")->rows;
			foreach ($rows as $r) {
				$raw[] = array(
					'key' => 'ticket:' . (int)$r['ticket_id'], 'kind' => 'ticket', 'tag' => null,
					'title' => 'Support ticket #' . (int)$r['ticket_id'] . ': ' . $r['subject'],
					'who' => $r['name'] ?: $r['email'], 'email' => $r['email'], 'amount' => '',
					'hint' => 'Answer the ticket in Support tickets.',
					'since' => $r['last_msg'] ?: ($r['date_modified'] ?: $r['date_added']), 'limit' => $other['ticket'],
					'link' => $this->link('extension/module/dpc_support', 'status=open')
				);
			}
		}

		// Contact form messages saved by Journal, while the Inbox is not reading the mailbox they go to
		if (!$inboxActive && $other['form'] > 0 && $this->hasTable('journal3_message') && $this->hasTable('dpc_followup')) {
			$since = $this->db->query("SELECT CREATE_TIME AS t FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $this->db->escape(DB_PREFIX . 'dpc_followup') . "'")->row;
			$since = $since && $since['t'] ? $since['t'] : date('Y-m-d H:i:s');
			$rows = $this->db->query("SELECT message_id, name, email, fields, date FROM `" . DB_PREFIX . "journal3_message` WHERE `date` >= '" . $this->db->escape($since) . "' ORDER BY message_id DESC LIMIT 100")->rows;
			foreach ($rows as $r) {
				$topic = '';
				$f = json_decode((string)$r['fields'], true);
				if (is_array($f)) {
					foreach ($f as $fld) {
						if (isset($fld['type']) && $fld['type'] === 'select' && is_string($fld['value'])) {
							$topic = $fld['value'];
						}
					}
				}
				$raw[] = array(
					'key' => 'form:' . (int)$r['message_id'], 'kind' => 'form', 'tag' => null,
					'title' => 'Contact form' . ($topic !== '' ? ': ' . $topic : ''),
					'who' => $r['name'] ?: $r['email'], 'email' => $r['email'], 'amount' => '',
					'hint' => 'Answer by email, then mark it done.',
					'since' => $r['date'], 'limit' => $other['form'],
					'link' => $this->link('journal3/journal3', '') . '#/message'
				);
			}
		}

		// Follow-up notes and snoozes
		$acts = array();
		if ($raw && $this->hasTable('dpc_followup')) {
			$keys = array();
			foreach ($raw as $it) {
				$keys[] = "'" . $this->db->escape($it['key']) . "'";
			}
			$rows = $this->db->query("SELECT `item`, `action`, `note`, `until`, `username`, `created` FROM `" . DB_PREFIX . "dpc_followup` WHERE `item` IN (" . implode(',', $keys) . ") ORDER BY `created` ASC, `followup_id` ASC")->rows;
			foreach ($rows as $r) {
				$acts[$r['item']][] = $r;
			}
		}

		$items = array('overdue' => array(), 'waiting' => array(), 'snoozed' => array());
		foreach ($raw as $it) {
			$clock = strtotime($it['since']);
			$it['note'] = null;
			$snooze = 0;
			foreach (isset($acts[$it['key']]) ? $acts[$it['key']] : array() as $a) {
				$t = strtotime($a['created']);
				if ($a['action'] === 'note') {
					$clock = max($clock, $t);
					$it['note'] = array('text' => $a['note'], 'by' => $a['username'], 'when' => $this->ago($now - $t));
				}
			}
			// Done: hidden until the item changes again
			$done = false;
			foreach (isset($acts[$it['key']]) ? $acts[$it['key']] : array() as $a) {
				if ($a['action'] === 'done' && strtotime($a['created']) >= strtotime($it['since'])) {
					$done = true;
				}
			}
			if ($done) {
				continue;
			}
			foreach (isset($acts[$it['key']]) ? $acts[$it['key']] : array() as $a) {
				// A snooze counts only if nothing changed on the item after it was set
				if ($a['action'] === 'snooze' && strtotime($a['created']) >= $clock - 1 && strtotime($a['until']) > $now) {
					$snooze = max($snooze, strtotime($a['until']));
				}
			}
			$elapsed = $now - $clock;
			$limit = (int)round($it['limit'] * 3600);
			$it['since_text'] = $this->ago($elapsed);
			$it['since_at'] = date('Y-m-d H:i', $clock);
			$it['late'] = $elapsed - $limit;
			if ($snooze) {
				$it['state'] = 'snoozed';
				$it['due_text'] = 'until ' . date('D j M H:i', $snooze);
				$it['sort'] = $snooze;
			} elseif ($elapsed >= $limit) {
				$it['state'] = 'overdue';
				$it['due_text'] = $this->ago($elapsed - $limit) . ' overdue';
				$it['sort'] = -$it['late'];
			} else {
				$it['state'] = 'waiting';
				$it['due_text'] = 'due in ' . $this->ago($limit - $elapsed);
				$it['sort'] = $limit - $elapsed;
			}
			unset($it['limit']);
			$items[$it['state']][] = $it;
		}
		foreach ($items as &$list) {
			usort($list, function ($a, $b) { return $a['sort'] <=> $b['sort']; });
		}
		unset($list);
		return $items;
	}

	public function ago($s) {
		$s = max(0, (int)$s);
		if ($s < 3600) {
			return max(1, (int)floor($s / 60)) . ' min';
		}
		if ($s < 48 * 3600) {
			return (int)floor($s / 3600) . ' h';
		}
		return (int)floor($s / 86400) . ' days';
	}

	// The daily email: subject, HTML and text. Returns null when nothing is overdue (unless $always).
	public static function digest($items, $store, $dashboard, $always = false) {
		$over = $items['overdue'];
		if (!$over && !$always) {
			return null;
		}
		$n = count($over);
		$w = count($items['waiting']);
		$subject = $n
			? ($n == 1 ? '1 customer is waiting too long' : $n . ' customers are waiting too long') . ' · ' . $store
			: 'Nobody is waiting too long · ' . $store;
		$e = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
		$html = '<div style="font-family:Arial,Helvetica,sans-serif;color:#1E2A35;max-width:640px">';
		$html .= '<h2 style="font-size:20px;margin:0 0 6px">' . $e($subject) . '</h2>';
		$html .= '<p style="margin:0 0 16px;color:#6B7885">' . ($n ? 'These need an answer today. Open each one, or add a follow-up note in admin saying what you did.' : 'Everything is answered.') . ($w ? ' ' . $w . ' more waiting, not overdue yet.' : '') . '</p>';
		$text = $subject . "\n\n";
		foreach ($over as $it) {
			$tag = $it['tag'] === 'ship' ? '<span style="background:#1F6FB8;color:#fff;font-size:11px;padding:1px 7px;border-radius:9px;margin-right:6px">Shipped goods</span>' : ($it['tag'] === 'dig' ? '<span style="background:#D9730D;color:#fff;font-size:11px;padding:1px 7px;border-radius:9px;margin-right:6px">Digital</span>' : '');
			$html .= '<div style="border:1px solid #E3E8ED;border-left:4px solid #C42B1C;border-radius:4px;padding:10px 14px;margin:0 0 8px">'
				. '<div style="font-weight:bold">' . $tag . '<a href="' . $e($it['link']) . '" style="color:#1E2A35">' . $e($it['title']) . '</a>'
				. '<span style="float:right;color:#C42B1C">' . $e($it['due_text']) . '</span></div>'
				. '<div style="color:#6B7885;font-size:13px">' . $e(implode('  ·  ', array_filter(array($it['who'], $it['email'] !== $it['who'] ? $it['email'] : '', $it['amount'])))) . ' · waiting ' . $e($it['since_text']) . '</div>'
				. '<div style="font-size:14px;margin-top:4px">' . $e($it['hint']) . '</div>'
				. ($it['note'] ? '<div style="font-size:13px;color:#6B7885;margin-top:4px">Last note (' . $e($it['note']['by']) . '): ' . $e($it['note']['text']) . '</div>' : '')
				. '</div>';
			$text .= '- ' . $it['title'] . ' (' . $it['due_text'] . ', waiting ' . $it['since_text'] . ")\n  " . $it['who'] . ' ' . $it['email'] . "\n  " . $it['hint'] . "\n  " . $it['link'] . "\n\n";
		}
		$html .= '<p style="margin:16px 0 0"><a href="' . $e($dashboard) . '" style="background:#1F6FB8;color:#fff;padding:10px 18px;border-radius:4px;text-decoration:none;display:inline-block">Open the follow-up list</a></p>';
		$html .= '<p style="color:#9AA5B1;font-size:12px;margin-top:18px">Sent once a day by the dpCREATOR follow-ups add-on. Turn it off or change the time in Extensions → Dashboard → dpCREATOR follow-ups.</p></div>';
		$text .= 'Follow-up list: ' . $dashboard . "\n";
		return array('subject' => $subject, 'html' => $html, 'text' => $text);
	}

	// Send with the shop's own mail settings. $cfg: function($key)
	public static function send($cfg, $to, $mailData) {
		if (!class_exists('Mail')) {
			require_once(DIR_SYSTEM . 'library/mail.php');
		}
		$engine = $cfg('config_mail_engine') ?: 'mail';
		if (!class_exists('Mail\\' . $engine) && is_file(DIR_SYSTEM . 'library/mail/' . $engine . '.php')) {
			require_once(DIR_SYSTEM . 'library/mail/' . $engine . '.php');
		}
		$store = html_entity_decode((string)$cfg('config_name'), ENT_QUOTES, 'UTF-8');
		$sent = 0;
		foreach (preg_split('/[\s,;]+/', (string)$to) as $addr) {
			if (!filter_var($addr, FILTER_VALIDATE_EMAIL)) {
				continue;
			}
			$mail = new Mail($engine);
			$mail->parameter = $cfg('config_mail_parameter');
			$mail->smtp_hostname = $cfg('config_mail_smtp_hostname');
			$mail->smtp_username = $cfg('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode((string)$cfg('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $cfg('config_mail_smtp_port');
			$mail->smtp_timeout = $cfg('config_mail_smtp_timeout');
			$mail->setTo($addr);
			$mail->setFrom($cfg('config_email'));
			$mail->setSender($store);
			$mail->setSubject($mailData['subject']);
			$mail->setHtml($mailData['html']);
			$mail->setText($mailData['text']);
			$mail->send();
			$sent++;
		}
		return $sent;
	}
}
