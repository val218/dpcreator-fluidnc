<?php
// dpCREATOR Inbox storage: mailboxes, conversations (threads) and messages kept in the shop
// database, synced from the mail server. Mail stays on the server; this is a copy for the admin.
require_once(__DIR__ . '/dpcmail.php');

class DpcInbox {
	private $db;
	private $p;
	public $errors = array();

	public function __construct($db) {
		$this->db = $db;
		$this->p = DB_PREFIX . 'dpc_mail_';
	}

	// The shop's database connection is utf8 (3-byte). Characters outside it (emoji in a subject or a name)
	// make MySQL refuse the query ("Illegal mix of collations"), so they are left out of what is sent.
	private static function bmp($s) {
		return preg_replace('/[\x{10000}-\x{10FFFF}]/u', '', (string)$s) ?? preg_replace('/[\xF0-\xF7][\x80-\xBF]{3}/', '', (string)$s);
	}
	private function e($s) {
		return $this->db->escape(self::bmp($s));
	}

	public function install() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->p . "account` (
			`account_id` INT(11) NOT NULL AUTO_INCREMENT,
			`email` VARCHAR(128) NOT NULL,
			`name` VARCHAR(128) NOT NULL DEFAULT '',
			`username` VARCHAR(128) NOT NULL DEFAULT '',
			`password` TEXT NULL,
			`imap_host` VARCHAR(128) NOT NULL DEFAULT '',
			`imap_port` INT(11) NOT NULL DEFAULT 993,
			`imap_secure` VARCHAR(4) NOT NULL DEFAULT 'ssl',
			`smtp_host` VARCHAR(128) NOT NULL DEFAULT '',
			`smtp_port` INT(11) NOT NULL DEFAULT 587,
			`smtp_secure` VARCHAR(4) NOT NULL DEFAULT 'tls',
			`verify_cert` TINYINT(1) NOT NULL DEFAULT 1,
			`signature` TEXT NULL,
			`status` TINYINT(1) NOT NULL DEFAULT 1,
			`sort_order` INT(11) NOT NULL DEFAULT 0,
			`uidvalidity` BIGINT NOT NULL DEFAULT 0,
			`last_uid` BIGINT NOT NULL DEFAULT 0,
			`sent_folder` VARCHAR(128) NOT NULL DEFAULT '',
			`sent_uidvalidity` BIGINT NOT NULL DEFAULT 0,
			`sent_last_uid` BIGINT NOT NULL DEFAULT 0,
			`last_sync` DATETIME NULL,
			`last_error` VARCHAR(500) NOT NULL DEFAULT '',
			PRIMARY KEY (`account_id`)
		) DEFAULT CHARSET=utf8mb4");
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->p . "thread` (
			`thread_id` INT(11) NOT NULL AUTO_INCREMENT,
			`account_id` INT(11) NOT NULL,
			`subject` VARCHAR(255) NOT NULL DEFAULT '',
			`norm_subject` VARCHAR(255) NOT NULL DEFAULT '',
			`contact_email` VARCHAR(128) NOT NULL DEFAULT '',
			`contact_name` VARCHAR(128) NOT NULL DEFAULT '',
			`customer_id` INT(11) NOT NULL DEFAULT 0,
			`order_id` INT(11) NOT NULL DEFAULT 0,
			`kind` VARCHAR(8) NOT NULL DEFAULT 'person',
			`state` VARCHAR(8) NOT NULL DEFAULT 'open',
			`last_in` DATETIME NULL,
			`last_out` DATETIME NULL,
			`last_date` DATETIME NULL,
			`snippet` VARCHAR(255) NOT NULL DEFAULT '',
			`messages` INT(11) NOT NULL DEFAULT 0,
			`unread` INT(11) NOT NULL DEFAULT 0,
			`attachments` INT(11) NOT NULL DEFAULT 0,
			`done_at` DATETIME NULL,
			PRIMARY KEY (`thread_id`),
			KEY `contact` (`account_id`, `contact_email`),
			KEY `state` (`state`, `last_date`)
		) DEFAULT CHARSET=utf8mb4");
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->p . "message` (
			`message_id` INT(11) NOT NULL AUTO_INCREMENT,
			`thread_id` INT(11) NOT NULL,
			`account_id` INT(11) NOT NULL,
			`folder` VARCHAR(8) NOT NULL DEFAULT 'inbox',
			`uid` BIGINT NOT NULL DEFAULT 0,
			`direction` VARCHAR(3) NOT NULL DEFAULT 'in',
			`msgid` VARCHAR(255) NOT NULL DEFAULT '',
			`in_reply_to` VARCHAR(255) NOT NULL DEFAULT '',
			`refs` TEXT NULL,
			`from_email` VARCHAR(128) NOT NULL DEFAULT '',
			`from_name` VARCHAR(128) NOT NULL DEFAULT '',
			`reply_to` VARCHAR(128) NOT NULL DEFAULT '',
			`to_list` TEXT NULL,
			`cc_list` TEXT NULL,
			`subject` VARCHAR(255) NOT NULL DEFAULT '',
			`date` DATETIME NOT NULL,
			`body_text` MEDIUMTEXT NULL,
			`body_html` MEDIUMTEXT NULL,
			`attachments` TEXT NULL,
			`seen` TINYINT(1) NOT NULL DEFAULT 0,
			`user` VARCHAR(64) NOT NULL DEFAULT '',
			PRIMARY KEY (`message_id`),
			KEY `thread` (`thread_id`, `date`),
			KEY `msgid` (`msgid`(100)),
			KEY `uid` (`account_id`, `folder`, `uid`)
		) DEFAULT CHARSET=utf8mb4");
		$this->migrate();
	}

	// Columns added after the first version (run once per request, from ready())
	private static $migrated = false;
	private function migrate() {
		if (self::$migrated) {
			return;
		}
		self::$migrated = true;
		// Deleting: a message moved to Trash (or another folder) on the server is hidden here, not removed
		if (!$this->db->query("SHOW COLUMNS FROM `" . $this->p . "message` LIKE 'trashed'")->num_rows) {
			$this->db->query("ALTER TABLE `" . $this->p . "message` ADD `trashed` TINYINT(1) NOT NULL DEFAULT 0");
		}
		if (!$this->db->query("SHOW COLUMNS FROM `" . $this->p . "thread` LIKE 'trashed'")->num_rows) {
			$this->db->query("ALTER TABLE `" . $this->p . "thread` ADD `trashed` TINYINT(1) NOT NULL DEFAULT 0");
		}
		if (!$this->db->query("SHOW COLUMNS FROM `" . $this->p . "account` LIKE 'trash_folder'")->num_rows) {
			$this->db->query("ALTER TABLE `" . $this->p . "account` ADD `trash_folder` VARCHAR(128) NOT NULL DEFAULT ''");
		}
		// Some MariaDB versions read a column added in place wrongly in full-table scans: rebuild once and set the value
		$k = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `code` = 'dpc_inbox_schema' AND `key` = 'dpc_inbox_schema' AND store_id = 0")->row;
		if (!$k || (int)$k['value'] < 2) {
			foreach (array('thread', 'message') as $t) {
				try {
					$this->db->query("ALTER TABLE `" . $this->p . $t . "` FORCE");
				} catch (\Exception $e) {
				}
				$this->db->query("UPDATE `" . $this->p . $t . "` SET `trashed` = 0");
			}
			$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'dpc_inbox_schema' AND `key` = 'dpc_inbox_schema' AND store_id = 0");
			$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = 0, `code` = 'dpc_inbox_schema', `key` = 'dpc_inbox_schema', `value` = '2', serialized = 0");
		}
	}

	public function ready() {
		$ok = (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e($this->p . 'thread') . "'")->num_rows;
		if ($ok) {
			$this->migrate();
		}
		return $ok;
	}

	// ---- passwords (kept encrypted in the database, never sent to the browser)

	private function key() {
		return hash('sha256', 'dpc-inbox|' . DB_PASSWORD . '|' . DB_DATABASE . '|' . DB_PREFIX, true);
	}

	public function encrypt($plain) {
		$iv = random_bytes(16);
		return base64_encode($iv . openssl_encrypt($plain, 'aes-256-cbc', $this->key(), OPENSSL_RAW_DATA, $iv));
	}

	public function decrypt($stored) {
		$raw = base64_decode((string)$stored);
		if (strlen($raw) < 17) {
			return '';
		}
		$out = openssl_decrypt(substr($raw, 16), 'aes-256-cbc', $this->key(), OPENSSL_RAW_DATA, substr($raw, 0, 16));
		return $out === false ? '' : $out;
	}

	// ---- accounts

	public function accounts($activeOnly = false) {
		if (!$this->ready()) {
			return array();
		}
		$rows = $this->db->query("SELECT * FROM `" . $this->p . "account`" . ($activeOnly ? " WHERE `status` = 1" : "") . " ORDER BY `sort_order`, `account_id`")->rows;
		foreach ($rows as &$r) {
			$r['has_password'] = $r['password'] !== null && $r['password'] !== '';
		}
		return $rows;
	}

	public function account($id) {
		$r = $this->db->query("SELECT * FROM `" . $this->p . "account` WHERE `account_id` = '" . (int)$id . "'")->row;
		return $r ?: null;
	}

	public function saveAccount($a) {
		$f = "`email` = '" . $this->e(strtolower(trim($a['email']))) . "',
			`name` = '" . $this->e($a['name']) . "',
			`username` = '" . $this->e(trim($a['username'])) . "',
			`imap_host` = '" . $this->e(trim($a['imap_host'])) . "',
			`imap_port` = '" . (int)$a['imap_port'] . "',
			`imap_secure` = '" . $this->e($a['imap_secure']) . "',
			`smtp_host` = '" . $this->e(trim($a['smtp_host'])) . "',
			`smtp_port` = '" . (int)$a['smtp_port'] . "',
			`smtp_secure` = '" . $this->e($a['smtp_secure']) . "',
			`verify_cert` = '" . (int)$a['verify_cert'] . "',
			`signature` = '" . $this->e($a['signature']) . "',
			`status` = '" . (int)$a['status'] . "',
			`sort_order` = '" . (int)$a['sort_order'] . "'";
		if (isset($a['password']) && $a['password'] !== '') {
			$f .= ", `password` = '" . $this->e($this->encrypt($a['password'])) . "'";
		}
		if (!empty($a['account_id'])) {
			$old = $this->account($a['account_id']);
			if ($old && ($old['email'] !== strtolower(trim($a['email'])) || $old['imap_host'] !== trim($a['imap_host']))) {
				$f .= ", `uidvalidity` = 0, `last_uid` = 0, `sent_folder` = '', `sent_uidvalidity` = 0, `sent_last_uid` = 0";
			}
			$this->db->query("UPDATE `" . $this->p . "account` SET " . $f . " WHERE `account_id` = '" . (int)$a['account_id'] . "'");
			return (int)$a['account_id'];
		}
		$this->db->query("INSERT INTO `" . $this->p . "account` SET " . $f);
		return (int)$this->db->getLastId();
	}

	private function imap($acc) {
		$im = new DpcImap();
		$im->connect($acc['imap_host'], $acc['imap_port'], $acc['imap_secure'], $acc['verify_cert']);
		$im->login($acc['username'] ?: $acc['email'], $this->decrypt($acc['password']));
		return $im;
	}

	public function testAccount($acc) {
		$out = array();
		try {
			$im = $this->imap($acc);
			$info = $im->select('INBOX');
			$sent = $im->sentFolder();
			$im->logout();
			$out[] = 'Reading: OK, ' . $info['exists'] . ' emails in the inbox' . ($sent ? ', sent folder "' . $sent . '"' : ', no sent folder found');
		} catch (\Exception $e) {
			$out[] = 'Reading: ' . $e->getMessage();
		}
		try {
			$s = new DpcSmtp();
			$s->test($acc['smtp_host'], $acc['smtp_port'], $acc['smtp_secure'], $acc['verify_cert'], $acc['username'] ?: $acc['email'], $this->decrypt($acc['password']));
			$out[] = 'Sending: OK';
		} catch (\Exception $e) {
			$out[] = 'Sending: ' . $e->getMessage();
		}
		return $out;
	}

	// ---- sync

	public function lastSync() {
		if (!$this->ready()) {
			return null;
		}
		$r = $this->db->query("SELECT MIN(`last_sync`) AS t FROM `" . $this->p . "account` WHERE `status` = 1 AND `password` IS NOT NULL AND `password` <> ''")->row;
		return $r ? $r['t'] : null;
	}

	// Sync all active mailboxes; stops after $budget seconds. Returns number of new messages.
	public function sync($budget = 20, $sinceDays = 60) {
		if (!$this->ready()) {
			return 0;
		}
		$start = microtime(true);
		$new = 0;
		$lock = DIR_STORAGE . 'dpc_inbox_sync.lock';
		$lf = @fopen($lock, 'c');
		if ($lf && !flock($lf, LOCK_EX | LOCK_NB)) {
			fclose($lf);
			return 0; // another sync is running
		}
		foreach ($this->accounts(true) as $acc) {
			if (!$acc['has_password'] || $acc['imap_host'] === '') {
				continue;
			}
			if (microtime(true) - $start > $budget) {
				break;
			}
			$err = '';
			try {
				$im = $this->imap($acc);
				$new += $this->syncFolder($im, $acc, 'inbox', 'INBOX', $start, $budget, $sinceDays);
				if (microtime(true) - $start < $budget) {
					$sent = $acc['sent_folder'];
					if ($sent === '') {
						$sent = $im->sentFolder();
						$this->db->query("UPDATE `" . $this->p . "account` SET `sent_folder` = '" . $this->e($sent) . "' WHERE `account_id` = '" . (int)$acc['account_id'] . "'");
						$acc['sent_folder'] = $sent;
					}
					if ($sent !== '') {
						$acc = $this->account($acc['account_id']) + array('has_password' => true);
						$new += $this->syncFolder($im, $acc, 'sent', $sent, $start, $budget, $sinceDays);
					}
				}
				$im->logout();
			} catch (\Exception $e) {
				$err = $e->getMessage();
				$this->errors[] = $acc['email'] . ': ' . $err;
			}
			$this->db->query("UPDATE `" . $this->p . "account` SET `last_sync` = NOW(), `last_error` = '" . $this->e(substr($err, 0, 500)) . "' WHERE `account_id` = '" . (int)$acc['account_id'] . "'");
		}
		if ($lf) {
			flock($lf, LOCK_UN);
			fclose($lf);
		}
		return $new;
	}

	private function syncFolder($im, $acc, $kind, $folder, $start, $budget, $sinceDays) {
		$info = $im->select($folder);
		$vCol = $kind === 'inbox' ? 'uidvalidity' : 'sent_uidvalidity';
		$uCol = $kind === 'inbox' ? 'last_uid' : 'sent_last_uid';
		$last = (int)$acc[$uCol];
		if ((int)$acc[$vCol] !== (int)$info['uidvalidity']) {
			$last = 0;
			$this->db->query("UPDATE `" . $this->p . "account` SET `" . $vCol . "` = '" . (int)$info['uidvalidity'] . "', `" . $uCol . "` = 0 WHERE `account_id` = '" . (int)$acc['account_id'] . "'");
		}
		if ($info['exists'] == 0) {
			return 0;
		}
		if ($last === 0) {
			$uids = $im->uidSearch('SINCE ' . date('j-M-Y', strtotime('-' . (int)$sinceDays . ' days')));
		} else {
			$uids = array_values(array_filter($im->uidSearch('UID ' . ($last + 1) . ':*'), function ($u) use ($last) { return $u > $last; }));
		}
		$new = 0;
		foreach (array_chunk($uids, 10) as $chunk) {
			if (microtime(true) - $start > $budget) {
				break;
			}
			$got = $im->fetch($chunk);
			ksort($got);
			foreach ($got as $uid => $m) {
				if ($this->store($acc, $kind, $uid, $m)) {
					$new++;
				}
				$this->db->query("UPDATE `" . $this->p . "account` SET `" . $uCol . "` = GREATEST(`" . $uCol . "`, " . (int)$uid . ") WHERE `account_id` = '" . (int)$acc['account_id'] . "'");
			}
		}
		return $new;
	}

	public static function normSubject($s) {
		$s = preg_replace('/^\s*((re|fw|fwd|aw|wg|sv|vs|ats|atb|odp|tr)(\[\d+\])?\s*:\s*)+/iu', '', (string)$s);
		$s = preg_replace('/\s+/u', ' ', trim(self::bmp($s)));
		return mb_strtolower(mb_substr($s, 0, 200));
	}

	private function own() {
		$own = array();
		foreach ($this->accounts() as $a) {
			$own[] = $a['email'];
			if ($a['username']) {
				$own[] = strtolower($a['username']);
			}
		}
		return $own;
	}

	// Store one fetched message; returns true if new
	private function store($acc, $kind, $uid, $m) {
		if ($m['raw'] === '') {
			return false;
		}
		$exists = $this->db->query("SELECT `message_id` FROM `" . $this->p . "message` WHERE `account_id` = '" . (int)$acc['account_id'] . "' AND `folder` = '" . $this->e($kind) . "' AND `uid` = '" . (int)$uid . "' LIMIT 1")->row;
		if ($exists) {
			return false;
		}
		$p = DpcMime::parse($m['raw']);
		$h = $p['headers'];
		$g = function ($n) use ($h) { return isset($h[$n][0]) ? $h[$n][0] : ''; };
		$msgid = ($ids = DpcMime::ids($g('message-id'))) ? $ids[0] : sha1($m['raw']) . '@local';
		// our own reply already stored when sent from the Inbox
		$dup = $this->db->query("SELECT `message_id`, `thread_id`, `uid`, `trashed` FROM `" . $this->p . "message` WHERE `account_id` = '" . (int)$acc['account_id'] . "' AND `msgid` = '" . $this->e($msgid) . "' LIMIT 1")->row;
		if ($dup) {
			if (!$dup['uid'] || $dup['trashed']) {
				// a reply sent from here gets its server copy, or a message moved back from Trash or a folder shows again
				$this->db->query("UPDATE `" . $this->p . "message` SET `uid` = '" . (int)$uid . "', `folder` = '" . $this->e($kind) . "', `trashed` = 0 WHERE `message_id` = '" . (int)$dup['message_id'] . "'");
				if ($dup['trashed']) {
					$this->refreshThread($dup['thread_id']);
				}
			}
			return false;
		}
		$from = DpcMime::addresses($g('from'));
		$from = $from ? $from[0] : array('name' => '', 'email' => '');
		$replyTo = DpcMime::addresses($g('reply-to'));
		$to = DpcMime::addresses(implode(', ', isset($h['to']) ? $h['to'] : array()));
		$cc = DpcMime::addresses(implode(', ', isset($h['cc']) ? $h['cc'] : array()));
		$subject = mb_substr(DpcMime::header($g('subject')), 0, 255);
		$ts = strtotime(preg_replace('/\s*\([^)]*\)\s*$/', '', $g('date')));
		if (!$ts || $ts > time() + 86400) {
			$ts = $m['date'] ? strtotime($m['date']) : time();
		}
		$date = date('Y-m-d H:i:s', $ts);
		$inReply = ($ids = DpcMime::ids($g('in-reply-to'))) ? $ids[0] : '';
		$refs = DpcMime::ids($g('references'));
		$own = $this->own();
		$fromOwn = in_array($from['email'], $own, true);
		$replyExternal = $replyTo && !in_array($replyTo[0]['email'], $own, true);
		// In the inbox, mail "from" our own address is either a contact form (customer in Reply-To)
		// or a shop notification such as a new-order alert
		$direction = ($kind === 'sent' || ($fromOwn && !$replyExternal && $kind !== 'inbox')) ? 'out' : 'in';
		$shopNotice = $kind === 'inbox' && $fromOwn && !$replyExternal;

		// who the conversation is with
		if ($direction === 'in') {
			$contact = $replyTo ? $replyTo[0] : $from;
			if (in_array($contact['email'], $own, true)) {
				$contact = $from; // e.g. contact form sent from our own address with the customer as reply-to missing
			}
		} else {
			$contact = array('name' => '', 'email' => '');
			foreach (array_merge($to, $cc) as $a) {
				if (!in_array($a['email'], $own, true)) {
					$contact = $a;
					break;
				}
			}
		}

		// automatic mail: newsletters, notifications, bounces, spam
		$auto = $shopNotice;
		$as = strtolower($g('auto-submitted'));
		if (($as !== '' && $as !== 'no') || in_array(strtolower($g('precedence')), array('bulk', 'list', 'junk'), true) || $g('list-unsubscribe') !== '' || $g('list-id') !== ''
			|| preg_match('/^(no-?reply|do-?not-?reply|mailer-daemon|postmaster|bounce|notifications?)[@+._-]/i', $from['email']) || stripos($g('x-spam-flag'), 'yes') !== false || preg_match('/^\s*\*{3}\s*SPAM/i', $subject)) {
			$auto = true;
		}

		// thread: by references, then by contact + subject
		$thread = 0;
		$look = array_filter(array_unique(array_merge($inReply ? array($inReply) : array(), $refs)));
		if ($look) {
			$in = implode(',', array_map(function ($x) { return "'" . $this->e($x) . "'"; }, $look));
			$r = $this->db->query("SELECT `thread_id` FROM `" . $this->p . "message` WHERE `account_id` = '" . (int)$acc['account_id'] . "' AND `msgid` IN (" . $in . ") ORDER BY `date` DESC LIMIT 1")->row;
			if ($r) {
				$thread = (int)$r['thread_id'];
			}
		}
		$norm = self::normSubject($subject);
		if (!$thread && $contact['email'] !== '') {
			$r = $this->db->query("SELECT `thread_id` FROM `" . $this->p . "thread` WHERE `account_id` = '" . (int)$acc['account_id'] . "' AND `contact_email` = '" . $this->e($contact['email']) . "' AND `norm_subject` = '" . $this->e($norm) . "' AND `last_date` > '" . $this->e(date('Y-m-d H:i:s', $ts - 120 * 86400)) . "' ORDER BY `last_date` DESC LIMIT 1")->row;
			if ($r) {
				$thread = (int)$r['thread_id'];
			}
		}
		if (!$thread) {
			if ($direction === 'out' && $kind === 'sent') {
				// a sent email that starts a new conversation (written in webmail or on a phone)
			}
			$customer = $this->db->query("SELECT `customer_id` FROM `" . DB_PREFIX . "customer` WHERE LOWER(`email`) = '" . $this->e($contact['email']) . "' LIMIT 1")->row;
			$order = 0;
			if (preg_match('/(?:order|pasūtījum|заказ|bestellung|commande)\D{0,12}#?\s*(\d{1,7})|#(\d{1,7})\b/iu', $subject . ' ' . mb_substr($p['text'], 0, 2000), $om)) {
				$oid = (int)($om[1] ?: $om[2]);
				$o = $this->db->query("SELECT `order_id` FROM `" . DB_PREFIX . "order` WHERE `order_id` = '" . $oid . "' AND `order_status_id` > 0 LIMIT 1")->row;
				if ($o) {
					$order = $oid;
				}
			}
			$this->db->query("INSERT INTO `" . $this->p . "thread` SET `account_id` = '" . (int)$acc['account_id'] . "', `subject` = '" . $this->e($subject) . "', `norm_subject` = '" . $this->e($norm) . "', `contact_email` = '" . $this->e($contact['email']) . "', `contact_name` = '" . $this->e(mb_substr($contact['name'], 0, 128)) . "', `customer_id` = '" . (int)($customer ? $customer['customer_id'] : 0) . "', `order_id` = '" . (int)$order . "', `kind` = '" . ($auto ? 'auto' : 'person') . "', `state` = '" . ($auto || $direction === 'out' ? 'done' : 'open') . "', `last_date` = '" . $this->e($date) . "'");
			$thread = (int)$this->db->getLastId();
		}

		// attachments to disk
		$atts = array();
		$dir = DIR_STORAGE . 'dpc_inbox/' . (int)$acc['account_id'] . '/' . $kind . '-' . (int)$uid . '/';
		foreach ($p['attachments'] as $i => $a) {
			if (strlen($a['data']) > 25 * 1024 * 1024) {
				$atts[] = array('name' => $a['name'], 'type' => $a['type'], 'size' => strlen($a['data']), 'file' => '', 'cid' => $a['cid'], 'inline' => $a['inline']);
				continue;
			}
			if (!is_dir($dir)) {
				@mkdir($dir, 0755, true);
				@file_put_contents(DIR_STORAGE . 'dpc_inbox/.htaccess', "Require all denied\nDeny from all\n");
			}
			$file = $i . '.bin';
			@file_put_contents($dir . $file, $a['data']);
			$atts[] = array('name' => mb_substr($a['name'], 0, 200), 'type' => $a['type'], 'size' => strlen($a['data']), 'file' => $kind . '-' . (int)$uid . '/' . $file, 'cid' => $a['cid'], 'inline' => $a['inline']);
		}
		$text = $p['text'];
		if ($text === '' && $p['html'] !== '') {
			$text = self::htmlToText($p['html']);
		}
		$this->db->query("INSERT INTO `" . $this->p . "message` SET `thread_id` = '" . $thread . "', `account_id` = '" . (int)$acc['account_id'] . "', `folder` = '" . $this->e($kind) . "', `uid` = '" . (int)$uid . "', `direction` = '" . $direction . "', `msgid` = '" . $this->e($msgid) . "', `in_reply_to` = '" . $this->e($inReply) . "', `refs` = '" . $this->e(implode(' ', array_slice($refs, -30))) . "', `from_email` = '" . $this->e($from['email']) . "', `from_name` = '" . $this->e(mb_substr($from['name'], 0, 128)) . "', `reply_to` = '" . $this->e($replyTo ? $replyTo[0]['email'] : '') . "', `to_list` = '" . $this->e(json_encode($to)) . "', `cc_list` = '" . $this->e(json_encode($cc)) . "', `subject` = '" . $this->e($subject) . "', `date` = '" . $this->e($date) . "', `body_text` = '" . $this->e($text) . "', `body_html` = '" . $this->e($p['html']) . "', `attachments` = '" . $this->e(json_encode($atts)) . "', `seen` = '" . ((in_array('\\Seen', $m['flags'], true) || $direction === 'out') ? 1 : 0) . "'");
		$this->refreshThread($thread, $direction === 'in' && !$auto);
		return true;
	}

	public static function htmlToText($html) {
		$t = preg_replace('#<(script|style|head)[^>]*>.*?</\1>#is', '', $html);
		$t = preg_replace('#<br\s*/?>#i', "\n", $t);
		$t = preg_replace('#</(p|div|tr|li|h[1-6]|blockquote)>#i', "\n", $t);
		$t = html_entity_decode(strip_tags($t), ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$t = preg_replace("/[ \t]+/", ' ', $t);
		return trim(preg_replace("/\n\s*\n\s*\n+/", "\n\n", $t));
	}

	public static function snippet($text) {
		$t = preg_replace('/\n>.*$/s', '', "\n" . $text);         // quoted part
		$t = preg_replace('/\n(On .{5,120} wrote:|-----Original Message-----).*$/s', '', $t);
		$t = trim(preg_replace('/\s+/u', ' ', $t));
		return mb_substr($t, 0, 200);
	}

	// Recalculate thread summary; $reopen: a new inbound email reopens a done conversation
	public function refreshThread($thread, $reopen = false) {
		$t = (int)$thread;
		$s = $this->db->query("SELECT COUNT(*) AS n, SUM(`seen` = 0) AS unread, MAX(IF(`direction` = 'in', `date`, NULL)) AS last_in, MAX(IF(`direction` = 'out', `date`, NULL)) AS last_out, MAX(`date`) AS last_date, SUM(`attachments` <> '[]' AND `attachments` IS NOT NULL) AS att FROM `" . $this->p . "message` WHERE `thread_id` = '" . $t . "' AND `trashed` = 0")->row;
		if (!(int)$s['n']) {
			// every message of the conversation was deleted: the conversation is hidden
			$this->db->query("UPDATE `" . $this->p . "thread` SET `trashed` = 1, `messages` = 0, `unread` = 0 WHERE `thread_id` = '" . $t . "'");
			return;
		}
		$last = $this->db->query("SELECT `body_text`, `subject` FROM `" . $this->p . "message` WHERE `thread_id` = '" . $t . "' AND `trashed` = 0 ORDER BY `date` DESC, `message_id` DESC LIMIT 1")->row;
		$this->db->query("UPDATE `" . $this->p . "thread` SET `messages` = '" . (int)$s['n'] . "', `unread` = '" . (int)$s['unread'] . "', `last_in` = " . ($s['last_in'] ? "'" . $this->e($s['last_in']) . "'" : 'NULL') . ", `last_out` = " . ($s['last_out'] ? "'" . $this->e($s['last_out']) . "'" : 'NULL') . ", `last_date` = '" . $this->e($s['last_date']) . "', `attachments` = '" . (int)$s['att'] . "', `snippet` = '" . $this->e($last ? self::snippet($last['body_text']) : '') . "', `trashed` = 0" . ($reopen ? ", `state` = 'open', `done_at` = NULL" : '') . " WHERE `thread_id` = '" . $t . "'");
	}

	// ---- reading

	// $filter: reply | all | done | auto
	public function threads($filter, $account = 0, $search = '', $page = 1, $limit = 40) {
		if (!$this->ready()) {
			return array('items' => array(), 'total' => 0);
		}
		$w = array("t.`trashed` = 0");
		if ($filter === 'reply') {
			$w[] = "t.`kind` = 'person' AND t.`state` = 'open' AND t.`last_in` IS NOT NULL AND (t.`last_out` IS NULL OR t.`last_out` < t.`last_in`)";
		} elseif ($filter === 'done') {
			$w[] = "t.`kind` = 'person' AND (t.`state` = 'done' OR (t.`last_out` IS NOT NULL AND t.`last_out` >= IFNULL(t.`last_in`, '1970-01-01')))";
		} elseif ($filter === 'auto') {
			$w[] = "t.`kind` = 'auto'";
		} else {
			$w[] = "t.`kind` = 'person'";
		}
		if ($account) {
			$w[] = "t.`account_id` = '" . (int)$account . "'";
		}
		if ($search !== '') {
			$s = $this->e('%' . str_replace(array('%', '_'), array('\\%', '\\_'), $search) . '%');
			$w[] = "(t.`subject` LIKE '" . $s . "' OR t.`contact_email` LIKE '" . $s . "' OR t.`contact_name` LIKE '" . $s . "' OR t.`thread_id` IN (SELECT `thread_id` FROM `" . $this->p . "message` WHERE `body_text` LIKE '" . $s . "'))";
		}
		$where = implode(' AND ', $w);
		$total = (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . $this->p . "thread` t WHERE " . $where)->row['n'];
		$rows = $this->db->query("SELECT t.*, a.`email` AS account_email, a.`name` AS account_name FROM `" . $this->p . "thread` t LEFT JOIN `" . $this->p . "account` a ON a.`account_id` = t.`account_id` WHERE " . $where . " ORDER BY t.`last_date` DESC LIMIT " . (max(1, (int)$page) - 1) * $limit . ", " . (int)$limit)->rows;
		foreach ($rows as &$r) {
			$r['needs_reply'] = $r['kind'] === 'person' && $r['state'] === 'open' && $r['last_in'] && (!$r['last_out'] || $r['last_out'] < $r['last_in']);
		}
		return array('items' => $rows, 'total' => $total);
	}

	public function counts() {
		if (!$this->ready()) {
			return array('reply' => 0, 'unread' => 0);
		}
		$r = $this->db->query("SELECT SUM(`kind` = 'person' AND `state` = 'open' AND `last_in` IS NOT NULL AND (`last_out` IS NULL OR `last_out` < `last_in`)) AS reply, SUM(`kind` = 'person' AND `unread` > 0) AS unread FROM `" . $this->p . "thread` WHERE `trashed` = 0")->row;
		return array('reply' => (int)$r['reply'], 'unread' => (int)$r['unread']);
	}

	// Conversations waiting for a reply (for follow-ups)
	public function waiting() {
		if (!$this->ready()) {
			return array();
		}
		return $this->db->query("SELECT t.*, a.`email` AS account_email FROM `" . $this->p . "thread` t LEFT JOIN `" . $this->p . "account` a ON a.`account_id` = t.`account_id` WHERE t.`trashed` = 0 AND t.`kind` = 'person' AND t.`state` = 'open' AND t.`last_in` IS NOT NULL AND (t.`last_out` IS NULL OR t.`last_out` < t.`last_in`) ORDER BY t.`last_in` LIMIT 300")->rows;
	}

	public function thread($id) {
		$t = $this->db->query("SELECT t.*, a.`email` AS account_email, a.`name` AS account_name FROM `" . $this->p . "thread` t LEFT JOIN `" . $this->p . "account` a ON a.`account_id` = t.`account_id` WHERE t.`thread_id` = '" . (int)$id . "'")->row;
		if (!$t) {
			return null;
		}
		$t['messages'] = $this->db->query("SELECT * FROM `" . $this->p . "message` WHERE `thread_id` = '" . (int)$id . "' AND `trashed` = 0 ORDER BY `date` ASC, `message_id` ASC")->rows;
		foreach ($t['messages'] as &$m) {
			$m['to_list'] = json_decode((string)$m['to_list'], true) ?: array();
			$m['cc_list'] = json_decode((string)$m['cc_list'], true) ?: array();
			$m['attachments'] = json_decode((string)$m['attachments'], true) ?: array();
		}
		return $t;
	}

	public function markRead($thread) {
		$unseen = $this->db->query("SELECT `message_id`, `account_id`, `uid` FROM `" . $this->p . "message` WHERE `thread_id` = '" . (int)$thread . "' AND `seen` = 0 AND `folder` = 'inbox'")->rows;
		if (!$unseen) {
			return;
		}
		$this->db->query("UPDATE `" . $this->p . "message` SET `seen` = 1 WHERE `thread_id` = '" . (int)$thread . "'");
		$this->db->query("UPDATE `" . $this->p . "thread` SET `unread` = 0 WHERE `thread_id` = '" . (int)$thread . "'");
		// mark them read on the server too, so the phone and webmail agree
		$by = array();
		foreach ($unseen as $u) {
			if ($u['uid']) {
				$by[$u['account_id']][] = (int)$u['uid'];
			}
		}
		foreach ($by as $aid => $uids) {
			try {
				$acc = $this->account($aid);
				$im = $this->imap($acc);
				$im->select('INBOX');
				foreach ($uids as $uid) {
					$im->addFlag($uid, '\\Seen');
				}
				$im->logout();
			} catch (\Exception $e) {
				// not important enough to bother the admin
			}
		}
	}

	public function setState($thread, $state) {
		$this->db->query("UPDATE `" . $this->p . "thread` SET `state` = '" . ($state === 'done' ? 'done' : 'open') . "', `done_at` = " . ($state === 'done' ? 'NOW()' : 'NULL') . " WHERE `thread_id` = '" . (int)$thread . "'");
	}

	public function setKind($thread, $kind) {
		$this->db->query("UPDATE `" . $this->p . "thread` SET `kind` = '" . ($kind === 'auto' ? 'auto' : 'person') . "' WHERE `thread_id` = '" . (int)$thread . "'");
	}

	public function attachment($messageId, $index) {
		$m = $this->db->query("SELECT `account_id`, `attachments` FROM `" . $this->p . "message` WHERE `message_id` = '" . (int)$messageId . "'")->row;
		if (!$m) {
			return null;
		}
		$atts = json_decode((string)$m['attachments'], true) ?: array();
		if (!isset($atts[$index]) || $atts[$index]['file'] === '') {
			return null;
		}
		$a = $atts[$index];
		$path = DIR_STORAGE . 'dpc_inbox/' . (int)$m['account_id'] . '/' . $a['file'];
		if (strpos($a['file'], '..') !== false || !is_file($path)) {
			return null;
		}
		$a['path'] = $path;
		return $a;
	}

	// ---- deleting and moving (the server is changed first; then the copy here is hidden)

	// The mailbox's Trash folder; created if the server has none
	private function trashFolder($im, $acc) {
		$t = isset($acc['trash_folder']) ? $acc['trash_folder'] : '';
		if ($t === '') {
			$t = $im->specialFolder('Trash');
			if ($t === '') {
				$t = 'Trash';
				try {
					$im->create($t);
				} catch (\Exception $e) {
				}
			}
			$this->db->query("UPDATE `" . $this->p . "account` SET `trash_folder` = '" . $this->e($t) . "' WHERE `account_id` = '" . (int)$acc['account_id'] . "'");
		}
		return $t;
	}

	// Server folder of a stored message: the Inbox or the Sent folder
	private function serverFolder($im, $acc, $kind) {
		if ($kind !== 'sent') {
			return 'INBOX';
		}
		return $acc['sent_folder'] !== '' ? $acc['sent_folder'] : $im->sentFolder();
	}

	// Moves stored messages to Trash (dest '') or another server folder, then hides them here
	public function moveMessages(array $messageIds, $dest = '') {
		$ids = array_filter(array_map('intval', $messageIds));
		if (!$ids) {
			return 0;
		}
		$rows = $this->db->query("SELECT `message_id`, `thread_id`, `account_id`, `folder`, `uid`, `msgid` FROM `" . $this->p . "message` WHERE `message_id` IN (" . implode(',', $ids) . ") AND `trashed` = 0")->rows;
		$by = array();
		foreach ($rows as $r) {
			$by[$r['account_id']][$r['folder']][] = $r;
		}
		$threads = array();
		$moved = 0;
		foreach ($by as $aid => $folders) {
			$acc = $this->account($aid);
			if (!$acc || !$acc['password']) {
				throw new DpcMailError('The mailbox of this email is not connected.');
			}
			$im = $this->imap($acc);
			$target = $dest === '' ? $this->trashFolder($im, $acc) : $dest;
			foreach ($folders as $kind => $list) {
				$folder = $this->serverFolder($im, $acc, $kind);
				$uids = array();
				if ($folder !== '') {
					$im->select($folder);
					foreach ($list as $r) {
						$uid = (int)$r['uid'];
						if (!$uid && $r['msgid'] !== '' && substr($r['msgid'], -6) !== '@local') {
							// sent from here before the Sent folder was synced: find it by Message-ID
							$found = $im->uidSearch('HEADER Message-ID ' . $im->quote('<' . $r['msgid'] . '>'));
							$uid = $found ? (int)end($found) : 0;
						}
						if ($uid) {
							$uids[] = $uid;
						}
					}
					if ($uids && $folder !== $target) {
						$im->move($uids, $target);
					}
				}
				foreach ($list as $r) {
					$this->db->query("UPDATE `" . $this->p . "message` SET `trashed` = 1 WHERE `message_id` = '" . (int)$r['message_id'] . "'");
					$threads[$r['thread_id']] = true;
					$moved++;
				}
			}
			$im->logout();
		}
		foreach (array_keys($threads) as $t) {
			$this->refreshThread($t);
		}
		return $moved;
	}

	public function moveThreads(array $threadIds, $dest = '') {
		$ids = array_filter(array_map('intval', $threadIds));
		if (!$ids) {
			return 0;
		}
		$m = array();
		foreach ($this->db->query("SELECT `message_id` FROM `" . $this->p . "message` WHERE `thread_id` IN (" . implode(',', $ids) . ") AND `trashed` = 0")->rows as $r) {
			$m[] = (int)$r['message_id'];
		}
		return $this->moveMessages($m, $dest);
	}

	// ---- server folders, read live from the mail server

	public static function folderLabel($name) {
		$n = $name;
		if (function_exists('mb_convert_encoding') && strpos($n, '&') !== false) {
			$d = @mb_convert_encoding($n, 'UTF-8', 'UTF7-IMAP');
			if ($d !== false && $d !== '') {
				$n = $d;
			}
		}
		$n = preg_replace('/^INBOX[.\/]/i', '', $n);
		return strtoupper($n) === 'INBOX' ? 'Inbox' : $n;
	}

	public function folderList($accountId) {
		$acc = $this->account($accountId);
		if (!$acc || !$acc['password']) {
			throw new DpcMailError('This mailbox is not connected.');
		}
		$im = $this->imap($acc);
		$all = $im->folders();
		$special = array('INBOX' => 'inbox', $this->trashFolder($im, $acc) => 'trash');
		foreach (array('Junk' => 'junk', 'Archive' => 'archive', 'Sent' => 'sent', 'Drafts' => 'drafts') as $use => $k) {
			$f = $use === 'Sent' ? ($acc['sent_folder'] ?: $im->sentFolder()) : $im->specialFolder($use);
			if ($f !== '' && !isset($special[$f])) {
				$special[$f] = $k;
			}
		}
		$all = $im->folders();
		$order = array('inbox' => 0, 'drafts' => 1, 'sent' => 2, 'archive' => 3, 'junk' => 4, 'trash' => 5);
		$out = array();
		foreach ($all as $name => $attr) {
			if (stripos($attr, '\\Noselect') !== false || stripos($attr, '\\NonExistent') !== false) {
				continue;
			}
			$st = array('messages' => 0, 'unseen' => 0);
			try {
				$st = $im->status($name);
			} catch (\Exception $e) {
			}
			$k = isset($special[$name]) ? $special[$name] : '';
			$out[] = array('name' => $name, 'label' => $k === 'inbox' ? 'Inbox' : ($k === 'trash' ? 'Trash' : ($k === 'junk' ? 'Spam' : self::folderLabel($name))), 'use' => $k, 'messages' => $st['messages'], 'unseen' => $st['unseen'], 'sort' => isset($order[$k]) ? $order[$k] : 10);
		}
		$im->logout();
		usort($out, function ($a, $b) { return $a['sort'] - $b['sort'] ?: strcasecmp($a['label'], $b['label']); });
		return $out;
	}

	public function folderPage($accountId, $folder, $page = 1, $limit = 50, $search = '') {
		$acc = $this->account($accountId);
		if (!$acc || !$acc['password']) {
			throw new DpcMailError('This mailbox is not connected.');
		}
		$im = $this->imap($acc);
		$info = $im->select($folder);
		$uids = array();
		if ($info['exists'] > 0) {
			$q = trim((string)$search);
			$uids = $q === '' ? $im->uidSearch('ALL') : $im->uidSearch('CHARSET UTF-8 TEXT ' . $im->quote(self::bmp($q)));
		}
		rsort($uids);
		$total = count($uids);
		$pageUids = array_slice($uids, (max(1, (int)$page) - 1) * $limit, $limit);
		$items = array();
		foreach ($im->fetchHeaders($pageUids) as $uid => $m) {
			list($h) = DpcMime::split($m['head']);
			$g = function ($n) use ($h) { return isset($h[$n][0]) ? $h[$n][0] : ''; };
			$from = DpcMime::addresses($g('from'));
			$to = DpcMime::addresses(implode(', ', isset($h['to']) ? $h['to'] : array()));
			$ts = strtotime(preg_replace('/\s*\([^)]*\)\s*$/', '', $g('date'))) ?: strtotime($m['date']);
			$items[] = array('uid' => $uid, 'from' => $from ? $from[0] : array('name' => '', 'email' => ''), 'to' => $to, 'subject' => DpcMime::header($g('subject')), 'date' => $ts ? date('Y-m-d H:i:s', $ts) : '',
				'seen' => in_array('\\Seen', $m['flags'], true), 'size' => $m['size'], 'attachments' => stripos($g('content-type'), 'multipart/mixed') !== false);
		}
		$im->logout();
		usort($items, function ($a, $b) { return $b['uid'] - $a['uid']; });
		return array('items' => $items, 'total' => $total);
	}

	// One message from a server folder: parsed, marked as read on the server
	public function folderMessage($accountId, $folder, $uid) {
		$acc = $this->account($accountId);
		if (!$acc || !$acc['password']) {
			throw new DpcMailError('This mailbox is not connected.');
		}
		$im = $this->imap($acc);
		$im->select($folder);
		$got = $im->fetch(array((int)$uid));
		if (empty($got[(int)$uid]['raw'])) {
			$im->logout();
			throw new DpcMailError('This email is no longer in the folder.');
		}
		$m = $got[(int)$uid];
		if (!in_array('\\Seen', $m['flags'], true)) {
			try {
				$im->addFlag((int)$uid, '\\Seen');
			} catch (\Exception $e) {
			}
		}
		$im->logout();
		$p = DpcMime::parse($m['raw']);
		$h = $p['headers'];
		$g = function ($n) use ($h) { return isset($h[$n][0]) ? $h[$n][0] : ''; };
		$from = DpcMime::addresses($g('from'));
		$replyTo = DpcMime::addresses($g('reply-to'));
		$ts = strtotime(preg_replace('/\s*\([^)]*\)\s*$/', '', $g('date'))) ?: time();
		$text = $p['text'] !== '' ? $p['text'] : ($p['html'] !== '' ? self::htmlToText($p['html']) : '');
		return array('uid' => (int)$uid, 'from' => $from ? $from[0] : array('name' => '', 'email' => ''), 'reply_to' => $replyTo ? $replyTo[0]['email'] : '',
			'to' => DpcMime::addresses(implode(', ', isset($h['to']) ? $h['to'] : array())), 'cc' => DpcMime::addresses(implode(', ', isset($h['cc']) ? $h['cc'] : array())),
			'subject' => DpcMime::header($g('subject')), 'date' => date('Y-m-d H:i:s', $ts), 'text' => $text, 'html' => $p['html'], 'attachments' => $p['attachments'],
			'msgid' => ($ids = DpcMime::ids($g('message-id'))) ? $ids[0] : '');
	}

	// Move (dest = folder name) or delete (dest = '') messages of a server folder. Deleting in Trash removes them for good.
	public function folderMove($accountId, $folder, array $uids, $dest = '') {
		$acc = $this->account($accountId);
		if (!$acc || !$acc['password']) {
			throw new DpcMailError('This mailbox is not connected.');
		}
		$uids = array_values(array_filter(array_map('intval', $uids)));
		if (!$uids) {
			return array('moved' => 0, 'forever' => false);
		}
		$im = $this->imap($acc);
		$trash = $this->trashFolder($im, $acc);
		$im->select($folder);
		$forever = $dest === '' && $folder === $trash;
		if ($forever) {
			$im->expunge($uids);
		} elseif ($dest === 'RESTORE') {
			// back where they came from: our own emails to Sent, the rest to the Inbox
			$sent = $acc['sent_folder'] !== '' ? $acc['sent_folder'] : $im->sentFolder();
			$own = $this->own();
			$toSent = array();
			$toInbox = array();
			foreach ($im->fetchHeaders($uids) as $uid => $m) {
				list($h) = DpcMime::split($m['head']);
				$from = DpcMime::addresses(isset($h['from'][0]) ? $h['from'][0] : '');
				if ($sent !== '' && $from && in_array($from[0]['email'], $own, true)) {
					$toSent[] = $uid;
				} else {
					$toInbox[] = $uid;
				}
			}
			$im->move($toSent, $sent);
			$im->move($toInbox, 'INBOX');
		} else {
			$im->move($uids, $dest === '' ? $trash : $dest);
		}
		$im->logout();
		// Messages taken out of the Inbox or Sent here are hidden in the conversations too
		$sent = $acc['sent_folder'];
		$kind = strtoupper($folder) === 'INBOX' ? 'inbox' : ($sent !== '' && $folder === $sent ? 'sent' : '');
		if ($kind !== '' && !($dest !== '' && ($dest === 'INBOX' || $dest === $sent || $dest === 'RESTORE'))) {
			$rows = $this->db->query("SELECT `message_id`, `thread_id` FROM `" . $this->p . "message` WHERE `account_id` = '" . (int)$acc['account_id'] . "' AND `folder` = '" . $kind . "' AND `uid` IN (" . implode(',', $uids) . ")")->rows;
			foreach ($rows as $r) {
				$this->db->query("UPDATE `" . $this->p . "message` SET `trashed` = 1 WHERE `message_id` = '" . (int)$r['message_id'] . "'");
				$this->refreshThread($r['thread_id']);
			}
		}
		return array('moved' => count($uids), 'forever' => $forever);
	}

	public function emptyTrash($accountId) {
		$acc = $this->account($accountId);
		if (!$acc || !$acc['password']) {
			throw new DpcMailError('This mailbox is not connected.');
		}
		$im = $this->imap($acc);
		$trash = $this->trashFolder($im, $acc);
		$info = $im->select($trash);
		$n = 0;
		if ($info['exists'] > 0) {
			$uids = $im->uidSearch('ALL');
			$n = count($uids);
			foreach (array_chunk($uids, 500) as $chunk) {
				$im->expunge($chunk);
			}
		}
		$im->logout();
		return $n;
	}

	// Attachments of a message being forwarded: array('message_id' => n) or array('account_id', 'folder', 'uid')
	private function forwardAttachments($f) {
		$out = array();
		if (!empty($f['message_id'])) {
			$m = $this->db->query("SELECT `attachments` FROM `" . $this->p . "message` WHERE `message_id` = '" . (int)$f['message_id'] . "'")->row;
			foreach ($m ? (json_decode((string)$m['attachments'], true) ?: array()) : array() as $i => $a) {
				if ($a['inline'] && $a['cid'] !== '') {
					continue;
				}
				$x = $this->attachment($f['message_id'], $i);
				if ($x) {
					$out[] = array('name' => $a['name'], 'type' => $a['type'], 'data' => file_get_contents($x['path']));
				}
			}
		} elseif (!empty($f['uid'])) {
			$m = $this->folderMessage($f['account_id'], $f['folder'], $f['uid']);
			foreach ($m['attachments'] as $a) {
				if (!($a['inline'] && $a['cid'] !== '')) {
					$out[] = array('name' => $a['name'], 'type' => $a['type'], 'data' => $a['data']);
				}
			}
		}
		return $out;
	}

	// ---- sending

	// $o: account_id, thread_id (0 = new), to, cc (strings), subject, text, attachments (name,type,data), user
	public function send($o) {
		$acc = $this->account($o['account_id']);
		if (!$acc || !$acc['password']) {
			throw new DpcMailError('This mailbox is not set up yet. Add its password in the Inbox settings.');
		}
		$to = DpcMime::addresses($o['to']);
		$cc = DpcMime::addresses($o['cc']);
		$bcc = DpcMime::addresses(isset($o['bcc']) ? $o['bcc'] : '');
		if (!$to) {
			throw new DpcMailError('Add the address to send to.');
		}
		if (trim($o['text']) === '') {
			throw new DpcMailError('Write the message first.');
		}
		// Forwarding: the original message's attachments go with it
		if (!empty($o['forward'])) {
			$o['attachments'] = array_merge($this->forwardAttachments($o['forward']), isset($o['attachments']) ? $o['attachments'] : array());
			$size = 0;
			foreach ($o['attachments'] as $a) {
				$size += strlen($a['data']);
			}
			if ($size > 20 * 1024 * 1024) {
				throw new DpcMailError('The attachments are more than 20 MB together. Leave some out.');
			}
		}
		$thread = !empty($o['thread_id']) ? $this->thread($o['thread_id']) : null;
		$inReply = '';
		$refs = array();
		$quoteText = '';
		$quoteHtml = '';
		if ($thread && $thread['messages']) {
			$lastIn = null;
			foreach ($thread['messages'] as $m) {
				if ($m['msgid'] && substr($m['msgid'], -6) !== '@local') {
					$refs[] = $m['msgid'];
				}
				$lastIn = $m;
			}
			if ($lastIn) {
				$inReply = $lastIn['msgid'];
				$who = $lastIn['from_name'] ?: $lastIn['from_email'];
				$when = date('j M Y, H:i', strtotime($lastIn['date']));
				$body = rtrim($lastIn['body_text']);
				$quoteText = "\n\nOn " . $when . ', ' . $who . " wrote:\n> " . str_replace("\n", "\n> ", $body);
				$quoteHtml = '<p style="color:#6B7885;margin:18px 0 6px">On ' . htmlspecialchars($when) . ', ' . htmlspecialchars($who) . ' wrote:</p><blockquote style="margin:0;padding-left:12px;border-left:3px solid #D5DCE3;color:#4A5763">' . nl2br(htmlspecialchars($body)) . '</blockquote>';
			}
		}
		$text = rtrim($o['text']);
		$sig = trim((string)$acc['signature']);
		$textAll = $text . ($sig !== '' ? "\n\n-- \n" . $sig : '') . $quoteText;
		$html = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.5;color:#1E2A35">'
			. nl2br(htmlspecialchars($text))
			. ($sig !== '' ? '<p style="color:#6B7885;margin-top:16px">' . nl2br(htmlspecialchars($sig)) . '</p>' : '')
			. $quoteHtml . '</div>';
		$domain = substr(strrchr($acc['email'], '@'), 1) ?: 'localhost';
		list($raw, $id) = DpcMime::build(array(
			'from' => $acc['email'], 'from_name' => $acc['name'], 'to' => $to, 'cc' => $cc,
			'subject' => $o['subject'], 'text' => $textAll, 'html' => $html,
			'in_reply_to' => $inReply, 'references' => $refs,
			'attachments' => isset($o['attachments']) ? $o['attachments'] : array(), 'domain' => $domain
		));
		$rcpts = array();
		foreach (array_merge($to, $cc, $bcc) as $a) {
			$rcpts[] = $a['email'];
		}
		$smtp = new DpcSmtp();
		$smtp->send($acc['smtp_host'], $acc['smtp_port'], $acc['smtp_secure'], $acc['verify_cert'], $acc['username'] ?: $acc['email'], $this->decrypt($acc['password']), $acc['email'], array_unique($rcpts), $raw);

		// keep a copy in the mailbox's Sent folder, so the phone and webmail show the reply too
		$savedSent = false;
		try {
			$im = $this->imap($acc);
			$sent = $acc['sent_folder'] ?: $im->sentFolder();
			if ($sent !== '') {
				$im->append($sent, $raw);
				$savedSent = true;
			}
			$im->logout();
		} catch (\Exception $e) {
		}

		// store it now; the Sent sync recognises it by Message-ID later
		if (!$thread) {
			$contact = $to[0];
			$customer = $this->db->query("SELECT `customer_id` FROM `" . DB_PREFIX . "customer` WHERE LOWER(`email`) = '" . $this->e($contact['email']) . "' LIMIT 1")->row;
			$this->db->query("INSERT INTO `" . $this->p . "thread` SET `account_id` = '" . (int)$acc['account_id'] . "', `subject` = '" . $this->e(mb_substr($o['subject'], 0, 255)) . "', `norm_subject` = '" . $this->e(self::normSubject($o['subject'])) . "', `contact_email` = '" . $this->e($contact['email']) . "', `contact_name` = '" . $this->e(isset($o['contact_name']) ? $o['contact_name'] : $contact['name']) . "', `customer_id` = '" . (int)($customer ? $customer['customer_id'] : 0) . "', `order_id` = '" . (int)(isset($o['order_id']) ? $o['order_id'] : 0) . "', `kind` = 'person', `state` = 'open', `last_date` = NOW()");
			$tid = (int)$this->db->getLastId();
		} else {
			$tid = (int)$thread['thread_id'];
		}
		$atts = array();
		foreach (isset($o['attachments']) ? $o['attachments'] : array() as $a) {
			$atts[] = array('name' => $a['name'], 'type' => $a['type'], 'size' => strlen($a['data']), 'file' => '', 'cid' => '', 'inline' => false);
		}
		$this->db->query("INSERT INTO `" . $this->p . "message` SET `thread_id` = '" . $tid . "', `account_id` = '" . (int)$acc['account_id'] . "', `folder` = 'sent', `uid` = 0, `direction` = 'out', `msgid` = '" . $this->e($id) . "', `in_reply_to` = '" . $this->e($inReply) . "', `refs` = '" . $this->e(implode(' ', $refs)) . "', `from_email` = '" . $this->e($acc['email']) . "', `from_name` = '" . $this->e($acc['name']) . "', `to_list` = '" . $this->e(json_encode($to)) . "', `cc_list` = '" . $this->e(json_encode($cc)) . "', `subject` = '" . $this->e(mb_substr($o['subject'], 0, 255)) . "', `date` = NOW(), `body_text` = '" . $this->e($textAll) . "', `body_html` = '" . $this->e($html) . "', `attachments` = '" . $this->e(json_encode($atts)) . "', `seen` = 1, `user` = '" . $this->e($o['user']) . "'");
		$this->refreshThread($tid);
		return array('thread_id' => $tid, 'saved_sent' => $savedSent);
	}
}
