<?php
// Was a temporary check; not used.
class ControllerExtensionModuleDpcInboxDbg extends Controller {
	public function index() {
	}
}
