<?php
// dpCREATOR Inbox: read and answer the shop mailboxes inside the admin.
require_once(DIR_SYSTEM . 'library/dpcinbox.php');

class ControllerExtensionModuleDpcInbox extends Controller {
	private $error = array();

	private function inbox() {
		static $i = null;
		if ($i === null) {
			$i = new DpcInbox($this->db);
		}
		return $i;
	}

	private function token() {
		return 'user_token=' . $this->session->data['user_token'];
	}

	private function json($data) {
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
	}

	private function canModify() {
		return $this->user->hasPermission('modify', 'extension/module/dpc_inbox');
	}

	public function install() {
		$this->inbox()->install();
		if (!$this->inbox()->accounts()) {
			$main = strtolower((string)$this->config->get('config_email'));
			$domain = substr(strrchr($main, '@'), 1);
			$host = $domain ? 'mail.' . $domain : '';
			$name = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
			$list = array($main);
			if ($domain && $main !== 'info@' . $domain) {
				$list[] = 'info@' . $domain;
			}
			foreach ($list as $i => $email) {
				$this->inbox()->saveAccount(array('email' => $email, 'name' => $name, 'username' => $email, 'imap_host' => $host, 'imap_port' => 993, 'imap_secure' => 'ssl', 'smtp_host' => $host, 'smtp_port' => 587, 'smtp_secure' => 'tls', 'verify_cert' => 1, 'signature' => $name . "\n" . rtrim(HTTPS_CATALOG, '/'), 'status' => 1, 'sort_order' => $i));
			}
		}
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_inbox', array(
			'module_dpc_inbox_status' => 1,
			'module_dpc_inbox_templates' => json_encode($this->defaultTemplates())
		));
	}

	public function uninstall() {
		// Messages and settings are kept; removing the tables would lose the conversation history.
	}

	private function defaultTemplates() {
		return array(
			array('title' => 'Order shipped', 'body' => "Hi {first_name},\n\nYour order #{order_id} is on its way. Tracking: \n\nThanks for ordering from {shop}!"),
			array('title' => 'Firmware: how to flash', 'body' => "Hi {first_name},\n\nYou can flash the firmware from your browser on the Flash Firmware page: {shop_url}index.php?route=information/information&information_id=8\nConnect the board over USB, choose the board and press Install. Chrome or Edge is needed.\n\nLet me know if anything gets stuck."),
			array('title' => 'Need more details', 'body' => "Hi {first_name},\n\nThanks for your message. To help you quickly, could you send:\n- your board (R2 or R3) and firmware version\n- what you expected and what happened\n- a photo or screenshot if you have one\n"),
			array('title' => 'Thanks, all sorted', 'body' => "Hi {first_name},\n\nGreat to hear it works now. If anything else comes up, just reply to this email.")
		);
	}

	// ---- pages

	public function index() {
		$this->load->language('extension/module/dpc_inbox');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->inbox()->install();
		$data['heading_title'] = $this->language->get('heading_title');
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $this->token(), true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/module/dpc_inbox', $this->token(), true))
		);
		$base = html_entity_decode($this->url->link('extension/module/dpc_inbox', $this->token(), true), ENT_QUOTES, 'UTF-8');
		$accounts = array();
		foreach ($this->inbox()->accounts() as $a) {
			$accounts[] = array('id' => (int)$a['account_id'], 'email' => $a['email'], 'name' => $a['name'], 'ready' => $a['has_password'] && $a['status'], 'error' => $a['last_error'], 'last_sync' => $a['last_sync'], 'signature' => (string)$a['signature']);
		}
		$templates = json_decode((string)$this->config->get('module_dpc_inbox_templates'), true);
		$data['config'] = json_encode(array(
			'base' => $base,
			'accounts' => $accounts,
			'templates' => is_array($templates) ? $templates : $this->defaultTemplates(),
			'shop' => html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8'),
			'shop_url' => HTTPS_CATALOG,
			'can_edit' => $this->canModify(),
			'reply_hours' => ($rh = $this->config->get('module_dpc_inbox_reply_hours')) === null || $rh === '' ? 24 : (int)$rh,
			'compose' => array(
				'to' => isset($this->request->get['to']) ? (string)$this->request->get['to'] : '',
				'subject' => isset($this->request->get['subject']) ? (string)$this->request->get['subject'] : '',
				'order_id' => isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0,
				'name' => isset($this->request->get['name']) ? (string)$this->request->get['name'] : ''
			),
			'open' => isset($this->request->get['thread_id']) ? (int)$this->request->get['thread_id'] : 0
		), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
		$data['settings'] = $this->url->link('extension/module/dpc_inbox/setting', $this->token(), true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_inbox', $data));
	}

	public function setting() {
		$this->load->language('extension/module/dpc_inbox');
		$this->document->setTitle($this->language->get('heading_settings'));
		$this->inbox()->install();
		$this->load->model('setting/setting');

		if ($this->request->server['REQUEST_METHOD'] == 'POST') {
			if (!$this->canModify()) {
				$this->error['warning'] = $this->language->get('error_permission');
			} else {
				$post = $this->request->post;
				foreach (isset($post['account']) ? $post['account'] : array() as $a) {
					$a = array_map(function ($v) { return is_string($v) ? html_entity_decode($v, ENT_QUOTES, 'UTF-8') : $v; }, $a);
					if (trim($a['email']) === '') {
						continue;
					}
					if (!filter_var(trim($a['email']), FILTER_VALIDATE_EMAIL)) {
						$this->error['warning'] = 'Check the email address ' . htmlspecialchars($a['email']) . '.';
						continue;
					}
					$a['verify_cert'] = !empty($a['verify_cert']) ? 1 : 0;
					$a['status'] = !empty($a['status']) ? 1 : 0;
					$this->inbox()->saveAccount($a);
				}
				$templates = array();
				foreach (isset($post['template']) ? $post['template'] : array() as $t) {
					$title = trim(html_entity_decode($t['title'], ENT_QUOTES, 'UTF-8'));
					$body = html_entity_decode($t['body'], ENT_QUOTES, 'UTF-8');
					if ($title !== '' && trim($body) !== '') {
						$templates[] = array('title' => $title, 'body' => $body);
					}
				}
				$this->model_setting_setting->editSetting('module_dpc_inbox', array(
					'module_dpc_inbox_status' => 1,
					'module_dpc_inbox_templates' => json_encode($templates),
					'module_dpc_inbox_reply_hours' => max(0, (int)$post['reply_hours'])
				));
				if (!$this->error) {
					$this->session->data['success'] = $this->language->get('text_saved');
					$this->response->redirect($this->url->link('extension/module/dpc_inbox/setting', $this->token(), true));
				}
			}
		}

		$data['heading_title'] = $this->language->get('heading_settings');
		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
		unset($this->session->data['success']);
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $this->token(), true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/module/dpc_inbox', $this->token(), true)),
			array('text' => $this->language->get('heading_settings'), 'href' => $this->url->link('extension/module/dpc_inbox/setting', $this->token(), true))
		);
		$data['action'] = $this->url->link('extension/module/dpc_inbox/setting', $this->token(), true);
		$data['back'] = $this->url->link('extension/module/dpc_inbox', $this->token(), true);
		$data['test_url'] = html_entity_decode($this->url->link('extension/module/dpc_inbox/test', $this->token(), true), ENT_QUOTES, 'UTF-8');
		$data['accounts'] = $this->inbox()->accounts();
		$data['accounts'][] = array('account_id' => 0, 'email' => '', 'name' => html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), 'username' => '', 'has_password' => false, 'imap_host' => '', 'imap_port' => 993, 'imap_secure' => 'ssl', 'smtp_host' => '', 'smtp_port' => 587, 'smtp_secure' => 'tls', 'verify_cert' => 1, 'signature' => '', 'status' => 1, 'sort_order' => 9, 'last_sync' => null, 'last_error' => '');
		$templates = json_decode((string)$this->config->get('module_dpc_inbox_templates'), true);
		$data['templates'] = is_array($templates) ? $templates : $this->defaultTemplates();
		$data['templates'][] = array('title' => '', 'body' => '');
		$rh = $this->config->get('module_dpc_inbox_reply_hours');
		$data['reply_hours'] = ($rh === null || $rh === '') ? 24 : (int)$rh;
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_inbox_setting', $data));
	}

	// ---- JSON endpoints

	public function test() {
		if (!$this->canModify()) {
			return $this->json(array('error' => 'No permission.'));
		}
		$acc = $this->inbox()->account(isset($this->request->post['account_id']) ? (int)$this->request->post['account_id'] : 0);
		if (!$acc) {
			return $this->json(array('error' => 'Save the mailbox first.'));
		}
		if (!$acc['password']) {
			return $this->json(array('error' => 'Enter the password and save first.'));
		}
		$this->json(array('result' => $this->inbox()->testAccount($acc)));
	}

	public function sync() {
		$this->inbox()->install();
		$new = $this->inbox()->sync(isset($this->request->get['quick']) ? 8 : 20);
		$accounts = array();
		foreach ($this->inbox()->accounts() as $a) {
			$accounts[] = array('id' => (int)$a['account_id'], 'email' => $a['email'], 'ready' => $a['has_password'] && $a['status'], 'error' => $a['last_error'], 'last_sync' => $a['last_sync']);
		}
		$this->json(array('new' => $new, 'errors' => $this->inbox()->errors, 'accounts' => $accounts, 'counts' => $this->inbox()->counts()));
	}

	public function threads() {
		$g = $this->request->get;
		$r = $this->inbox()->threads(isset($g['filter']) ? $g['filter'] : 'reply', isset($g['account']) ? (int)$g['account'] : 0, isset($g['q']) ? trim(html_entity_decode($g['q'], ENT_QUOTES, 'UTF-8')) : '', isset($g['page']) ? (int)$g['page'] : 1);
		$items = array();
		foreach ($r['items'] as $t) {
			$items[] = array(
				'id' => (int)$t['thread_id'], 'subject' => $t['subject'], 'name' => $t['contact_name'], 'email' => $t['contact_email'],
				'account' => $t['account_email'], 'snippet' => $t['snippet'], 'date' => $t['last_date'], 'unread' => (int)$t['unread'] > 0,
				'needs_reply' => (bool)$t['needs_reply'], 'customer' => (int)$t['customer_id'] > 0, 'messages' => (int)$t['messages'],
				'attachments' => (int)$t['attachments'] > 0, 'state' => $t['state'], 'last_in' => $t['last_in'], 'kind' => $t['kind']
			);
		}
		$this->json(array('items' => $items, 'total' => $r['total'], 'counts' => $this->inbox()->counts(), 'now' => date('Y-m-d H:i:s')));
	}

	public function thread() {
		$id = isset($this->request->get['thread_id']) ? (int)$this->request->get['thread_id'] : 0;
		$t = $this->inbox()->thread($id);
		if (!$t) {
			return $this->json(array('error' => 'This conversation was not found.'));
		}
		if ((int)$t['unread'] > 0) {
			$this->inbox()->markRead($id);
		}
		$base = html_entity_decode($this->url->link('extension/module/dpc_inbox/attachment', $this->token(), true), ENT_QUOTES, 'UTF-8');
		$messages = array();
		foreach ($t['messages'] as $m) {
			$atts = array();
			$cids = array();
			foreach ($m['attachments'] as $i => $a) {
				$url = $a['file'] !== '' ? $base . '&message_id=' . (int)$m['message_id'] . '&i=' . $i : '';
				if ($a['cid'] !== '' && $a['file'] !== '' && strpos($a['type'], 'image/') === 0 && $a['size'] < 1500000) {
					$a2 = $this->inbox()->attachment($m['message_id'], $i);
					if ($a2) {
						$cids[$a['cid']] = 'data:' . $a['type'] . ';base64,' . base64_encode(file_get_contents($a2['path']));
					}
				}
				if (!$a['inline'] || $a['cid'] === '') {
					$atts[] = array('name' => $a['name'], 'size' => $a['size'], 'type' => $a['type'], 'url' => $url);
				}
			}
			$html = (string)$m['body_html'];
			if ($html !== '') {
				$html = $this->cleanHtml($html, $cids);
			}
			$messages[] = array(
				'id' => (int)$m['message_id'], 'direction' => $m['direction'], 'from' => $m['from_email'], 'from_name' => $m['from_name'],
				'to' => $m['to_list'], 'cc' => $m['cc_list'], 'subject' => $m['subject'], 'date' => $m['date'], 'text' => (string)$m['body_text'],
				'html' => $html, 'attachments' => $atts, 'user' => $m['user']
			);
		}
		$this->json(array(
			'thread' => array('id' => (int)$t['thread_id'], 'subject' => $t['subject'], 'account_id' => (int)$t['account_id'], 'account' => $t['account_email'], 'email' => $t['contact_email'], 'name' => $t['contact_name'], 'state' => $t['state'], 'kind' => $t['kind'], 'order_id' => (int)$t['order_id']),
			'messages' => $messages,
			'customer' => $this->customerContext($t['contact_email'], (int)$t['customer_id'], (int)$t['order_id']),
			'followup' => $this->followupNotes('mail:' . (int)$t['thread_id'])
		));
	}

	private function followupNotes($key) {
		if (!$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'dpc_followup') . "'")->num_rows) {
			return array();
		}
		return $this->db->query("SELECT `action`, `note`, `username`, `created` FROM `" . DB_PREFIX . "dpc_followup` WHERE `item` = '" . $this->db->escape($key) . "' ORDER BY `created` DESC LIMIT 10")->rows;
	}

	// Remove scripts and event handlers; images from the internet stay blocked until the admin asks
	private function cleanHtml($html, $cids) {
		$html = preg_replace('#<(script|iframe|object|embed|applet|form|meta|link|base)\b[^>]*>(.*?</\1>)?#is', '', $html);
		$html = preg_replace('#<(script|iframe|object|embed|applet|form|meta|link|base)\b[^>]*/?>#is', '', $html);
		$html = preg_replace('#\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)#i', '', $html);
		$html = preg_replace('#(href|src)\s*=\s*(["\']?)\s*javascript:[^"\'>\s]*\2#i', '$1="#"', $html);
		foreach ($cids as $cid => $uri) {
			$html = str_ireplace('cid:' . $cid, $uri, $html);
		}
		return $html;
	}

	private function customerContext($email, $customerId, $orderId) {
		$out = array('customer' => null, 'orders' => array(), 'tickets' => 0, 'rnd' => '');
		$e = $this->db->escape(strtolower($email));
		$c = $customerId
			? $this->db->query("SELECT customer_id, firstname, lastname, email, telephone, date_added FROM `" . DB_PREFIX . "customer` WHERE customer_id = '" . (int)$customerId . "'")->row
			: $this->db->query("SELECT customer_id, firstname, lastname, email, telephone, date_added FROM `" . DB_PREFIX . "customer` WHERE LOWER(email) = '" . $e . "' LIMIT 1")->row;
		if ($c) {
			$out['customer'] = array('name' => trim($c['firstname'] . ' ' . $c['lastname']), 'email' => $c['email'], 'phone' => $c['telephone'], 'since' => substr($c['date_added'], 0, 10),
				'link' => html_entity_decode($this->url->link('customer/customer/edit', $this->token() . '&customer_id=' . (int)$c['customer_id'], true), ENT_QUOTES, 'UTF-8'));
		}
		$lang = (int)$this->config->get('config_language_id');
		$rows = $this->db->query("SELECT o.order_id, o.date_added, o.total, o.currency_code, o.currency_value, o.firstname, o.lastname, os.name AS status,
				(SELECT GROUP_CONCAT(CONCAT(op.quantity, '× ', op.name) SEPARATOR ', ') FROM `" . DB_PREFIX . "order_product` op WHERE op.order_id = o.order_id) AS products
			FROM `" . DB_PREFIX . "order` o LEFT JOIN `" . DB_PREFIX . "order_status` os ON os.order_status_id = o.order_status_id AND os.language_id = '" . $lang . "'
			WHERE o.order_status_id > 0 AND (LOWER(o.email) = '" . $e . "'" . ($c ? " OR o.customer_id = '" . (int)$c['customer_id'] . "'" : '') . ($orderId ? " OR o.order_id = '" . (int)$orderId . "'" : '') . ")
			ORDER BY o.order_id DESC LIMIT 8")->rows;
		foreach ($rows as $r) {
			$out['orders'][] = array('id' => (int)$r['order_id'], 'date' => substr($r['date_added'], 0, 10), 'status' => $r['status'], 'products' => $r['products'],
				'total' => $this->currency->format($r['total'], $r['currency_code'], $r['currency_value']),
				'link' => html_entity_decode($this->url->link('sale/order/info', $this->token() . '&order_id=' . (int)$r['order_id'], true), ENT_QUOTES, 'UTF-8'));
			if (!$out['customer'] && !$c) {
				$out['guest'] = trim($r['firstname'] . ' ' . $r['lastname']);
			}
		}
		if ($this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'dpc_ticket') . "'")->num_rows) {
			$out['tickets'] = (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_ticket` WHERE LOWER(email) = '" . $e . "'" . ($c ? " OR customer_id = '" . (int)$c['customer_id'] . "'" : ''))->row['n'];
			$out['tickets_link'] = html_entity_decode($this->url->link('extension/module/dpc_support', $this->token(), true), ENT_QUOTES, 'UTF-8');
		}
		if ($c && $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'dpc_rnd_member') . "'")->num_rows) {
			$m = $this->db->query("SELECT status, stage FROM `" . DB_PREFIX . "dpc_rnd_member` WHERE customer_id = '" . (int)$c['customer_id'] . "'")->row;
			if ($m && $m['status'] !== 'removed') {
				$out['rnd'] = 'R&D Club: ' . $m['status'] . ', stage ' . $m['stage'];
			}
		}
		return $out;
	}

	public function attachment() {
		$a = $this->inbox()->attachment(isset($this->request->get['message_id']) ? (int)$this->request->get['message_id'] : 0, isset($this->request->get['i']) ? (int)$this->request->get['i'] : -1);
		if (!$a) {
			$this->response->addHeader('HTTP/1.1 404 Not Found');
			$this->response->setOutput('Not found');
			return;
		}
		// always as a download: never let a mailed file run inside the admin
		$name = str_replace(array('"', "\r", "\n"), '', $a['name']);
		header('Content-Type: application/octet-stream');
		header('X-Content-Type-Options: nosniff');
		header('Content-Disposition: attachment; filename="' . preg_replace('/[^\x20-\x7E]/', '_', $name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
		header('Content-Length: ' . filesize($a['path']));
		readfile($a['path']);
		exit;
	}

	public function send() {
		if (!$this->canModify()) {
			return $this->json(array('error' => 'You do not have permission to send emails.'));
		}
		$p = $this->request->post;
		$dec = function ($k) use ($p) { return isset($p[$k]) ? html_entity_decode((string)$p[$k], ENT_QUOTES, 'UTF-8') : ''; };
		$atts = array();
		$total = 0;
		if (!empty($this->request->files['files']['name']) && is_array($this->request->files['files']['name'])) {
			foreach ($this->request->files['files']['name'] as $i => $name) {
				if ((int)$this->request->files['files']['error'][$i] !== UPLOAD_ERR_OK || !is_uploaded_file($this->request->files['files']['tmp_name'][$i])) {
					continue;
				}
				$tmp = $this->request->files['files']['tmp_name'][$i];
				$total += filesize($tmp);
				if ($total > 15 * 1024 * 1024) {
					return $this->json(array('error' => 'Attachments are limited to 15 MB in total.'));
				}
				$atts[] = array('name' => basename(html_entity_decode($name, ENT_QUOTES, 'UTF-8')), 'type' => $this->request->files['files']['type'][$i] ?: 'application/octet-stream', 'data' => file_get_contents($tmp));
			}
		}
		try {
			$r = $this->inbox()->send(array(
				'account_id' => (int)$dec('account_id'), 'thread_id' => (int)$dec('thread_id'), 'to' => $dec('to'), 'cc' => $dec('cc'),
				'subject' => $dec('subject'), 'text' => $dec('text'), 'attachments' => $atts, 'user' => $this->user->getUserName(), 'bcc' => $dec('bcc'),
				'forward' => (int)$dec('fwd_message_id') ? array('message_id' => (int)$dec('fwd_message_id')) : ((int)$dec('fwd_uid') ? array('account_id' => (int)$dec('fwd_account'), 'folder' => $dec('fwd_folder'), 'uid' => (int)$dec('fwd_uid')) : null),
				'order_id' => (int)$dec('order_id'), 'contact_name' => $dec('name')
			));
			if (!empty($p['done'])) {
				$this->inbox()->setState($r['thread_id'], 'done');
			}
			$this->json(array('success' => 'Sent.' . ($r['saved_sent'] ? '' : ' (A copy could not be saved in the Sent folder.)'), 'thread_id' => $r['thread_id']));
		} catch (\Exception $e) {
			$this->json(array('error' => $e->getMessage()));
		}
	}

	public function state() {
		if (!$this->canModify()) {
			return $this->json(array('error' => 'No permission.'));
		}
		$id = isset($this->request->post['thread_id']) ? (int)$this->request->post['thread_id'] : 0;
		$what = isset($this->request->post['state']) ? $this->request->post['state'] : '';
		if ($what === 'done' || $what === 'open') {
			$this->inbox()->setState($id, $what);
		} elseif ($what === 'auto' || $what === 'person') {
			$this->inbox()->setKind($id, $what);
		}
		$this->json(array('success' => true, 'counts' => $this->inbox()->counts()));
	}

	// ---- deleting and folders

	private function ids($k) {
		$v = isset($this->request->post[$k]) ? $this->request->post[$k] : array();
		return array_values(array_filter(array_map('intval', is_array($v) ? $v : explode(',', (string)$v))));
	}

	// Conversations or single messages to Trash (or to another server folder)
	public function delete() {
		if (!$this->canModify()) {
			return $this->json(array('error' => 'No permission.'));
		}
		$dest = isset($this->request->post['dest']) ? html_entity_decode((string)$this->request->post['dest'], ENT_QUOTES, 'UTF-8') : '';
		try {
			$n = $this->ids('message_ids') ? $this->inbox()->moveMessages($this->ids('message_ids'), $dest) : $this->inbox()->moveThreads($this->ids('thread_ids'), $dest);
			$this->json(array('success' => true, 'moved' => $n, 'counts' => $this->inbox()->counts()));
		} catch (\Exception $e) {
			$this->json(array('error' => $e->getMessage()));
		}
	}

	private function g($k, $def = '') {
		return isset($this->request->get[$k]) ? html_entity_decode((string)$this->request->get[$k], ENT_QUOTES, 'UTF-8') : $def;
	}

	public function folders() {
		try {
			$this->json(array('folders' => $this->inbox()->folderList((int)$this->g('account'))));
		} catch (\Exception $e) {
			$this->json(array('error' => $e->getMessage()));
		}
	}

	public function folder() {
		try {
			$this->json($this->inbox()->folderPage((int)$this->g('account'), $this->g('folder', 'INBOX'), (int)$this->g('page', 1), 50, $this->g('q')));
		} catch (\Exception $e) {
			$this->json(array('error' => $e->getMessage()));
		}
	}

	public function fmessage() {
		try {
			$m = $this->inbox()->folderMessage((int)$this->g('account'), $this->g('folder'), (int)$this->g('uid'));
		} catch (\Exception $e) {
			return $this->json(array('error' => $e->getMessage()));
		}
		$base = html_entity_decode($this->url->link('extension/module/dpc_inbox/fattachment', $this->token(), true), ENT_QUOTES, 'UTF-8') . '&account=' . (int)$this->g('account') . '&folder=' . rawurlencode($this->g('folder')) . '&uid=' . (int)$m['uid'];
		$atts = array();
		$cids = array();
		foreach ($m['attachments'] as $i => $a) {
			if ($a['cid'] !== '' && strpos($a['type'], 'image/') === 0 && strlen($a['data']) < 1500000) {
				$cids[$a['cid']] = 'data:' . $a['type'] . ';base64,' . base64_encode($a['data']);
			}
			if (!$a['inline'] || $a['cid'] === '') {
				$atts[] = array('name' => $a['name'], 'size' => strlen($a['data']), 'type' => $a['type'], 'url' => $base . '&i=' . $i);
			}
		}
		$m['html'] = $m['html'] !== '' ? $this->cleanHtml($m['html'], $cids) : '';
		$m['attachments'] = $atts;
		$this->json(array('message' => $m));
	}

	public function fattachment() {
		try {
			$m = $this->inbox()->folderMessage((int)$this->g('account'), $this->g('folder'), (int)$this->g('uid'));
		} catch (\Exception $e) {
			$m = null;
		}
		$i = (int)$this->g('i', -1);
		if (!$m || !isset($m['attachments'][$i])) {
			$this->response->addHeader('HTTP/1.1 404 Not Found');
			$this->response->setOutput('Not found');
			return;
		}
		$a = $m['attachments'][$i];
		$name = str_replace(array('"', "\r", "\n"), '', $a['name']);
		header('Content-Type: application/octet-stream');
		header('X-Content-Type-Options: nosniff');
		header('Content-Disposition: attachment; filename="' . preg_replace('/[^\x20-\x7E]/', '_', $name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
		header('Content-Length: ' . strlen($a['data']));
		echo $a['data'];
		exit;
	}

	public function fmove() {
		if (!$this->canModify()) {
			return $this->json(array('error' => 'No permission.'));
		}
		$p = $this->request->post;
		$dec = function ($k) use ($p) { return isset($p[$k]) ? html_entity_decode((string)$p[$k], ENT_QUOTES, 'UTF-8') : ''; };
		try {
			$r = $this->inbox()->folderMove((int)$dec('account'), $dec('folder'), $this->ids('uids'), $dec('dest'));
			$this->json(array('success' => true) + $r + array('counts' => $this->inbox()->counts()));
		} catch (\Exception $e) {
			$this->json(array('error' => $e->getMessage()));
		}
	}

	public function empty_trash() {
		if (!$this->canModify()) {
			return $this->json(array('error' => 'No permission.'));
		}
		try {
			$this->json(array('success' => true, 'removed' => $this->inbox()->emptyTrash((int)(isset($this->request->post['account']) ? $this->request->post['account'] : 0))));
		} catch (\Exception $e) {
			$this->json(array('error' => $e->getMessage()));
		}
	}

	// Count for the menu badge
	public function counts() {
		$this->json($this->inbox()->counts());
	}
}
