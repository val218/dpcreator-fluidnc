/* dpCREATOR Inbox page. Data: extension/module/dpc_inbox/{sync,threads,thread,send,state,attachment,delete,folders,folder,fmessage,fattachment,fmove,empty_trash} */
(function () {
	var C = window.DPCI_CONFIG, root = document.getElementById('dpci');
	if (!C || !root) return;
	var U = function (m, q) { return C.base.replace('route=extension/module/dpc_inbox', 'route=extension/module/dpc_inbox/' + m) + (q || ''); };
	var S = {filter: 'reply', account: 0, q: '', page: 1, list: [], total: 0, counts: {reply: 0, unread: 0}, open: 0, thread: null, compose: null, syncing: false, accounts: C.accounts,
		mode: 'conv', sel: {}, folders: [], folder: '', fitems: [], ftotal: 0, fpage: 1, fsel: {}, fopen: 0};

	var css = '' +
		'.dpci{--ink:#1E2A35;--mut:#6B7885;--line:#E3E8ED;--soft:#F5F7F9;--blue:#1F6FB8;--red:#C42B1C;--amb:#B26A00;--grn:#2E7D4F;color:var(--ink)}' +
		'.dpci-bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}' +
		'.dpci-tabs{display:inline-flex;border:1px solid var(--line);border-radius:4px;overflow:hidden;background:#fff}' +
		'.dpci-tabs button{border:0;background:#fff;padding:7px 12px;font-size:13px;color:var(--mut);cursor:pointer;border-right:1px solid var(--line)}.dpci-tabs button:last-child{border-right:0}' +
		'.dpci-tabs button[aria-pressed=true]{background:var(--ink);color:#fff}' +
		'.dpci-tabs .n{display:inline-block;margin-left:5px;font-size:11px;font-weight:700;background:var(--red);color:#fff;border-radius:9px;padding:1px 6px}' +
		'.dpci-bar select,.dpci-bar input[type=search]{height:32px;font-size:13px;width:auto}.dpci-bar input[type=search]{min-width:200px;flex:1 1 200px}' +
		'.dpci-sync{font-size:12px;color:var(--mut);margin-left:auto;display:flex;gap:8px;align-items:center}' +
		'.dpci-warn{background:#FFF4E0;border:1px solid #F2D29C;color:#7A4900;border-radius:4px;padding:8px 12px;margin-bottom:10px;font-size:13px}.dpci-warn.err{background:#FDECEA;border-color:#F1B8B1;color:#8E1E14}' +
		'.dpci-main{display:grid;grid-template-columns:minmax(280px,380px) 1fr;gap:14px;align-items:start}' +
		'.dpci-list{background:#fff;border:1px solid var(--line);border-radius:4px;max-height:calc(100vh - 230px);overflow:auto}' +
		'.dpci-row{display:block;width:100%;text-align:left;border:0;border-bottom:1px solid var(--line);background:#fff;padding:10px 12px 10px 14px;cursor:pointer;position:relative;color:inherit}' +
		'.dpci-row:hover{background:var(--soft)}.dpci-row[aria-current=true]{background:#E9F1FA}' +
		'.dpci-row.need:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--amb)}.dpci-row.late:before{background:var(--red)}' +
		'.dpci-row .t{display:flex;gap:8px;align-items:baseline}.dpci-row .w{flex:1;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dpci-row.unread .w,.dpci-row.unread .s{font-weight:700}' +
		'.dpci-row .d{font-size:12px;color:var(--mut);white-space:nowrap}.dpci-row .s{font-size:13px;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
		'.dpci-row .p{font-size:12px;color:var(--mut);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
		'.dpci-tag{display:inline-block;font-size:10.5px;font-weight:600;border-radius:9px;padding:0 6px;margin-right:4px;border:1px solid var(--line);color:var(--mut);vertical-align:1px}.dpci-tag.c{border-color:#BFD6EE;color:var(--blue)}' +
		'.dpci-empty{padding:30px 16px;text-align:center;color:var(--mut)}' +
		'.dpci-view{background:#fff;border:1px solid var(--line);border-radius:4px;min-height:300px}' +
		'.dpci-vh{padding:14px 16px;border-bottom:1px solid var(--line);display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap}' +
		'.dpci-vh h2{font-size:18px;margin:0;flex:1 1 300px;line-height:1.3}.dpci-vh .sub{font-size:12.5px;color:var(--mut);margin-top:3px}' +
		'.dpci-vb{display:grid;grid-template-columns:1fr 250px;gap:0}' +
		'.dpci-msgs{padding:12px 16px;min-width:0}' +
		'.dpci-m{border:1px solid var(--line);border-radius:4px;margin-bottom:10px;background:#fff}.dpci-m.out{border-left:3px solid var(--blue)}' +
		'.dpci-mh{display:flex;gap:10px;padding:9px 12px;cursor:pointer;align-items:baseline}.dpci-mh .f{font-weight:600;font-size:13.5px}.dpci-mh .e{color:var(--mut);font-size:12px}.dpci-mh .d{margin-left:auto;color:var(--mut);font-size:12px;white-space:nowrap}' +
		'.dpci-m.col .dpci-mb{display:none}.dpci-m.col .dpci-mh .snip{display:block}.dpci-mh .snip{display:none;color:var(--mut);font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}' +
		'.dpci-mb{padding:0 12px 12px}.dpci-to{font-size:12px;color:var(--mut);margin-bottom:8px}' +
		'.dpci-text{white-space:pre-wrap;word-wrap:break-word;font-size:14px;line-height:1.5}.dpci-q{color:var(--mut)}' +
		'.dpci-qt{font-size:12px;color:var(--blue);background:none;border:0;padding:0;cursor:pointer}' +
		'.dpci-frame{width:100%;border:0;min-height:60px;display:block}' +
		'.dpci-mtools{display:flex;gap:10px;font-size:12px;margin:6px 0}.dpci-mtools button{background:none;border:0;padding:0;color:var(--blue);cursor:pointer}' +
		'.dpci-att{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.dpci-att a{font-size:12.5px;border:1px solid var(--line);border-radius:4px;padding:4px 8px;color:var(--ink);text-decoration:none;background:var(--soft)}' +
		'.dpci-side{border-left:1px solid var(--line);padding:12px 14px;font-size:13px;background:#FBFCFD}' +
		'.dpci-side h4{font-size:12px;font-weight:700;color:var(--mut);margin:12px 0 6px}.dpci-side h4:first-child{margin-top:0}' +
		'.dpci-side .o{border-top:1px solid var(--line);padding:6px 0}.dpci-side .o a{font-weight:600}.dpci-side .o small{display:block;color:var(--mut)}' +
		'.dpci-reply{border-top:1px solid var(--line);padding:12px 16px;background:#FBFCFD}' +
		'.dpci-reply .row2{display:grid;grid-template-columns:70px 1fr;gap:6px 8px;align-items:center;margin-bottom:6px;font-size:13px}.dpci-reply label{color:var(--mut);font-weight:400;margin:0}' +
		'.dpci-reply input[type=text],.dpci-reply select{height:30px;font-size:13px}' +
		'.dpci-reply textarea{width:100%;min-height:160px;font-size:14px;line-height:1.5;resize:vertical}' +
		'.dpci-ra{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}.dpci-ra .msg{font-size:13px}' +
		'.dpci-back{display:none}' +
		'.dpci-row{padding-left:38px}.dpci .dpci-ck{position:absolute!important;left:12px!important;top:12px!important;margin:0!important;width:16px;height:16px;cursor:pointer}' +
		'.dpci-selbar{display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--line);background:#E9F1FA;font-size:13px;position:sticky;top:0;z-index:2}' +
		'.dpci-fold{display:flex;flex-wrap:wrap;gap:4px;padding:8px 10px;border-bottom:1px solid var(--line);background:var(--soft)}' +
		'.dpci-fold button{border:1px solid var(--line);background:#fff;border-radius:14px;font-size:12.5px;padding:3px 10px;cursor:pointer;color:var(--ink)}' +
		'.dpci-fold button[aria-pressed=true]{background:var(--ink);border-color:var(--ink);color:#fff}' +
		'.dpci-fold .u{font-weight:700;margin-left:4px}' +
		'.dpci-fhead{display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--line);font-size:12.5px;color:var(--mut)}' +
		'.dpci-files{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.dpci-file{display:inline-flex;gap:6px;align-items:center;font-size:12.5px;border:1px solid var(--line);border-radius:4px;padding:3px 4px 3px 8px;background:#fff}' +
		'.dpci-file button{border:0;background:none;color:var(--red);font-size:15px;line-height:1;cursor:pointer;padding:0 4px}' +
		'.dpci-reply.drag{outline:2px dashed var(--blue);outline-offset:-4px}' +
		'.dpci-sig{font-size:12px;color:var(--mut);margin-top:6px;white-space:pre-wrap}' +
		'.dpci-mode{display:inline-flex;border:1px solid var(--line);border-radius:4px;overflow:hidden;background:#fff}.dpci-mode button{border:0;background:#fff;padding:7px 12px;font-size:13px;color:var(--mut);cursor:pointer;border-right:1px solid var(--line)}.dpci-mode button:last-child{border-right:0}.dpci-mode button[aria-pressed=true]{background:var(--blue);color:#fff}' +
		'.dpci-mact{display:flex;gap:10px;font-size:12px;margin-left:auto}.dpci-mact button{background:none;border:0;padding:0;color:var(--blue);cursor:pointer}.dpci-mact button.del{color:var(--red)}' +
		'@media (max-width:991px){.dpci-main{grid-template-columns:1fr}.dpci-vb{grid-template-columns:1fr}.dpci-side{border-left:0;border-top:1px solid var(--line)}.dpci.viewing .dpci-list{display:none}.dpci:not(.viewing) .dpci-view{display:none}.dpci-back{display:inline-block}.dpci-list{max-height:none}}';
	var st = document.createElement('style');
	st.textContent = css;
	document.head.appendChild(st);

	function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
	function btn(c, x, f) { var b = el('button', c, x); b.type = 'button'; if (f) b.addEventListener('click', f); return b; }
	function get(m, q) { return fetch(U(m, q), {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}}).then(function (r) { return r.json(); }); }
	function post(m, body) {
		var fd = body instanceof FormData ? body : new FormData();
		if (!(body instanceof FormData)) for (var k in body) fd.append(k, body[k]);
		return fetch(U(m), {method: 'POST', body: fd, credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}}).then(function (r) { return r.json(); });
	}
	function pd(s) { if (!s) return null; var p = s.split(/[- :]/); return new Date(+p[0], p[1] - 1, +p[2], +p[3] || 0, +p[4] || 0, +p[5] || 0); }
	var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	function when(s, full) {
		var d = pd(s); if (!d) return '';
		var n = new Date(), hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
		if (d.toDateString() === n.toDateString()) return full ? 'Today ' + hm : hm;
		var s2 = d.getDate() + ' ' + MON[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? ' ' + d.getFullYear() : '');
		return full ? s2 + ', ' + hm : s2;
	}
	function size(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }
	function hoursSince(s) { var d = pd(s); return d ? (Date.now() - d.getTime()) / 3600000 : 0; }

	// ---------- layout
	root.textContent = '';
	var warn = el('div');
	var bar = el('div', 'dpci-bar');
	var modeBox = el('div', 'dpci-mode');
	modeBox.setAttribute('role', 'group');
	modeBox.setAttribute('aria-label', 'View');
	[['conv', 'Conversations'], ['folder', 'Folders']].forEach(function (m) {
		var b = btn('', m[1], function () { setMode(m[0]); });
		b.dataset.m = m[0];
		modeBox.appendChild(b);
	});
	bar.appendChild(modeBox);
	var tabs = el('div', 'dpci-tabs');
	tabs.setAttribute('role', 'group');
	tabs.setAttribute('aria-label', 'Show');
	var TABS = [['reply', 'Needs a reply'], ['all', 'All'], ['done', 'Answered and done'], ['auto', 'Automatic']];
	TABS.forEach(function (t) {
		var b = btn('', t[1], function () { S.filter = t[0]; S.page = 1; drawTabs(); loadList(); });
		b.dataset.f = t[0];
		tabs.appendChild(b);
	});
	bar.appendChild(tabs);
	var accSel = el('select', 'form-control');
	accSel.setAttribute('aria-label', 'Mailbox');
	accSel.appendChild(new Option('All mailboxes', '0'));
	S.accounts.forEach(function (a) { accSel.appendChild(new Option(a.email, a.id)); });
	accSel.addEventListener('change', function () { S.account = +accSel.value; S.page = 1; if (S.mode === 'folder') { S.folder = ''; loadFolders(); } else loadList(); });
	bar.appendChild(accSel);
	var search = el('input', 'form-control');
	search.type = 'search';
	search.placeholder = 'Search name, email, subject or text';
	search.setAttribute('aria-label', 'Search');
	var st2;
	search.addEventListener('input', function () { clearTimeout(st2); st2 = setTimeout(function () { S.q = search.value.trim(); S.page = 1; S.fpage = 1; if (S.mode === 'folder') loadFolder(); else loadList(); }, 450); });
	bar.appendChild(search);
	var syncBox = el('div', 'dpci-sync');
	var syncText = el('span');
	var syncBtn = btn('btn btn-default btn-sm', 'Check for new email', function () { sync(false); });
	syncBox.appendChild(syncText);
	syncBox.appendChild(syncBtn);
	bar.appendChild(syncBox);
	var main = el('div', 'dpci-main');
	var list = el('div', 'dpci-list');
	list.setAttribute('aria-label', 'Conversations');
	var view = el('div', 'dpci-view');
	main.appendChild(list);
	main.appendChild(view);
	root.appendChild(warn);
	root.appendChild(bar);
	root.appendChild(main);

	function drawTabs() {
		tabs.querySelectorAll('button').forEach(function (b) {
			b.setAttribute('aria-pressed', b.dataset.f === S.filter ? 'true' : 'false');
			var old = b.querySelector('.n'); if (old) old.remove();
			if (b.dataset.f === 'reply' && S.counts.reply) b.appendChild(el('span', 'n', String(S.counts.reply)));
		});
	}

	function drawWarn() {
		warn.textContent = '';
		var notReady = S.accounts.filter(function (a) { return !a.ready; });
		var errs = S.accounts.filter(function (a) { return a.ready && a.error; });
		if (notReady.length) {
			var w = el('div', 'dpci-warn');
			w.appendChild(document.createTextNode((notReady.length === S.accounts.length ? 'Connect your mailboxes to start: ' : 'Not connected yet: ') + notReady.map(function (a) { return a.email; }).join(', ') + '. '));
			var a = el('a', null, 'Open the Inbox settings');
			a.href = C.base.replace('route=extension/module/dpc_inbox', 'route=extension/module/dpc_inbox/setting');
			w.appendChild(a);
			w.appendChild(document.createTextNode(' and enter the mailbox password.'));
			warn.appendChild(w);
		}
		errs.forEach(function (a) { warn.appendChild(el('div', 'dpci-warn err', a.email + ': ' + a.error)); });
	}

	// ---------- list
	function loadList() {
		return get('threads', '&filter=' + S.filter + '&account=' + S.account + '&q=' + encodeURIComponent(S.q) + '&page=' + S.page).then(function (j) {
			S.list = j.items; S.total = j.total; S.counts = j.counts;
			drawTabs(); drawList();
		});
	}

	function selected() { return Object.keys(S.sel).filter(function (k) { return S.sel[k]; }).map(Number); }
	function selBar() {
		var ids = selected();
		if (!ids.length || !C.can_edit) return null;
		var b = el('div', 'dpci-selbar');
		b.appendChild(el('b', null, ids.length + ' selected'));
		b.appendChild(btn('btn btn-danger btn-xs', 'Delete', function () { deleteThreads(ids); }));
		if (S.filter !== 'auto') b.appendChild(btn('btn btn-default btn-xs', 'Mark done', function () { Promise.all(ids.map(function (id) { return post('state', {thread_id: id, state: 'done'}); })).then(function () { S.sel = {}; loadList(); }); }));
		b.appendChild(btn('btn btn-link btn-xs', 'Clear', function () { S.sel = {}; drawList(); }));
		return b;
	}
	function deleteThreads(ids) {
		if (!window.confirm((ids.length === 1 ? 'Move this conversation' : 'Move ' + ids.length + ' conversations') + ' to Trash? It goes to the Trash folder on the mail server too; you can restore it from Folders > Trash.')) return;
		var fd = new FormData();
		ids.forEach(function (id) { fd.append('thread_ids[]', id); });
		post('delete', fd).then(function (j) {
			if (j.error) { alert(j.error); return; }
			S.sel = {};
			if (ids.indexOf(S.open) >= 0) { S.open = 0; view.textContent = ''; view.appendChild(el('div', 'dpci-empty', 'Moved to Trash.')); root.classList.remove('viewing'); }
			S.counts = j.counts; drawTabs(); loadList();
		});
	}

	function drawList() {
		list.textContent = '';
		var sb = selBar(); if (sb) list.appendChild(sb);
		if (!S.list.length) {
			var msg = S.q ? 'Nothing matches "' + S.q + '".' : S.filter === 'reply' ? 'Nobody is waiting for a reply.' : 'No conversations here yet.';
			list.appendChild(el('div', 'dpci-empty', msg));
			return;
		}
		var limit = +((C.reply_hours) || 24);
		S.list.forEach(function (t) {
			var late = t.needs_reply && hoursSince(t.last_in) >= limit;
			var b = el('div', 'dpci-row' + (t.unread ? ' unread' : '') + (t.needs_reply ? ' need' : '') + (late ? ' late' : ''));
			b.setAttribute('role', 'button'); b.tabIndex = 0;
			b.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target === b) { e.preventDefault(); openThread(t.id); } });
			b.setAttribute('aria-current', t.id === S.open ? 'true' : 'false');
			b.dataset.id = t.id;
			var top = el('div', 't');
			top.appendChild(el('span', 'w', t.name || t.email));
			top.appendChild(el('span', 'd', when(t.date)));
			b.appendChild(top);
			b.appendChild(el('div', 's', (t.subject || '(no subject)') + (t.messages > 1 ? '  (' + t.messages + ')' : '')));
			var p = el('div', 'p');
			if (t.customer) p.appendChild(el('span', 'dpci-tag c', 'customer'));
			if (S.accounts.length > 1) p.appendChild(el('span', 'dpci-tag', t.account.split('@')[0] + '@'));
			if (t.attachments) p.appendChild(el('span', 'dpci-tag', 'attachment'));
			p.appendChild(document.createTextNode(t.snippet));
			b.appendChild(p);
			b.addEventListener('click', function (e) { if (e.target.classList.contains('dpci-ck')) return; openThread(t.id); });
			if (C.can_edit) {
				var ck = el('input', 'dpci-ck'); ck.type = 'checkbox'; ck.checked = !!S.sel[t.id];
				ck.setAttribute('aria-label', 'Select ' + (t.subject || t.email));
				ck.addEventListener('click', function (e) { e.stopPropagation(); });
				ck.addEventListener('change', function () { S.sel[t.id] = ck.checked; var keep = list.scrollTop; drawList(); list.scrollTop = keep; });
				b.insertBefore(ck, b.firstChild);
			}
			list.appendChild(b);
		});
		if (S.total > S.list.length * S.page && S.list.length >= 40) {
			list.appendChild(btn('btn btn-link btn-block', 'Show older', function () { S.page++; get('threads', '&filter=' + S.filter + '&account=' + S.account + '&q=' + encodeURIComponent(S.q) + '&page=' + S.page).then(function (j) { S.list = S.list.concat(j.items); drawList(); }); }));
		}
	}

	// ---------- thread
	function openThread(id) {
		S.open = id; S.compose = null;
		root.classList.add('viewing');
		list.querySelectorAll('.dpci-row').forEach(function (r) { r.setAttribute('aria-current', r.dataset.id === String(id) ? 'true' : 'false'); });
		view.textContent = '';
		view.appendChild(el('div', 'dpci-empty', 'Loading…'));
		try { history.replaceState(null, '', C.base + '&thread_id=' + id); } catch (e) {}
		get('thread', '&thread_id=' + id).then(function (j) {
			if (j.error) { view.textContent = ''; view.appendChild(el('div', 'dpci-empty', j.error)); return; }
			S.thread = j;
			drawThread();
			S.list.forEach(function (t) { if (t.id === id) t.unread = false; });
			drawList();
		});
	}

	function quoteSplit(text) {
		var lines = text.split('\n'), cut = -1;
		for (var i = 0; i < lines.length; i++) {
			if (/^\s*>/.test(lines[i]) || /^(On .{5,160} wrote:|-----Original Message-----|From: .+)$/.test(lines[i].trim())) { cut = i; break; }
		}
		if (cut <= 0) return [text, ''];
		return [lines.slice(0, cut).join('\n').replace(/\s+$/, ''), lines.slice(cut).join('\n')];
	}

	function frame(html, images) {
		var f = el('iframe', 'dpci-frame');
		f.setAttribute('sandbox', 'allow-same-origin allow-popups allow-popups-to-escape-sandbox');
		f.setAttribute('referrerpolicy', 'no-referrer');
		f.title = 'Email content';
		var csp = "default-src 'none'; style-src 'unsafe-inline'; font-src data:; img-src data:" + (images ? ' https: http:' : '');
		f.srcdoc = '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="' + csp + '"><base target="_blank"><style>body{margin:0;font:14px/1.5 Arial,Helvetica,sans-serif;color:#1E2A35;word-wrap:break-word}img{max-width:100%;height:auto}table{max-width:100%}blockquote{margin:0 0 0 4px;padding-left:10px;border-left:3px solid #D5DCE3;color:#4A5763}</style></head><body>' + html + '</body></html>';
		f.addEventListener('load', function () {
			try {
				var h = f.contentDocument.documentElement.scrollHeight;
				f.style.height = Math.min(Math.max(h + 8, 60), 4000) + 'px';
				setTimeout(function () { try { f.style.height = Math.min(Math.max(f.contentDocument.documentElement.scrollHeight + 8, 60), 4000) + 'px'; } catch (e) {} }, 400);
			} catch (e) { f.style.height = '500px'; }
		});
		return f;
	}

	function message(m, collapsed) {
		var box = el('article', 'dpci-m ' + m.direction + (collapsed ? ' col' : ''));
		var h = el('div', 'dpci-mh');
		h.setAttribute('role', 'button');
		h.tabIndex = 0;
		h.appendChild(el('span', 'f', m.direction === 'out' ? (m.user ? m.user + ' (' + (m.from_name || m.from) + ')' : (m.from_name || m.from)) : (m.from_name || m.from)));
		if (m.from_name) h.appendChild(el('span', 'e', m.from));
		h.appendChild(el('span', 'snip', (m.text || '').replace(/\s+/g, ' ').slice(0, 140)));
		h.appendChild(el('span', 'd', when(m.date, true)));
		var toggle = function () { box.classList.toggle('col'); };
		h.addEventListener('click', toggle);
		h.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
		box.appendChild(h);
		var b = el('div', 'dpci-mb');
		var to = m.to.map(function (a) { return a.name ? a.name + ' <' + a.email + '>' : a.email; }).join(', ');
		var cc = m.cc.map(function (a) { return a.email; }).join(', ');
		b.appendChild(el('div', 'dpci-to', 'To: ' + to + (cc ? '  ·  Cc: ' + cc : '')));
		var body = el('div');
		var mode = m.html && !/^\s*$/.test(m.html) ? 'html' : 'text', images = false;
		var tools = el('div', 'dpci-mtools');
		function render() {
			body.textContent = '';
			tools.textContent = '';
			if (mode === 'html') {
				body.appendChild(frame(m.html, images));
				if (/<img[^>]+src=["']?https?:/i.test(m.html) && !images) tools.appendChild(btn('', 'Show pictures from the internet', function () { images = true; render(); }));
				tools.appendChild(btn('', 'Show as plain text', function () { mode = 'text'; render(); }));
			} else {
				var parts = quoteSplit(m.text || '');
				var t = el('div', 'dpci-text', parts[0] || (m.text ? '' : '(no text)'));
				body.appendChild(t);
				if (parts[1]) {
					var q = el('div', 'dpci-text dpci-q', parts[1]);
					q.hidden = true;
					var qb = btn('dpci-qt', 'Show quoted text', function () { q.hidden = !q.hidden; qb.textContent = q.hidden ? 'Show quoted text' : 'Hide quoted text'; });
					body.appendChild(qb);
					body.appendChild(q);
				}
				if (m.html) tools.appendChild(btn('', 'Show formatted', function () { mode = 'html'; render(); }));
			}
		}
		render();
		b.appendChild(body);
		b.appendChild(tools);
		if (m.attachments.length) {
			var at = el('div', 'dpci-att');
			m.attachments.forEach(function (a) {
				if (a.url) { var l = el('a', null, '📎 ' + a.name + ' (' + size(a.size) + ')'); l.href = a.url; at.appendChild(l); }
				else at.appendChild(el('span', 'dpci-tag', a.name + ' (' + size(a.size) + ')'));
			});
			b.appendChild(at);
		}
		if (C.can_edit && m.id) {
			var ma = el('div', 'dpci-mact');
			ma.appendChild(btn('', 'Forward', function () { forwardMsg({message_id: m.id, from: m.from, from_name: m.from_name, date: m.date, subject: m.subject, to: m.to, text: m.text, attachments: m.attachments, account_id: S.thread ? S.thread.thread.account_id : 0}); }));
			if (S.thread && S.thread.messages.length > 1) ma.appendChild(btn('del', 'Delete this email', function () {
				if (!window.confirm('Move this email to Trash?')) return;
				var fd = new FormData(); fd.append('message_ids[]', m.id);
				post('delete', fd).then(function (j) { if (j.error) { alert(j.error); return; } openThread(S.open); loadList(); });
			}));
			b.appendChild(ma);
		}
		box.appendChild(b);
		return box;
	}

	// Forward: a new email with the original below and its attachments
	function forwardMsg(f) {
		var who = f.from_name ? f.from_name + ' <' + f.from + '>' : f.from;
		var head = '\n\n---------- Forwarded message ----------\nFrom: ' + who + '\nDate: ' + when(f.date, true) + '\nSubject: ' + (f.subject || '') + '\nTo: ' + (f.to || []).map(function (a) { return a.email; }).join(', ') + '\n\n' + (f.text || '');
		compose({account_id: f.account_id, subject: /^fwd?:/i.test(f.subject || '') ? f.subject : 'Fwd: ' + (f.subject || ''), body: head, forward: f, title: 'Forward'});
	}

	function side(c, j) {
		var s = el('aside', 'dpci-side');
		s.appendChild(el('h4', null, 'Customer'));
		if (c.customer) {
			var a = el('a', null, c.customer.name || c.customer.email);
			a.href = c.customer.link;
			var p = el('div'); p.appendChild(a); s.appendChild(p);
			s.appendChild(el('div', 'text-muted', 'Account since ' + c.customer.since + (c.customer.phone ? ' · ' + c.customer.phone : '')));
		} else {
			s.appendChild(el('div', null, (c.guest ? c.guest + ' · ' : '') + 'No shop account with ' + j.thread.email));
		}
		if (c.rnd) s.appendChild(el('div', null, c.rnd));
		if (c.tickets) { var tl = el('a', null, c.tickets + ' support ticket' + (c.tickets > 1 ? 's' : '')); tl.href = c.tickets_link; var d = el('div'); d.appendChild(tl); s.appendChild(d); }
		s.appendChild(el('h4', null, c.orders.length ? 'Orders' : 'No orders'));
		c.orders.forEach(function (o) {
			var d = el('div', 'o');
			var l = el('a', null, '#' + o.id); l.href = o.link;
			d.appendChild(l);
			d.appendChild(document.createTextNode(' · ' + o.status + ' · ' + o.total));
			d.appendChild(el('small', null, o.date + ' · ' + (o.products || '')));
			s.appendChild(d);
		});
		if (j.followup && j.followup.length) {
			s.appendChild(el('h4', null, 'Follow-up notes'));
			j.followup.forEach(function (n) { s.appendChild(el('div', 'o', n.username + ': ' + n.note)); });
		}
		return s;
	}

	function drawThread() {
		var j = S.thread, t = j.thread;
		view.textContent = '';
		var vh = el('div', 'dpci-vh');
		var back = btn('btn btn-default btn-sm dpci-back', '‹ Back', function () { root.classList.remove('viewing'); });
		vh.appendChild(back);
		var ht = el('div');
		ht.style.flex = '1 1 300px';
		ht.appendChild(el('h2', null, t.subject || '(no subject)'));
		ht.appendChild(el('div', 'sub', (t.name ? t.name + ' <' + t.email + '>' : t.email) + '  ·  to ' + t.account));
		vh.appendChild(ht);
		if (C.can_edit) {
			var acts = el('div');
			acts.style.display = 'flex'; acts.style.gap = '6px'; acts.style.flexWrap = 'wrap';
			var lastIn = null;
			j.messages.forEach(function (m) { if (m.direction === 'in') lastIn = m; });
			var answered = j.messages.length && j.messages[j.messages.length - 1].direction === 'out';
			if (t.state === 'open' && !answered) acts.appendChild(btn('btn btn-default btn-sm', 'Done, no reply needed', function () { setState('done'); }));
			if (t.state === 'done') acts.appendChild(btn('btn btn-default btn-sm', 'Reopen', function () { setState('open'); }));
			acts.appendChild(btn('btn btn-default btn-sm', t.kind === 'auto' ? 'This is a person' : 'Automatic email', function () { setState(t.kind === 'auto' ? 'person' : 'auto'); }));
			acts.appendChild(moveSelect(t.account_id, function (dest, label) {
				if (!window.confirm('Move this conversation to ' + label + '? It leaves the Inbox here and on the mail server.')) return;
				var fd = new FormData(); fd.append('thread_ids[]', t.id); fd.append('dest', dest);
				post('delete', fd).then(function (j) { if (j.error) { alert(j.error); return; } S.open = 0; view.textContent = ''; view.appendChild(el('div', 'dpci-empty', 'Moved to ' + label + '.')); loadList(); });
			}, true));
			acts.appendChild(btn('btn btn-danger btn-sm', 'Delete', function () { deleteThreads([t.id]); }));
			vh.appendChild(acts);
		}
		view.appendChild(vh);
		var vb = el('div', 'dpci-vb');
		var msgs = el('div', 'dpci-msgs');
		var n = j.messages.length;
		j.messages.forEach(function (m, i) { msgs.appendChild(message(m, n > 2 && i < n - 2)); });
		vb.appendChild(msgs);
		vb.appendChild(side(j.customer, j));
		view.appendChild(vb);
		if (C.can_edit) {
			var last = j.messages[n - 1] || {};
			var subj = t.subject || '';
			if (!/^re:/i.test(subj)) subj = 'Re: ' + subj;
			var first = (t.name || (j.customer.customer ? j.customer.customer.name : '') || '').split(' ')[0];
			view.appendChild(replyBox({account_id: t.account_id, thread_id: t.id, to: t.email, subject: subj, first_name: first, order_id: t.order_id || (j.customer.orders[0] ? j.customer.orders[0].id : '')}));
		}
	}

	function setState(state) {
		post('state', {thread_id: S.open, state: state}).then(function (j) { S.counts = j.counts; drawTabs(); openThread(S.open); loadList(); });
	}

	// ---------- reply / compose
	function fill(tpl, ctx) {
		return tpl.replace(/\{(\w+)\}/g, function (m, k) {
			var v = {first_name: ctx.first_name || 'there', name: ctx.first_name || 'there', order_id: ctx.order_id || '', shop: C.shop, shop_url: C.shop_url}[k];
			return v == null ? m : v;
		});
	}

	function replyBox(o) {
		var f = el('form', 'dpci-reply');
		f.setAttribute('aria-label', o.thread_id ? 'Reply' : 'New email');
		function rowF(label, input) { var r = el('div', 'row2'); var l = el('label', null, label); l.htmlFor = input.id; r.appendChild(l); r.appendChild(input); f.appendChild(r); return r; }
		var from = el('select', 'form-control'); from.id = 'dpci-from';
		S.accounts.forEach(function (a) { var op = new Option(a.email + (a.ready ? '' : ' (not connected)'), a.id); op.disabled = !a.ready; from.appendChild(op); });
		from.value = o.account_id || (S.accounts.filter(function (a) { return a.ready; })[0] || {}).id || '';
		rowF('From', from);
		var to = el('input', 'form-control'); to.type = 'text'; to.id = 'dpci-to'; to.value = o.to || ''; to.placeholder = 'customer@example.com';
		rowF('To', to);
		var cc = el('input', 'form-control'); cc.type = 'text'; cc.id = 'dpci-cc'; cc.placeholder = 'Optional';
		var ccRow = rowF('Cc', cc); ccRow.hidden = true;
		var bcc = el('input', 'form-control'); bcc.type = 'text'; bcc.id = 'dpci-bcc'; bcc.placeholder = 'Hidden copies: the other people do not see these';
		var bccRow = rowF('Bcc', bcc); bccRow.hidden = true;
		if (o.cc) { cc.value = o.cc; ccRow.hidden = false; }
		var subject = el('input', 'form-control'); subject.type = 'text'; subject.id = 'dpci-subject'; subject.value = o.subject || '';
		rowF('Subject', subject);
		var tools = el('div', 'dpci-ra');
		tools.style.margin = '4px 0 6px';
		var tpl = el('select', 'form-control'); tpl.style.width = 'auto'; tpl.setAttribute('aria-label', 'Insert a saved reply');
		tpl.appendChild(new Option('Insert a saved reply…', ''));
		(C.templates || []).forEach(function (t, i) { tpl.appendChild(new Option(t.title, i)); });
		tools.appendChild(tpl);
		tools.appendChild(btn('btn btn-link btn-sm', 'Add Cc', function () { ccRow.hidden = false; cc.focus(); }));
		tools.appendChild(btn('btn btn-link btn-sm', 'Add Bcc', function () { bccRow.hidden = false; bcc.focus(); }));
		f.appendChild(tools);
		var ta = el('textarea', 'form-control'); ta.setAttribute('aria-label', 'Message');
		ta.placeholder = o.thread_id ? 'Write your reply. Your signature and the earlier message are added automatically.' : 'Write your message. Your signature is added automatically.';
		if (o.body) { ta.value = o.body; setTimeout(function () { ta.setSelectionRange(0, 0); ta.scrollTop = 0; }, 0); }
		f.appendChild(ta);
		// signature of the chosen address, as it will be added
		var sig = el('div', 'dpci-sig');
		function drawSig() {
			var a = S.accounts.filter(function (x) { return String(x.id) === String(from.value); })[0];
			sig.textContent = a && a.signature ? 'Signature added below:\n' + a.signature : 'No signature for this address. Add one in the Inbox settings.';
		}
		from.addEventListener('change', drawSig); drawSig();
		f.appendChild(sig);
		// attachments: chosen files, the original's when forwarding
		var picked = [];
		var fileList = el('div', 'dpci-files');
		function drawFiles() {
			fileList.textContent = '';
			if (o.forward) (o.forward.attachments || []).filter(function (a) { return a.url; }).forEach(function (a) { fileList.appendChild(el('span', 'dpci-file', '📎 ' + a.name + ' (' + size(a.size) + ', from the original)')); });
			picked.forEach(function (fl, i) {
				var c = el('span', 'dpci-file', '📎 ' + fl.name + ' (' + size(fl.size) + ')');
				var x = btn('', '×', function () { picked.splice(i, 1); drawFiles(); }); x.setAttribute('aria-label', 'Remove ' + fl.name);
				c.appendChild(x); fileList.appendChild(c);
			});
		}
		function addFiles(list) { for (var i = 0; i < list.length; i++) picked.push(list[i]); drawFiles(); }
		f.addEventListener('dragover', function (e) { if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') >= 0) { e.preventDefault(); f.classList.add('drag'); } });
		f.addEventListener('dragleave', function (e) { if (e.target === f) f.classList.remove('drag'); });
		f.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files.length) { e.preventDefault(); f.classList.remove('drag'); addFiles(e.dataTransfer.files); } });
		tpl.addEventListener('change', function () {
			if (tpl.value === '') return;
			var t = C.templates[+tpl.value];
			var text = fill(t.body, o);
			ta.value = ta.value.trim() ? ta.value.replace(/\s+$/, '') + '\n\n' + text : text;
			tpl.value = '';
			ta.focus();
		});
		var ra = el('div', 'dpci-ra');
		var files = el('input'); files.type = 'file'; files.multiple = true; files.style.display = 'none';
		files.addEventListener('change', function () { addFiles(files.files); files.value = ''; });
		var attachBtn = btn('btn btn-default', '📎 Attach files', function () { files.click(); });
		attachBtn.title = 'Or drop files onto the message';
		var send = el('button', 'btn btn-primary', 'Send'); send.type = 'submit';
		ra.appendChild(send);
		var sendDone = null;
		if (o.thread_id) { sendDone = btn('btn btn-default', 'Send and close', function () { go(true); }); ra.appendChild(sendDone); }
		ra.appendChild(attachBtn);
		ra.appendChild(files);
		var msg = el('span', 'msg'); msg.setAttribute('role', 'status');
		ra.appendChild(msg);
		f.appendChild(ra);
		f.appendChild(fileList);
		drawFiles();
		function go(done) {
			var fd = new FormData();
			fd.append('account_id', from.value); fd.append('thread_id', o.thread_id || 0); fd.append('to', to.value); fd.append('cc', cc.value); fd.append('bcc', bcc.value);
			fd.append('subject', subject.value); fd.append('text', ta.value); fd.append('order_id', o.order_id || 0); fd.append('name', o.name || '');
			if (done) fd.append('done', '1');
			picked.forEach(function (fl) { fd.append('files[]', fl, fl.name); });
			if (o.forward) {
				if (o.forward.message_id) fd.append('fwd_message_id', o.forward.message_id);
				else { fd.append('fwd_account', o.forward.account_id); fd.append('fwd_folder', o.forward.folder); fd.append('fwd_uid', o.forward.uid); }
			}
			send.disabled = true; if (sendDone) sendDone.disabled = true;
			msg.style.color = '#6B7885'; msg.textContent = 'Sending…';
			post('send', fd).then(function (j) {
				if (j.error) { msg.style.color = '#C42B1C'; msg.textContent = j.error; return; }
				msg.style.color = '#2E7D4F'; msg.textContent = j.success;
				setTimeout(function () { if (S.mode === 'folder') { view.textContent = ''; view.appendChild(el('div', 'dpci-empty', j.success)); folderCache = {}; } else { openThread(j.thread_id); loadList(); } }, 600);
			}).catch(function () { msg.style.color = '#C42B1C'; msg.textContent = 'Not sent. Check you are still logged in.'; })
				.then(function () { send.disabled = false; if (sendDone) sendDone.disabled = false; });
		}
		f.addEventListener('submit', function (e) { e.preventDefault(); go(false); });
		ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); go(false); } });
		return f;
	}

	function compose(pre) {
		S.open = 0; S.thread = null;
		root.classList.add('viewing');
		view.textContent = '';
		var vh = el('div', 'dpci-vh');
		vh.appendChild(btn('btn btn-default btn-sm dpci-back', '‹ Back', function () { root.classList.remove('viewing'); }));
		vh.appendChild(el('h2', null, pre.title || 'New email'));
		view.appendChild(vh);
		var first = (pre.name || '').split(' ')[0];
		view.appendChild(replyBox({account_id: pre.account_id || 0, thread_id: 0, to: pre.to || '', cc: pre.cc || '', subject: pre.subject || '', first_name: first, order_id: pre.order_id || '', name: pre.name || '', body: pre.body || '', forward: pre.forward || null}));
		var focus = view.querySelector(pre.to ? 'textarea' : '#dpci-to'); if (focus) focus.focus();
	}
	document.getElementById('dpci-new').addEventListener('click', function () { compose({account_id: S.mode === 'folder' ? S.account : 0}); });

	// ---------- server folders (read live from the mail server)
	var folderCache = {};
	function foldersOf(acc) {
		if (folderCache[acc]) return Promise.resolve(folderCache[acc]);
		return get('folders', '&account=' + acc).then(function (j) { if (j.error) throw new Error(j.error); folderCache[acc] = j.folders; return j.folders; });
	}
	// "Move to…" list for one mailbox; cb(folderName, label)
	function moveSelect(acc, cb, notInbox, current) {
		var sel = el('select', 'form-control input-sm');
		sel.style.width = 'auto'; sel.style.height = '30px';
		sel.setAttribute('aria-label', 'Move to a folder');
		sel.appendChild(new Option('Move to…', ''));
		var loaded = false;
		function load() {
			if (loaded) return; loaded = true;
			foldersOf(acc).then(function (fs) {
				fs.forEach(function (f) {
					if (f.use === 'trash' || f.name === current || (notInbox && f.use === 'inbox') || f.use === 'drafts') return;
					sel.appendChild(new Option(f.label, f.name));
				});
			}).catch(function (e) { sel.appendChild(new Option('Folders not available: ' + e.message, '')); });
		}
		sel.addEventListener('focus', load); sel.addEventListener('mousedown', load);
		sel.addEventListener('change', function () { if (!sel.value) return; var v = sel.value, l = sel.options[sel.selectedIndex].text; sel.value = ''; cb(v, l); });
		return sel;
	}

	function setMode(m) {
		S.mode = m;
		modeBox.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.m === m ? 'true' : 'false'); });
		tabs.style.display = m === 'folder' ? 'none' : '';
		accSel.options[0].disabled = m === 'folder';
		search.placeholder = m === 'folder' ? 'Search this folder' : 'Search name, email, subject or text';
		S.open = 0; S.fopen = 0; S.sel = {}; S.fsel = {};
		view.textContent = ''; root.classList.remove('viewing');
		if (m === 'folder') {
			if (!S.account) { var a = S.accounts.filter(function (x) { return x.ready; })[0]; if (!a) { list.textContent = ''; list.appendChild(el('div', 'dpci-empty', 'Connect a mailbox first.')); return; } S.account = a.id; accSel.value = a.id; }
			loadFolders();
		} else {
			loadList();
		}
	}

	function loadFolders() {
		list.textContent = ''; list.appendChild(el('div', 'dpci-empty', 'Reading the folders…'));
		delete folderCache[S.account];
		return foldersOf(S.account).then(function (fs) {
			S.folders = fs;
			if (!S.folder || !fs.some(function (f) { return f.name === S.folder; })) S.folder = (fs.filter(function (f) { return f.use === 'inbox'; })[0] || fs[0] || {}).name || '';
			S.fpage = 1;
			if (!S.fopen && window.innerWidth > 991) { view.textContent = ''; view.appendChild(el('div', 'dpci-empty', 'Choose an email on the left.')); }
			return loadFolder();
		}).catch(function (e) { list.textContent = ''; list.appendChild(el('div', 'dpci-empty', e.message)); });
	}
	function curFolder() { return S.folders.filter(function (f) { return f.name === S.folder; })[0] || {}; }
	function loadFolder(more) {
		return get('folder', '&account=' + S.account + '&folder=' + encodeURIComponent(S.folder) + '&page=' + S.fpage + '&q=' + encodeURIComponent(S.q)).then(function (j) {
			if (j.error) { list.textContent = ''; list.appendChild(el('div', 'dpci-empty', j.error)); return; }
			S.fitems = more ? S.fitems.concat(j.items) : j.items; S.ftotal = j.total;
			if (!more) S.fsel = {};
			drawFolderList();
		});
	}
	function fselected() { return Object.keys(S.fsel).filter(function (k) { return S.fsel[k]; }).map(Number); }
	function folderAct(uids, dest, label) {
		var f = curFolder(), trash = f.use === 'trash' && !dest;
		var q = trash ? 'Delete ' + (uids.length === 1 ? 'this email' : uids.length + ' emails') + ' for good? This cannot be undone.' : dest ? 'Move ' + (uids.length === 1 ? 'this email' : uids.length + ' emails') + ' to ' + label + '?' : 'Move ' + (uids.length === 1 ? 'this email' : uids.length + ' emails') + ' to Trash?';
		if (!window.confirm(q)) return;
		var fd = new FormData();
		fd.append('account', S.account); fd.append('folder', S.folder); fd.append('dest', dest || '');
		uids.forEach(function (u) { fd.append('uids[]', u); });
		post('fmove', fd).then(function (j) {
			if (j.error) { alert(j.error); return; }
			if (uids.indexOf(S.fopen) >= 0) { S.fopen = 0; view.textContent = ''; view.appendChild(el('div', 'dpci-empty', j.forever ? 'Deleted for good.' : 'Moved.')); root.classList.remove('viewing'); }
			folderCache = {};
			loadFolders();
		});
	}
	function drawFolderList() {
		list.textContent = '';
		var nav = el('div', 'dpci-fold');
		nav.setAttribute('role', 'group'); nav.setAttribute('aria-label', 'Folders');
		S.folders.forEach(function (f) {
			var b = btn('', f.label, function () { S.folder = f.name; S.fpage = 1; S.fopen = 0; loadFolder(); });
			b.setAttribute('aria-pressed', f.name === S.folder ? 'true' : 'false');
			if (f.unseen && f.use !== 'trash' && f.use !== 'junk') b.appendChild(el('span', 'u', String(f.unseen)));
			else if (f.messages && (f.use === 'trash' || f.use === 'junk')) b.appendChild(el('span', 'u', String(f.messages)));
			nav.appendChild(b);
		});
		list.appendChild(nav);
		var cf = curFolder();
		var fh = el('div', 'dpci-fhead');
		fh.appendChild(el('span', null, S.ftotal + ' email' + (S.ftotal === 1 ? '' : 's') + (S.q ? ' found' : '') + (cf.use === 'inbox' ? '. The Inbox as it is on the server; Conversations groups the same emails.' : '')));
		if (cf.use === 'trash' && C.can_edit && S.ftotal) fh.appendChild(btn('btn btn-danger btn-xs', 'Empty Trash', function () {
			if (!window.confirm('Delete all ' + S.ftotal + ' emails in Trash for good? This cannot be undone.')) return;
			post('empty_trash', {account: S.account}).then(function (j) { if (j.error) { alert(j.error); return; } folderCache = {}; loadFolders(); });
		}));
		list.appendChild(fh);
		var ids = fselected();
		if (ids.length && C.can_edit) {
			var sb = el('div', 'dpci-selbar');
			sb.appendChild(el('b', null, ids.length + ' selected'));
			sb.appendChild(btn('btn btn-danger btn-xs', cf.use === 'trash' ? 'Delete for good' : 'Delete', function () { folderAct(ids, ''); }));
			if (cf.use === 'junk' || cf.use === 'trash') sb.appendChild(btn('btn btn-default btn-xs', cf.use === 'junk' ? 'Not spam' : 'Restore', function () { folderAct(ids, cf.use === 'junk' ? 'INBOX' : 'RESTORE', cf.use === 'junk' ? 'Inbox' : 'where they came from'); }));
			sb.appendChild(moveSelect(S.account, function (d, l) { folderAct(ids, d, l); }, false, S.folder));
			sb.appendChild(btn('btn btn-link btn-xs', 'Clear', function () { S.fsel = {}; drawFolderList(); }));
			list.appendChild(sb);
		}
		if (!S.fitems.length) { list.appendChild(el('div', 'dpci-empty', S.q ? 'Nothing matches "' + S.q + '".' : 'This folder is empty.')); return; }
		var sentLike = cf.use === 'sent' || cf.use === 'drafts';
		S.fitems.forEach(function (m) {
			var b = el('div', 'dpci-row' + (m.seen ? '' : ' unread'));
			b.setAttribute('role', 'button'); b.tabIndex = 0; b.dataset.id = m.uid;
			b.setAttribute('aria-current', m.uid === S.fopen ? 'true' : 'false');
			var who = sentLike ? 'To: ' + (m.to[0] ? (m.to[0].name || m.to[0].email) : '') : (m.from.name || m.from.email);
			var top = el('div', 't'); top.appendChild(el('span', 'w', who)); top.appendChild(el('span', 'd', when(m.date))); b.appendChild(top);
			b.appendChild(el('div', 's', m.subject || '(no subject)'));
			var pp = el('div', 'p'); if (m.attachments) pp.appendChild(el('span', 'dpci-tag', 'attachment')); pp.appendChild(document.createTextNode(size(m.size))); b.appendChild(pp);
			b.addEventListener('click', function (e) { if (e.target.classList.contains('dpci-ck')) return; openFolderMsg(m.uid); });
			b.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target === b) { e.preventDefault(); openFolderMsg(m.uid); } });
			if (C.can_edit) {
				var ck = el('input', 'dpci-ck'); ck.type = 'checkbox'; ck.checked = !!S.fsel[m.uid];
				ck.setAttribute('aria-label', 'Select ' + (m.subject || 'email'));
				ck.addEventListener('click', function (e) { e.stopPropagation(); });
				ck.addEventListener('change', function () { S.fsel[m.uid] = ck.checked; var keep = list.scrollTop; drawFolderList(); list.scrollTop = keep; });
				b.insertBefore(ck, b.firstChild);
			}
			list.appendChild(b);
		});
		if (S.ftotal > S.fitems.length) list.appendChild(btn('btn btn-link btn-block', 'Show older', function () { S.fpage++; loadFolder(true); }));
	}
	function openFolderMsg(uid) {
		S.fopen = uid;
		root.classList.add('viewing');
		list.querySelectorAll('.dpci-row').forEach(function (r) { r.setAttribute('aria-current', r.dataset.id === String(uid) ? 'true' : 'false'); });
		view.textContent = ''; view.appendChild(el('div', 'dpci-empty', 'Loading…'));
		var acc = S.account, folder = S.folder, cf = curFolder();
		get('fmessage', '&account=' + acc + '&folder=' + encodeURIComponent(folder) + '&uid=' + uid).then(function (j) {
			if (S.fopen !== uid) return;
			view.textContent = '';
			if (j.error) { view.appendChild(el('div', 'dpci-empty', j.error)); return; }
			var m = j.message;
			S.fitems.forEach(function (x) { if (x.uid === uid && !x.seen) { x.seen = true; var r = list.querySelector('.dpci-row[data-id="' + uid + '"]'); if (r) r.classList.remove('unread'); } });
			var vh = el('div', 'dpci-vh');
			vh.appendChild(btn('btn btn-default btn-sm dpci-back', '‹ Back', function () { root.classList.remove('viewing'); }));
			var ht = el('div'); ht.style.flex = '1 1 300px';
			ht.appendChild(el('h2', null, m.subject || '(no subject)'));
			ht.appendChild(el('div', 'sub', cf.label + ' · ' + (S.accounts.filter(function (a) { return a.id === acc; })[0] || {}).email));
			vh.appendChild(ht);
			if (C.can_edit) {
				var acts = el('div'); acts.style.display = 'flex'; acts.style.gap = '6px'; acts.style.flexWrap = 'wrap';
				var replyTo = m.reply_to || m.from.email;
				var quote = '\n\nOn ' + when(m.date, true) + ', ' + (m.from.name || m.from.email) + ' wrote:\n> ' + (m.text || '').replace(/\n/g, '\n> ');
				acts.appendChild(btn('btn btn-primary btn-sm', 'Reply', function () { compose({account_id: acc, to: replyTo, subject: /^re:/i.test(m.subject) ? m.subject : 'Re: ' + m.subject, body: quote, title: 'Reply'}); }));
				var me = (S.accounts.filter(function (a) { return a.id === acc; })[0] || {}).email;
				var others = m.to.concat(m.cc).map(function (a) { return a.email; }).filter(function (e) { return e !== me && e !== replyTo; });
				if (others.length) acts.appendChild(btn('btn btn-default btn-sm', 'Reply all', function () { compose({account_id: acc, to: replyTo, cc: others.join(', '), subject: /^re:/i.test(m.subject) ? m.subject : 'Re: ' + m.subject, body: quote, title: 'Reply all'}); }));
				acts.appendChild(btn('btn btn-default btn-sm', 'Forward', function () { forwardMsg({account_id: acc, folder: folder, uid: uid, from: m.from.email, from_name: m.from.name, date: m.date, subject: m.subject, to: m.to, text: m.text, attachments: m.attachments}); }));
				if (cf.use === 'junk' || cf.use === 'trash') acts.appendChild(btn('btn btn-default btn-sm', cf.use === 'junk' ? 'Not spam' : 'Restore', function () { folderAct([uid], cf.use === 'junk' ? 'INBOX' : 'RESTORE', cf.use === 'junk' ? 'Inbox' : 'where it came from'); }));
				acts.appendChild(moveSelect(acc, function (d, l) { folderAct([uid], d, l); }, false, folder));
				acts.appendChild(btn('btn btn-danger btn-sm', cf.use === 'trash' ? 'Delete for good' : 'Delete', function () { folderAct([uid], ''); }));
				vh.appendChild(acts);
			}
			view.appendChild(vh);
			var msgs = el('div', 'dpci-msgs');
			msgs.appendChild(message({direction: cf.use === 'sent' ? 'out' : 'in', from: m.from.email, from_name: m.from.name, to: m.to, cc: m.cc, date: m.date, text: m.text, html: m.html, attachments: m.attachments}, false));
			view.appendChild(msgs);
		});
	}

	// ---------- sync
	function sync(quiet) {
		if (S.syncing) return Promise.resolve();
		S.syncing = true;
		syncBtn.disabled = true;
		syncText.textContent = 'Checking…';
		return get('sync', quiet ? '&quick=1' : '').then(function (j) {
			S.accounts = S.accounts.map(function (a) { var n = j.accounts.filter(function (x) { return x.id === a.id; })[0]; return n ? Object.assign(a, n) : a; });
			drawWarn();
			S.counts = j.counts;
			var d = new Date(); syncText.textContent = 'Checked at ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + (j.new ? ' · ' + j.new + ' new' : '');
			return S.mode === 'conv' ? loadList() : null;
		}).catch(function () { syncText.textContent = 'Could not check. Are you still logged in?'; })
			.then(function () { S.syncing = false; syncBtn.disabled = false; });
	}

	// ---------- start
	modeBox.querySelector('[data-m=conv]').setAttribute('aria-pressed', 'true');
	modeBox.querySelector('[data-m=folder]').setAttribute('aria-pressed', 'false');
	drawTabs();
	drawWarn();
	var start = C.open ? (S.filter = 'all', drawTabs(), loadList().then(function () { openThread(C.open); })) : loadList();
	start.then(function () {
		if (C.compose && C.compose.to) compose(C.compose);
		else if (!C.open && window.innerWidth > 991) view.appendChild(el('div', 'dpci-empty', 'Choose a conversation on the left.'));
		return sync(true);
	});
	setInterval(function () { if (!document.hidden) sync(true); }, 90000);
})();
