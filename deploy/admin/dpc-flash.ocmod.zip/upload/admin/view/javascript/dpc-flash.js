/* dpCREATOR Flash station (admin). Wraps the Flash Firmware page's tools: every flash and install they do
   is logged per device. Controllers get their chip ID from the WebUI/Studio install or the "Read chip ID" button. */
(function () {
	'use strict';
	var C = window.DPFS;
	if (!C) return;

	var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
	var short = function (v) { return String(v || '').split(/\s/)[0]; };

	function api(f, body, form, q) {
		var o = { method: body ? 'POST' : 'GET', credentials: 'same-origin', headers: {} };
		if (body && form) {
			var fd = new FormData();
			Object.keys(body).forEach(function (k) {
				if (Array.isArray(body[k])) body[k].forEach(function (v) { fd.append(k + '[]', v); });
				else fd.append(k, body[k]);
			});
			o.body = fd;
		} else if (body) {
			o.headers['Content-Type'] = 'application/json';
			o.body = JSON.stringify(body);
		}
		return ofetch(C.api + '&f=' + f + (q || ''), o).then(function (r) { return r.text(); }).then(function (t) {
			try { return JSON.parse(t); } catch (e) { return { error: /password/.test(t) ? 'The admin session has expired. Log in again.' : 'The server answered with an error.' }; }
		});
	}

	// ------------------------------------------------------------------ watch what the tools do
	var ofetch = window.fetch.bind(window);
	var versions = {};          // fw -> build, from f=version answers
	var pendant = null;         // chip ID registered for the pendant being flashed
	var pendingCtrl = null;     // a controller flashed, chip ID not known yet
	var lastCtrl = 0;           // device_id of the controller handled last in this session
	var session = [];

	function bodyText(b) {
		if (!b) return '';
		if (typeof b === 'string') return b;
		if (b instanceof URLSearchParams) return b.toString();
		return '';
	}

	// Controller firmware comes from the admin (same cached build as the shop), so no shop login is needed here
	function adminFw(u, init) {
		var f = u.searchParams.get('f');
		if (f === 'access') {
			return Promise.resolve(new Response(JSON.stringify({ logged_in: true, entitled: true, access: 'admin', download: true }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
		}
		if (f === 'manifest' || f === 'bin') {
			// ask the shop's firmware server first, so it checks GitHub for a newer build
			return ofetch('/fw.php?fw=controller&f=version', { credentials: 'same-origin' }).catch(function () {}).then(function () {
				return ofetch(C.api + '&f=' + (f === 'manifest' ? 'fwmanifest' : 'fwbin'), { credentials: 'same-origin' });
			});
		}
		return null;
	}

	window.fetch = function (input, init) {
		var url = String(input && input.url || input);
		var p = null;
		try {
			var uu = new URL(url, location.href);
			if (uu.pathname.split('/').pop() === 'fw.php' && uu.searchParams.get('fw') === 'controller') p = adminFw(uu, init);
		} catch (e) {}
		if (!p) p = ofetch(input, init);
		try {
			var u = new URL(url, location.href);
			var file = u.pathname.split('/').pop();
			var f = u.searchParams.get('f');
			var fw = u.searchParams.get('fw');
			var body = bodyText(init && init.body);
			if (file === 'fw.php' && f === 'version') {
				p.then(function (r) { return r.clone().json(); }).then(function (j) { versions[fw] = short(j.version); }).catch(function () {});
			} else if (/^(webui|studio|studio-pro)\.php$/.test(file) && f === 'version') {
				p.then(function (r) { return r.clone().json(); }).then(function (j) { versions[file.replace('.php', '')] = short(j.version || j.build); }).catch(function () {});
			} else if (file === 'fw.php' && fw === 'pendant' && f === 'licence') {
				var id = (body.match(/(?:^|&)id=([0-9A-Fa-f:]+)/) || [])[1] || '';
				p.then(function (r) { return r.clone().json(); }).then(function (j) {
					pendant = { chip_id: id, firmware: short(j.version) || versions.pendant || '', licence_to: (String(j.licence || '').match(/\nto=(.*)\n/) || [])[1] || '' };
				}).catch(function () {});
			} else if (file === 'fw.php' && f === 'done') {
				if (fw === 'pendant') {
					var pd = pendant || {};
					record({ kind: 'pendant', what: 'flash', chip_id: pd.chip_id || '', chip: 'ESP32', firmware: pd.firmware || versions.pendant || '', licence_to: pd.licence_to || '' });
					pendant = null;
				} else {
					pendingCtrl = { firmware: versions[fw] || versions.controller || '', at: new Date() };
					banner();
				}
			} else if (/^(webui|studio|studio-pro)\.php$/.test(file) && f === 'install') {
				var board = '';
				try { board = (JSON.parse(body || '{}').board || ''); } catch (e) {}
				p.then(function (r) {
					if (!r.ok) return;
					var what = file === 'webui.php' ? 'webui' : 'studio';
					var ver = versions[file.replace('.php', '')] || '';
					var ev = { kind: 'controller', what: what, chip_id: board, chip: 'ESP32-S3', device_id: lastCtrl };
					ev[what] = (file === 'studio-pro.php' ? 'Pro ' : '') + ver;
					if (pendingCtrl && board) {
						flashCtrl(board).then(function () { record(ev); });
					} else {
						record(ev);
					}
				});
			}
		} catch (e) {}
		return p;
	};

	function flashCtrl(chip) {
		var pc = pendingCtrl;
		pendingCtrl = null;
		banner();
		return record({ kind: 'controller', what: 'flash', chip_id: chip, chip: 'ESP32-S3', firmware: pc ? pc.firmware : '' });
	}

	function record(ev) {
		return api('event', ev).then(function (j) {
			if (j.error) { toast(j.error, true); return; }
			var d = j.device;
			if (d.kind === 'controller') lastCtrl = d.device_id;
			if (session.indexOf(d.device_id) < 0) session.push(d.device_id);
			toast((d.kind === 'pendant' ? 'Pendant ' : 'Controller ') + (d.chip_id || '#' + d.device_id) + ': ' + (ev.what === 'flash' ? 'flash logged' : ev.what === 'webui' ? 'WebUI install logged' : ev.what === 'studio' ? 'Studio install logged' : 'logged'));
			load();
		});
	}

	// Reads the chip ID of whatever is on the USB port, then restarts it
	function readChip() {
		var transport = null;
		return import('https://unpkg.com/esptool-js@0.5.4/bundle.js').then(function (m) {
			return navigator.serial.requestPort({}).then(function (port) {
				transport = new m.Transport(port, false);
				var loader = new m.ESPLoader({ transport: transport, baudrate: 115200, romBaudrate: 115200, terminal: { clean: function () {}, writeLine: function () {}, write: function () {} } });
				return loader.main().then(function (chip) {
					return loader.chip.readMac(loader).then(function (mac) {
						return loader.after('hard_reset').catch(function () {}).then(function () { return { chip: chip, id: mac.replace(/:/g, '').toUpperCase() }; });
					});
				});
			});
		}).finally(function () { if (transport) return transport.disconnect().catch(function () {}); });
	}

	// ------------------------------------------------------------------ the log panel
	var root = document.getElementById('dpfs-log');
	var S = { status: 'all', kind: 'all', q: '', rows: [], counts: {}, stock: {}, sel: {} };
	try { var saved = JSON.parse(sessionStorage.getItem('dpfs') || '{}'); S.status = saved.status || 'all'; S.kind = saved.kind || 'all'; } catch (e) {}

	var css = document.createElement('style');
	css.textContent = ''
		+ '.dpfs-page .dpfs-sub{margin:4px 0 0;color:#5F6C78}'
		+ '#dpfs-log{background:#fff;border:1px solid #E3E8ED;border-radius:8px;padding:14px 16px;margin-bottom:16px;color:#1E2A35}'
		+ '#dpfs-log h2{font-size:17px;font-weight:700;margin:0}'
		+ '#dpfs-log .hd{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:10px}#dpfs-log .hd .sp{flex:1}'
		+ '#dpfs-log .bt{border:1px solid #CFD7DE;background:#fff;color:#1E2A35;border-radius:6px;padding:5px 11px;font-weight:600;font-size:12.5px;cursor:pointer}'
		+ '#dpfs-log .bt.pri{background:#1F6FB8;border-color:#1F6FB8;color:#fff}#dpfs-log .bt[disabled]{opacity:.5;cursor:default}'
		+ '#dpfs-log .bt:focus-visible,#dpfs-log select:focus-visible,#dpfs-log textarea:focus-visible{outline:2px solid #1F6FB8;outline-offset:2px}'
		+ '#dpfs-log select,#dpfs-log input[type=search]{height:30px;font-size:13px;border:1px solid #CFD7DE;border-radius:6px;padding:0 8px;background:#fff}'
		+ '#dpfs-log .seg{display:inline-flex;border:1px solid #CFD7DE;border-radius:6px;overflow:hidden}#dpfs-log .seg button{border:0;background:#fff;padding:5px 10px;font-size:12.5px;cursor:pointer;color:#5F6C78;border-right:1px solid #E3E8ED}#dpfs-log .seg button:last-child{border:0}#dpfs-log .seg button[aria-pressed=true]{background:#1E2A35;color:#fff}'
		+ '#dpfs-log table{width:100%;border-collapse:collapse;font-size:13px}'
		+ '#dpfs-log th{font-size:12px;color:#5F6C78;text-align:left;padding:6px;border-bottom:1px solid #E3E8ED;white-space:nowrap}'
		+ '#dpfs-log td{padding:7px 6px;border-bottom:1px solid #F0F2F4;vertical-align:top}'
		+ '#dpfs-log td small{display:block;color:#5F6C78;font-size:11.5px}'
		+ '#dpfs-log .chip{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px}'
		+ '#dpfs-log textarea{width:100%;min-height:34px;font-size:12.5px;border:1px solid #E3E8ED;border-radius:6px;padding:4px 6px;resize:vertical}'
		+ '#dpfs-log .st{font-size:12.5px;height:28px}#dpfs-log .st.ok{border-color:#1E8A57;color:#155E3B}#dpfs-log .st.fail{border-color:#C42B1C;color:#8A1F14}#dpfs-log .st.scrap{color:#5F6C78}'
		+ '#dpfs-log .pill{display:inline-block;font-size:11px;font-weight:700;border-radius:10px;padding:1px 8px;background:#EEF1F4;color:#5F6C78}#dpfs-log .pill.in{background:#E3F4EB;color:#155E3B}#dpfs-log .pill.new{background:#FBF0DC;color:#7A4A00}'
		+ '#dpfs-log .ban{background:#FFF6E5;border:1px solid #F2D399;color:#5C3B00;border-radius:8px;padding:8px 10px;margin-bottom:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}'
		+ '#dpfs-log .warn{background:#FFF6E5;border:1px solid #F2D399;color:#5C3B00;border-radius:8px;padding:8px 10px;margin:8px 0;font-size:13px}'
		+ '#dpfs-log .foot{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:10px}'
		+ '#dpfs-log .empty{color:#5F6C78;padding:10px 0}'
		+ '#dpfs-toast{position:fixed;right:20px;bottom:80px;background:#1E2A35;color:#fff;border-radius:8px;padding:10px 14px;font-size:13px;opacity:0;transition:opacity .2s;pointer-events:none;z-index:9999;max-width:420px}#dpfs-toast.on{opacity:1}#dpfs-toast.bad{background:#C42B1C}'
		+ '.dpfs-modal{position:fixed;inset:0;background:rgba(20,28,36,.45);z-index:9000;display:flex;align-items:flex-start;justify-content:center;padding:5vh 16px}'
		+ '.dpfs-modal>div{background:#fff;border-radius:10px;width:min(900px,100%);padding:16px 18px;max-height:88vh;display:flex;flex-direction:column}'
		+ '.dpfs-modal pre{flex:1;overflow:auto;background:#0E1217;color:#D6DEE6;border-radius:6px;padding:10px;font-size:12px;white-space:pre-wrap;margin:10px 0}'
		+ '.dpfs-tools{margin-top:6px;background:#11161C;color:#E8EEF4;border-radius:8px;padding:18px 18px 8px}.dpfs-tools a{color:#7FC4F5}';
	document.head.appendChild(css);

	var tEl = document.createElement('div');
	tEl.id = 'dpfs-toast';
	tEl.setAttribute('role', 'status');
	document.body.appendChild(tEl);
	function toast(m, bad) { tEl.textContent = m; tEl.className = 'on' + (bad ? ' bad' : ''); clearTimeout(toast.t); toast.t = setTimeout(function () { tEl.className = ''; }, 4500); }

	function remember() { try { sessionStorage.setItem('dpfs', JSON.stringify({ status: S.status, kind: S.kind })); } catch (e) {} }

	function load() {
		return api('list', null, false, '&status=' + S.status + '&kind=' + S.kind + '&q=' + encodeURIComponent(S.q)).then(function (j) {
			if (j.error) { root.innerHTML = '<div class="warn">' + esc(j.error) + '</div>'; return; }
			S.rows = j.rows; S.counts = j.counts || {}; S.stock = j.stock || {};
			draw();
		});
	}

	function count(kind, st) { var c = S.counts[kind] || {}; return st ? (c[st] || 0) : Object.keys(c).reduce(function (a, k) { return a + c[k]; }, 0); }

	var STATUS = { 'new': 'Not tested', ok: 'Passed', fail: 'Failed', scrap: 'Scrapped' };

	function banner() {
		var b = root.querySelector('.ban');
		if (!pendingCtrl) { if (b) b.remove(); return; }
		var html = '<b>Controller flashed with ' + esc(pendingCtrl.firmware || 'the latest build') + '.</b> <span>Install the WebUI or Studio to log it with its chip ID, or:</span>'
			+ '<button type="button" class="bt pri" data-a="readchip">Read chip ID</button><button type="button" class="bt" data-a="nochip">Log without chip ID</button>';
		if (b) b.innerHTML = html; else { var d = document.createElement('div'); d.className = 'ban'; d.innerHTML = html; root.insertBefore(d, root.firstChild); }
	}

	function draw() {
		var segs = function (name, opts, cur) {
			return '<div class="seg" role="group" aria-label="' + name + '">' + opts.map(function (o) { return '<button type="button" data-' + name + '="' + o[0] + '" aria-pressed="' + (o[0] === cur) + '">' + esc(o[1]) + '</button>'; }).join('') + '</div>';
		};
		var tot = count('controller') + count('pendant');
		var h = '<div class="hd"><h2>Devices</h2><span class="sp"></span>'
			+ segs('kind', [['all', 'All'], ['controller', 'Controllers ' + count('controller')], ['pendant', 'Pendants ' + count('pendant')]], S.kind)
			+ segs('status', [['all', 'Any'], ['new', 'Not tested'], ['ok', 'Passed'], ['fail', 'Failed'], ['scrap', 'Scrapped']], S.status)
			+ '<input type="search" placeholder="Chip ID or note" value="' + esc(S.q) + '" aria-label="Search devices">'
			+ (C.can ? '<button type="button" class="bt" data-a="add">Add by chip ID</button>' : '') + '</div>';
		if (session.length) h += '<p class="empty" style="padding:0 0 8px">This session: ' + session.length + ' device' + (session.length > 1 ? 's' : '') + ' logged.</p>';
		if (!S.rows.length) {
			h += '<p class="empty">' + (tot ? 'No devices match.' : 'Nothing flashed yet. Flash a controller or pendant with the tools below: each one is logged here, with its chip ID, build and your notes.') + '</p>';
		} else {
			h += '<table><thead><tr><th></th><th>Device</th><th>Builds</th><th>Flashed</th><th>Status</th><th style="width:34%">Notes for debugging</th><th></th></tr></thead><tbody>'
				+ S.rows.map(function (r) {
					var builds = [r.firmware ? 'fw ' + r.firmware : '', r.webui ? 'WebUI ' + r.webui : '', r.studio ? 'Studio ' + r.studio : ''].filter(Boolean).join('<br>');
					return '<tr data-id="' + r.device_id + '"><td>' + (+r.batch_id ? '' : '<input type="checkbox" aria-label="Select"' + (S.sel[r.device_id] ? ' checked' : '') + '>') + '</td>'
						+ '<td><b>' + (r.kind === 'pendant' ? 'Pendant' : 'Controller') + '</b> <span class="chip">' + esc(r.chip_id || 'no chip ID') + '</span>'
						+ '<small>' + esc(r.chip || '') + (r.licence_to ? ' · licence: ' + esc(r.licence_to) : '') + (+r.order_id ? ' · order #' + r.order_id : '') + '</small>'
						+ (+r.batch_id ? '<span class="pill in">In stock · batch #' + r.batch_id + '</span>' : '') + '</td>'
						+ '<td><small style="color:#1E2A35">' + (builds || '–') + '</small></td>'
						+ '<td>' + esc(String(r.last_flash || '').slice(0, 16)) + '<small>' + (+r.flashes) + ' flash' + (+r.flashes === 1 ? '' : 'es') + ' · ' + esc(r.user) + '</small></td>'
						+ '<td><select class="st ' + r.status + '" aria-label="Status"' + (C.can ? '' : ' disabled') + '>' + Object.keys(STATUS).map(function (k) { return '<option value="' + k + '"' + (k === r.status ? ' selected' : '') + '>' + STATUS[k] + '</option>'; }).join('') + '</select></td>'
						+ '<td><textarea aria-label="Notes"' + (C.can ? '' : ' disabled') + ' placeholder="What you tested, what went wrong…">' + esc(r.notes) + '</textarea></td>'
						+ '<td style="white-space:nowrap"><button type="button" class="bt" data-a="log">History' + (+r.log_len > 0 ? '' : '') + '</button> '
						+ (C.can ? '<button type="button" class="bt" data-a="term" title="Add what the Board tools terminal shows to this device">+ Terminal</button>' : '') + '</td></tr>';
				}).join('') + '</tbody></table>';
		}
		var nsel = Object.keys(S.sel).filter(function (k) { return S.sel[k]; }).length;
		if (C.can) {
			h += '<div class="foot"><button type="button" class="bt pri" data-a="stock"' + (nsel ? '' : ' disabled') + '>Put ' + (nsel || '') + ' selected in stock</button>'
				+ '<span class="empty" style="padding:0">Passed devices become a batch in <a href="' + esc(C.stock) + '">Purchases and stock</a>: the parts from the product\'s recipe are used up and the shop stock goes up.</span></div>';
			['controller', 'pendant'].forEach(function (k) { var s = S.stock[k]; if (s && !s.ready) h += '<div class="warn">' + (k === 'pendant' ? 'Pendants' : 'Controllers') + ': ' + esc(s.why) + '</div>'; else if (s && !s.recipe) h += '<div class="warn">' + (k === 'pendant' ? 'Pendants' : 'Controllers') + ': "' + esc(s.name) + '" has no recipe yet, so a batch would add stock without using up any parts. Add the recipe in Purchases and stock.</div>'; });
		}
		root.innerHTML = h;
		banner();
	}

	function sel(id, on) { if (on) S.sel[id] = 1; else delete S.sel[id]; var b = root.querySelector('[data-a=stock]'); var n = Object.keys(S.sel).length; if (b) { b.disabled = !n; b.textContent = 'Put ' + (n || '') + ' selected in stock'; } }

	function modal(title, html, foot) {
		var m = document.createElement('div');
		m.className = 'dpfs-modal';
		m.innerHTML = '<div role="dialog" aria-modal="true" aria-label="' + esc(title) + '"><h3 style="margin:0;font-size:17px;font-weight:700">' + esc(title) + '</h3>' + html + '<div style="display:flex;gap:8px;justify-content:flex-end">' + (foot || '') + '<button type="button" class="bt" data-x>Close</button></div></div>';
		m.addEventListener('click', function (e) { if (e.target === m || e.target.hasAttribute('data-x')) m.remove(); });
		document.body.appendChild(m);
		return m;
	}

	// Text the Board tools terminal is showing (its biggest output box)
	function terminalText() {
		var scope = document.getElementById('dpct-term') || document.querySelector('[id^="dpct-term"]') || document.querySelector('.dpfs-tools');
		var best = '';
		(scope ? scope.querySelectorAll('pre, textarea, .log, [class*="out"]') : []).forEach(function (el) {
			var t = el.value !== undefined && el.tagName === 'TEXTAREA' ? el.value : el.textContent;
			if (t && t.length > best.length) best = t;
		});
		return best.trim();
	}

	root.addEventListener('click', function (e) {
		var b = e.target.closest('button');
		if (!b) return;
		if (b.dataset.kind !== undefined) { S.kind = b.dataset.kind; S.sel = {}; remember(); load(); return; }
		if (b.dataset.status !== undefined) { S.status = b.dataset.status; S.sel = {}; remember(); load(); return; }
		var a = b.dataset.a;
		var tr = b.closest('tr');
		var id = tr ? +tr.dataset.id : 0;
		var row = S.rows.filter(function (r) { return +r.device_id === id; })[0];
		if (a === 'readchip') {
			if (!('serial' in navigator)) { toast('Reading the chip ID needs Chrome or Edge.', true); return; }
			b.disabled = true;
			readChip().then(function (r) {
				if (!/S3/.test(r.chip)) toast('That is an ' + r.chip + ' (a pendant?), not the R3. Check the port.', true);
				else flashCtrl(r.id);
			}).catch(function (er) { if (!er || er.name !== 'NotFoundError') toast('Could not read the chip: ' + (er && er.message || er), true); }).finally(function () { b.disabled = false; });
		} else if (a === 'nochip') {
			flashCtrl('');
		} else if (a === 'add') {
			var m = modal('Add a device by chip ID', '<div style="display:grid;gap:8px;margin-top:10px"><label>Type <select name="k"><option value="controller">Controller (R3)</option><option value="pendant">Pendant</option></select></label><label>Chip ID <input name="c" class="form-control" placeholder="e.g. 3C84279E1A2C"></label><p class="empty" style="margin:0">Or connect it by USB and read it:</p><div><button type="button" class="bt" data-r>Read chip ID</button></div></div>', '<button type="button" class="bt pri" data-s>Add</button>');
			m.querySelector('[data-r]').onclick = function () { readChip().then(function (r) { m.querySelector('[name=c]').value = r.id; m.querySelector('[name=k]').value = /S3/.test(r.chip) ? 'controller' : 'pendant'; }).catch(function (er) { if (!er || er.name !== 'NotFoundError') toast(String(er && er.message || er), true); }); };
			m.querySelector('[data-s]').onclick = function () {
				var c = m.querySelector('[name=c]').value.trim();
				if (!/^[0-9A-Fa-f:]{6,}$/.test(c)) { toast('Enter the chip ID (letters A–F and numbers).', true); return; }
				var k = m.querySelector('[name=k]').value;
				record({ kind: k, what: 'chipid', chip_id: c, chip: k === 'pendant' ? 'ESP32' : 'ESP32-S3' }).then(function () { m.remove(); });
			};
		} else if (a === 'log' && row) {
			api('device', null, false, '&id=' + id).then(function (j) {
				if (j.error) { toast(j.error, true); return; }
				var d = j.device;
				var mm = modal('History · ' + (d.kind === 'pendant' ? 'pendant ' : 'controller ') + (d.chip_id || '#' + d.device_id), '<pre>' + esc(d.log || 'Nothing yet.') + '</pre>', '<button type="button" class="bt" data-c>Copy</button>');
				mm.querySelector('[data-c]').onclick = function () { try { navigator.clipboard.writeText(d.log || ''); toast('Copied.'); } catch (er) {} };
			});
		} else if (a === 'term' && row) {
			var t = terminalText();
			if (!t) { toast('The Board tools terminal is empty. Open Board tools, connect and run what you need first.', true); return; }
			api('addlog', { device_id: id, text: t, title: 'terminal log' }).then(function (j) { if (j.error) toast(j.error, true); else toast('Terminal log (' + t.split('\n').length + ' lines) added to ' + (row.chip_id || '#' + id) + '.'); });
		} else if (a === 'stock') {
			var ids = Object.keys(S.sel).map(Number);
			var rows = S.rows.filter(function (r) { return S.sel[r.device_id]; });
			if (rows.some(function (r) { return r.status !== 'ok'; })) { toast('Mark the devices as Passed first: only tested devices go in stock.', true); return; }
			var kind = rows[0] && rows[0].kind;
			if (rows.some(function (r) { return r.kind !== kind; })) { toast('Put controllers and pendants in stock separately.', true); return; }
			var info = S.stock[kind] || {};
			if (!window.confirm('Put ' + ids.length + ' ' + (kind === 'pendant' ? 'pendant' : 'controller') + (ids.length > 1 ? 's' : '') + ' in stock as "' + (info.name || '') + '"? This adds them to the shop stock and uses up their parts from the recipe.')) return;
			var go = function (allow) {
				b.disabled = true;
				api('stock', { ids: ids, allow_short: allow ? 1 : 0 }, true).then(function (j) {
					b.disabled = false;
					if (j.error) {
						if (/Not enough in stock/.test(j.error) && !allow && window.confirm(j.error.replace(/ Receive the invoice.*$/, '') + '\n\nPut them in stock anyway?')) { go(true); return; }
						toast(j.error, true); return;
					}
					S.sel = {};
					toast(j.n + ' in stock (batch #' + j.batch_id + ').');
					load();
				});
			};
			go(false);
		}
	});
	root.addEventListener('change', function (e) {
		var tr = e.target.closest('tr');
		if (!tr) return;
		var id = +tr.dataset.id;
		if (e.target.type === 'checkbox') { sel(id, e.target.checked); return; }
		if (e.target.classList.contains('st')) {
			api('save', { device_id: id, status: e.target.value }).then(function (j) {
				if (j.error) { toast(j.error, true); load(); return; }
				e.target.className = 'st ' + e.target.value;
				var r = S.rows.filter(function (x) { return +x.device_id === id; })[0]; if (r) r.status = e.target.value;
			});
		}
	});
	root.addEventListener('focusout', function (e) {
		if (e.target.tagName !== 'TEXTAREA') return;
		var tr = e.target.closest('tr');
		var id = +tr.dataset.id;
		var r = S.rows.filter(function (x) { return +x.device_id === id; })[0];
		if (!r || r.notes === e.target.value) return;
		api('save', { device_id: id, notes: e.target.value }).then(function (j) { if (j.error) toast(j.error, true); else { r.notes = e.target.value; toast('Note saved.'); } });
	});
	root.addEventListener('input', function (e) {
		if (e.target.type !== 'search') return;
		clearTimeout(S.t);
		S.t = setTimeout(function () { S.q = e.target.value; load().then(function () { var s = root.querySelector('input[type=search]'); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } }); }, 300);
	});

	root.innerHTML = '<p class="empty">Loading devices…</p>';
	load();

})();
