<?php
$_['heading_title'] = 'dpCREATOR Flash station (flash and log boards and pendants)';
