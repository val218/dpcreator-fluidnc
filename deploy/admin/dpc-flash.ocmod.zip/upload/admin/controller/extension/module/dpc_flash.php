<?php
// dpCREATOR Flash station: the Flash Firmware page's tools inside the admin, for flashing the boards and pendants
// you build. Every flash and install is logged per device (chip ID, build, status, debug notes, terminal logs),
// and devices that passed can be put in stock as a batch in Purchases and stock.
class ControllerExtensionModuleDpcFlash extends Controller {
	private $T;

	public function __construct($registry) {
		parent::__construct($registry);
		$this->T = DB_PREFIX . 'dpc_flash_device';
	}

	public function install() {
		$this->table();
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_flash', array('module_dpc_flash_status' => 1, 'module_dpc_flash_page' => 8));
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_flash');
		$this->model_setting_event->addEvent('dpc_flash', 'admin/view/common/column_left/before', 'extension/module/dpc_flash/menu');
	}

	public function uninstall() {
		// The device log stays: it is the record of what was flashed.
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_flash');
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_flash');
	}

	private function table() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `{$this->T}` (
			`device_id` INT NOT NULL AUTO_INCREMENT, `kind` VARCHAR(16) NOT NULL, `chip_id` VARCHAR(32) NOT NULL DEFAULT '', `chip` VARCHAR(32) NOT NULL DEFAULT '',
			`firmware` VARCHAR(64) NOT NULL DEFAULT '', `webui` VARCHAR(64) NOT NULL DEFAULT '', `studio` VARCHAR(64) NOT NULL DEFAULT '', `licence_to` VARCHAR(160) NOT NULL DEFAULT '',
			`status` VARCHAR(8) NOT NULL DEFAULT 'new', `notes` TEXT, `log` MEDIUMTEXT, `flashes` INT NOT NULL DEFAULT 0, `batch_id` INT NOT NULL DEFAULT 0, `order_id` INT NOT NULL DEFAULT 0,
			`first_flash` DATETIME NULL, `last_flash` DATETIME NULL, `user` VARCHAR(64) NOT NULL DEFAULT '', `created` DATETIME NOT NULL, `modified` DATETIME NOT NULL,
			PRIMARY KEY (`device_id`), KEY `chip_id` (`chip_id`), KEY `status` (`status`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	private function e($s) { return $this->db->escape((string)$s); }
	private function out($x) { $this->response->addHeader('Content-Type: application/json'); $this->response->setOutput(json_encode($x)); }
	private function fail($m) { $this->out(array('error' => $m)); }
	private function input() { $j = json_decode(file_get_contents('php://input'), true); return is_array($j) ? $j : $this->request->post; }
	private function link($route, $q = '') { return html_entity_decode($this->url->link($route, 'user_token=' . $this->session->data['user_token'] . ($q ? '&' . $q : ''), true), ENT_QUOTES, 'UTF-8'); }
	private function cfg($k, $d = '') { $v = $this->config->get('module_dpc_flash_' . $k); return $v === null || $v === '' ? $d : $v; }
	private function hasTable($t) { return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e(DB_PREFIX . $t) . "'")->num_rows; }

	// ------------------------------------------------------------------ menu entry
	public function menu(&$route, &$data, &$output) {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_flash') || !(int)$this->config->get('module_dpc_flash_status') || !isset($data['menus']) || !is_array($data['menus'])) {
			return;
		}
		$entry = array('id' => 'menu-dpc-flash', 'icon' => 'fa-bolt', 'name' => 'Flash station', 'href' => $this->link('extension/module/dpc_flash'), 'children' => array());
		// after Catalog when it is there
		$pos = count($data['menus']);
		foreach ($data['menus'] as $i => $m) {
			if (isset($m['id']) && $m['id'] === 'menu-catalog') {
				$pos = $i + 1;
			}
		}
		array_splice($data['menus'], $pos, 0, array($entry));
	}

	// ------------------------------------------------------------------ the page
	public function index() {
		$this->load->language('extension/module/dpc_flash');
		$this->document->setTitle('Flash station');
		$this->table();
		$page = (int)$this->cfg('page', 8);
		$r = $this->db->query("SELECT description FROM `" . DB_PREFIX . "information_description` WHERE information_id = '" . $page . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "'")->row;
		$tools = $r ? html_entity_decode($r['description'], ENT_QUOTES, 'UTF-8') : '<p>The Flash Firmware page (information page ' . $page . ') was not found.</p>';
		$conf = array(
			'api' => $this->link('extension/module/dpc_flash/api'),
			'stock' => $this->link('extension/module/dpc_stock'),
			'can' => $this->user->hasPermission('modify', 'extension/module/dpc_flash') ? 1 : 0,
			'shop' => HTTPS_CATALOG,
		);
		$html = '<div id="content" class="dpfs-page"><div class="page-header"><div class="container-fluid"><h1>Flash station</h1>'
			. '<p class="dpfs-sub">The same tools as the shop\'s Flash Firmware page, for the boards and pendants you build. Every flash and install is logged below, per device. <a href="' . HTTPS_CATALOG . 'fw.php?f=licences" target="_blank" rel="noopener">Licences and registered devices</a></p></div></div>'
			. '<div class="container-fluid">'
			. '<div id="dpfs-log"></div>'
			. '<div id="dpfs-access" class="alert alert-info" style="display:none"></div>'
			// before the tools, so it sees every request they make
			. '<script>window.DPFS=' . json_encode($conf) . ';</script>'
			. '<script src="view/javascript/dpc-flash.js?v=5"></script>'
			. '<div class="dpfs-tools">' . $tools . '</div>'
			. '</div></div>';
		$this->response->setOutput($this->load->controller('common/header') . $this->load->controller('common/column_left') . $html . $this->load->controller('common/footer'));
	}

	// ------------------------------------------------------------------ data
	public function api() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_flash')) {
			return $this->fail('No access to the Flash station.');
		}
		$this->table();
		$f = isset($this->request->get['f']) ? $this->request->get['f'] : 'list';
		if (in_array($f, array('event', 'save', 'addlog', 'stock'), true) && !$this->user->hasPermission('modify', 'extension/module/dpc_flash')) {
			return $this->fail('You may look but not change the device log.');
		}
		$m = 'f_' . $f;
		if (!method_exists($this, $m)) {
			return $this->fail('Unknown request.');
		}
		try {
			$this->$m();
		} catch (\Throwable $e) {
			$this->fail($e->getMessage());
		}
	}

	private function row($id) {
		return $this->db->query("SELECT * FROM `{$this->T}` WHERE device_id = '" . (int)$id . "'")->row;
	}

	private function f_list() {
		$g = $this->request->get;
		$w = '1';
		if (!empty($g['status']) && $g['status'] !== 'all') {
			$w .= " AND status = '" . $this->e($g['status']) . "'";
		}
		if (!empty($g['kind']) && $g['kind'] !== 'all') {
			$w .= " AND kind = '" . $this->e($g['kind']) . "'";
		}
		if (!empty($g['q'])) {
			$q = $this->e('%' . $g['q'] . '%');
			$w .= " AND (chip_id LIKE '$q' OR notes LIKE '$q' OR firmware LIKE '$q')";
		}
		$rows = $this->db->query("SELECT device_id, kind, chip_id, chip, firmware, webui, studio, licence_to, status, notes, LENGTH(log) AS log_len, flashes, batch_id, order_id, first_flash, last_flash, user FROM `{$this->T}` WHERE " . $w . " ORDER BY COALESCE(last_flash, created) DESC, device_id DESC LIMIT 300")->rows;
		$counts = array();
		foreach ($this->db->query("SELECT kind, status, COUNT(*) AS n FROM `{$this->T}` GROUP BY kind, status")->rows as $c) {
			$counts[$c['kind']][$c['status']] = (int)$c['n'];
		}
		$this->out(array('rows' => $rows, 'counts' => $counts, 'stock' => $this->stockInfo()));
	}

	// A flash or install seen on the page. in: kind, chip_id, chip, firmware, webui, studio, licence_to, device_id (optional), what
	private function f_event() {
		$in = $this->input();
		$kind = in_array(isset($in['kind']) ? $in['kind'] : '', array('controller', 'pendant'), true) ? $in['kind'] : 'controller';
		$chip = strtoupper(preg_replace('/[^0-9A-Fa-f:]/', '', (string)(isset($in['chip_id']) ? $in['chip_id'] : '')));
		$chip = str_replace(':', '', $chip);
		$what = isset($in['what']) ? (string)$in['what'] : 'flash';
		$d = null;
		if ($chip !== '') {
			$d = $this->db->query("SELECT * FROM `{$this->T}` WHERE chip_id = '" . $this->e($chip) . "' AND kind = '" . $this->e($kind) . "'")->row;
		}
		if (!$d && !empty($in['device_id'])) {
			$d = $this->row($in['device_id']);
			if ($d && $d['chip_id'] !== '' && $chip !== '' && $d['chip_id'] !== $chip) {
				$d = null;
			}
		}
		$set = array();
		foreach (array('chip', 'firmware', 'webui', 'studio', 'licence_to') as $k) {
			if (isset($in[$k]) && $in[$k] !== '') {
				$set[] = "`$k` = '" . $this->e(mb_substr((string)$in[$k], 0, 160)) . "'";
			}
		}
		if ($chip !== '') {
			$set[] = "chip_id = '" . $this->e($chip) . "'";
		}
		$stamp = date('Y-m-d H:i') . ' ' . $this->user->getUserName() . ': ';
		$line = $stamp . ($what === 'flash' ? 'flashed ' . (isset($in['firmware']) ? $in['firmware'] : '') : ($what === 'webui' ? 'WebUI installed ' . (isset($in['webui']) ? $in['webui'] : '') : ($what === 'studio' ? 'Studio installed ' . (isset($in['studio']) ? $in['studio'] : '') : ($what === 'motion' ? 'Motion installed ' . (isset($in['motion']) ? $in['motion'] : '') : ($what === 'chipid' ? 'chip ID read' : $what)))));
		if ($what === 'flash') {
			$set[] = "flashes = flashes + 1";
			$set[] = "last_flash = NOW()";
			$set[] = "first_flash = COALESCE(first_flash, NOW())";
		}
		$set[] = "modified = NOW()";
		if ($d) {
			$this->db->query("UPDATE `{$this->T}` SET " . implode(', ', $set) . ", log = CONCAT(COALESCE(log, ''), '" . $this->e("\n[" . trim($line) . "]\n") . "') WHERE device_id = '" . (int)$d['device_id'] . "'");
			$id = (int)$d['device_id'];
		} else {
			$this->db->query("INSERT INTO `{$this->T}` SET kind = '" . $kind . "', " . implode(', ', $set) . ", status = 'new', notes = '', log = '" . $this->e('[' . trim($line) . "]\n") . "', user = '" . $this->e($this->user->getUserName()) . "', created = NOW()");
			$id = (int)$this->db->getLastId();
		}
		$this->out(array('ok' => 1, 'device' => $this->row($id)));
	}

	private function f_save() {
		$in = $this->input();
		$d = $this->row(isset($in['device_id']) ? $in['device_id'] : 0);
		if (!$d) {
			return $this->fail('Device not found.');
		}
		$set = array("modified = NOW()");
		if (isset($in['status']) && in_array($in['status'], array('new', 'ok', 'fail', 'scrap'), true)) {
			if ((int)$d['batch_id'] && $in['status'] !== 'ok') {
				return $this->fail('This device is already in stock (batch #' . (int)$d['batch_id'] . '). Take it out of stock in Purchases and stock first.');
			}
			$set[] = "status = '" . $in['status'] . "'";
		}
		if (isset($in['notes'])) {
			$set[] = "notes = '" . $this->e(mb_substr((string)$in['notes'], 0, 20000)) . "'";
		}
		if (isset($in['chip_id']) && $d['chip_id'] === '') {
			$set[] = "chip_id = '" . $this->e(strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', $in['chip_id']))) . "'";
		}
		if (isset($in['order_id'])) {
			$set[] = "order_id = '" . (int)$in['order_id'] . "'";
		}
		$this->db->query("UPDATE `{$this->T}` SET " . implode(', ', $set) . " WHERE device_id = '" . (int)$d['device_id'] . "'");
		$this->out(array('ok' => 1, 'device' => $this->row($d['device_id'])));
	}

	// Terminal output or anything else pasted to a device, kept with a time stamp
	private function f_addlog() {
		$in = $this->input();
		$d = $this->row(isset($in['device_id']) ? $in['device_id'] : 0);
		if (!$d) {
			return $this->fail('Device not found.');
		}
		$t = trim((string)(isset($in['text']) ? $in['text'] : ''));
		if ($t === '') {
			return $this->fail('Nothing to add.');
		}
		$t = mb_substr($t, -200000);
		$this->db->query("UPDATE `{$this->T}` SET log = CONCAT(COALESCE(log, ''), '" . $this->e("\n[" . date('Y-m-d H:i') . ' ' . $this->user->getUserName() . ': ' . (isset($in['title']) ? mb_substr($in['title'], 0, 80) : 'terminal log') . "]\n" . $t . "\n") . "'), modified = NOW() WHERE device_id = '" . (int)$d['device_id'] . "'");
		$this->out(array('ok' => 1));
	}

	// ------------------------------------------------------------------ controller firmware for admins
	// The shop's firmware server (fw.php) only knows the shop's customer login, and logging in to the shop and the
	// admin in one browser can push one of them out. So the admin serves the same cached build itself.
	private function fwFile($ext) {
		$dir = rtrim(dirname(rtrim(DIR_APPLICATION, '/')), '/') . '/fw-cache/';
		return $dir . 'controller.' . $ext;
	}

	private function f_fwmanifest() {
		$meta = is_file($this->fwFile('json')) ? (json_decode(file_get_contents($this->fwFile('json')), true) ?: array()) : array();
		if (!is_file($this->fwFile('bin'))) {
			return $this->fail('No controller build on the server yet. Open the shop\'s Flash Firmware page once so it fetches the latest build.');
		}
		$sha = isset($meta['sha256']) ? substr($meta['sha256'], 0, 12) : (string)filemtime($this->fwFile('bin'));
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode(array(
			'name' => 'dpCREATOR controller firmware',
			'version' => isset($meta['version']) ? $meta['version'] : '',
			'home_page' => HTTPS_CATALOG,
			'new_install_prompt_erase' => true,
			'builds' => array(array('chipFamily' => 'ESP32-S3', 'parts' => array(array('path' => $this->link('extension/module/dpc_flash/api', 'f=fwbin&v=' . $sha), 'offset' => 0)))),
		), JSON_UNESCAPED_SLASHES));
	}

	private function f_fwbin() {
		$bin = $this->fwFile('bin');
		if (!is_file($bin)) {
			return $this->fail('No controller build on the server.');
		}
		$this->response->addHeader('Content-Type: application/octet-stream');
		$this->response->addHeader('Cache-Control: private, no-store');
		$this->response->setOutput(file_get_contents($bin));
	}

	private function f_device() {
		$d = $this->row(isset($this->request->get['id']) ? $this->request->get['id'] : 0);
		if (!$d) {
			return $this->fail('Device not found.');
		}
		$this->out(array('device' => $d));
	}

	// ------------------------------------------------------------------ stock: devices that passed become a batch in Purchases and stock
	private function stockItem($kind) {
		if (!$this->hasTable('dpc_inv_item')) {
			return null;
		}
		$pid = $kind === 'pendant' ? (int)$this->cfg('pendant_product', 382) : (int)$this->cfg('controller_product', 381);
		$it = $this->db->query("SELECT i.*, pd.name AS pname FROM `" . DB_PREFIX . "dpc_inv_item` i LEFT JOIN `" . DB_PREFIX . "product_description` pd ON pd.product_id = i.product_id AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "' WHERE i.kind = 'product' AND i.status = 1 AND i.product_id = '" . $pid . "' ORDER BY i.item_id LIMIT 1")->row;
		return $it ?: array('missing' => 1, 'product_id' => $pid);
	}

	private function stockInfo() {
		$o = array();
		foreach (array('controller', 'pendant') as $k) {
			$it = $this->stockItem($k);
			if (!$it) {
				$o[$k] = array('ready' => 0, 'why' => 'Purchases and stock is not installed.');
			} elseif (!empty($it['missing'])) {
				$o[$k] = array('ready' => 0, 'why' => 'No finished product in Purchases and stock is linked to shop product #' . $it['product_id'] . '.');
			} else {
				$rec = $this->db->query("SELECT recipe_id FROM `" . DB_PREFIX . "dpc_inv_recipe` WHERE item_id = '" . (int)$it['item_id'] . "'")->row;
				$o[$k] = array('ready' => 1, 'item_id' => (int)$it['item_id'], 'name' => $it['name'] ?: $it['pname'], 'recipe' => $rec ? 1 : 0);
			}
		}
		return $o;
	}

	private function f_stock() {
		$in = $this->input();
		$ids = array_values(array_filter(array_map('intval', (array)(isset($in['ids']) ? $in['ids'] : array()))));
		if (!$ids) {
			return $this->fail('Tick the devices to put in stock.');
		}
		$rows = $this->db->query("SELECT * FROM `{$this->T}` WHERE device_id IN (" . implode(',', $ids) . ")")->rows;
		$kinds = array_unique(array_column($rows, 'kind'));
		if (count($kinds) !== 1) {
			return $this->fail('Put controllers and pendants in stock separately.');
		}
		foreach ($rows as $r) {
			if ($r['status'] !== 'ok') {
				return $this->fail('Only devices marked "Passed" can go in stock (' . ($r['chip_id'] ?: '#' . $r['device_id']) . ' is not).');
			}
			if ((int)$r['batch_id']) {
				return $this->fail(($r['chip_id'] ?: '#' . $r['device_id']) . ' is already in stock (batch #' . (int)$r['batch_id'] . ').');
			}
		}
		$kind = $kinds[0];
		$it = $this->stockItem($kind);
		if (!$it || !empty($it['missing'])) {
			return $this->fail('Link a finished product to shop product #' . ($kind === 'pendant' ? 382 : 381) . ' in Purchases and stock first.');
		}
		$n = count($rows);
		// Parts from the product's recipe, times the number of devices
		$uses = array();
		$labourH = 0;
		$grams = 0;
		$hours = 0;
		$pack = 0;
		$rec = $this->db->query("SELECT * FROM `" . DB_PREFIX . "dpc_inv_recipe` WHERE item_id = '" . (int)$it['item_id'] . "'")->row;
		if ($rec) {
			foreach ($this->db->query("SELECT item_id, qty FROM `" . DB_PREFIX . "dpc_inv_recipe_line` WHERE recipe_id = '" . (int)$rec['recipe_id'] . "'")->rows as $l) {
				$uses[] = array('item_id' => (int)$l['item_id'], 'qty' => (float)$l['qty'] * $n);
			}
			$labourH = (float)$rec['labour_min'] * $n / 60;
			$grams = (float)$rec['print_grams'] * $n;
			$hours = (float)$rec['print_hours'] * $n;
			$pack = (float)$rec['packaging'];
		}
		$chips = implode(', ', array_map(function ($r) { return $r['chip_id'] ?: '#' . $r['device_id']; }, $rows));
		$post = array('item_id' => (int)$it['item_id'], 'date' => date('Y-m-d'), 'started' => $n, 'passed' => $n, 'labour_hours' => round($labourH, 2), 'print_grams' => $grams, 'print_hours' => $hours,
			'print_invoice' => 0, 'packaging_each' => $pack, 'extra' => 0, 'uses' => $uses, 'note' => 'Flash station: ' . $chips, 'allow_short' => !empty($in['allow_short']) ? 1 : 0);
		$j = $this->stockApi('save_batch', $post);
		if (isset($j['error'])) {
			return $this->fail($j['error']);
		}
		$bid = (int)$j['batch_id'];
		$this->db->query("UPDATE `{$this->T}` SET batch_id = '" . $bid . "', modified = NOW(), log = CONCAT(COALESCE(log, ''), '" . $this->e("\n[" . date('Y-m-d H:i') . ' ' . $this->user->getUserName() . ': put in stock, batch #' . $bid . "]\n") . "') WHERE device_id IN (" . implode(',', $ids) . ")");
		$this->out(array('ok' => 1, 'batch_id' => $bid, 'n' => $n, 'recipe' => $rec ? 1 : 0));
	}

	// Calls the Purchases and stock module in-process, as this admin user
	private function stockApi($f, $post) {
		if (!is_file(DIR_APPLICATION . 'controller/extension/module/dpc_stock.php')) {
			return array('error' => 'Purchases and stock is not installed.');
		}
		if (!$this->user->hasPermission('modify', 'extension/module/dpc_stock')) {
			return array('error' => 'Your admin user may not change stock.');
		}
		$saveGet = $this->request->get;
		$savePost = $this->request->post;
		$saveOut = $this->response->getOutput();
		$this->request->get = array('route' => 'extension/module/dpc_stock/api', 'user_token' => $this->session->data['user_token'], 'f' => $f);
		$this->request->post = $post;
		$this->load->controller('extension/module/dpc_stock/api');
		$res = $this->response->getOutput();
		$this->request->get = $saveGet;
		$this->request->post = $savePost;
		$this->response->setOutput($saveOut);
		$j = json_decode((string)$res, true);
		return is_array($j) ? $j : array('error' => 'Purchases and stock did not answer.');
	}
}
