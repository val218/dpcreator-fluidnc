<?php
// dpCREATOR safety register: complaints, incidents and safety issues about products sold
// (EU General Product Safety Regulation 2023/988). Records are never deleted; a case is closed.
class ControllerExtensionModuleDpcSafety extends Controller {
	private function T() { return DB_PREFIX . 'dpc_safety'; }

	public function install() {
		$this->table();
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_safety', array('module_dpc_safety_status' => 1));
	}

	public function uninstall() {
		// The register is a record you must keep: the table stays.
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_safety');
	}

	private function table() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->T() . "` (
			`case_id` INT NOT NULL AUTO_INCREMENT, `received` DATE NOT NULL, `source` VARCHAR(32) NOT NULL DEFAULT 'email',
			`customer` VARCHAR(160) NOT NULL DEFAULT '', `contact` VARCHAR(160) NOT NULL DEFAULT '', `order_id` INT NOT NULL DEFAULT 0,
			`product_id` INT NOT NULL DEFAULT 0, `product` VARCHAR(255) NOT NULL DEFAULT '', `serial` VARCHAR(64) NOT NULL DEFAULT '', `country` VARCHAR(64) NOT NULL DEFAULT '',
			`kind` VARCHAR(16) NOT NULL DEFAULT 'complaint', `description` TEXT, `injury` VARCHAR(10) NOT NULL DEFAULT 'none', `damage` TEXT,
			`risk` VARCHAR(10) NOT NULL DEFAULT 'unknown', `cause` TEXT, `action` TEXT,
			`reported` TINYINT NOT NULL DEFAULT 0, `reported_date` DATE NULL, `reported_ref` VARCHAR(64) NOT NULL DEFAULT '',
			`status` VARCHAR(8) NOT NULL DEFAULT 'open', `closed` DATE NULL, `created` DATETIME NOT NULL, `modified` DATETIME NOT NULL, `user` VARCHAR(64) NOT NULL DEFAULT '',
			PRIMARY KEY (`case_id`), KEY `received` (`received`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	private function lists() {
		return array(
			'source' => array('email' => 'Email', 'phone' => 'Phone', 'review' => 'Review or forum', 'return' => 'Return', 'own' => 'Found by us', 'authority' => 'Authority', 'other' => 'Other'),
			'kind' => array('complaint' => 'Complaint', 'incident' => 'Incident (something happened)', 'nearmiss' => 'Near miss', 'defect' => 'Defect found', 'question' => 'Safety question'),
			'injury' => array('none' => 'No injury', 'minor' => 'Minor injury', 'serious' => 'Serious injury', 'death' => 'Death'),
			'risk' => array('unknown' => 'Not assessed yet', 'low' => 'Low', 'medium' => 'Medium', 'high' => 'High', 'serious' => 'Serious'),
		);
	}

	private function d($v) { $t = strtotime((string)$v); return ($v !== '' && $t) ? date('Y-m-d', $t) : ''; }
	private function e($s) { return $this->db->escape((string)$s); }

	public function index() {
		$this->load->language('extension/module/dpc_safety');
		$this->document->setTitle('Safety register');
		$this->table();
		$token = 'user_token=' . $this->session->data['user_token'];
		$can = $this->user->hasPermission('modify', 'extension/module/dpc_safety');
		$data['error'] = '';
		$data['success'] = '';
		if (!empty($this->session->data['dpc_safety_ok'])) {
			$data['success'] = $this->session->data['dpc_safety_ok'];
			unset($this->session->data['dpc_safety_ok']);
		}
		$L = $this->lists();
		$edit = isset($this->request->get['case_id']) ? (int)$this->request->get['case_id'] : null;

		if ($this->request->server['REQUEST_METHOD'] === 'POST') {
			$p = $this->request->post;
			if (!$can) {
				$data['error'] = 'You do not have permission to change the safety register.';
			} elseif (trim(isset($p['description']) ? $p['description'] : '') === '') {
				$data['error'] = 'Describe what was reported.';
			} else {
				$pick = function ($k, $def) use ($p, $L) { return isset($p[$k]) && isset($L[$k][$p[$k]]) ? $p[$k] : $def; };
				$pid = (int)(isset($p['product_id']) ? $p['product_id'] : 0);
				$pname = trim(isset($p['product']) ? $p['product'] : '');
				if ($pid) {
					$r = $this->db->query("SELECT name FROM `" . DB_PREFIX . "product_description` WHERE product_id = '" . $pid . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "'")->row;
					$pname = $r ? html_entity_decode($r['name'], ENT_QUOTES, 'UTF-8') : '';
				}
				$status = isset($p['status']) && $p['status'] === 'closed' ? 'closed' : 'open';
				$closed = $status === 'closed' ? ($this->d(isset($p['closed']) ? $p['closed'] : '') ?: date('Y-m-d')) : '';
				$rep = !empty($p['reported']) ? 1 : 0;
				$set = "received = '" . $this->e($this->d($p['received']) ?: date('Y-m-d')) . "', source = '" . $this->e($pick('source', 'email')) . "', customer = '" . $this->e(trim($p['customer'])) . "', contact = '" . $this->e(trim($p['contact'])) . "',
					order_id = '" . (int)$p['order_id'] . "', product_id = '" . $pid . "', product = '" . $this->e($pname) . "', serial = '" . $this->e(trim($p['serial'])) . "', country = '" . $this->e(trim($p['country'])) . "',
					kind = '" . $this->e($pick('kind', 'complaint')) . "', description = '" . $this->e(trim($p['description'])) . "', injury = '" . $this->e($pick('injury', 'none')) . "', damage = '" . $this->e(trim($p['damage'])) . "',
					risk = '" . $this->e($pick('risk', 'unknown')) . "', cause = '" . $this->e(trim($p['cause'])) . "', action = '" . $this->e(trim($p['action'])) . "',
					reported = '" . $rep . "', reported_date = " . ($rep && $this->d($p['reported_date']) ? "'" . $this->e($this->d($p['reported_date'])) . "'" : 'NULL') . ", reported_ref = '" . $this->e(trim($p['reported_ref'])) . "',
					status = '" . $status . "', closed = " . ($closed ? "'" . $closed . "'" : 'NULL') . ", modified = NOW(), user = '" . $this->e($this->user->getUserName()) . "'";
				$id = (int)(isset($p['case_id']) ? $p['case_id'] : 0);
				if ($id) {
					$this->db->query("UPDATE `" . $this->T() . "` SET " . $set . " WHERE case_id = '" . $id . "'");
				} else {
					$this->db->query("INSERT INTO `" . $this->T() . "` SET " . $set . ", created = NOW()");
					$id = (int)$this->db->getLastId();
				}
				$this->session->data['dpc_safety_ok'] = 'Case #' . $id . ' saved.' . ((in_array($pick('injury', 'none'), array('serious', 'death'), true) || $pick('risk', 'unknown') === 'serious') && !$rep ? ' Serious injury or serious risk: report it without delay through the EU Safety Business Gateway, then tick "Reported to the authority".' : '');
				$this->response->redirect($this->url->link('extension/module/dpc_safety', $token, true));
				return;
			}
			$edit = isset($p['case_id']) ? (int)$p['case_id'] : 0;
		}

		$g = $this->request->get;
		$filter = array('status' => isset($g['status']) && in_array($g['status'], array('open', 'closed', 'all'), true) ? $g['status'] : 'all', 'year' => isset($g['year']) ? (int)$g['year'] : 0);
		$data['filter'] = $filter;
		$data['cases'] = $this->cases($filter);
		$data['years'] = array_map(function ($r) { return (int)$r['y']; }, $this->db->query("SELECT DISTINCT YEAR(received) AS y FROM `" . $this->T() . "` ORDER BY y DESC")->rows);
		$data['open_count'] = (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . $this->T() . "` WHERE status = 'open'")->row['n'];
		$data['lists'] = $L;
		$lang = (int)$this->config->get('config_language_id');
		$data['products'] = array_map(function ($r) { $r['name'] = html_entity_decode($r['name'], ENT_QUOTES, 'UTF-8'); return $r; }, $this->db->query("SELECT p.product_id, pd.name, p.model FROM `" . DB_PREFIX . "product` p LEFT JOIN `" . DB_PREFIX . "product_description` pd ON pd.product_id = p.product_id AND pd.language_id = '" . $lang . "' WHERE p.shipping = 1 ORDER BY pd.name")->rows);
		$blank = array('case_id' => 0, 'received' => date('Y-m-d'), 'source' => 'email', 'customer' => '', 'contact' => '', 'order_id' => '', 'product_id' => 0, 'product' => '', 'serial' => '', 'country' => '', 'kind' => 'complaint', 'description' => '', 'injury' => 'none', 'damage' => '', 'risk' => 'unknown', 'cause' => '', 'action' => '', 'reported' => 0, 'reported_date' => '', 'reported_ref' => '', 'status' => 'open', 'closed' => '');
		// Prefill from an order (?order_id=123)
		if ($edit === null && !empty($g['order_id'])) {
			$o = $this->db->query("SELECT o.order_id, o.firstname, o.lastname, o.email, COALESCE(cs.name, cp.name, '') AS country FROM `" . DB_PREFIX . "order` o LEFT JOIN `" . DB_PREFIX . "country` cs ON cs.country_id = o.shipping_country_id LEFT JOIN `" . DB_PREFIX . "country` cp ON cp.country_id = o.payment_country_id WHERE o.order_id = '" . (int)$g['order_id'] . "'")->row;
			if ($o) {
				$blank = array_merge($blank, array('order_id' => $o['order_id'], 'customer' => trim($o['firstname'] . ' ' . $o['lastname']), 'contact' => $o['email'], 'country' => $o['country']));
				$edit = 0;
			}
		}
		$data['case'] = $blank;
		$data['show_form'] = $edit !== null;
		if ($edit) {
			$c = $this->db->query("SELECT * FROM `" . $this->T() . "` WHERE case_id = '" . (int)$edit . "'")->row;
			if ($c) {
				$data['case'] = $c;
			}
		}
		if ($this->request->server['REQUEST_METHOD'] === 'POST' && $data['error']) {
			$data['case'] = array_merge($blank, array_intersect_key($this->request->post, $blank));
			$data['show_form'] = true;
		}
		$data['can_modify'] = $can;
		$data['action'] = $this->url->link('extension/module/dpc_safety', $token, true);
		$data['new_link'] = $this->url->link('extension/module/dpc_safety', $token . '&case_id=0', true);
		$data['base'] = $this->url->link('extension/module/dpc_safety', $token, true);
		$data['csv'] = $this->url->link('extension/module/dpc_safety/csv', $token . '&status=' . $filter['status'] . '&year=' . $filter['year'], true);
		$data['user_token'] = $this->session->data['user_token'];
		$data['cancel'] = $this->url->link('marketplace/extension', $token . '&type=module', true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_safety', $data));
	}

	private function cases($f) {
		$w = '1';
		if ($f['status'] !== 'all') {
			$w .= " AND status = '" . $this->e($f['status']) . "'";
		}
		if ($f['year']) {
			$w .= " AND YEAR(received) = '" . (int)$f['year'] . "'";
		}
		$rows = $this->db->query("SELECT * FROM `" . $this->T() . "` WHERE " . $w . " ORDER BY received DESC, case_id DESC")->rows;
		$L = $this->lists();
		$token = 'user_token=' . $this->session->data['user_token'];
		foreach ($rows as &$r) {
			$r['edit'] = $this->url->link('extension/module/dpc_safety', $token . '&case_id=' . $r['case_id'], true);
			$r['order_link'] = $r['order_id'] ? $this->url->link('sale/order/info', $token . '&order_id=' . $r['order_id'], true) : '';
			foreach (array('kind', 'injury', 'risk', 'source') as $k) {
				$r[$k . '_label'] = isset($L[$k][$r[$k]]) ? $L[$k][$r[$k]] : $r[$k];
			}
			$r['days_open'] = $r['status'] === 'open' ? (int)floor((time() - strtotime($r['received'])) / 86400) : null;
		}
		return $rows;
	}

	public function csv() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_safety')) {
			$this->response->redirect($this->url->link('error/permission', 'user_token=' . $this->session->data['user_token'], true));
			return;
		}
		$this->table();
		$g = $this->request->get;
		$f = array('status' => isset($g['status']) && in_array($g['status'], array('open', 'closed', 'all'), true) ? $g['status'] : 'all', 'year' => isset($g['year']) ? (int)$g['year'] : 0);
		$rows = $this->cases($f);
		$out = fopen('php://temp', 'w+');
		fwrite($out, "\xEF\xBB\xBF");
		fputcsv($out, array('Case', 'Received', 'Source', 'Type', 'Customer', 'Contact', 'Order', 'Product', 'Serial / chip ID', 'Country', 'What was reported', 'Injury', 'Damage', 'Risk', 'Cause found', 'Action taken', 'Reported to authority', 'Reported on', 'Authority reference', 'Status', 'Closed on', 'Last changed by'));
		foreach ($rows as $r) {
			fputcsv($out, array($r['case_id'], $r['received'], $r['source_label'], $r['kind_label'], $r['customer'], $r['contact'], $r['order_id'] ?: '', $r['product'], $r['serial'], $r['country'], $r['description'], $r['injury_label'], $r['damage'], $r['risk_label'], $r['cause'], $r['action'], $r['reported'] ? 'yes' : 'no', $r['reported_date'], $r['reported_ref'], $r['status'], $r['closed'], $r['user']));
		}
		rewind($out);
		$csv = stream_get_contents($out);
		fclose($out);
		$this->response->addHeader('Content-Type: text/csv; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="safety-register-' . date('Y-m-d') . '.csv"');
		$this->response->setOutput($csv);
	}
}
