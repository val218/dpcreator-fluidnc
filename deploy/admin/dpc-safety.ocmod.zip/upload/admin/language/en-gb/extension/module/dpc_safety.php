<?php
$_['heading_title'] = 'dpCREATOR Safety register (complaints and incidents)';
