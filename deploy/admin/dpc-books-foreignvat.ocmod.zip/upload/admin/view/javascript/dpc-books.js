/* dpCREATOR Books: admin page. Talks to extension/module/dpc_books/api. */
(function () {
  'use strict';
  var C = window.DPB || {};
  var main = document.getElementById('dpb-main');
  var S = null, tab = 'overview', seq = 0;
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var TYPE = { a: 'Assets', l: 'Owed by the company', e: 'Equity', i: 'Income', x: 'Costs' };
  var STATUS = { todo: 'To do', ready: 'File ready', submitted: 'Submitted', notneeded: 'Not needed', check: 'Watching', off: 'Off' };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isNaN(n) ? 0 : n; }
  function eur(v) { var n = num(v); return (n < 0 ? '−' : '') + '€' + Math.abs(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function whole(v) { var n = Math.round(num(v)); return (n < 0 ? '−' : '') + Math.abs(n).toLocaleString('en-GB'); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function dshort(d) { var p = String(d).split('-'); return p.length === 3 ? (+p[2]) + ' ' + MON[+p[1] - 1] + ' ' + p[0] : d; }
  function toast(msg, bad) {
    var t = document.getElementById('dpb-toast');
    t.textContent = msg; t.className = 'on' + (bad ? ' bad' : '');
    clearTimeout(t._h); t._h = setTimeout(function () { t.className = ''; }, bad ? 6000 : 3000);
  }
  function api(f, body, query) {
    var url = C.api + '&f=' + encodeURIComponent(f) + (query ? '&' + Object.keys(query).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(query[k]); }).join('&') : '');
    var opt = { credentials: 'same-origin' };
    if (body instanceof FormData) { opt.method = 'POST'; opt.body = body; }
    else if (body) { opt.method = 'POST'; opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(body); }
    return fetch(url, opt).then(function (r) { return r.text(); }).then(function (t) {
      var j; try { j = JSON.parse(t); } catch (e) { throw new Error('The server answered with something that is not data. Your login may have expired: reload the page.'); }
      if (j && j.error) throw new Error(j.error);
      return j;
    });
  }
  function acc(code) { for (var i = 0; i < (S ? S.accounts.length : 0); i++) if (S.accounts[i].code === code) return S.accounts[i]; return null; }
  function accName(code) { var a = acc(code); return a ? code + ' ' + (a.name_en || a.name) : code; }
  function accSelect(name, value, filter, blank) {
    var h = '<select name="' + name + '">' + (blank ? '<option value="">' + esc(blank) + '</option>' : '');
    ['a', 'l', 'e', 'i', 'x'].forEach(function (t) {
      var list = S.accounts.filter(function (a) { return a.type === t && +a.status === 1 && (!filter || filter(a)); });
      if (!list.length) return;
      h += '<optgroup label="' + TYPE[t] + '">' + list.map(function (a) { return '<option value="' + a.code + '"' + (a.code === String(value) ? ' selected' : '') + '>' + a.code + ' ' + esc(a.name_en || a.name) + '</option>'; }).join('') + '</optgroup>';
    });
    return h + '</select>';
  }
  function val(root, name) { var el = root.querySelector('[name="' + name + '"]'); if (!el) return ''; return el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value; }
  function modal(title, body, foot) {
    var m = document.createElement('div');
    m.className = 'dpb-modal';
    m.innerHTML = '<div role="dialog" aria-modal="true" aria-label="' + esc(title) + '"><h3>' + esc(title) + '</h3><div class="mb">' + body + '</div><div class="foot">' + (foot || '') + '<button type="button" class="dpb-btn" data-close>Close</button></div></div>';
    document.body.appendChild(m);
    m.addEventListener('click', function (e) { if (e.target === m || e.target.hasAttribute('data-close')) m.remove(); });
    document.addEventListener('keydown', function k(e) { if (e.key === 'Escape') { m.remove(); document.removeEventListener('keydown', k); } });
    var f = m.querySelector('input,select,textarea,button'); if (f) f.focus();
    return m;
  }
  function busy(btn, on) { if (btn) { btn.disabled = on; } }
  function ro() { return !+C.can; }

  // ------------------------------------------------------------------ tabs
  document.querySelectorAll('.dpb-tabs button').forEach(function (b) {
    b.addEventListener('click', function () { go(b.getAttribute('data-tab')); });
  });
  function go(t) {
    tab = t;
    document.querySelectorAll('.dpb-tabs button').forEach(function (b) { b.setAttribute('aria-selected', b.getAttribute('data-tab') === t ? 'true' : 'false'); });
    try { var u = new URL(location.href); u.searchParams.set('tab', t); history.replaceState(null, '', u.toString()); } catch (e) {}
    render();
  }
  function render() {
    var my = ++seq;
    var fn = { overview: overview, returns: returns, expenses: expenses, bank: bank, journal: journal, reports: reports, settings: settings }[tab] || overview;
    main.innerHTML = '<p class="dpb-mut">Loading…</p>';
    Promise.resolve(fn(my)).catch(function (e) { if (my === seq) main.innerHTML = '<div class="dpb-err">' + esc(e.message) + '</div>'; });
  }
  function load() { return api('state').then(function (s) { S = s; return s; }); }

  // ------------------------------------------------------------------ overview
  function dueRow(f) {
    var late = f.days < 0 && f.status !== 'submitted', soon = f.days >= 0 && f.days <= 7;
    var p = String(f.due).split('-');
    var when = f.status === 'submitted' ? 'Submitted' + (f.eds_no ? ' (EDS ' + esc(f.eds_no) + ')' : '') : late ? (-f.days) + ' days late' : f.days === 0 ? 'Due today' : 'Due in ' + f.days + ' days';
    var hint = { UIN: 'Corporate income tax. Pay any tax by the 23rd.', GP: 'Balance sheet, profit or loss and notes.', DDZ: 'Wages, social tax and income tax.', PVN: 'VAT return.', PVNP: f.note || 'VAT you pay yourself on services from foreign suppliers.', SEC: 'Change the Expires line on the site and upload it.' }[f.kind] || '';
    if (f.status === 'check') hint = 'Only needed if something taxable happens this month (a dividend, a cost not for the business).';
    return '<div class="dpb-due' + (late ? ' late' : soon ? ' soon' : '') + '"><div class="dpb-date"><b>' + (+p[2]) + '</b><span>' + MON[+p[1] - 1] + '</span></div>' +
      '<div><b>' + esc(f.title) + '</b> <span class="dpb-pill ' + (late ? 'late' : f.status) + '">' + (late ? 'Late' : STATUS[f.status] || f.status) + '</span><p>' + when + '. ' + hint + '</p></div>' +
      '<div>' + (['UIN', 'GP'].indexOf(f.kind) >= 0 && f.status !== 'notneeded' && f.status !== 'off' ? '<button type="button" class="dpb-btn sm" data-open="' + f.filing_id + '">' + (f.status === 'submitted' ? 'View' : 'Prepare') + '</button>' : (f.status === 'todo' ? '<button type="button" class="dpb-btn sm" data-mark="' + f.filing_id + '">Mark submitted</button>' : '')) + '</div></div>';
  }
  function meter(label, v, lim, note) {
    var pct = lim ? Math.min(100, v / lim * 100) : 0;
    return '<div style="margin-bottom:10px"><div class="dpb-row" style="justify-content:space-between"><b>' + esc(label) + '</b><span>' + eur(v) + ' of ' + eur(lim) + '</span></div>' +
      '<div class="dpb-meter' + (pct >= 100 ? ' over' : pct >= 75 ? ' hot' : '') + '"><i style="width:' + pct.toFixed(1) + '%"></i></div><small class="dpb-mut">' + note + '</small></div>';
  }
  function overview(my) {
    return load().then(function (s) {
      if (my !== seq) return;
      var m = {}; s.money.forEach(function (x) { m[x.code] = x; });
      var cash = s.money.filter(function (x) { return x.tag === 'money'; }).reduce(function (a, x) { return a + x.balance; }, 0);
      var pl = s.year.pl;
      var h = '';
      if (s.sync_error) h += '<div class="dpb-err">Bringing in shop and stock documents stopped: ' + esc(s.sync_error) + '</div>';
      if (!s.settings.reg_no) h += '<div class="dpb-warn"><b>Start here:</b> add the SIA details in <a href="#" data-go="settings">Settings</a>: registration number, registration date, the date the books start, and your name as board member.</div>';
      h += '<div class="dpb-kpis">' +
        '<div class="dpb-kpi"><span>Money (bank, Stripe, PayPal, cash)</span><b>' + eur(cash) + '</b><small>' + s.money.filter(function (x) { return x.tag === 'money' && x.balance; }).map(function (x) { return esc(x.name) + ' ' + eur(x.balance); }).join(' · ') + '</small></div>' +
        '<div class="dpb-kpi"><span>Sales ' + esc(s.year.label) + '</span><b>' + eur(pl.revenue) + '</b><small>Gross profit ' + eur(pl.gross) + '</small></div>' +
        '<div class="dpb-kpi"><span>Profit ' + esc(s.year.label) + ' so far</span><b>' + eur(pl.profit) + '</b><small>Before tax ' + eur(pl.before_tax) + '</small></div>' +
        '<div class="dpb-kpi"><span>Owed</span><b>' + eur((m['5310'] ? m['5310'].balance : 0) + (m['5590'] ? m['5590'].balance : 0)) + '</b><small>Suppliers ' + eur(m['5310'] ? m['5310'].balance : 0) + ' · to you ' + eur(m['5590'] ? m['5590'].balance : 0) + ' · customers owe ' + eur(m['2310'] ? m['2310'].balance : 0) + '</small></div></div>';
      var upcoming = s.filings.filter(function (f) { return ['todo', 'ready', 'check'].indexOf(f.status) >= 0; }).slice(0, 6);
      h += '<div class="dpb-grid2"><div class="dpb-card"><div class="dpb-ch"><h2>Next deadlines</h2><a href="#" class="dpb-btn sm" data-go="returns">All returns</a></div>' +
        (upcoming.length ? upcoming.map(dueRow).join('') : '<p class="dpb-mut">Nothing due. Deadlines appear once the books start date is set.</p>') + '</div>';
      h += '<div><div class="dpb-card"><h2>To do</h2>';
      var todo = [];
      if (s.todo.bank) todo.push('<li><a href="#" data-go="bank">' + s.todo.bank + ' bank payment' + (s.todo.bank === 1 ? '' : 's') + ' to book</a></li>');
      if (s.todo.drafts) todo.push('<li>' + s.todo.drafts + ' supplier invoice' + (s.todo.drafts === 1 ? '' : 's') + ' not in stock yet (Purchases and stock). They reach the books when you put them in stock.</li>');
      s.checks.forEach(function (c) { todo.push('<li>' + esc(c) + '</li>'); });
      h += todo.length ? '<ul class="dpb-steps">' + todo.join('') + '</ul>' : '<p class="dpb-mut">All booked. ' + (s.synced ? s.synced + ' shop or stock documents were just brought in.' : '') + '</p>';
      h += '</div>';
      var L = s.limits;
      h += '<div class="dpb-card"><h2>VAT registration limits ' + esc(L.year) + '</h2>' +
        meter('Turnover this year', L.turnover, L.lv_limit, 'Over €50,000 in a calendar year: apply to VID for VAT registration (the first time you go over).') +
        meter('Sales to consumers in other EU countries', L.eu_b2c, L.eu_limit, 'Goods sent and licences sold to EU consumers outside Latvia. Over €10,000: their country\'s VAT applies, through OSS.') +
        (L.uk_orders ? '<div class="dpb-warn">' + L.uk_orders + ' order' + (L.uk_orders === 1 ? '' : 's') + ' from UK customers this year (' + eur(L.uk_b2c) + ' to consumers). UK VAT applies to digital sales to UK consumers from the first sale; serve UK customers from the UK company.</div>' : '') +
        (+s.settings.vat ? '<p class="dpb-mut">The SIA is set as VAT registered.</p>' : '') + '</div></div></div>';
      main.innerHTML = h;
      wire(main);
    });
  }
  function wire(root) {
    root.querySelectorAll('[data-go]').forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); go(a.getAttribute('data-go')); }); });
    root.querySelectorAll('[data-open]').forEach(function (b) { b.addEventListener('click', function () { openFiling(+b.getAttribute('data-open')); }); });
    root.querySelectorAll('[data-mark]').forEach(function (b) { b.addEventListener('click', function () { markFiling(+b.getAttribute('data-mark')); }); });
  }

  // ------------------------------------------------------------------ returns
  function returns(my) {
    return Promise.all([S ? S : load(), api('filings')]).then(function (r) {
      if (my !== seq) return;
      var all = r[1].filings, now = today();
      var soon = addDays(now, 45), open = all.filter(function (f) { return ['todo', 'ready'].indexOf(f.status) >= 0 || (f.status === 'check' && f.due <= soon); }).sort(function (a, b) { return a.due < b.due ? -1 : 1; });
      var past = all.filter(function (f) { return ['submitted', 'notneeded'].indexOf(f.status) >= 0 && f.due <= addDays(now, 400); });
      var h = '<div class="dpb-card"><h2>How filing works</h2><ol class="dpb-steps"><li>Book everything for the period: bank statements, expenses, stock invoices.</li><li>Open the return here, check the figures, and download the XML file.</li><li>In EDS (eds.vid.gov.lv), start the document by importing the XML file. Check the form EDS shows, then sign and submit it there.</li><li>Come back and mark it as submitted, with the EDS document number.</li></ol></div>';
      h += '<div class="dpb-card"><h2>Open</h2>' + (open.length ? open.map(function (f) { f.days = Math.floor((new Date(f.due) - new Date(now)) / 864e5); return dueRow(f); }).join('') : '<p class="dpb-mut">Nothing open.</p>') + '</div>';
      h += '<div class="dpb-card"><h2>Done</h2>' + (past.length ? '<table class="dpb-t"><thead><tr><th>Return</th><th>Due</th><th>Status</th><th class="r">Tax / result</th><th>EDS no.</th><th></th></tr></thead><tbody>' + past.map(function (f) {
        return '<tr><td>' + esc(f.title) + '</td><td>' + dshort(f.due) + '</td><td><span class="dpb-pill ' + f.status + '">' + (STATUS[f.status] || f.status) + '</span></td><td class="r">' + (f.generated ? eur(f.amount) : '') + '</td><td>' + esc(f.eds_no) + '</td><td class="r">' + (f.file ? '<a class="dpb-btn sm" href="' + C.file + '&filing=' + f.filing_id + '">XML</a> ' : '') + (['UIN', 'GP'].indexOf(f.kind) >= 0 && f.status !== 'notneeded' ? '<button type="button" class="dpb-btn sm" data-open="' + f.filing_id + '">View</button>' : '') + '</td></tr>';
      }).join('') + '</tbody></table>' : '<p class="dpb-mut">Nothing filed yet.</p>') + '<p class="dpb-mut" style="margin-top:8px">Later months show up here as they come near. Months with nothing taxable do not need a UIN declaration; they are listed as not needed.</p></div>';
      main.innerHTML = h;
      wire(main);
    });
  }
  function addDays(d, n) { var t = new Date(d); t.setDate(t.getDate() + n); return t.toISOString().slice(0, 10); }

  function markFiling(id, after) {
    var m = modal('Mark as submitted', '<div class="dpb-form"><label class="w2">EDS document number <em>(optional)</em><input type="text" name="eds_no"></label><label class="w2">Note <em>(optional)</em><input type="text" name="note"></label></div>',
      '<button type="button" class="dpb-btn" data-nn>Not needed</button><button type="button" class="dpb-btn pri" data-ok>Mark submitted</button>');
    function send(status, btn) {
      busy(btn, true);
      api('mark', { filing_id: id, status: status, eds_no: val(m, 'eds_no'), note: val(m, 'note') }).then(function () { m.remove(); toast(status === 'submitted' ? 'Marked as submitted.' : 'Marked as not needed.'); if (after) after(); render(); }).catch(function (e) { busy(btn, false); toast(e.message, true); });
    }
    m.querySelector('[data-ok]').addEventListener('click', function () { send('submitted', this); });
    m.querySelector('[data-nn]').addEventListener('click', function () { send('notneeded', this); });
  }

  function openFiling(id) {
    api('preview', null, { id: id }).then(function (p) {
      if (p.filing.kind === 'UIN') return uinModal(p);
      if (p.filing.kind === 'GP') return gpModal(p);
      markFiling(id);
    }).catch(function (e) { toast(e.message, true); });
  }

  function stepsAfter(fl, name) {
    return '<div class="dpb-okb"><b>File ready.</b> <a href="' + C.file + '&filing=' + fl.filing_id + '">Download ' + esc(name || 'the XML') + '</a></div><ol class="dpb-steps"><li>Log in to EDS (eds.vid.gov.lv) as the SIA.</li><li>Start the document by importing this XML file.</li><li>Check the form EDS shows; it recalculates the totals and flags anything missing.</li><li>Sign and submit. Then mark it as submitted here.</li></ol>';
  }

  function uinModal(p) {
    var fl = p.filing, f = p.figures, c = p.computed, i = p.inputs;
    var row = function (code, label, editable) {
      return '<tr><td>' + code.replace('_', '.') + '</td><td>' + label + '</td><td class="r">' + (editable && !ro() && fl.status !== 'submitted' ? '<input type="number" step="1" min="0" name="' + code + '" value="' + Math.round(num(i[code])) + '" style="width:110px;text-align:right">' : '<b data-c="' + code + '">' + whole(c[code]) + '</b>') + '</td></tr>';
    };
    var body = '<p class="dpb-mut">' + esc(dshort(f.from)) + ' – ' + esc(dshort(f.to)) + (f.last ? '. Last declaration of the year (required even with nothing to tax).' : '.') + ' Whole euros.</p>';
    if (p.first_year && f.last) body += '<div class="dpb-okb">First year: the SIA was registered this year, so the €50 minimum tax does not apply (marked in the file).</div>';
    else if (f.last) body += '<div class="dpb-warn">If the year\'s tax comes to less than €50 and the SIA paid less than €100 in wage taxes this year, EDS adds the difference up to the €50 minimum when you import the file.</div>';
    if (f.items.length) body += '<p>From the books: ' + f.items.map(function (x) { return esc(x.name) + ' ' + eur(x.amount); }).join(', ') + '.</p>';
    if (f.loan_owner > 0) body += '<div class="dpb-warn">At year end the company has lent you ' + eur(f.loan_owner) + '. Under the UIN law a loan to a related person can count as taxable (row 6.4). Enter it below if it applies.</div>';
    body += '<table class="dpb-t"><thead><tr><th>Row</th><th></th><th class="r">EUR</th></tr></thead><tbody>' +
      row('R01', 'Dividends declared (or paid like dividends)', true) +
      row('R03', 'Tax base from dividends (1 ÷ 0.8)') + row('R04', 'Tax on dividends (20%)') +
      row('R06_1', 'Costs not for the business', true) +
      (f.last ? row('R06_2', 'Doubtful debts', true) + row('R06_3', 'Interest over the limit', true) + row('R06_4', 'Loans to related persons', true) + row('R06_5', 'Transfer-price adjustments', true) : '') +
      row('R06', 'Deemed profit distributed, total') + row('R07', 'Tax base from it (÷ 0.8)') + row('R22', 'Tax base') + row('R23', 'Tax (20%)') +
      '<tr class="tot"><td>29</td><td>Tax for the month</td><td class="r"><b data-c="R29">' + whole(c.R29) + '</b></td></tr></tbody></table>';
    if (fl.file) body += stepsAfter(fl);
    var m = modal(fl.title, body, (fl.status !== 'submitted' && !ro() ? '<button type="button" class="dpb-btn" data-mark>Mark submitted</button><button type="button" class="dpb-btn pri" data-build>' + (fl.file ? 'Build again' : 'Build the XML') + '</button>' : (fl.file ? '<a class="dpb-btn" href="' + C.file + '&filing=' + fl.filing_id + '">Download XML</a>' : '')));
    function inputs() { var o = {}; m.querySelectorAll('input[type=number]').forEach(function (el) { o[el.name] = el.value; }); Object.keys(i).forEach(function (k) { if (!(k in o)) o[k] = i[k]; }); return o; }
    function recompute() {
      var x = inputs(), r = {};
      ['R01', 'R02', 'R06_1', 'R06_2', 'R06_3', 'R06_4', 'R06_5', 'R06_7', 'R06_8', 'R05_1', 'R05_2', 'R05_3'].forEach(function (k) { r[k] = Math.max(0, Math.round(num(x[k]))); });
      r.R03 = Math.round(Math.max(0, r.R01 - r.R02) / 0.8); r.R04 = Math.round(r.R03 * 0.2);
      r.R06 = r.R06_1 + r.R06_2 + r.R06_3 + r.R06_4 + r.R06_5 + r.R06_7 + r.R06_8; r.R05 = r.R05_1 + r.R05_2 + r.R05_3;
      r.R07 = Math.round((r.R05 + r.R06) / 0.8); r.R14 = Math.round(r.R04 / 0.2); r.R22 = r.R14 + r.R07; r.R23 = Math.round(r.R22 * 0.2); r.R29 = r.R23;
      m.querySelectorAll('[data-c]').forEach(function (b) { b.textContent = whole(r[b.getAttribute('data-c')]); });
    }
    m.querySelectorAll('input[type=number]').forEach(function (el) { el.addEventListener('input', recompute); });
    var b = m.querySelector('[data-build]');
    if (b) b.addEventListener('click', function () {
      busy(b, true);
      api('build', { filing_id: fl.filing_id, inputs: inputs() }).then(function (r) { m.remove(); toast('UIN declaration built: tax ' + eur(r.amount) + '.'); openFiling(fl.filing_id); }).catch(function (e) { busy(b, false); toast(e.message, true); });
    });
    var mk = m.querySelector('[data-mark]');
    if (mk) mk.addEventListener('click', function () { m.remove(); markFiling(fl.filing_id); });
  }

  var BA = [['I. Intangible assets', null], ['R40', 'Software, licences, trademarks'], ['R80', 'Intangible assets, total', 1], ['II. Fixed assets', null], ['R190', 'Other fixed assets and equipment'], ['R220', 'Fixed assets, total', 1], ['R340', 'Long-term investments, total', 1],
    ['Stock', null], ['R370', 'Parts and materials'], ['R390', 'Finished products and goods'], ['R400', 'Prepaid stock'], ['R450', 'Stock, total', 1], ['Debtors', null], ['R470', 'Owed by customers'], ['R500', 'Other debtors'], ['R510', 'Share capital not paid in'], ['R520', 'Short-term loans to owner and board'], ['R530', 'Costs paid in advance'], ['R550', 'Debtors, total', 1], ['R620', 'Cash and bank'], ['R630', 'Current assets, total', 1], ['R640', 'BALANCE SHEET TOTAL', 2]];
  var BP = [['Equity', null], ['R660', 'Share capital'], ['R780', 'Profit kept from earlier years'], ['R790', 'Profit or loss of the year'], ['R800', 'Equity, total', 1], ['Short-term creditors', null], ['R1060', 'Other loans (from the owner)'], ['R1070', 'Customer prepayments'], ['R1080', 'Owed to suppliers'], ['R1120', 'Taxes and social contributions'], ['R1130', 'Other creditors'], ['R1150', 'Dividends not paid'], ['R1160', 'Accrued costs'], ['R1180', 'Short-term creditors, total', 1], ['R1190', 'BALANCE SHEET TOTAL', 2]];
  var PZ = [['R10', 'Net turnover', 1], ['R40', 'Cost of sales'], ['R50', 'Gross profit', 1], ['R60', 'Selling costs'], ['R70', 'Administration costs'], ['R80', 'Other income'], ['R90', 'Other costs'], ['R170', 'Interest received'], ['R210', 'Interest paid'], ['R240', 'Profit before corporate income tax', 1], ['R250', 'Corporate income tax'], ['R290', 'Profit or loss of the year', 2]];
  function gpTable(rows, cur, prev) {
    return '<table class="dpb-t"><thead><tr><th>Row</th><th></th><th class="r">This year</th><th class="r">Last year</th></tr></thead><tbody>' + rows.map(function (r) {
      if (r[1] === null) return '<tr class="sub"><td colspan="4"><b>' + esc(r[0]) + '</b></td></tr>';
      var c = cur[r[0]] || 0, p = prev ? prev[r[0]] || 0 : 0;
      if (!r[2] && !c && !p) return '';
      return '<tr' + (r[2] ? ' class="tot"' : '') + '><td>' + r[0].slice(1) + '</td><td>' + esc(r[1]) + '</td><td class="r">' + whole(c) + '</td><td class="r">' + (prev ? whole(p) : '–') + '</td></tr>';
    }).join('') + '</tbody></table>';
  }
  function gpModal(p) {
    var fl = p.filing, c = p.columns, o = p.opt, locked = fl.status === 'submitted' || ro();
    var body = '<p class="dpb-mut">' + dshort(p.from) + ' – ' + dshort(p.to) + '. A micro company\'s annual report: balance sheet, profit or loss by function (PZA2) and notes. Whole euros.' + (c.rounding ? ' Rounding to whole euros: ' + c.rounding + ' EUR put into other creditors.' : '') + '</p>';
    if (p.unbooked) body += '<div class="dpb-warn">' + p.unbooked + ' bank payment' + (p.unbooked === 1 ? '' : 's') + ' of this year still to book. Book them first, or the report will be wrong.</div>';
    (p.checks || []).forEach(function (x) { body += '<div class="dpb-warn">' + esc(x) + '</div>'; });
    if (Math.abs(c.diff) >= 1) body += '<div class="dpb-err">The books do not balance (off by ' + eur(c.diff) + ').</div>';
    body += '<div class="dpb-grid2"><div><h3>Assets</h3>' + gpTable(BA, c.ba, null) + '</div><div><h3>Equity and liabilities</h3>' + gpTable(BP, c.bp, null) + '<h3>Profit or loss</h3>' + gpTable(PZ, c.pz, null) + '</div></div>';
    body += '<h3>For the report</h3><div class="dpb-form">' +
      '<label>Date you approved it<input type="date" name="approved" value="' + esc(o.approved || '') + '"' + (locked ? ' disabled' : '') + '></label>' +
      '<label>Average employees<input type="number" min="0" step="1" name="staff" value="' + esc(o.staff) + '"' + (locked ? ' disabled' : '') + '></label>' +
      '<label class="w2">Events after the year end <em>(notes)</em><input type="text" name="after" value="' + esc(o.after) + '"' + (locked ? ' disabled' : '') + '></label>' +
      '<label class="w2">Guarantees given <em>(notes)</em><input type="text" name="guarantees" value="' + esc(o.guarantees) + '"' + (locked ? ' disabled' : '') + '></label>' +
      '<label>Leases <em>(notes)</em><input type="text" name="leases" value="' + esc(o.leases) + '"' + (locked ? ' disabled' : '') + '></label>' +
      '<label>Pledged assets <em>(notes)</em><input type="text" name="pledges" value="' + esc(o.pledges) + '"' + (locked ? ' disabled' : '') + '></label>' +
      '<label class="w4">Accounting policy <em>(notes, in Latvian)</em><textarea name="policy"' + (locked ? ' disabled' : '') + '>' + esc(o.policy) + '</textarea></label></div>' +
      '<p class="dpb-mut">As the only owner you approve the report yourself (a written decision kept with the books). Submitting it closes the year here: later changes become dated corrections.</p>';
    if (fl.file) body += stepsAfter(fl);
    var m = modal(fl.title, body, !locked ? '<button type="button" class="dpb-btn" data-mark>Mark submitted</button><button type="button" class="dpb-btn pri" data-build>' + (fl.file ? 'Build again' : 'Build the XML') + '</button>' : (fl.file ? '<a class="dpb-btn" href="' + C.file + '&filing=' + fl.filing_id + '">Download XML</a>' : ''));
    var b = m.querySelector('[data-build]');
    if (b) b.addEventListener('click', function () {
      var opt = {}; ['approved', 'staff', 'after', 'guarantees', 'leases', 'pledges', 'policy'].forEach(function (k) { opt[k] = val(m, k); });
      busy(b, true);
      api('build', { filing_id: fl.filing_id, opt: opt }).then(function (r) { m.remove(); toast('Annual report built: result ' + eur(r.amount) + '.'); openFiling(fl.filing_id); }).catch(function (e) { busy(b, false); toast(e.message, true); });
    });
    var mk = m.querySelector('[data-mark]');
    if (mk) mk.addEventListener('click', function () { m.remove(); markFiling(fl.filing_id); });
  }

  // ------------------------------------------------------------------ expenses
  var period = { from: new Date().getFullYear() + '-01-01', to: new Date().getFullYear() + '-12-31' };
  function periodBar(id) {
    return '<div class="dpb-row" id="' + id + '"><label class="dpb-mut">From <input type="date" name="from" value="' + period.from + '" style="width:auto"></label><label class="dpb-mut">to <input type="date" name="to" value="' + period.to + '" style="width:auto"></label></div>';
  }
  function wirePeriod(root, id) {
    root.querySelectorAll('#' + id + ' input').forEach(function (el) { el.addEventListener('change', function () { period[el.name] = el.value; render(); }); });
  }
  function expenses(my) {
    return Promise.all([S ? S : load(), api('expenses', null, period)]).then(function (r) {
      if (my !== seq) return;
      var ex = r[1].expenses, st = r[1].stock;
      var tot = ex.filter(function (e) { return e.status !== 'void'; }).reduce(function (a, e) { return a + num(e.amount_eur); }, 0);
      var h = '<div class="dpb-card"><div class="dpb-ch"><h2>Expense invoices</h2><div class="dpb-row">' + periodBar('pe') + (ro() ? '' : '<button type="button" class="dpb-btn pri" data-add><i class="fa fa-plus"></i> Add an invoice</button>') + '</div></div>' +
        '<p class="dpb-mut">Hosting, software, tools, shipping, fees: anything the SIA pays that is not stock. Parts and materials for stock go in Purchases and stock, and reach the books from there. Total ' + eur(tot) + '.</p>';
      h += ex.length ? '<table class="dpb-t"><thead><tr><th>Date</th><th>Supplier</th><th>For</th><th>Paid by</th><th class="r">EUR</th><th></th></tr></thead><tbody>' + ex.map(function (e) {
        return '<tr class="click" data-id="' + e.expense_id + '"><td>' + dshort(e.date) + '</td><td>' + esc(e.supplier) + '<small>' + esc(e.number) + '</small></td><td>' + esc(accName(e.account)) + (+e.nonbiz ? ' <span class="dpb-pill late">Not for the business</span>' : '') + (+e.rc ? ' <span class="dpb-pill check">+21% VAT to VID</span>' : '') + '</td><td>' + esc(accName(e.paid)) + '</td><td class="r">' + eur(e.amount_eur) + (e.currency !== 'EUR' ? '<small>' + esc(e.amount + ' ' + e.currency) + '</small>' : '') + '</td><td class="r">' + (e.status === 'void' ? '<span class="dpb-pill void">Voided</span>' : '') + (e.file ? ' <a class="dpb-btn sm" target="_blank" rel="noopener" href="' + C.file + '&expense=' + e.expense_id + '" data-stop>PDF</a>' : '') + '</td></tr>';
      }).join('') + '</tbody></table>' : '<p class="dpb-mut">No expense invoices in this period.</p>';
      h += '</div><div class="dpb-card"><h2>Supplier invoices from Purchases and stock</h2>' + (st.length ? '<table class="dpb-t"><thead><tr><th>Date</th><th>Supplier</th><th>Number</th><th>Status</th><th class="r">EUR</th><th></th></tr></thead><tbody>' + st.map(function (i) {
        return '<tr><td>' + dshort(i.date) + '</td><td>' + esc(i.supplier) + '</td><td>' + esc(i.number) + '</td><td>' + (i.status === 'received' ? '<span class="dpb-pill submitted">In the books</span>' : '<span class="dpb-pill todo">Not in stock yet</span>') + '</td><td class="r">' + eur(i.total_eur) + '</td><td class="r">' + (i.file ? '<a class="dpb-btn sm" target="_blank" rel="noopener" href="' + C.stockFile + '&id=' + i.invoice_id + '">PDF</a>' : '') + '</td></tr>';
      }).join('') + '</tbody></table>' : '<p class="dpb-mut">None in this period.</p>') + '</div>';
      main.innerHTML = h;
      wirePeriod(main, 'pe');
      var add = main.querySelector('[data-add]'); if (add) add.addEventListener('click', function () { expenseModal(null); });
      main.querySelectorAll('[data-stop]').forEach(function (a) { a.addEventListener('click', function (e) { e.stopPropagation(); }); });
      main.querySelectorAll('tr.click').forEach(function (tr) { tr.addEventListener('click', function () { expenseModal(ex.filter(function (e) { return e.expense_id === tr.getAttribute('data-id'); })[0]); }); });
    });
  }
  function expenseModal(e) {
    var v = e || { date: today(), currency: 'EUR', rate: 1, account: '7520', paid: '5310', nonbiz: 0 };
    var void_ = e && e.status === 'void', lock = void_ || ro();
    var dis = lock ? ' disabled' : '';
    var body = (void_ ? '<div class="dpb-warn">This expense was voided.</div>' : '') + '<div class="dpb-form">' +
      '<label>Invoice date<input type="date" name="date" value="' + esc(v.date) + '"' + dis + '></label>' +
      '<label>Supplier<input type="text" name="supplier" value="' + esc(v.supplier || '') + '"' + dis + '></label>' +
      '<label>Invoice number<input type="text" name="number" value="' + esc(v.number || '') + '"' + dis + '></label>' +
      '<label>Amount<input type="number" step="0.01" name="amount" value="' + esc(v.amount || '') + '"' + dis + '></label>' +
      '<label>Currency<input type="text" name="currency" maxlength="3" value="' + esc(v.currency) + '"' + dis + '></label>' +
      '<label>Rate to EUR <em>(ECB, invoice date)</em><input type="number" step="any" name="rate" value="' + esc(v.rate) + '"' + dis + '></label>' +
      '<label class="w2">What it was for' + accSelect('account', v.account, function (a) { return a.type === 'x' || a.type === 'a'; }) + '</label>' +
      '<label class="w2">How it was paid' + accSelect('paid', v.paid, function (a) { return a.tag === 'money' || ['5310', '5590', '5800'].indexOf(a.code) >= 0; }) + '<em>"Owed to suppliers" if the bank paid it (you match the bank payment later); "Owed to you" if you paid with your own card.</em></label>' +
      '<label class="w4 chk"><input type="checkbox" name="nonbiz"' + (+v.nonbiz ? ' checked' : '') + dis + '> Not for the business (taxed in the UIN declaration of that month)</label>' +
      '<label class="w4 chk"><input type="checkbox" name="rc"' + (+v.rc ? ' checked' : '') + dis + '> Service from a supplier outside Latvia with no VAT on the invoice (software, hosting, ads): the SIA pays 21% VAT to VID itself</label>' +
      '<label class="w4">Note<input type="text" name="note" value="' + esc(v.note || '') + '"' + dis + '></label></div>' +
      '<div class="dpb-drop" tabindex="0">' + (v.file ? 'Invoice: ' + esc(v.file_name) + (lock ? '' : '. Drop or click to replace.') : 'Drop the invoice PDF or picture here, or click to choose it') + '</div><input type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" hidden>';
    var m = modal(e ? 'Expense ' + (e.supplier || '') : 'Add an expense invoice', body, lock ? '' : (e ? '<button type="button" class="dpb-btn" data-void>Void it</button>' : '') + '<button type="button" class="dpb-btn pri" data-save>Save</button>');
    var file = { file: v.file || '', file_name: v.file_name || '' };
    var drop = m.querySelector('.dpb-drop'), inp = m.querySelector('input[type=file]');
    function up(f) {
      var fd = new FormData(); fd.append('file', f);
      drop.textContent = 'Uploading…';
      api('upload', fd).then(function (r) { file = r; drop.textContent = 'Invoice: ' + r.file_name; }).catch(function (er) { drop.textContent = er.message; });
    }
    if (!lock) {
      drop.addEventListener('click', function () { inp.click(); });
      drop.addEventListener('keydown', function (k) { if (k.key === 'Enter' || k.key === ' ') { k.preventDefault(); inp.click(); } });
      inp.addEventListener('change', function () { if (inp.files[0]) up(inp.files[0]); });
      drop.addEventListener('dragover', function (d) { d.preventDefault(); drop.classList.add('on'); });
      drop.addEventListener('dragleave', function () { drop.classList.remove('on'); });
      drop.addEventListener('drop', function (d) { d.preventDefault(); drop.classList.remove('on'); if (d.dataTransfer.files[0]) up(d.dataTransfer.files[0]); });
    } else if (v.file) {
      drop.innerHTML = '<a target="_blank" rel="noopener" href="' + C.file + '&expense=' + v.expense_id + '">Open ' + esc(v.file_name) + '</a>';
    }
    var cur = m.querySelector('[name=currency]'), rate = m.querySelector('[name=rate]');
    if (cur) cur.addEventListener('input', function () { if (cur.value.toUpperCase() === 'EUR') rate.value = 1; });
    var s = m.querySelector('[data-save]');
    if (s) s.addEventListener('click', function () {
      busy(s, true);
      var body = { expense_id: e ? e.expense_id : 0, file: file.file, file_name: file.file_name };
      ['date', 'supplier', 'number', 'amount', 'currency', 'rate', 'account', 'paid', 'nonbiz', 'rc', 'note'].forEach(function (k) { body[k] = val(m, k); });
      api('save_expense', body).then(function () { m.remove(); toast('Expense saved and booked.'); render(); }).catch(function (er) { busy(s, false); toast(er.message, true); });
    });
    var vd = m.querySelector('[data-void]');
    if (vd) vd.addEventListener('click', function () {
      if (!window.confirm('Void this expense? Its booking is reversed; the record stays.')) return;
      api('void_expense', { expense_id: e.expense_id }).then(function () { m.remove(); toast('Expense voided.'); render(); }).catch(function (er) { toast(er.message, true); });
    });
  }

  // ------------------------------------------------------------------ bank
  var bankView = 'open';
  function bank(my) {
    return Promise.all([S ? S : load(), api('bank_rows', null, { status: bankView })]).then(function (r) {
      if (my !== seq) return;
      var rows = r[1].rows, rules = r[1].rules;
      var h = '<div class="dpb-card"><h2>Bring in a statement</h2><p class="dpb-mut">Export the statement from your bank as <b>camt.053</b> (ISO 20022 XML; Swedbank, SEB, Citadele and Luminor all offer it) or as CSV, then choose the file. Rows already brought in are skipped, so overlapping statements are fine.</p>' +
        (ro() ? '' : '<div class="dpb-row"><label class="dpb-mut">Account ' + accSelect('bacc', '2620', function (a) { return a.tag === 'money'; }) + '</label><input type="file" accept=".xml,.csv,.txt" name="stmt"><button type="button" class="dpb-btn pri" data-imp>Bring in</button></div>') + '</div>';
      h += '<div class="dpb-card"><div class="dpb-ch"><h2>' + (bankView === 'open' ? 'Payments to book' : 'All payments') + '</h2><div class="dpb-row"><button type="button" class="dpb-btn sm" data-view="open"' + (bankView === 'open' ? ' disabled' : '') + '>To book</button><button type="button" class="dpb-btn sm" data-view="all"' + (bankView === 'all' ? ' disabled' : '') + '>All</button></div></div>';
      h += rows.length ? '<table class="dpb-t"><thead><tr><th>Date</th><th>Who and what</th><th class="r">EUR</th><th>Book to</th><th></th></tr></thead><tbody>' + rows.map(function (t) {
        var sug = (t.suggest || []).map(function (s, i) { return '<button type="button" data-sug="' + t.tx_id + ':' + i + '" title="' + esc(s.why) + '">' + esc(accName(s.account)) + (s.doc ? ' · ' + esc(s.why) : '') + '</button>'; }).join('');
        return '<tr data-tx="' + t.tx_id + '"><td>' + dshort(t.date) + '<small>' + esc(accName(t.account)) + '</small></td><td><b>' + esc(t.counterparty || '—') + '</b><small>' + esc(t.details) + '</small>' + (sug ? '<div class="dpb-sug">' + sug + '</div>' : '') + '</td><td class="r"' + (num(t.amount) < 0 ? '' : ' style="color:var(--ok)"') + '>' + eur(t.amount) + '</td>' +
          (t.status === 'open' ? '<td>' + accSelect('acc' + t.tx_id, '', null, 'Choose…') + '<label class="chk" style="font-size:12px;margin-top:4px"><input type="checkbox" name="rule' + t.tx_id + '"> Always for “' + esc((t.counterparty || '').slice(0, 30)) + '”</label></td><td>' + (ro() ? '' : '<button type="button" class="dpb-btn sm pri" data-book="' + t.tx_id + '">Book</button>') + '</td>' : '<td>' + esc(accName(t.contra)) + '</td><td>' + (ro() ? '' : '<button type="button" class="dpb-btn sm" data-reopen="' + t.tx_id + '">Change</button>') + '</td>') + '</tr>';
      }).join('') + '</tbody></table>' : '<p class="dpb-mut">' + (bankView === 'open' ? 'Nothing to book.' : 'No payments brought in yet.') + '</p>';
      h += '</div>';
      if (rules.length) h += '<div class="dpb-card"><h2>Your rules</h2><table class="dpb-t"><tbody>' + rules.map(function (u) { return '<tr><td>“' + esc(u.match) + '”</td><td>' + esc(accName(u.account)) + '</td><td class="r">' + (ro() ? '' : '<button type="button" class="dpb-btn sm" data-unrule="' + u.rule_id + '">Remove</button>') + '</td></tr>'; }).join('') + '</tbody></table></div>';
      main.innerHTML = h;
      var bookedOnce = {};
      main.querySelectorAll('[data-view]').forEach(function (b) { b.addEventListener('click', function () { bankView = b.getAttribute('data-view'); render(); }); });
      var imp = main.querySelector('[data-imp]');
      if (imp) imp.addEventListener('click', function () {
        var f = main.querySelector('[name=stmt]').files[0];
        if (!f) return toast('Choose the statement file first.', true);
        busy(imp, true);
        f.text().then(function (txt) { return api('bank_import', { account: val(main, 'bacc'), content: txt, name: f.name }); })
          .then(function (r) { toast(r.added + ' new payment' + (r.added === 1 ? '' : 's') + (r.duplicates ? ', ' + r.duplicates + ' already here' : '') + (r.auto ? ', ' + r.auto + ' booked by your rules' : '') + '.'); S = null; render(); })
          .catch(function (e) { busy(imp, false); toast(e.message, true); });
      });
      function book(id, account, doc, partner, btn) {
        if (bookedOnce[id]) return;
        var t = rows.filter(function (x) { return x.tx_id === String(id); })[0];
        var rule = main.querySelector('[name=rule' + id + ']');
        busy(btn, true);
        bookedOnce[id] = 1;
        api('bank_assign', { tx_id: id, account: account, doc: doc || '', partner: partner || '', rule: rule && rule.checked ? (t.counterparty || '').trim() : '' })
          .then(function () { toast('Booked to ' + accName(account) + '.'); var tr = main.querySelector('tr[data-tx="' + id + '"]'); if (tr && bankView === 'open') tr.remove(); else render(); S = null; if (rule && rule.checked) render(); })
          .catch(function (e) { bookedOnce[id] = 0; busy(btn, false); toast(e.message, true); });
      }
      main.querySelectorAll('[data-book]').forEach(function (b) { b.addEventListener('click', function () { var id = b.getAttribute('data-book'), a = val(main, 'acc' + id); if (!a) return toast('Choose what the payment was for.', true); book(id, a, '', '', b); }); });
      main.querySelectorAll('[data-sug]').forEach(function (b) {
        b.addEventListener('click', function () {
          if (ro()) return;
          var p = b.getAttribute('data-sug').split(':'), t = rows.filter(function (x) { return x.tx_id === p[0]; })[0], s = t.suggest[+p[1]];
          book(p[0], s.account, s.doc, s.partner, b);
        });
      });
      main.querySelectorAll('[data-reopen]').forEach(function (b) { b.addEventListener('click', function () { api('bank_reopen', { tx_id: b.getAttribute('data-reopen') }).then(function () { bankView = 'open'; render(); }).catch(function (e) { toast(e.message, true); }); }); });
      main.querySelectorAll('[data-unrule]').forEach(function (b) { b.addEventListener('click', function () { api('rule_delete', { rule_id: b.getAttribute('data-unrule') }).then(render).catch(function (e) { toast(e.message, true); }); }); });
    });
  }

  // ------------------------------------------------------------------ journal
  var jAcc = '';
  function journal(my) {
    return Promise.all([S ? S : load(), api('entries', null, { from: period.from, to: period.to, account: jAcc })]).then(function (r) {
      if (my !== seq) return;
      var es = r[1].entries;
      var h = '<div class="dpb-card"><div class="dpb-ch"><h2>Journal</h2><div class="dpb-row">' + periodBar('pj') + '<label class="dpb-mut">Account ' + accSelect('jacc', jAcc, null, 'All accounts') + '</label>' +
        (ro() ? '' : '<button type="button" class="dpb-btn" data-div>Declare a dividend</button><button type="button" class="dpb-btn pri" data-new><i class="fa fa-plus"></i> Entry</button>') + '</div></div>';
      if (jAcc && r[1].opening !== null) h += '<p class="dpb-mut">Balance before ' + dshort(period.from) + ': ' + eur(r[1].opening) + ' (debit minus credit).</p>';
      h += es.length ? '<table class="dpb-t"><thead><tr><th>Date</th><th>Entry</th><th>Account</th><th class="r">Debit</th><th class="r">Credit</th><th></th></tr></thead><tbody>' + es.map(function (e) {
        var first = true;
        return e.lines.map(function (l) {
          var row = '<tr' + (first ? '' : ' class="sub"') + '><td>' + (first ? dshort(e.date) : '') + '</td><td>' + (first ? '<b>' + esc(e.descr) + '</b><small>' + esc(e.ref) + (e.kind ? ' · ' + esc(e.kind) : '') + '</small>' : esc(l.note)) + '</td><td>' + esc(accName(l.account)) + (l.partner ? '<small>' + esc(l.partner) + '</small>' : '') + '</td><td class="r">' + (num(l.debit) ? eur(l.debit) : '') + '</td><td class="r">' + (num(l.credit) ? eur(l.credit) : '') + '</td><td class="r">' + (first && /^man:/.test(e.src) && !ro() ? '<button type="button" class="dpb-btn sm" data-rev="' + e.entry_id + '">Reverse</button>' : '') + '</td></tr>';
          first = false; return row;
        }).join('');
      }).join('') + '</tbody></table>' : '<p class="dpb-mut">No entries in this period.</p>';
      h += '</div>';
      main.innerHTML = h;
      wirePeriod(main, 'pj');
      main.querySelector('[name=jacc]').addEventListener('change', function () { jAcc = this.value; render(); });
      var n = main.querySelector('[data-new]'); if (n) n.addEventListener('click', entryModal);
      var d = main.querySelector('[data-div]'); if (d) d.addEventListener('click', dividendModal);
      main.querySelectorAll('[data-rev]').forEach(function (b) { b.addEventListener('click', function () { if (!window.confirm('Post a reversing entry dated today?')) return; api('reverse_entry', { entry_id: b.getAttribute('data-rev') }).then(function () { toast('Reversed.'); render(); }).catch(function (e) { toast(e.message, true); }); }); });
    });
  }
  function entryModal() {
    var line = function () { return '<tr><td>' + accSelect('a', '', null, 'Account…') + '</td><td><input type="number" step="0.01" name="d"></td><td><input type="number" step="0.01" name="c"></td><td><input type="text" name="p"></td></tr>'; };
    var body = '<div class="dpb-form"><label>Date<input type="date" name="date" value="' + today() + '"></label><label>Kind<select name="kind"><option value="manual">Adjustment</option><option value="opening">Opening balance</option><option value="deprec">Depreciation</option><option value="yearend">Year end</option></select></label><label class="w2">What it is for<input type="text" name="descr"></label></div>' +
      '<table class="dpb-t" id="lines"><thead><tr><th>Account</th><th>Debit</th><th>Credit</th><th>Partner</th></tr></thead><tbody>' + line() + line() + '</tbody></table>' +
      '<div class="dpb-row" style="margin-top:8px"><button type="button" class="dpb-btn sm" data-line>Add a line</button><span class="dpb-mut" data-bal></span></div>' +
      '<p class="dpb-mut">Examples: share capital paid in = debit 2620 Bank, credit 3110 Share capital. Opening stock = debit 2110/2130, credit 3410.</p>';
    var m = modal('New journal entry', body, '<button type="button" class="dpb-btn pri" data-save>Post</button>');
    function bal() { var d = 0, c = 0; m.querySelectorAll('#lines tbody tr').forEach(function (tr) { d += num(tr.querySelector('[name=d]').value); c += num(tr.querySelector('[name=c]').value); }); m.querySelector('[data-bal]').textContent = 'Debit ' + eur(d) + ' · credit ' + eur(c) + (Math.abs(d - c) > 0.004 ? ' · off by ' + eur(d - c) : ' · balanced'); }
    m.querySelector('[data-line]').addEventListener('click', function () { m.querySelector('#lines tbody').insertAdjacentHTML('beforeend', line()); });
    m.addEventListener('input', bal);
    m.querySelector('[data-save]').addEventListener('click', function () {
      var lines = []; m.querySelectorAll('#lines tbody tr').forEach(function (tr) { lines.push({ account: tr.querySelector('[name=a]').value, debit: tr.querySelector('[name=d]').value, credit: tr.querySelector('[name=c]').value, partner: tr.querySelector('[name=p]').value }); });
      var b = this; busy(b, true);
      api('save_entry', { date: val(m, 'date'), kind: val(m, 'kind'), descr: val(m, 'descr'), lines: lines }).then(function () { m.remove(); toast('Entry posted.'); render(); }).catch(function (e) { busy(b, false); toast(e.message, true); });
    });
  }
  function dividendModal() {
    var m = modal('Declare a dividend', '<p>The dividend comes out of profit kept from earlier years (account 3410). The SIA pays 20/80 of it as corporate income tax: €100 to you means €25 tax, declared in the UIN declaration of the month you declare it.</p>' +
      '<div class="dpb-form"><label>Date of your decision<input type="date" name="date" value="' + today() + '"></label><label>Amount to you (EUR)<input type="number" step="0.01" name="amount" data-amt></label><label class="w2">Note<input type="text" name="note"></label></div><div class="dpb-sum"><div><span>Tax for the SIA (20/80)</span><b data-tax>€0.00</b></div><div class="big"><span>Cost to the SIA</span><b data-all>€0.00</b></div></div>',
      '<button type="button" class="dpb-btn pri" data-save>Declare</button>');
    m.querySelector('[data-amt]').addEventListener('input', function () { var a = num(this.value); m.querySelector('[data-tax]').textContent = eur(a / 0.8 * 0.2); m.querySelector('[data-all]').textContent = eur(a / 0.8); });
    m.querySelector('[data-save]').addEventListener('click', function () {
      var b = this; busy(b, true);
      api('dividend', { date: val(m, 'date'), amount: val(m, 'amount'), note: val(m, 'note') }).then(function (r) { m.remove(); toast('Dividend booked; tax ' + eur(r.tax) + '.'); render(); }).catch(function (e) { busy(b, false); toast(e.message, true); });
    });
  }

  // ------------------------------------------------------------------ reports
  function reports(my) {
    return Promise.all([S ? S : load(), api('report', null, { from: period.from, to: period.to > today() ? today() : period.to })]).then(function (r) {
      if (my !== seq) return;
      var R = r[1], pl = R.pl, bs = R.bs;
      var label = { R30: 'Sales', R40: 'Cost of sales', R60: 'Selling costs', R70: 'Administration costs', R80: 'Other income', R90: 'Other costs', R190: 'Interest received', R230: 'Interest paid', R250: 'Corporate income tax' };
      var h = '<div class="dpb-card"><div class="dpb-ch"><h2>Profit or loss</h2>' + periodBar('pr') + '</div>';
      var max = Math.max.apply(null, R.months.map(function (x) { return Math.max(Math.abs(x.revenue), Math.abs(x.profit)); }).concat([1]));
      h += '<div class="dpb-bars" aria-label="Sales by month">' + R.months.map(function (x) { return '<div title="' + x.month + ': sales ' + eur(x.revenue) + ', profit ' + eur(x.profit) + '"><i style="height:' + (Math.abs(x.revenue) / max * 100).toFixed(1) + 'px"></i><span>' + MON[+x.month.slice(5) - 1] + '</span></div>'; }).join('') + '</div>';
      h += '<table class="dpb-t"><tbody>';
      ['R30', 'R40'].forEach(function (k) { h += plRow(k); });
      h += '<tr class="tot"><td>Gross profit</td><td class="r">' + eur(pl.gross) + '</td></tr>';
      ['R60', 'R70', 'R80', 'R90', 'R190', 'R230'].forEach(function (k) { h += plRow(k); });
      h += '<tr class="tot"><td>Profit before tax</td><td class="r">' + eur(pl.before_tax) + '</td></tr>' + plRow('R250') + '<tr class="tot"><td>Profit or loss</td><td class="r"><b>' + eur(pl.profit) + '</b></td></tr></tbody></table></div>';
      function plRow(k) {
        var v = pl.rows[k] || 0, sub = pl.accounts.filter(function (a) { return a.row === k && a.amount; });
        if (!v && !sub.length) return '';
        return '<tr><td>' + label[k] + '</td><td class="r">' + eur(v) + '</td></tr>' + sub.map(function (a) { return '<tr class="sub"><td>' + a.code + ' ' + esc(a.name) + '</td><td class="r">' + eur(a.amount) + '</td></tr>'; }).join('');
      }
      h += '<div class="dpb-grid2"><div class="dpb-card"><h2>Balance sheet at ' + dshort(R.to) + '</h2>' + (Math.abs(bs.diff) >= 0.01 ? '<div class="dpb-err">Off by ' + eur(bs.diff) + '.</div>' : '') + '<table class="dpb-t"><tbody>';
      var names = {}; BA.concat(BP).forEach(function (x) { if (x[1]) names[x[0]] = x[1]; });
      Object.keys(bs.rows).sort(function (a, b) { return (a.slice(0, 2) === b.slice(0, 2) ? +a.slice(4) - +b.slice(4) : (a < b ? -1 : 1)); }).forEach(function (k) {
        if (Math.abs(bs.rows[k]) < 0.005) return;
        h += '<tr><td>' + (k.slice(0, 2) === 'BA' ? 'Asset' : 'Equity / owed') + ' · ' + k.slice(4) + ' ' + esc(names[k.slice(3)] || '') + '</td><td class="r">' + eur(bs.rows[k]) + '</td></tr>';
      });
      h += '<tr class="tot"><td>Assets</td><td class="r">' + eur(bs.assets) + '</td></tr><tr class="tot"><td>Equity and liabilities</td><td class="r">' + eur(bs.liabilities) + '</td></tr></tbody></table></div>';
      h += '<div class="dpb-card"><h2>Trial balance</h2><table class="dpb-t"><thead><tr><th>Account</th><th class="r">Debit</th><th class="r">Credit</th><th class="r">Balance</th></tr></thead><tbody>' + R.tb.map(function (a) {
        return '<tr class="click" data-acc="' + a.code + '"><td>' + a.code + ' ' + esc(a.name) + '<small>' + esc(a.lv) + '</small></td><td class="r">' + eur(a.debit) + '</td><td class="r">' + eur(a.credit) + '</td><td class="r">' + eur(a.balance) + '</td></tr>';
      }).join('') + '</tbody></table><p class="dpb-mut">Balance is debit minus credit since the books started. Click an account to see its entries.</p></div></div>';
      main.innerHTML = h;
      wirePeriod(main, 'pr');
      main.querySelectorAll('[data-acc]').forEach(function (tr) { tr.addEventListener('click', function () { jAcc = tr.getAttribute('data-acc'); go('journal'); }); });
    });
  }

  // ------------------------------------------------------------------ settings
  function settings(my) {
    return load().then(function (s) {
      if (my !== seq) return;
      var v = s.settings, dis = ro() ? ' disabled' : '';
      var inp = function (k, label, type, cls, hint) { return '<label' + (cls ? ' class="' + cls + '"' : '') + '>' + label + (hint ? ' <em>' + hint + '</em>' : '') + '<input type="' + (type || 'text') + '" name="' + k + '" value="' + esc(v[k]) + '"' + dis + '></label>'; };
      var chk = function (k, label) { return '<label class="w2 chk"><input type="checkbox" name="' + k + '"' + (+v[k] ? ' checked' : '') + dis + '> ' + label + '</label>'; };
      var h = '<div class="dpb-card"><h2>The SIA</h2><div class="dpb-form">' + inp('company', 'Name', 'text', 'w2') + inp('reg_no', 'Registration number', 'text', '', '(11 digits)') + inp('registered', 'Registered on', 'date') +
        inp('address', 'Legal address', 'text', 'w2') + inp('email', 'Email for VID', 'email') + inp('phone', 'Phone for VID') +
        inp('board_name', 'Board member (keeps the books)', 'text', 'w2') + inp('board_title', 'Position') +
        '<label>Financial year starts<select name="fy_start"' + dis + '>' + MON.map(function (mn, i) { return '<option value="' + (i + 1) + '"' + (+v.fy_start === i + 1 ? ' selected' : '') + '>' + mn + '</option>'; }).join('') + '</select></label>' +
        inp('books_start', 'Books start on', 'date', '', '(usually the registration date)') + inp('gp_months', 'Annual report due, months after year end', 'number', '', '(5 for a micro company)') +
        chk('employees', 'The SIA employs someone (adds the monthly employer report)') + chk('vat', 'VAT registered') + inp('vat_no', 'VAT number') + '</div></div>';
      h += '<div class="dpb-card"><h2>Shop and stock</h2><div class="dpb-form">' + chk('sync_shop', 'Book shop orders automatically') + chk('sync_stock', 'Book received stock invoices, batches and outside sales') +
        '<label class="w2">Invoice amounts not tied to a stock item go to' + accSelect('inv_other', v.inv_other, function (a) { return a.type === 'x'; }) + '</label></div>' +
        '<h3>Where the money of each payment method lands</h3>' + (v.pay_codes.length ? '<table class="dpb-t"><tbody>' + v.pay_codes.map(function (p) { return '<tr><td>' + esc(p.name) + '<small>' + esc(p.code) + ' · ' + p.n + ' orders</small></td><td>' + accSelect('pm_' + p.code, (v.pay_map || {})[p.code] || '2310', function (a) { return a.tag === 'money' || a.code === '2310'; }) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="dpb-mut">No orders yet. Card payments (Stripe, PayPal) land in their balance; bank transfers stay as owed by the customer until the bank statement shows them.</p>') + '</div>';
      h += '<div class="dpb-card"><h2>Reminders</h2><div class="dpb-form">' + chk('remind_on', 'Email me before each deadline') + inp('remind_email', 'Send to', 'email') + inp('remind_days', 'Days before', 'text', '', '(e.g. 7,2,0)') + '</div>' + (ro() ? '' : '<button type="button" class="dpb-btn sm" data-test>Send a test email</button>') + ' <span class="dpb-mut">Late returns get a reminder once a week until they are marked submitted.</span></div>';
      h += '<div class="dpb-card"><h2>Notes text for the annual report</h2><div class="dpb-form"><label class="w4">Accounting policy (Latvian)<textarea name="policy"' + dis + '>' + esc(v.policy) + '</textarea></label></div></div>';
      if (!ro()) h += '<div class="dpb-row" style="margin-bottom:14px"><button type="button" class="dpb-btn pri" data-save>Save settings</button></div>';
      h += '<div class="dpb-card"><div class="dpb-ch"><h2>Chart of accounts</h2>' + (ro() ? '' : '<button type="button" class="dpb-btn sm" data-addacc>Add an account</button>') + '</div><table class="dpb-t"><thead><tr><th>No.</th><th>Name</th><th>Annual report row</th><th>Use</th></tr></thead><tbody>' + s.accounts.map(function (a) {
        return '<tr class="click" data-acc="' + a.code + '"><td>' + a.code + '</td><td>' + esc(a.name_en) + '<small>' + esc(a.name) + '</small></td><td>' + esc(a.gp) + '</td><td>' + (+a.status ? '' : '<span class="dpb-pill off">Hidden</span>') + (a.tag === 'R06_1' ? '<span class="dpb-pill late">Taxed in UIN</span>' : '') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
      main.innerHTML = h;
      var sv = main.querySelector('[data-save]');
      if (sv) sv.addEventListener('click', function () {
        var body = {};
        ['company', 'reg_no', 'registered', 'address', 'email', 'phone', 'board_name', 'board_title', 'fy_start', 'books_start', 'gp_months', 'employees', 'vat', 'vat_no', 'sync_shop', 'sync_stock', 'inv_other', 'remind_on', 'remind_email', 'remind_days', 'policy'].forEach(function (k) { body[k] = val(main, k); });
        body.pay_map = {}; v.pay_codes.forEach(function (p) { body.pay_map[p.code] = val(main, 'pm_' + p.code); });
        busy(sv, true);
        api('settings', body).then(function () { busy(sv, false); toast('Settings saved.'); S = null; }).catch(function (e) { busy(sv, false); toast(e.message, true); });
      });
      var t = main.querySelector('[data-test]');
      if (t) t.addEventListener('click', function () { api('test_reminder', {}).then(function () { toast('Test email sent.'); }).catch(function (e) { toast(e.message, true); }); });
      main.querySelectorAll('[data-acc]').forEach(function (tr) { tr.addEventListener('click', function () { if (!ro()) accountModal(acc(tr.getAttribute('data-acc'))); }); });
      var aa = main.querySelector('[data-addacc]'); if (aa) aa.addEventListener('click', function () { accountModal(null); });
    });
  }
  function accountModal(a) {
    var v = a || { code: '', name: '', name_en: '', type: 'x', gp: 'PZ:R70', tag: '', status: 1 };
    var m = modal(a ? 'Account ' + a.code : 'Add an account', '<div class="dpb-form"><label>Number<input type="text" name="code" value="' + esc(v.code) + '"' + (a ? ' disabled' : '') + '></label>' +
      '<label>Kind<select name="type"' + (a ? ' disabled' : '') + '>' + Object.keys(TYPE).map(function (k) { return '<option value="' + k + '"' + (v.type === k ? ' selected' : '') + '>' + TYPE[k] + '</option>'; }).join('') + '</select></label>' +
      '<label class="w2">Annual report row <em>(BA:R…, BP:R…, PZ:R…)</em><input type="text" name="gp" value="' + esc(v.gp) + '"></label>' +
      '<label class="w2">Name in Latvian<input type="text" name="name" value="' + esc(v.name) + '"></label><label class="w2">Name in English<input type="text" name="name_en" value="' + esc(v.name_en) + '"></label>' +
      '<label class="w2 chk"><input type="checkbox" name="status"' + (+v.status ? ' checked' : '') + '> In use</label><label class="w2 chk"><input type="checkbox" name="nb"' + (v.tag === 'R06_1' ? ' checked' : '') + '> Costs here are not for the business (taxed in UIN)</label></div>',
      '<button type="button" class="dpb-btn pri" data-save>Save</button>');
    m.querySelector('[data-save]').addEventListener('click', function () {
      var tag = v.tag; if (val(m, 'nb')) tag = 'R06_1'; else if (tag === 'R06_1') tag = '';
      api('save_account', { code: a ? a.code : val(m, 'code'), type: a ? a.type : val(m, 'type'), gp: val(m, 'gp'), name: val(m, 'name'), name_en: val(m, 'name_en'), status: val(m, 'status'), tag: tag })
        .then(function () { m.remove(); toast('Account saved.'); S = null; render(); }).catch(function (e) { toast(e.message, true); });
    });
  }

  var q = new URLSearchParams(location.search).get('tab');
  go(q && /^(overview|returns|expenses|bank|journal|reports|settings)$/.test(q) ? q : 'overview');
})();
