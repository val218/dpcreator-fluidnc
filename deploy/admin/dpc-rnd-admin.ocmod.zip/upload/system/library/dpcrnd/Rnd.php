<?php
/**
 * dpCREATOR R&D Club, shared by the admin and the shop:
 * - e-mails to members when something about them changes (invited, profile live, changes asked, update live or not),
 * - the texts of the member's R&D section in their account, in the shop languages,
 * - the public "in progress" numbers.
 * Reads the tables of rnd.php (dpc_rnd_member, dpc_rnd_update); never changes them.
 */
if (!class_exists('DpcRnd')) {
class DpcRnd {
	public static function t($code) {
		$all = array(
			'en' => array(
				'menu' => 'R&D Club', 'card_title' => 'R&D Club', 'members' => 'See all members',
				'st_invited' => 'You are in. Create your public R&D profile to start.', 'st_waiting' => 'Thank you! We are checking your profile, usually within a day.',
				'st_changes' => 'Please change your profile: %s', 'st_active' => 'Your profile is live on the members page.', 'st_hidden' => 'Your profile is hidden from the members page for now.',
				'stage' => 'Stage: %s', 'btn_create' => 'Create my profile', 'btn_edit' => 'Edit profile and post an update',
				'stages' => array('licences' => 'Got the licences', 'parts' => 'Parts ready', 'building' => 'Building', 'running' => 'First job run', 'report' => 'Report sent'),
				'hi' => 'Hi %s,', 'sign' => "Val\ndpCREATOR", 'login' => 'Log in with this e-mail address.',
				'm_invite_s' => 'You are in: dpCREATOR R&D Club',
				'm_invite' => "Your application to the dpCREATOR R&D Club is accepted. Welcome!\n\nNext step: create your public R&D profile (your machine, your controller and a few words about you). We check it before it goes on the members page.\n%s\n\nThen post your build updates as you go: parts, wiring, first job. Each update gets our feedback.",
				'm_live_s' => 'Your R&D profile is live',
				'm_live' => "Your R&D Club profile is now on the members page:\n%s\n\nPost your build updates from your profile page as you go:\n%s",
				'm_pchg_s' => 'Your R&D profile: one change, please',
				'm_pchg' => "Before your profile goes live, please change this:\n\n%s\n\nEdit it here:\n%s",
				'm_uok_s' => 'Your build update is live: %s',
				'm_uok' => "Your build update \"%s\" is now on the members page:\n%s",
				'm_uno_s' => 'Your build update: one change, please',
				'm_uno' => "Your build update \"%s\" did not go live yet:\n\n%s\n\nYou can post it again from your profile page:\n%s",
				'm_fb_s' => 'Feedback on your build update: %s',
				'm_fb' => "We left feedback on your build update \"%s\":\n\n%s\n\n%s"
			),
			'lv' => array(
				'menu' => 'R&D klubs', 'card_title' => 'R&D klubs', 'members' => 'Visi dalībnieki',
				'st_invited' => 'Jūs esat klubā! Lai sāktu, izveidojiet savu publisko R&D profilu.', 'st_waiting' => 'Paldies! Pārbaudām jūsu profilu, parasti dienas laikā.',
				'st_changes' => 'Lūdzu, izmainiet profilu: %s', 'st_active' => 'Jūsu profils ir redzams dalībnieku lapā.', 'st_hidden' => 'Jūsu profils pagaidām nav redzams dalībnieku lapā.',
				'stage' => 'Posms: %s', 'btn_create' => 'Izveidot profilu', 'btn_edit' => 'Labot profilu un ievietot jaunumus',
				'stages' => array('licences' => 'Licences saņemtas', 'parts' => 'Detaļas gatavas', 'building' => 'Būvē', 'running' => 'Pirmais darbs', 'report' => 'Atskaite nosūtīta'),
				'hi' => 'Sveiki, %s!', 'sign' => "Val\ndpCREATOR", 'login' => 'Pieslēdzieties ar šo e-pasta adresi.',
				'm_invite_s' => 'Jūs esat uzņemts dpCREATOR R&D klubā',
				'm_invite' => "Jūsu pieteikums dpCREATOR R&D klubam ir apstiprināts. Laipni lūdzam!\n\nNākamais solis: izveidojiet savu publisko R&D profilu (jūsu mašīna, kontrolieris un daži vārdi par jums). Pirms tas parādās dalībnieku lapā, mēs to pārbaudām.\n%s\n\nPēc tam ievietojiet jaunumus par būvi: detaļas, vadojums, pirmais darbs. Katram jaunumam sniegsim atsauksmi.",
				'm_live_s' => 'Jūsu R&D profils ir publicēts',
				'm_live' => "Jūsu R&D kluba profils tagad ir dalībnieku lapā:\n%s\n\nJaunumus par būvi ievietojiet savā profila lapā:\n%s",
				'm_pchg_s' => 'Jūsu R&D profils: lūdzu, vienu izmaiņu',
				'm_pchg' => "Pirms profils tiek publicēts, lūdzu, izmainiet šo:\n\n%s\n\nLabot šeit:\n%s",
				'm_uok_s' => 'Jūsu jaunums ir publicēts: %s',
				'm_uok' => "Jūsu jaunums \"%s\" tagad ir dalībnieku lapā:\n%s",
				'm_uno_s' => 'Jūsu jaunums: lūdzu, vienu izmaiņu',
				'm_uno' => "Jūsu jaunums \"%s\" vēl nav publicēts:\n\n%s\n\nTo var ievietot vēlreiz savā profila lapā:\n%s",
				'm_fb_s' => 'Atsauksme par jūsu jaunumu: %s',
				'm_fb' => "Mēs atstājām atsauksmi par jūsu jaunumu \"%s\":\n\n%s\n\n%s"
			),
			'de' => array(
				'menu' => 'R&D Club', 'card_title' => 'R&D Club', 'members' => 'Alle Mitglieder',
				'st_invited' => 'Sie sind dabei! Legen Sie zuerst Ihr öffentliches R&D-Profil an.', 'st_waiting' => 'Danke! Wir prüfen Ihr Profil, meist innerhalb eines Tages.',
				'st_changes' => 'Bitte ändern Sie Ihr Profil: %s', 'st_active' => 'Ihr Profil ist auf der Mitgliederseite zu sehen.', 'st_hidden' => 'Ihr Profil ist auf der Mitgliederseite vorerst ausgeblendet.',
				'stage' => 'Stand: %s', 'btn_create' => 'Profil anlegen', 'btn_edit' => 'Profil bearbeiten und Update posten',
				'stages' => array('licences' => 'Lizenzen erhalten', 'parts' => 'Teile bereit', 'building' => 'Im Bau', 'running' => 'Erster Auftrag gelaufen', 'report' => 'Bericht gesendet'),
				'hi' => 'Hallo %s,', 'sign' => "Val\ndpCREATOR", 'login' => 'Melden Sie sich mit dieser E-Mail-Adresse an.',
				'm_invite_s' => 'Sie sind dabei: dpCREATOR R&D Club',
				'm_invite' => "Ihre Bewerbung für den dpCREATOR R&D Club ist angenommen. Willkommen!\n\nNächster Schritt: Legen Sie Ihr öffentliches R&D-Profil an (Ihre Maschine, Ihr Controller und ein paar Worte über Sie). Wir prüfen es, bevor es auf der Mitgliederseite erscheint.\n%s\n\nDanach posten Sie Updates zu Ihrem Bau: Teile, Verdrahtung, erster Auftrag. Zu jedem Update geben wir Feedback.",
				'm_live_s' => 'Ihr R&D-Profil ist online',
				'm_live' => "Ihr R&D-Club-Profil ist jetzt auf der Mitgliederseite:\n%s\n\nUpdates zu Ihrem Bau posten Sie auf Ihrer Profilseite:\n%s",
				'm_pchg_s' => 'Ihr R&D-Profil: bitte eine Änderung',
				'm_pchg' => "Bevor Ihr Profil online geht, ändern Sie bitte Folgendes:\n\n%s\n\nHier bearbeiten:\n%s",
				'm_uok_s' => 'Ihr Update ist online: %s',
				'm_uok' => "Ihr Update \"%s\" ist jetzt auf der Mitgliederseite:\n%s",
				'm_uno_s' => 'Ihr Update: bitte eine Änderung',
				'm_uno' => "Ihr Update \"%s\" ist noch nicht online:\n\n%s\n\nSie können es auf Ihrer Profilseite erneut posten:\n%s",
				'm_fb_s' => 'Feedback zu Ihrem Update: %s',
				'm_fb' => "Wir haben Feedback zu Ihrem Update \"%s\" hinterlassen:\n\n%s\n\n%s"
			),
			'ru' => array(
				'menu' => 'R&D клуб', 'card_title' => 'R&D клуб', 'members' => 'Все участники',
				'st_invited' => 'Вы в клубе! Чтобы начать, создайте свой публичный R&D-профиль.', 'st_waiting' => 'Спасибо! Проверяем ваш профиль, обычно в течение дня.',
				'st_changes' => 'Пожалуйста, измените профиль: %s', 'st_active' => 'Ваш профиль опубликован на странице участников.', 'st_hidden' => 'Ваш профиль пока скрыт со страницы участников.',
				'stage' => 'Этап: %s', 'btn_create' => 'Создать профиль', 'btn_edit' => 'Изменить профиль и добавить новость',
				'stages' => array('licences' => 'Лицензии получены', 'parts' => 'Детали готовы', 'building' => 'Сборка', 'running' => 'Первая работа', 'report' => 'Отчёт отправлен'),
				'hi' => 'Здравствуйте, %s!', 'sign' => "Val\ndpCREATOR", 'login' => 'Войдите с этим адресом e-mail.',
				'm_invite_s' => 'Вы приняты в dpCREATOR R&D клуб',
				'm_invite' => "Ваша заявка в dpCREATOR R&D клуб принята. Добро пожаловать!\n\nСледующий шаг: создайте свой публичный R&D-профиль (ваш станок, контроллер и пара слов о вас). Мы проверим его перед публикацией на странице участников.\n%s\n\nЗатем публикуйте новости о сборке: детали, проводка, первая работа. На каждую новость мы дадим отзыв.",
				'm_live_s' => 'Ваш R&D-профиль опубликован',
				'm_live' => "Ваш профиль R&D клуба теперь на странице участников:\n%s\n\nНовости о сборке публикуйте на странице своего профиля:\n%s",
				'm_pchg_s' => 'Ваш R&D-профиль: нужно одно изменение',
				'm_pchg' => "Перед публикацией профиля, пожалуйста, измените:\n\n%s\n\nИзменить здесь:\n%s",
				'm_uok_s' => 'Ваша новость опубликована: %s',
				'm_uok' => "Ваша новость \"%s\" теперь на странице участников:\n%s",
				'm_uno_s' => 'Ваша новость: нужно одно изменение',
				'm_uno' => "Ваша новость \"%s\" пока не опубликована:\n\n%s\n\nЕё можно отправить снова на странице профиля:\n%s",
				'm_fb_s' => 'Отзыв о вашей новости: %s',
				'm_fb' => "Мы оставили отзыв о вашей новости \"%s\":\n\n%s\n\n%s"
			)
		);
		$k = strtolower(substr((string)$code, 0, 2));
		return isset($all[$k]) ? array_replace($all['en'], $all[$k]) : $all['en'];
	}

	private static function has($db, $t) {
		return (bool)$db->query("SHOW TABLES LIKE '" . $db->escape(DB_PREFIX . $t) . "'")->num_rows;
	}

	/** The member row of one customer, or null. */
	public static function member($db, $customer_id) {
		if (!$customer_id || !self::has($db, 'dpc_rnd_member')) {
			return null;
		}
		$r = $db->query("SELECT * FROM `" . DB_PREFIX . "dpc_rnd_member` WHERE customer_id = " . (int)$customer_id . " AND status <> 'removed' LIMIT 1");
		return $r->num_rows ? $r->row : null;
	}

	/** Public numbers: members still setting up (anonymous), and live profiles by stage. */
	public static function progress($db) {
		$o = array('setting_up' => 0, 'waiting' => 0, 'live' => 0, 'stages' => array('licences' => 0, 'parts' => 0, 'building' => 0, 'running' => 0, 'report' => 0), 'updates' => 0);
		if (!self::has($db, 'dpc_rnd_member')) {
			return $o;
		}
		foreach ($db->query("SELECT status, stage, pending, pub IS NOT NULL AS has_pub FROM `" . DB_PREFIX . "dpc_rnd_member` WHERE status IN ('invited','active')")->rows as $r) {
			if ($r['status'] === 'active') {
				$o['live']++;
				if (isset($o['stages'][$r['stage']])) { $o['stages'][$r['stage']]++; }
			} elseif ((int)$r['pending']) {
				$o['waiting']++;
			} else {
				$o['setting_up']++;
			}
		}
		if (self::has($db, 'dpc_rnd_update')) {
			$o['updates'] = (int)$db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_rnd_update` WHERE status = 'approved'")->row['n'];
		}
		return $o;
	}

	/**
	 * Sends the member e-mails that are due. Each e-mail is sent once (dpc_rnd_notice).
	 * $base: shop URL ending in "/". Returns how many were sent.
	 */
	public static function notify($db, $config, $base, $log = null) {
		if (!self::has($db, 'dpc_rnd_member')) {
			return 0;
		}
		$db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_rnd_notice` (`nkey` VARCHAR(80) NOT NULL, `sent_at` DATETIME NOT NULL, PRIMARY KEY (`nkey`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$sent = 0;
		$profile = $base . 'rnd-profile';
		$list = $base . 'rnd-members';
		$langs = array();
		foreach ($db->query("SELECT language_id, code FROM `" . DB_PREFIX . "language`")->rows as $l) {
			$langs[(int)$l['language_id']] = $l['code'];
		}
		$rows = $db->query("SELECT m.*, c.firstname, c.email, c.language_id FROM `" . DB_PREFIX . "dpc_rnd_member` m JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = m.customer_id WHERE m.status <> 'removed'")->rows;
		$members = array();
		foreach ($rows as $m) {
			$members[(int)$m['customer_id']] = $m;
			$due = array();
			$due[] = array('invite:' . $m['customer_id'] . ':' . $m['invited_at'], 'm_invite_s', 'm_invite', array(), array($profile));
			if ($m['status'] === 'active' && $m['pub_at']) {
				$due[] = array('live:' . $m['customer_id'], 'm_live_s', 'm_live', array(), array($list . '#m-' . $m['pid'], $profile));
			}
			if ((int)$m['pending'] === 0 && $m['reject_note'] !== '') {
				$due[] = array('pchg:' . $m['customer_id'] . ':' . md5($m['reject_note']), 'm_pchg_s', 'm_pchg', array(), array($m['reject_note'], $profile));
			}
			foreach ($due as $d) {
				$sent += self::once($db, $config, $d[0], $m, $langs, $d[1], $d[3], $d[2], $d[4], $log);
			}
		}
		if (self::has($db, 'dpc_rnd_update')) {
			foreach ($db->query("SELECT * FROM `" . DB_PREFIX . "dpc_rnd_update` WHERE status IN ('approved','rejected') OR (feedback IS NOT NULL AND feedback <> '')")->rows as $u) {
				$m = isset($members[(int)$u['customer_id']]) ? $members[(int)$u['customer_id']] : null;
				if (!$m) { continue; }
				if ($u['status'] === 'approved') {
					$fb = (string)$u['feedback'] !== '' ? "\n\n" . $u['feedback'] : '';
					$n = self::once($db, $config, 'uok:' . $u['id'], $m, $langs, 'm_uok_s', array($u['title']), 'm_uok', array($u['title'], $list . '#m-' . $m['pid'] . $fb), $log);
					if ($n && $fb !== '') {
						// the feedback went with it
						$db->query("INSERT IGNORE INTO `" . DB_PREFIX . "dpc_rnd_notice` SET nkey = '" . $db->escape(substr('ufb:' . $u['id'] . ':' . md5($u['feedback']), 0, 80)) . "', sent_at = NOW()");
					}
					$sent += $n;
				} elseif ($u['status'] === 'rejected') {
					$sent += self::once($db, $config, 'uno:' . $u['id'] . ':' . md5($u['reject_note']), $m, $langs, 'm_uno_s', array(), 'm_uno', array($u['title'], $u['reject_note'], $profile), $log);
				}
				if ((string)$u['feedback'] !== '' && $u['status'] === 'approved') {
					$sent += self::once($db, $config, 'ufb:' . $u['id'] . ':' . md5($u['feedback']), $m, $langs, 'm_fb_s', array($u['title']), 'm_fb', array($u['title'], $u['feedback'], $list . '#m-' . $m['pid']), $log);
				}
			}
		}
		return $sent;
	}

	private static function once($db, $config, $key, $m, $langs, $subjKey, $subjArgs, $bodyKey, $bodyArgs, $log) {
		$key = substr($key, 0, 80);
		if ($db->query("SELECT 1 FROM `" . DB_PREFIX . "dpc_rnd_notice` WHERE nkey = '" . $db->escape($key) . "'")->num_rows) {
			return 0;
		}
		// claim it first, so two page loads never send it twice
		$db->query("INSERT IGNORE INTO `" . DB_PREFIX . "dpc_rnd_notice` SET nkey = '" . $db->escape($key) . "', sent_at = NOW()");
		if (!$db->countAffected()) {
			return 0;
		}
		$code = isset($langs[(int)$m['language_id']]) ? $langs[(int)$m['language_id']] : 'en';
		$T = self::t($code);
		$subject = vsprintf($T[$subjKey], $subjArgs);
		$body = sprintf($T['hi'], $m['firstname']) . "\n\n" . vsprintf($T[$bodyKey], $bodyArgs) . "\n\n" . $T['login'] . "\n\n" . $T['sign'] . "\n";
		if (self::mail($config, $m['email'], $subject, $body, $log)) {
			return 1;
		}
		// not sent: try again later
		$db->query("DELETE FROM `" . DB_PREFIX . "dpc_rnd_notice` WHERE nkey = '" . $db->escape($key) . "'");
		return 0;
	}

	public static function mail($config, $to, $subject, $text, $log = null) {
		try {
			$from = (string)$config->get('config_email');
			if ($from === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
				return false;
			}
			$mail = new Mail($config->get('config_mail_engine'));
			$mail->parameter = $config->get('config_mail_parameter');
			$mail->smtp_hostname = $config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode((string)$config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $config->get('config_mail_smtp_timeout');
			$mail->setTo($to);
			$mail->setFrom($from);
			$mail->setReplyTo($from);
			$mail->setSender(html_entity_decode((string)$config->get('config_name'), ENT_QUOTES, 'UTF-8'));
			$mail->setSubject($subject);
			$mail->setText($text);
			$mail->send();
			return true;
		} catch (\Throwable $e) {
			if ($log) { $log->write('dpc_rnd mail: ' . $e->getMessage()); }
			return false;
		}
	}
}
}
