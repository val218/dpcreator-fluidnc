<?php
$_['heading_title'] = 'dpCREATOR R&D Club (admin menu, applications and review count)';
