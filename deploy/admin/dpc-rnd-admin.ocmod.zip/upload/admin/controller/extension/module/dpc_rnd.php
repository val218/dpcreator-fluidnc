<?php
// dpCREATOR R&D Club in the admin: its own side menu entry with a count of what is waiting
// (new applications from the R&D Club form, profiles and build updates to review), and an Applications page
// where an application becomes an invite with one click. Reviewing profiles and updates stays on rnd.php?f=admin.
class ControllerExtensionModuleDpcRnd extends Controller {
	// Labels of the "Experience with FluidNC" field of the R&D Club form (Journal form module 272), in every shop language.
	private static $MARK = array('Experience with FluidNC', 'Pieredze ar FluidNC', 'Erfahrung mit FluidNC', 'Опыт с FluidNC');

	public function install() {
		$this->table();
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_rnd', array('module_dpc_rnd_status' => 1));
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_rnd');
		$this->model_setting_event->addEvent('dpc_rnd', 'admin/view/common/column_left/before', 'extension/module/dpc_rnd/menu');
		$this->model_setting_event->addEvent('dpc_rnd', 'catalog/controller/journal3/form/send/before', 'extension/module/dpc_rnd/apply');
	}

	public function uninstall() {
		// The application states stay.
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_rnd');
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_rnd');
	}

	private function table() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_rnd_app_state` (
			`app_key` VARCHAR(20) NOT NULL, `state` VARCHAR(10) NOT NULL DEFAULT 'new', `at` DATETIME NOT NULL,
			PRIMARY KEY (`app_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_rnd_application` (
			`application_id` INT NOT NULL AUTO_INCREMENT, `name` VARCHAR(120) NOT NULL, `email` VARCHAR(160) NOT NULL,
			`fields` MEDIUMTEXT NOT NULL, `language` VARCHAR(8) NOT NULL DEFAULT '', `ip` VARCHAR(45) NOT NULL DEFAULT '',
			`customer_id` INT NOT NULL DEFAULT 0, `created` DATETIME NOT NULL, PRIMARY KEY (`application_id`), KEY `email` (`email`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	private function e($s) { return $this->db->escape((string)$s); }
	private function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
	private function link($route, $q = '') { return html_entity_decode($this->url->link($route, 'user_token=' . $this->session->data['user_token'] . ($q ? '&' . $q : ''), true), ENT_QUOTES, 'UTF-8'); }
	private function hasTable($t) { return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e(DB_PREFIX . $t) . "'")->num_rows; }
	private function out($x) { $this->response->addHeader('Content-Type: application/json'); $this->response->setOutput(json_encode($x)); }

	/** R&D Club applications, newest first: the ones this add-on saves, and any in Journal's form e-mails. */
	private function applications() {
		$this->table();
		$raw = array();
		foreach ($this->db->query("SELECT * FROM `" . DB_PREFIX . "dpc_rnd_application` ORDER BY application_id DESC LIMIT 300")->rows as $r) {
			$f = json_decode((string)$r['fields'], true);
			$raw[] = array('key' => 'a' . (int)$r['application_id'], 'name' => $r['name'], 'email' => $r['email'], 'date' => $r['created'], 'fields' => is_array($f) ? $f : array(), 'sort' => strtotime($r['created']));
		}
		if ($this->hasTable('journal3_message')) {
			$cols = array();
			foreach ($this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "journal3_message`")->rows as $c) {
				$cols[] = $c['Field'];
			}
			$id = $cols[0];
			$date = '';
			foreach ($cols as $c) {
				if (preg_match('/date|created|time/i', $c)) { $date = $c; break; }
			}
			foreach ($this->db->query("SELECT * FROM `" . DB_PREFIX . "journal3_message` WHERE `fields` LIKE '%FluidNC%' ORDER BY `" . $id . "` DESC LIMIT 300")->rows as $r) {
				$f = json_decode((string)$r['fields'], true);
				if (!is_array($f)) { continue; }
				$isApp = false;
				$email = isset($r['email']) ? trim((string)$r['email']) : '';
				$name = isset($r['name']) ? trim((string)$r['name']) : '';
				$fields = array();
				foreach ($f as $x) {
					$label = isset($x['label']) ? (string)$x['label'] : '';
					$val = isset($x['value']) ? $x['value'] : '';
					if (is_array($val)) { $val = implode(', ', $val); }
					$val = trim((string)$val);
					if (in_array($label, self::$MARK, true)) { $isApp = true; }
					if ($email === '' && filter_var($val, FILTER_VALIDATE_EMAIL)) { $email = $val; }
					if ($name === '' && $val !== '' && !$fields) { $name = $val; }
					$fields[] = array('label' => $label, 'value' => $val);
				}
				if (!$isApp) { continue; }
				$d = $date && isset($r[$date]) ? (string)$r[$date] : '';
				$raw[] = array('key' => 'j' . (int)$r[$id], 'name' => $name, 'email' => $email, 'date' => $d, 'fields' => $fields, 'sort' => $d ? strtotime($d) : 0);
			}
		}
		usort($raw, function ($a, $b) { return $b['sort'] - $a['sort']; });
		$states = array();
		foreach ($this->db->query("SELECT app_key, state FROM `" . DB_PREFIX . "dpc_rnd_app_state`")->rows as $r) {
			$states[$r['app_key']] = $r['state'];
		}
		$members = array();
		if ($this->hasTable('dpc_rnd_member')) {
			foreach ($this->db->query("SELECT LOWER(c.email) AS email, m.status FROM `" . DB_PREFIX . "dpc_rnd_member` m JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = m.customer_id")->rows as $r) {
				$members[$r['email']] = $r['status'];
			}
		}
		$out = array();
		foreach ($raw as $a) {
			$le = strtolower($a['email']);
			$state = isset($states[$a['key']]) ? $states[$a['key']] : 'new';
			if (isset($members[$le]) && $state === 'new') { $state = 'invited'; }
			$a['state'] = $state;
			$a['member'] = isset($members[$le]) ? $members[$le] : '';
			$out[] = $a;
		}
		return $out;
	}

	/** What is waiting: new applications, profiles and updates to review. */
	private function counts() {
		$c = array('apps' => 0, 'review' => 0);
		try {
			foreach ($this->applications() as $a) {
				if ($a['state'] === 'new') { $c['apps']++; }
			}
		} catch (\Throwable $e) {
		}
		try {
			if ($this->hasTable('dpc_rnd_member')) {
				$c['review'] += (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_rnd_member` WHERE pending = 1 AND status <> 'removed'")->row['n'];
			}
			if ($this->hasTable('dpc_rnd_update')) {
				$c['review'] += (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_rnd_update` WHERE status = 'pending'")->row['n'];
			}
		} catch (\Throwable $e) {
		}
		return $c;
	}

	private function badge($n) {
		return $n > 0 ? ' <span class="label label-danger" style="margin-left:6px;border-radius:9px;padding:2px 7px;font-size:11px">' . (int)$n . '</span>' : '';
	}

	// ------------------------------------------------------------------ menu entry
	public function menu(&$route, &$data, &$output) {
		if (!(int)$this->config->get('module_dpc_rnd_status') || !$this->user->hasPermission('access', 'extension/module/dpc_rnd') || !isset($data['menus']) || !is_array($data['menus'])) {
			return;
		}
		$c = $this->counts();
		$entry = array('id' => 'menu-dpc-rnd', 'icon' => 'fa-flask', 'name' => 'R&amp;D Club' . $this->badge($c['apps'] + $c['review']), 'href' => '', 'children' => array(
			array('name' => 'Applications' . $this->badge($c['apps']), 'href' => $this->link('extension/module/dpc_rnd'), 'children' => array()),
			array('name' => 'Review profiles and updates' . $this->badge($c['review']), 'href' => HTTPS_CATALOG . 'rnd.php?f=admin', 'children' => array()),
			array('name' => 'Members page (public)', 'href' => HTTPS_CATALOG . 'rnd-members', 'children' => array()),
			array('name' => 'R&amp;D Club page (public)', 'href' => HTTPS_CATALOG . 'rnd-club', 'children' => array())
		));
		$pos = count($data['menus']);
		foreach ($data['menus'] as $i => $m) {
			if (isset($m['id']) && $m['id'] === 'menu-customer') { $pos = $i + 1; }
		}
		array_splice($data['menus'], $pos, 0, array($entry));
	}

	// ------------------------------------------------------------------ applications page
	public function index() {
		$this->document->setTitle('R&D Club applications');
		$apps = $this->applications();
		$c = $this->counts();
		$can = $this->user->hasPermission('modify', 'extension/module/dpc_rnd');
		$accounts = array();
		$emails = array();
		foreach ($apps as $a) {
			if ($a['email'] !== '') { $emails[] = "'" . $this->e(strtolower($a['email'])) . "'"; }
		}
		if ($emails) {
			foreach ($this->db->query("SELECT LOWER(email) AS email FROM `" . DB_PREFIX . "customer` WHERE LOWER(email) IN (" . implode(',', array_unique($emails)) . ")")->rows as $r) {
				$accounts[$r['email']] = 1;
			}
		}
		$pill = array('new' => array('New', '#d9822b'), 'invited' => array('Invited', '#2e8b57'), 'declined' => array('Declined', '#8a8a8a'));
		$o = '<div id="content"><div class="page-header"><div class="container-fluid"><h1>R&amp;D Club applications</h1>'
			. '<p style="margin:6px 0 0;color:#666">Applications sent with the form on the R&amp;D Club page. <b>Invite</b> lets that customer fill in their R&amp;D profile; '
			. 'you approve the profile afterwards in <a href="' . HTTPS_CATALOG . 'rnd.php?f=admin" target="_blank" rel="noopener">Review profiles and updates</a>'
			. ($c['review'] ? ' (' . (int)$c['review'] . ' waiting)' : '') . '.</p></div></div><div class="container-fluid">';
		if (!$apps) {
			$o .= '<div class="alert alert-info">No applications yet.</div>';
		}
		$o .= '<div class="btn-group" style="margin-bottom:12px" id="rnd-filter"><button class="btn btn-default active" data-f="new">New (' . (int)$c['apps'] . ')</button><button class="btn btn-default" data-f="all">All (' . count($apps) . ')</button></div>';
		foreach ($apps as $a) {
			$p = isset($pill[$a['state']]) ? $pill[$a['state']] : $pill['new'];
			$has = $a['email'] !== '' && isset($accounts[strtolower($a['email'])]);
			$o .= '<div class="panel panel-default rnd-app" data-state="' . $this->h($a['state']) . '"><div class="panel-heading" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">'
				. '<strong style="font-size:15px">' . $this->h($a['name'] !== '' ? $a['name'] : $a['email']) . '</strong>'
				. '<span class="label" style="background:' . $p[1] . '">' . $p[0] . '</span>'
				. ($a['member'] ? '<span class="label label-info">profile: ' . $this->h($a['member']) . '</span>' : '')
				. '<span style="color:#777">' . $this->h($a['email']) . ($a['date'] ? ' · ' . $this->h(substr($a['date'], 0, 16)) : '') . '</span>'
				. '<span style="color:' . ($has ? '#2e8b57' : '#c0392b') . '">' . ($has ? 'has a shop account' : 'no shop account with this e-mail yet') . '</span>'
				. '</div><div class="panel-body"><dl class="dl-horizontal" style="margin:0">';
			foreach ($a['fields'] as $f) {
				if ($f['value'] === '') { continue; }
				$v = $this->h($f['value']);
				$v = preg_replace('~(https?://[^\s<]+)~', '<a href="$1" target="_blank" rel="nofollow noopener">$1</a>', $v);
				$o .= '<dt style="white-space:normal;width:260px">' . $this->h($f['label']) . '</dt><dd style="margin-left:280px;white-space:pre-wrap">' . $v . '</dd>';
			}
			$o .= '</dl>';
			if ($can) {
				$o .= '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">';
				if ($a['state'] !== 'invited') {
					$o .= '<button class="btn btn-success rnd-invite" data-id="' . $this->h($a['key']) . '" data-email="' . $this->h($a['email']) . '"' . ($has ? '' : ' title="They need to register first"') . '>Invite</button>';
				}
				if ($a['state'] === 'new') {
					$o .= '<button class="btn btn-default rnd-state" data-id="' . $this->h($a['key']) . '" data-state="declined">Decline</button>';
				} else {
					$o .= '<button class="btn btn-default rnd-state" data-id="' . $this->h($a['key']) . '" data-state="new">Mark as new</button>';
				}
				if ($a['email'] !== '') {
					$o .= '<a class="btn btn-link" href="mailto:' . $this->h($a['email']) . '?subject=' . rawurlencode('dpCREATOR R&D Club') . '">E-mail them</a>';
				}
				$o .= '</div>';
			}
			$o .= '</div></div>';
		}
		$o .= '</div></div><script>(function(){'
			. 'var api=' . json_encode($this->link('extension/module/dpc_rnd/state')) . ',rnd=' . json_encode(HTTPS_CATALOG . 'rnd.php?f=admin_action') . ';'
			. 'function filt(f){document.querySelectorAll(".rnd-app").forEach(function(p){p.style.display=(f==="all"||p.getAttribute("data-state")===f)?"":"none";});document.querySelectorAll("#rnd-filter button").forEach(function(b){b.classList.toggle("active",b.getAttribute("data-f")===f);});}'
			. 'document.querySelectorAll("#rnd-filter button").forEach(function(b){b.onclick=function(){filt(b.getAttribute("data-f"));};});filt("new");'
			. 'function setState(id,st){return fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"same-origin",body:JSON.stringify({id:id,state:st})}).then(function(r){return r.json();});}'
			. 'document.querySelectorAll(".rnd-state").forEach(function(b){b.onclick=function(){b.disabled=true;setState(b.getAttribute("data-id"),b.getAttribute("data-state")).then(function(){location.reload();});};});'
			. 'document.querySelectorAll(".rnd-invite").forEach(function(b){b.onclick=function(){b.disabled=true;'
			. 'fetch(rnd,{method:"POST",headers:{"Content-Type":"application/json","X-RND":"1"},credentials:"include",body:JSON.stringify({action:"invite",email:b.getAttribute("data-email")})})'
			. '.then(function(r){return r.json();}).then(function(j){if(j.error){alert(j.error);b.disabled=false;return;}setState(b.getAttribute("data-id"),"invited").then(function(){location.reload();});})'
			. '.catch(function(){alert("Could not reach rnd.php. Invite them on the Review page instead.");b.disabled=false;});};});'
			. '})();</script>';
		$this->response->setOutput($this->load->controller('common/header') . $this->load->controller('common/column_left') . $o . $this->load->controller('common/footer'));
	}

	public function state() {
		if (!$this->user->hasPermission('modify', 'extension/module/dpc_rnd')) {
			return $this->out(array('error' => 'No permission'));
		}
		$in = json_decode(file_get_contents('php://input'), true);
		$id = isset($in['id']) && preg_match('/^[aj]\d{1,9}$/', (string)$in['id']) ? (string)$in['id'] : '';
		$st = isset($in['state']) ? (string)$in['state'] : '';
		if (!$id || !in_array($st, array('new', 'invited', 'declined'), true)) {
			return $this->out(array('error' => 'Bad request'));
		}
		$this->table();
		$this->db->query("REPLACE INTO `" . DB_PREFIX . "dpc_rnd_app_state` SET app_key = '" . $this->e($id) . "', state = '" . $this->e($st) . "', at = NOW()");
		$this->out(array('ok' => 1));
	}
}
