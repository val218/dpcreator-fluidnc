<?php
// dpCREATOR R&D Club: keeps every application sent with the R&D Club form (Journal form module 272).
// Runs before Journal's own journal3/form/send, saves the application in dpc_rnd_application and e-mails the shop,
// then lets Journal carry on as before. Never stops the form from answering.
class ControllerExtensionModuleDpcRnd extends Controller {
	const FORM = 272;
	private static $LABELS = array(1 => 'Name or nickname', 2 => 'Email', 3 => 'Country', 4 => 'Machine type', 5 => 'Machine',
		6 => 'Experience with FluidNC', 7 => 'Controller to test on', 8 => 'About them', 9 => 'Where they share builds', 10 => 'Photos of the machine', 11 => 'Terms');

	public function apply(&$route, &$args) {
		try {
			if (!isset($this->request->get['module_id']) || (int)$this->request->get['module_id'] !== self::FORM || empty($this->request->post['item']) || !is_array($this->request->post['item'])) {
				return null;
			}
			$fields = array();
			$name = '';
			$email = '';
			foreach ($this->request->post['item'] as $k => $v) {
				$v = is_array($v) ? implode(', ', array_map('strval', $v)) : (string)$v;
				$v = trim(html_entity_decode($v, ENT_QUOTES, 'UTF-8'));
				$v = mb_substr($v, 0, 4000);
				$label = isset(self::$LABELS[(int)$k]) ? self::$LABELS[(int)$k] : 'Field ' . (int)$k;
				$fields[] = array('label' => $label, 'value' => $v);
				if ((int)$k === 1) { $name = mb_substr($v, 0, 120); }
				if ((int)$k === 2) { $email = mb_substr($v, 0, 160); }
			}
			if ($name === '' && $email === '') {
				return null;
			}
			$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_rnd_application` (
				`application_id` INT NOT NULL AUTO_INCREMENT, `name` VARCHAR(120) NOT NULL, `email` VARCHAR(160) NOT NULL,
				`fields` MEDIUMTEXT NOT NULL, `language` VARCHAR(8) NOT NULL DEFAULT '', `ip` VARCHAR(45) NOT NULL DEFAULT '',
				`customer_id` INT NOT NULL DEFAULT 0, `created` DATETIME NOT NULL, PRIMARY KEY (`application_id`), KEY `email` (`email`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
			$ip = isset($this->request->server['REMOTE_ADDR']) ? (string)$this->request->server['REMOTE_ADDR'] : '';
			// the same application sent twice within ten minutes is kept once
			$dup = $this->db->query("SELECT application_id FROM `" . DB_PREFIX . "dpc_rnd_application` WHERE email = '" . $this->db->escape($email) . "' AND created > DATE_SUB(NOW(), INTERVAL 10 MINUTE) LIMIT 1")->num_rows;
			if ($dup) {
				return null;
			}
			$this->db->query("INSERT INTO `" . DB_PREFIX . "dpc_rnd_application` SET name = '" . $this->db->escape($name) . "', email = '" . $this->db->escape($email) . "', fields = '" . $this->db->escape(json_encode($fields, JSON_UNESCAPED_UNICODE)) . "', language = '" . $this->db->escape((string)$this->config->get('config_language')) . "', ip = '" . $this->db->escape($ip) . "', customer_id = " . (int)$this->customer->getId() . ", created = NOW()");
			$this->mail($name, $email, $fields);
		} catch (\Throwable $e) {
			$this->log->write('dpc_rnd apply: ' . $e->getMessage());
		}
		return null;
	}

	private function mail($name, $email, $fields) {
		try {
			$to = (string)$this->config->get('config_email');
			if ($to === '') {
				return;
			}
			$text = "New R&D Club application\n\n";
			foreach ($fields as $f) {
				$text .= $f['label'] . ":\n" . $f['value'] . "\n\n";
			}
			$text .= "Review and invite: " . HTTPS_SERVER . "admin/index.php?route=extension/module/dpc_rnd\n";
			$mail = new Mail($this->config->get('config_mail_engine'));
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			$mail->setTo($to);
			$mail->setFrom($to);
			if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$mail->setReplyTo($email);
			}
			$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
			$mail->setSubject('R&D Club application: ' . ($name !== '' ? $name : $email));
			$mail->setText($text);
			$mail->send();
		} catch (\Throwable $e) {
			$this->log->write('dpc_rnd mail: ' . $e->getMessage());
		}
	}

	private function rnd() {
		require_once(DIR_SYSTEM . 'library/dpcrnd/Rnd.php');
	}

	private function lang() {
		return isset($this->session->data['language']) ? (string)$this->session->data['language'] : (string)$this->config->get('config_language');
	}

	private function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

	/** GET index.php?route=extension/module/dpc_rnd/progress: public numbers for the members page. */
	public function progress() {
		$o = array();
		try {
			$this->rnd();
			$o = DpcRnd::progress($this->db);
		} catch (\Throwable $e) {
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: max-age=60');
		$this->response->setOutput(json_encode($o));
	}

	/** catalog/controller/common/footer/before: sends due member e-mails, at most once a minute. */
	public function tick(&$route, &$args) {
		try {
			$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_rnd_notice` (`nkey` VARCHAR(80) NOT NULL, `sent_at` DATETIME NOT NULL, PRIMARY KEY (`nkey`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
			$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "dpc_rnd_notice` SET nkey = '~tick', sent_at = '2000-01-01'");
			$this->db->query("UPDATE `" . DB_PREFIX . "dpc_rnd_notice` SET sent_at = NOW() WHERE nkey = '~tick' AND sent_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)");
			if ($this->db->countAffected()) {
				$this->rnd();
				DpcRnd::notify($this->db, $this->config, HTTPS_SERVER, $this->log);
			}
		} catch (\Throwable $e) {
		}
		return null;
	}

	/** catalog/view/account/STAR/after: the member's R&D Club link in the account menu, and a card on the account page. */
	public function account(&$route, &$data, &$output) {
		try {
			if (!is_string($output) || !$this->customer->isLogged()) {
				return;
			}
			$this->rnd();
			$m = DpcRnd::member($this->db, (int)$this->customer->getId());
			if (!$m) {
				return;
			}
			$T = DpcRnd::t($this->lang());
			$profile = HTTPS_SERVER . 'rnd-profile';
			$list = HTTPS_SERVER . 'rnd-members';
			// menu link, right after "My Account" in Journal's account menu
			if (preg_match('~<div class="accordion-menu accordion-menu-\d+">\s*<ul class="j-menu">\s*<li\b.*?</li>~s', $output, $mm, PREG_OFFSET_CAPTURE)) {
				$at = $mm[0][1] + strlen($mm[0][0]);
				$li = '<li class="menu-item accordion-menu-item dpc-rnd-mi"><a href="' . $this->h($profile) . '"><span class="links-text">' . $this->h($T['menu']) . '</span></a></li>';
				$output = substr($output, 0, $at) . $li . substr($output, $at);
			}
			// and in Modern Customer Account's own side menu, after Overview
			if (strpos($output, 'dpc-rnd-mca') === false && preg_match('~<a class="mca-nav-a[^"]*"[^>]*>.*?</a>~s', $output, $nm, PREG_OFFSET_CAPTURE)) {
				$at = $nm[0][1] + strlen($nm[0][0]);
				$a = '<a class="mca-nav-a dpc-rnd-mca" href="' . $this->h($profile) . '"><span>' . $this->h($T['menu']) . '</span><span class="mca-count"></span></a>';
				$output = substr($output, 0, $at) . $a . substr($output, $at);
			}
			if (!preg_match('~(^|/)account/account$~', (string)$route) || strpos($output, 'id="dpc-rnd-card"') !== false) {
				return;
			}
			$draft = $m['draft'] !== null && $m['draft'] !== '';
			if ($m['status'] === 'active') {
				$st = $T['st_active'];
			} elseif ($m['status'] === 'hidden') {
				$st = $T['st_hidden'];
			} elseif ((int)$m['pending']) {
				$st = $T['st_waiting'];
			} elseif ($m['reject_note'] !== '') {
				$st = sprintf($T['st_changes'], $m['reject_note']);
			} else {
				$st = $T['st_invited'];
			}
			$stages = array_keys($T['stages']);
			$idx = array_search($m['stage'], $stages);
			$bar = '<div class="dpc-rnd-bar">';
			foreach ($stages as $i => $k) {
				$bar .= '<span class="' . ($idx !== false && $i <= $idx && ($m['status'] === 'active' || $draft) ? 'on' : '') . '">' . $this->h($T['stages'][$k]) . '</span>';
			}
			$bar .= '</div>';
			$btn = $draft ? $T['btn_edit'] : $T['btn_create'];
			$card = '<section id="dpc-rnd-card" class="dpc-rnd-card"><style>'
				. '.dpc-rnd-card{border:1px solid #2a2f36;border-radius:14px;padding:18px 20px;margin:0 0 22px;background:#0d1014;color:#d6dbe0}'
				. '.dpc-rnd-card h2{margin:0 0 6px;font-size:18px;color:#fff}.dpc-rnd-card p{margin:0 0 12px;color:#c9c9c9}'
				. '.dpc-rnd-bar{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}.dpc-rnd-bar span{font-size:12px;padding:4px 10px;border-radius:99px;border:1px solid #333a42;color:#8d96a0}'
				. '.dpc-rnd-card .dpc-rnd-bar span.on,html.dpc-light .dpc-rnd-card .dpc-rnd-bar span.on{background:#1f6fb8!important;border-color:#1f6fb8!important;color:#fff!important}.dpc-rnd-acts{display:flex;gap:10px;flex-wrap:wrap}'
				. '.dpc-rnd-acts a{display:inline-block;padding:9px 16px;border-radius:10px;text-decoration:none;font-weight:500}.dpc-rnd-card .dpc-rnd-acts a.p,.dpc-rnd-card .dpc-rnd-acts a.p:hover,.dpc-rnd-card .dpc-rnd-acts a.p:visited{background:#1f6fb8!important;color:#fff!important}.dpc-rnd-card .dpc-rnd-acts a.p:hover{background:#2b8fe0!important}.dpc-rnd-card .dpc-rnd-acts a.s{border:1px solid #333a42;color:#e6e6e6!important}'
				. 'html.dpc-light .dpc-rnd-card{background:#fff;border-color:#e3e6ea;color:#333}html.dpc-light .dpc-rnd-card h2{color:#111}html.dpc-light .dpc-rnd-card p{color:#444}'
				. 'html.dpc-light .dpc-rnd-bar span{border-color:#d5dae0;color:#5b6570}html.dpc-light .dpc-rnd-card .dpc-rnd-acts a.s{border-color:#d5dae0;color:#1f6fb8!important}html.dpc-light .dpc-rnd-card .dpc-rnd-acts a.p{color:#fff!important}'
				. '</style><h2>' . $this->h($T['card_title']) . '</h2><p>' . $this->h($st) . '</p>' . $bar
				. '<div class="dpc-rnd-acts"><a class="p" href="' . $this->h($profile) . '">' . $this->h($btn) . '</a><a class="s" href="' . $this->h($list) . '">' . $this->h($T['members']) . '</a></div></section>';
			if (preg_match('/<div\b[^>]*\bid\s*=\s*["\']content["\'][^>]*>/i', $output, $cm, PREG_OFFSET_CAPTURE)) {
				$at = $cm[0][1] + strlen($cm[0][0]);
				$output = substr($output, 0, $at) . $card . substr($output, $at);
			}
		} catch (\Throwable $e) {
		}
	}
}
