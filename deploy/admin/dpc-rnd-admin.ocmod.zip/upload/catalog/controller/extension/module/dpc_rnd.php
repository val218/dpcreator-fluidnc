<?php
// dpCREATOR R&D Club: keeps every application sent with the R&D Club form (Journal form module 272).
// Runs before Journal's own journal3/form/send, saves the application in dpc_rnd_application and e-mails the shop,
// then lets Journal carry on as before. Never stops the form from answering.
class ControllerExtensionModuleDpcRnd extends Controller {
	const FORM = 272;
	private static $LABELS = array(1 => 'Name or nickname', 2 => 'Email', 3 => 'Country', 4 => 'Machine type', 5 => 'Machine',
		6 => 'Experience with FluidNC', 7 => 'Controller to test on', 8 => 'About them', 9 => 'Where they share builds', 10 => 'Photos of the machine', 11 => 'Terms');

	public function apply(&$route, &$args) {
		try {
			if (!isset($this->request->get['module_id']) || (int)$this->request->get['module_id'] !== self::FORM || empty($this->request->post['item']) || !is_array($this->request->post['item'])) {
				return null;
			}
			$fields = array();
			$name = '';
			$email = '';
			foreach ($this->request->post['item'] as $k => $v) {
				$v = is_array($v) ? implode(', ', array_map('strval', $v)) : (string)$v;
				$v = trim(html_entity_decode($v, ENT_QUOTES, 'UTF-8'));
				$v = mb_substr($v, 0, 4000);
				$label = isset(self::$LABELS[(int)$k]) ? self::$LABELS[(int)$k] : 'Field ' . (int)$k;
				$fields[] = array('label' => $label, 'value' => $v);
				if ((int)$k === 1) { $name = mb_substr($v, 0, 120); }
				if ((int)$k === 2) { $email = mb_substr($v, 0, 160); }
			}
			if ($name === '' && $email === '') {
				return null;
			}
			$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_rnd_application` (
				`application_id` INT NOT NULL AUTO_INCREMENT, `name` VARCHAR(120) NOT NULL, `email` VARCHAR(160) NOT NULL,
				`fields` MEDIUMTEXT NOT NULL, `language` VARCHAR(8) NOT NULL DEFAULT '', `ip` VARCHAR(45) NOT NULL DEFAULT '',
				`customer_id` INT NOT NULL DEFAULT 0, `created` DATETIME NOT NULL, PRIMARY KEY (`application_id`), KEY `email` (`email`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
			$ip = isset($this->request->server['REMOTE_ADDR']) ? (string)$this->request->server['REMOTE_ADDR'] : '';
			// the same application sent twice within ten minutes is kept once
			$dup = $this->db->query("SELECT application_id FROM `" . DB_PREFIX . "dpc_rnd_application` WHERE email = '" . $this->db->escape($email) . "' AND created > DATE_SUB(NOW(), INTERVAL 10 MINUTE) LIMIT 1")->num_rows;
			if ($dup) {
				return null;
			}
			$this->db->query("INSERT INTO `" . DB_PREFIX . "dpc_rnd_application` SET name = '" . $this->db->escape($name) . "', email = '" . $this->db->escape($email) . "', fields = '" . $this->db->escape(json_encode($fields, JSON_UNESCAPED_UNICODE)) . "', language = '" . $this->db->escape((string)$this->config->get('config_language')) . "', ip = '" . $this->db->escape($ip) . "', customer_id = " . (int)$this->customer->getId() . ", created = NOW()");
			$this->mail($name, $email, $fields);
		} catch (\Throwable $e) {
			$this->log->write('dpc_rnd apply: ' . $e->getMessage());
		}
		return null;
	}

	private function mail($name, $email, $fields) {
		try {
			$to = (string)$this->config->get('config_email');
			if ($to === '') {
				return;
			}
			$text = "New R&D Club application\n\n";
			foreach ($fields as $f) {
				$text .= $f['label'] . ":\n" . $f['value'] . "\n\n";
			}
			$text .= "Review and invite: " . HTTPS_SERVER . "admin/index.php?route=extension/module/dpc_rnd\n";
			$mail = new Mail($this->config->get('config_mail_engine'));
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			$mail->setTo($to);
			$mail->setFrom($to);
			if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$mail->setReplyTo($email);
			}
			$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
			$mail->setSubject('R&D Club application: ' . ($name !== '' ? $name : $email));
			$mail->setText($text);
			$mail->send();
		} catch (\Throwable $e) {
			$this->log->write('dpc_rnd mail: ' . $e->getMessage());
		}
	}
}
