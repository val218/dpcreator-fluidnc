<?php
// dpCREATOR SEO fixes: the sitemap lists categories under the same address their canonical tag uses,
// and old addresses of retired products forward (301) to the product that replaced them.
class ControllerExtensionModuleDpcSeo extends Controller {
	public function install() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_seo_sitemap');
		$this->model_setting_event->deleteEventByCode('dpc_seo_redirect');
		$this->model_setting_event->addEvent('dpc_seo_sitemap', 'catalog/controller/extension/feed/google_sitemap/after', 'extension/module/dpc_seo/sitemap');
		$this->model_setting_event->addEvent('dpc_seo_redirect', 'catalog/controller/product/product/before', 'extension/module/dpc_seo/redirect');
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_seo', array('module_dpc_seo_status' => 1, 'module_dpc_seo_redirects' => json_encode(array('378' => '377', '385' => '377'))));
	}

	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_seo_sitemap');
		$this->model_setting_event->deleteEventByCode('dpc_seo_redirect');
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_seo');
	}

	public function index() {
		$this->load->language('extension/module/dpc_seo');
		$this->load->model('setting/setting');
		$token = 'user_token=' . $this->session->data['user_token'];
		$msg = '';
		if ($this->request->server['REQUEST_METHOD'] === 'POST' && $this->user->hasPermission('modify', 'extension/module/dpc_seo')) {
			$map = array();
			foreach (preg_split('/\r?\n/', (string)$this->request->post['redirects']) as $line) {
				if (preg_match('/^\s*(\d+)\s*(?:->|=>|=|\s)\s*(\d+)\s*$/', $line, $m)) {
					$map[$m[1]] = $m[2];
				}
			}
			$this->model_setting_setting->editSetting('module_dpc_seo', array('module_dpc_seo_status' => 1, 'module_dpc_seo_redirects' => json_encode($map)));
			$msg = '<div class="alert alert-success">Saved.</div>';
		}
		$map = json_decode((string)$this->model_setting_setting->getSettingValue('module_dpc_seo_redirects'), true) ?: array();
		$lines = '';
		foreach ($map as $from => $to) {
			$lines .= $from . ' -> ' . $to . "\n";
		}
		$back = $this->url->link('marketplace/extension', $token . '&type=module', true);
		$this->document->setTitle('SEO fixes');
		$html = '<div id="content"><div class="page-header"><div class="container-fluid"><div class="pull-right"><a href="' . $back . '" class="btn btn-default"><i class="fa fa-reply"></i> Extensions</a></div><h1>SEO fixes</h1></div></div><div class="container-fluid">' . $msg
			. '<div class="panel panel-default"><div class="panel-body"><p>The sitemap lists each category under the address its canonical tag uses, so Google does not see duplicates.</p>'
			. '<form method="post"><label>Retired products that forward (301) to another product, one per line: <code>old product ID -&gt; new product ID</code>. Only used while the old product is disabled.</label>'
			. '<textarea name="redirects" rows="6" class="form-control" style="font-family:monospace">' . htmlspecialchars($lines) . '</textarea><br><button type="submit" class="btn btn-primary">Save</button></form></div></div></div></div>';
		$this->response->setOutput($this->load->controller('common/header') . $this->load->controller('common/column_left') . $html . $this->load->controller('common/footer'));
	}
}
