<?php
$_['heading_title'] = 'dpCREATOR SEO fixes (sitemap, retired product redirects)';
