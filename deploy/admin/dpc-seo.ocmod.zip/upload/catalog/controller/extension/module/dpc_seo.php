<?php
class ControllerExtensionModuleDpcSeo extends Controller {
	// Sitemap: a category reached through its parents (/parent/child) is listed as /child, its canonical address
	public function sitemap(&$route, &$args, &$output) {
		$xml = $this->response->getOutput();
		if (!is_string($xml) || strpos($xml, '<loc>') === false) {
			return;
		}
		try {
			$this->rewrite($xml);
		} catch (\Throwable $e) {
			// Leave the sitemap as OpenCart made it
		}
	}

	private function rewrite($xml) {
		$cats = array();
		foreach ($this->db->query("SELECT keyword FROM `" . DB_PREFIX . "seo_url` WHERE `query` LIKE 'category_id=%' AND store_id = '" . (int)$this->config->get('config_store_id') . "'")->rows as $r) {
			$cats[$r['keyword']] = true;
		}
		$base = rtrim($this->config->get('config_ssl') ?: $this->config->get('config_url'), '/') . '/';
		$seen = array();
		$xml = preg_replace_callback('#<url>\s*<loc>([^<]+)</loc>(.*?)</url>\s*#s', function ($m) use ($cats, $base, &$seen) {
			$loc = $m[1];
			if (strpos($loc, $base) === 0) {
				$path = trim(substr($loc, strlen($base)), '/');
				$parts = explode('/', $path);
				if (count($parts) > 1 && strpos($path, '?') === false) {
					$all = true;
					foreach ($parts as $p) {
						if (!isset($cats[$p])) {
							$all = false;
						}
					}
					if ($all) {
						$loc = $base . end($parts);
					}
				}
			}
			if (isset($seen[$loc])) {
				return '';
			}
			$seen[$loc] = true;
			return '<url><loc>' . $loc . '</loc>' . $m[2] . "</url>\n";
		}, $xml);
		$this->response->setOutput($xml);
	}

	// Retired products: forward their old address to the product that replaced them
	public function redirect(&$route, &$args) {
		$id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
		if (!$id) {
			return;
		}
		$map = json_decode((string)$this->config->get('module_dpc_seo_redirects'), true);
		if (!is_array($map) || empty($map[$id])) {
			return;
		}
		$p = $this->db->query("SELECT status FROM `" . DB_PREFIX . "product` WHERE product_id = '" . $id . "'")->row;
		if ($p && (int)$p['status'] === 1) {
			return;
		}
		$this->response->redirect($this->url->link('product/product', 'product_id=' . (int)$map[$id]), 301);
	}
}
