/* dpCREATOR site tools in the visitor's language.
 *
 * The browser tools on dpcreator.eu (install wizard, installer cards, config builder, R&D profile editor,
 * Studio Pro box, release-notes list) build their screens in English. On a German, Latvian or Russian
 * page (<html lang="de|lv|ru">) this script swaps English text for the translation from
 * /catalog/view/javascript/dpc-setup/i18n/<lang>.json:
 *   - a text node or attribute (placeholder, title, aria-label, button value) that equals a key exactly
 *     (leading/trailing spaces kept);
 *   - a key of 20+ characters found inside a longer text node;
 *   - a key "re:<regex>" matching the whole text (the translation may use $1, $2 …).
 * It watches the page, so screens the tools draw later are translated too. English pages are untouched.
 * Mark an element data-no-i18n to leave it (and everything inside it) as it is.
 */
(function () {
  "use strict";
  var lang = (document.documentElement.getAttribute("lang") || "en").slice(0, 2).toLowerCase();
  if (!/^(de|lv|ru)$/.test(lang) || !window.fetch || !window.MutationObserver) return;
  var SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, CODE: 1, PRE: 1, KBD: 1, NOSCRIPT: 1 };
  var ATTRS = ["placeholder", "title", "aria-label", "alt"];
  var dict = null, longKeys = [], pats = [], busy = false;

  function skipEl(el) {
    for (var e = el; e && e.nodeType === 1; e = e.parentNode) {
      if (SKIP[e.tagName] || e.isContentEditable || e.hasAttribute("data-no-i18n")) return true;
    }
    return false;
  }
  function tr(s) {
    if (!s || s.length < 3) return null;
    var m = /^(\s*)([\s\S]*?)(\s*)$/.exec(s), core = m[2];
    if (Object.prototype.hasOwnProperty.call(dict, core)) {
      var t = dict[core];
      return t === core ? null : m[1] + t + m[3];
    }
    for (var r = 0; r < pats.length; r++) {
      if (pats[r][0].test(core)) return m[1] + core.replace(pats[r][0], pats[r][1]) + m[3];
    }
    if (core.length < 20) return null;
    var out = core, hit = false;
    for (var i = 0; i < longKeys.length; i++) {
      var k = longKeys[i];
      if (k.length > out.length) continue;
      if (out.indexOf(k) !== -1) { out = out.split(k).join(dict[k]); hit = true; }
    }
    return hit ? m[1] + out + m[3] : null;
  }
  function doText(n) {
    if (!n.parentNode || skipEl(n.parentNode)) return;
    var t = tr(n.nodeValue);
    if (t !== null && t !== n.nodeValue) n.nodeValue = t;
  }
  function doEl(el) {
    if (skipEl(el)) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var a = el.getAttribute(ATTRS[i]);
      if (a) { var t = tr(a); if (t !== null && t !== a) el.setAttribute(ATTRS[i], t); }
    }
    if (el.tagName === "INPUT" && /^(button|submit|reset)$/i.test(el.type) && el.value) {
      var v = tr(el.value); if (v !== null) el.value = v;
    }
  }
  function walk(root) {
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 || skipEl(root)) return;
    doEl(root);
    var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, null, false), n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) doText(n);
      else if (SKIP[n.tagName]) continue;
      else doEl(n);
    }
  }
  function start() {
    busy = true; walk(document.body); busy = false;
    new MutationObserver(function (list) {
      if (busy) return;
      busy = true;
      try {
        for (var i = 0; i < list.length; i++) {
          var r = list[i];
          if (r.type === "characterData") doText(r.target);
          else if (r.type === "attributes") doEl(r.target);
          else for (var j = 0; j < r.addedNodes.length; j++) walk(r.addedNodes[j]);
        }
      } finally { busy = false; }
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS.concat(["value"]) });
  }
  var src = document.currentScript && document.currentScript.src;
  var ver = src && /[?&]v=([\w.-]+)/.exec(src);
  fetch("/catalog/view/javascript/dpc-setup/i18n/" + lang + ".json?v=" + (ver ? ver[1] : "1"))
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (d) {
      if (!d) return;
      dict = d;
      // keys "re:<regex>" are whole-text patterns; the value may use $1, $2 …
      Object.keys(d).forEach(function (k) { if (k.indexOf("re:") === 0) { try { pats.push([new RegExp("^" + k.slice(3) + "$"), d[k]]); } catch (e) {} delete d[k]; } });
      longKeys = Object.keys(d).filter(function (k) { return k.length >= 20 && d[k] !== k; }).sort(function (a, b) { return b.length - a.length; });
      if (document.body) start(); else document.addEventListener("DOMContentLoaded", start);
    })
    .catch(function () {});
})();
