<?php
$_['heading_title'] = 'dpCREATOR Store logo (UK logo on dpcreator.co.uk)';
