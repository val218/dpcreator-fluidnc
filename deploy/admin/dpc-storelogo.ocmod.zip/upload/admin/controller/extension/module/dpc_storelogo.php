<?php
// Shows the dpCREATOR.CO.UK logo on the UK store (store 1); the EU store keeps its logo. Journal3 shares one skin, so the swap is done on the page output.
class ControllerExtensionModuleDpcStorelogo extends Controller {
	public function install() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_storelogo');
		$this->model_setting_event->addEvent('dpc_storelogo', 'catalog/controller/common/header/after', 'extension/module/dpc_storelogo/header');
		$this->model_setting_event->addEvent('dpc_storelogo', 'catalog/controller/common/footer/after', 'extension/module/dpc_storelogo/header');
		// Journal3 renders its footer and block modules through its own controllers
		$this->model_setting_event->addEvent('dpc_storelogo', 'catalog/controller/journal3/*/after', 'extension/module/dpc_storelogo/header');
		$this->model_setting_event->addEvent('dpc_storelogo', 'catalog/view/*/after', 'extension/module/dpc_storelogo/header');
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_storelogo', array('module_dpc_storelogo_status' => 1));
	}
	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_storelogo');
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_storelogo');
	}
	public function index() {
		$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
	}
}
