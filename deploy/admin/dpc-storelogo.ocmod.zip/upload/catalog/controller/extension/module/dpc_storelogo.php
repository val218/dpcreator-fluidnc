<?php
class ControllerExtensionModuleDpcStorelogo extends Controller {
	public function header(&$route, &$args, &$output) {
		if (!is_string($output) || (int)$this->config->get('config_store_id') !== 1 || !$this->config->get('module_dpc_storelogo_status') || stripos($output, 'logo') === false) {
			return;
		}
		$new = 'image/catalog/dpc-site/dpcreator-logo-v6-couk.png';
		// The EU logo is 729x220, the UK one 840x220: same height, wider
		$output = preg_replace_callback('#<img\b[^>]*dpcreator(?:%20| )logo(?:%20| )v6[^>]*>#i', function ($m) use ($new) {
			$t = preg_replace('#image/(?:cache/)?catalog/dpcreator(?:%20| )logo(?:%20| )v6(?:-\d+x\d+[a-z]*)?\.png#i', $new, $m[0]);
			$t = preg_replace_callback('#\bwidth="(\d+)"#', function ($w) { return 'width="' . round($w[1] * 840 / 729) . '"'; }, $t);
			return str_replace(array('alt="dpCREATOR UK"', 'alt="dpCREATOR"'), 'alt="dpCREATOR.CO.UK"', $t);
		}, $output);
		// Logos inside Journal's footer blocks are rendered outside OpenCart's events: swap those in the browser
		if ($route === 'common/header' && strpos($output, '</head>') !== false && strpos($output, 'dpcStoreLogo') === false) {
			$js = '<script id="dpcStoreLogo">document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll("img").forEach(function(i){var re=/image\/(?:cache\/)?catalog\/dpcreator(?:%20| )logo(?:%20| )v6(?:-\d+x\d+[a-z]*)?\.png/g;if(re.test(i.src)||re.test(i.srcset)){i.src=i.src.replace(re,"' . $new . '");if(i.srcset)i.srcset=i.srcset.replace(re,"' . $new . '");i.style.objectFit="contain"}})});</script>';
			$output = str_replace('</head>', $js . '</head>', $output);
		}
	}
}
