<?php
class ControllerExtensionModuleDpcStorelogo extends Controller {
	public function header(&$route, &$args, &$output) {
		if (!is_string($output) || (int)$this->config->get('config_store_id') !== 1 || !$this->config->get('module_dpc_storelogo_status')) {
			return;
		}
		$new = 'image/catalog/dpc-site/dpcreator-logo-v6-couk.png';
		// The EU logo is 729x220, the UK one 840x220: same height, wider
		$output = preg_replace_callback('#<img\b[^>]*dpcreator(?:%20| )logo(?:%20| )v6[^>]*>#i', function ($m) use ($new) {
			$t = preg_replace('#image/(?:cache/)?catalog/dpcreator(?:%20| )logo(?:%20| )v6(?:-\d+x\d+)?\.png#i', $new, $m[0]);
			$t = preg_replace_callback('#\bwidth="(\d+)"#', function ($w) { return 'width="' . round($w[1] * 840 / 729) . '"'; }, $t);
			return str_replace(array('alt="dpCREATOR UK"', 'alt="dpCREATOR"'), 'alt="dpCREATOR.CO.UK"', $t);
		}, $output);
	}
}
