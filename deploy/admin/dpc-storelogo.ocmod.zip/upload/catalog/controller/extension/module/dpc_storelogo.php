<?php
class ControllerExtensionModuleDpcStorelogo extends Controller {
	private static $script = false;

	public function header(&$route, &$args, &$output) {
		if (!is_string($output) || (int)$this->config->get('config_store_id') !== 1 || !$this->config->get('module_dpc_storelogo_status') || stripos($output, 'logo') === false) {
			return;
		}
		$new = 'image/catalog/dpc-site/dpcreator-logo-v6-couk.png';
		// Link previews (Facebook, LinkedIn, X...): the home page shares the logo
		if (strpos($output, 'og:image') !== false || strpos($output, 'twitter:image') !== false) {
			$output = preg_replace_callback('#<meta\b[^>]*(?:og:image|twitter:image)[^>]*>#i', function ($m) {
				$t = preg_replace('#image/cache/catalog/dpcreator(?:%20| )logo(?:%20| )v6-600x315[a-z]*\.png#i', 'image/catalog/dpc-site/dpcreator-logo-v6-couk-share.png', $m[0]);
				return preg_replace('#image/cache/catalog/dpcreator(?:%20| )logo(?:%20| )v6-\d+x\d+[a-z]*\.png#i', 'image/catalog/dpc-site/dpcreator-logo-v6-couk-square.png', $t);
			}, $output);
		}
		// The EU logo is 729x220, the UK one 840x220: same height, wider
		$output = preg_replace_callback('#<img\b[^>]*dpcreator(?:%20| )logo(?:%20| )v6[^>]*>#i', function ($m) use ($new) {
			$t = preg_replace('#image/(?:cache/)?catalog/dpcreator(?:%20| )logo(?:%20| )v6(?:-\d+x\d+[a-z]*)?\.png#i', $new, $m[0]);
			$t = preg_replace_callback('#\bwidth="(\d+)"#', function ($w) { return 'width="' . round($w[1] * 840 / 729) . '"'; }, $t);
			$t = str_replace(array('alt="dpCREATOR UK"', 'alt="dpCREATOR"'), 'alt="dpCREATOR.CO.UK"', $t);
			// Logos in Journal's footer blocks are rendered outside OpenCart's events: one small script swaps those in the browser
			if (!self::$script) {
				self::$script = true;
				$t .= '<script id="dpcStoreLogo">document.addEventListener("DOMContentLoaded",function(){var re=/image\/(?:cache\/)?catalog\/dpcreator(?:%20| )logo(?:%20| )v6(?:-\d+x\d+[a-z]*)?\.png/g;document.querySelectorAll("img").forEach(function(i){var s=i.getAttribute("src")||"",ss=i.getAttribute("srcset")||"";if(s.search(re)>=0||ss.search(re)>=0){i.src=s.replace(re,"' . $new . '");if(ss)i.srcset=ss.replace(re,"' . $new . '");i.style.objectFit="contain"}})});</script>';
			}
			return $t;
		}, $output);
	}
}
