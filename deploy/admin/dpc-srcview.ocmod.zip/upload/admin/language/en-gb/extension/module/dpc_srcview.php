<?php
$_['heading_title'] = 'dpCREATOR Server files (read-only, secrets hidden)';
