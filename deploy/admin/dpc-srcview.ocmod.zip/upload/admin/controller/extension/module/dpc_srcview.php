<?php
// Read-only view of the shop's own PHP files in the web root and of cache folders, for support.
// Secrets (tokens, keys, passwords) are blanked before anything is shown. Nothing is changed, except
// the "rename" action, which moves a cache file aside (adds .old-<time>) so it is downloaded again.
class ControllerExtensionModuleDpcSrcview extends Controller {
	public function install() {}
	public function uninstall() {}

	private function root() { return realpath(DIR_APPLICATION . '..') . '/'; }

	private function redact($s) {
		$s = preg_replace('/(gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{16,})/', '***TOKEN***', $s);
		$s = preg_replace('/((?:token|secret|password|passwd|pass|key|auth|bearer)[A-Za-z0-9_]*[\'"]?\s*(?:=>|=|:)\s*)([\'"])[^\'"]{4,}\2/i', '$1$2***$2', $s);
		$s = preg_replace('/([\'"])[A-Za-z0-9+\/=_\-]{32,}\1/', '$1***LONG***$1', $s);
		$s = preg_replace('/-----BEGIN [A-Z ]+-----[\s\S]*?-----END [A-Z ]+-----/', '***PEM***', $s);
		return $s;
	}

	private function safePath($rel) {
		$rel = str_replace("\0", '', (string)$rel);
		$p = realpath($this->root() . ltrim($rel, '/'));
		if (!$p || strpos($p, $this->root()) !== 0) {
			$p2 = realpath(DIR_STORAGE . ltrim(preg_replace('#^storage/#', '', $rel), '/'));
			if ($p2 && strpos($p2, realpath(DIR_STORAGE)) === 0) return $p2;
			return null;
		}
		return $p;
	}

	public function index() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_srcview')) {
			$this->response->setOutput('No permission');
			return;
		}
		$g = $this->request->get;
		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$out = array('root' => '(web root)', 'storage' => '(storage)');
		if (!empty($g['ls'])) {
			$p = $this->safePath($g['ls'] === '/' ? '' : $g['ls']);
			if (!$p || !is_dir($p)) { $out['error'] = 'not a folder'; }
			else {
				$out['items'] = array();
				foreach (scandir($p) as $f) {
					if ($f === '.' || $f === '..') continue;
					$fp = $p . '/' . $f;
					$out['items'][] = array('name' => $f, 'dir' => is_dir($fp), 'size' => is_file($fp) ? filesize($fp) : 0, 'mtime' => date('c', filemtime($fp)));
				}
			}
		} elseif (!empty($g['file'])) {
			$p = $this->safePath($g['file']);
			if (!$p || !is_file($p)) { $out['error'] = 'no such file'; }
			elseif (filesize($p) > 600000) { $out['error'] = 'too big'; $out['size'] = filesize($p); $out['head'] = $this->redact(file_get_contents($p, false, null, 0, 4000)); }
			else {
				$s = file_get_contents($p);
				$out['size'] = strlen($s);
				$out['mtime'] = date('c', filemtime($p));
				$out['text'] = preg_match('//u', $s) ? $this->redact($s) : '(binary, ' . strlen($s) . ' bytes, starts ' . bin2hex(substr($s, 0, 8)) . ')';
			}
		} elseif (!empty($g['rename']) && $this->user->hasPermission('modify', 'extension/module/dpc_srcview') && $this->request->server['REQUEST_METHOD'] === 'POST') {
			$p = $this->safePath($g['rename']);
			if (!$p || !is_file($p) || preg_match('/\.php$/i', $p)) { $out['error'] = 'not allowed'; }
			else { $to = $p . '.old-' . date('YmdHis'); $out['ok'] = rename($p, $to); $out['to'] = basename($to); }
		}
		$this->response->setOutput(json_encode($out, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
	}
}
