/* dpCREATOR admin assistant panel. Opens from the Ask button or Ctrl+J. */
(function () {
	'use strict';
	var C = window.DPCAI;
	if (!C || document.getElementById('dpcai')) return;

	var css = ''
		+ '#dpcai-btn{position:fixed;right:18px;bottom:18px;z-index:9990;background:#1F4E79;color:#fff;border:0;border-radius:22px;padding:10px 16px 10px 14px;font:600 14px/1 inherit;box-shadow:0 6px 20px rgba(0,0,0,.25);cursor:pointer;display:flex;align-items:center;gap:8px}'
		+ '#dpcai-btn:hover{background:#18405F}#dpcai-btn:focus-visible,#dpcai button:focus-visible,#dpcai textarea:focus-visible{outline:2px solid #2E8BE6;outline-offset:2px}'
		+ '#dpcai{position:fixed;right:18px;bottom:18px;z-index:9991;width:min(440px,calc(100vw - 24px));height:min(640px,calc(100vh - 36px));background:#fff;color:#1E2A35;border:1px solid #D5DCE3;border-radius:12px;box-shadow:0 18px 50px rgba(0,0,0,.28);display:none;flex-direction:column;overflow:hidden;font-size:13.5px}'
		+ '#dpcai.on{display:flex}#dpcai *{box-sizing:border-box}'
		+ '#dpcai .hd{display:flex;align-items:center;gap:6px;padding:9px 10px;border-bottom:1px solid #E3E8ED;background:#F6F8FA}'
		+ '#dpcai .hd b{flex:1;font-size:14px}#dpcai .hd small{color:#5F6C78;font-weight:400;margin-left:6px}'
		+ '#dpcai .ib{border:0;background:none;color:#3D4A56;padding:5px 7px;border-radius:6px;cursor:pointer;font-size:14px}#dpcai .ib:hover{background:#E6EBF0}'
		+ '#dpcai .bd{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px}'
		+ '#dpcai .m{max-width:92%;padding:8px 11px;border-radius:10px;line-height:1.45;overflow-wrap:anywhere}'
		+ '#dpcai .m.user{align-self:flex-end;background:#1F4E79;color:#fff;white-space:pre-wrap}'
		+ '#dpcai .m.assistant{align-self:flex-start;background:#F1F4F7}'
		+ '#dpcai .m.assistant p{margin:0 0 6px}#dpcai .m.assistant p:last-child{margin:0}#dpcai .m.assistant ul,#dpcai .m.assistant ol{margin:4px 0 6px;padding-left:18px}'
		+ '#dpcai .m.assistant code{background:#E3E8ED;border-radius:3px;padding:0 3px;font-size:12px}#dpcai .m.assistant pre{background:#E3E8ED;border-radius:6px;padding:7px;white-space:pre-wrap;font-size:12px;margin:4px 0}'
		+ '#dpcai .m.assistant table{border-collapse:collapse;font-size:12px;margin:4px 0}#dpcai .m.assistant td,#dpcai .m.assistant th{border:1px solid #D5DCE3;padding:2px 6px;text-align:left}'
		+ '#dpcai .m.assistant a{color:#1F6FB8;text-decoration:underline}'
		+ '#dpcai .tl{align-self:flex-start;color:#5F6C78;font-size:12px;padding:0 4px}#dpcai .tl:before{content:"\\2713  "}'
		+ '#dpcai .act{align-self:stretch;border:1px solid #BFD3E8;background:#EEF5FC;border-radius:10px;padding:9px 11px}'
		+ '#dpcai .act p{margin:0 0 8px}#dpcai .act .row2{display:flex;gap:6px;align-items:center;flex-wrap:wrap}'
		+ '#dpcai .act.applied{border-color:#B5DEC6;background:#E9F6EF}#dpcai .act.failed{border-color:#F1B9B2;background:#FDECEA}#dpcai .act.dismissed{opacity:.6}'
		+ '#dpcai .bt{border:1px solid #CFD7DE;background:#fff;color:#1E2A35;border-radius:6px;padding:5px 11px;font-weight:600;cursor:pointer;font-size:12.5px}'
		+ '#dpcai .bt.pri{background:#1F6FB8;border-color:#1F6FB8;color:#fff}#dpcai .bt[disabled]{opacity:.5;cursor:default}'
		+ '#dpcai .err{align-self:stretch;background:#FDECEA;border:1px solid #F1B9B2;color:#8A1F14;border-radius:8px;padding:7px 10px}'
		+ '#dpcai .wait{align-self:flex-start;color:#5F6C78;font-size:12.5px}'
		+ '#dpcai .ft{border-top:1px solid #E3E8ED;padding:8px 10px;background:#fff}'
		+ '#dpcai textarea{width:100%;border:1px solid #CFD7DE;border-radius:8px;padding:7px 9px;resize:none;font:inherit;min-height:40px;max-height:140px;color:#1E2A35;background:#fff}'
		+ '#dpcai .ft .row2{display:flex;align-items:center;gap:8px;margin-top:6px;font-size:12px;color:#5F6C78}#dpcai .ft .row2 label{display:flex;align-items:center;gap:4px;margin:0;font-weight:400;cursor:pointer}'
		+ '#dpcai .ft .row2 span{flex:1;text-align:right}'
		+ '#dpcai .list a{display:block;padding:7px 9px;border-radius:7px;color:#1E2A35;text-decoration:none;border:1px solid #E3E8ED;margin-bottom:5px}#dpcai .list a:hover{border-color:#1F6FB8}#dpcai .list small{display:block;color:#5F6C78}'
		+ '#dpcai .empty{color:#5F6C78;line-height:1.5}#dpcai .empty button{display:block;width:100%;text-align:left;margin:5px 0;border:1px solid #E3E8ED;background:#F8FAFB;border-radius:7px;padding:7px 9px;cursor:pointer;color:#1E2A35;font-size:12.5px}#dpcai .empty button:hover{border-color:#1F6FB8}'
		+ '@media (prefers-reduced-motion:no-preference){#dpcai.on{animation:dpcaiIn .14s ease-out}@keyframes dpcaiIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}}';
	var st = document.createElement('style');
	st.textContent = css;
	document.head.appendChild(st);

	var btn = document.createElement('button');
	btn.id = 'dpcai-btn';
	btn.type = 'button';
	btn.title = 'Ask the assistant (Ctrl+J)';
	btn.innerHTML = '<i class="fa fa-comments"></i> Ask';
	var box = document.createElement('div');
	box.id = 'dpcai';
	box.setAttribute('role', 'dialog');
	box.setAttribute('aria-label', 'Assistant');
	box.innerHTML = '<div class="hd"><b>Assistant<small id="dpcai-cost"></small></b>'
		+ '<button type="button" class="ib" data-a="list" title="Earlier chats"><i class="fa fa-history"></i></button>'
		+ '<button type="button" class="ib" data-a="new" title="New chat"><i class="fa fa-plus"></i></button>'
		+ '<a class="ib" href="' + esc(C.settings) + '" title="Settings and usage"><i class="fa fa-cog"></i></a>'
		+ '<button type="button" class="ib" data-a="close" title="Close (Esc)"><i class="fa fa-times"></i></button></div>'
		+ '<div class="bd" id="dpcai-bd" aria-live="polite"></div>'
		+ '<div class="ft"><textarea id="dpcai-in" rows="1" placeholder="Ask about orders, stock, books\u2026"></textarea>'
		+ '<div class="row2"><label title="Uses the stronger model: better for bookkeeping and long questions, costs more"><input type="checkbox" id="dpcai-th"> Thorough</label><span id="dpcai-tok"></span>'
		+ '<button type="button" class="bt pri" id="dpcai-send">Send</button></div></div>';
	document.body.appendChild(btn);
	document.body.appendChild(box);

	var bd = box.querySelector('#dpcai-bd'), inp = box.querySelector('#dpcai-in'), send = box.querySelector('#dpcai-send'), th = box.querySelector('#dpcai-th');
	var S = { chat: 0, busy: false, items: [] };
	try { S.chat = parseInt(sessionStorage.getItem('dpcai_chat') || '0', 10) || 0; th.checked = localStorage.getItem('dpcai_th') === '1'; } catch (e) {}

	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function remember() { try { sessionStorage.setItem('dpcai_chat', String(S.chat || 0)); } catch (e) {} }
	function money(v) { return '$' + (Math.round((v || 0) * 100) / 100).toFixed(2); }

	// Small, safe markdown: escape first, then bold, code, links, lists, tables
	function md(t) {
		var blocks = [], out = [];
		t = String(t || '').replace(/```[a-z]*\n?([\s\S]*?)```/g, function (m, c) { blocks.push(c); return '\u0000' + (blocks.length - 1) + '\u0000'; });
		var lines = esc(t).split('\n'), list = null, para = [], table = [];
		function inline(s) {
			return s.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
				.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, function (m, a, u) { return '<a href="' + u.replace(/&amp;/g, '&').replace(/"/g, '%22') + '" target="_blank" rel="noopener">' + a + '</a>'; });
		}
		function flush() {
			if (para.length) { out.push('<p>' + para.map(inline).join('<br>') + '</p>'); para = []; }
			if (list) { out.push('<' + list.t + '>' + list.i.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</' + list.t + '>'); list = null; }
			if (table.length) {
				var rows = table.filter(function (r) { return !/^\|?\s*:?-{2,}/.test(r); });
				out.push('<table>' + rows.map(function (r, i) { var cells = r.replace(/^\||\|$/g, '').split('|'); return '<tr>' + cells.map(function (c) { return (i ? '<td>' : '<th>') + inline(c.trim()) + (i ? '</td>' : '</th>'); }).join('') + '</tr>'; }).join('') + '</table>');
				table = [];
			}
		}
		lines.forEach(function (l) {
			var m;
			if (/^\s*\|.*\|\s*$/.test(l)) { if (!table.length) flush(); table.push(l.trim()); return; }
			if (table.length) flush();
			if ((m = l.match(/^\s*[-*\u2022]\s+(.*)/))) { if (para.length || (list && list.t !== 'ul')) flush(); list = list || { t: 'ul', i: [] }; list.i.push(m[1]); return; }
			if ((m = l.match(/^\s*\d+[.)]\s+(.*)/))) { if (para.length || (list && list.t !== 'ol')) flush(); list = list || { t: 'ol', i: [] }; list.i.push(m[1]); return; }
			if ((m = l.match(/^#{1,4}\s+(.*)/))) { flush(); out.push('<p><b>' + inline(m[1]) + '</b></p>'); return; }
			if (!l.trim()) { flush(); return; }
			if (list) flush();
			para.push(l);
		});
		flush();
		return out.join('').replace(/\u0000(\d+)\u0000/g, function (m, i) { return '<pre>' + esc(blocks[i]) + '</pre>'; });
	}

	function api(f, body, form) {
		var opt = { method: 'POST', credentials: 'same-origin', headers: {} };
		if (form) {
			// Sent as a form so the Books module reads it from the POST fields
			var fd = new FormData();
			Object.keys(body).forEach(function (k) { fd.append(k, body[k]); });
			opt.body = fd;
		} else if (body) {
			opt.headers['Content-Type'] = 'application/json';
			opt.body = JSON.stringify(body);
		} else {
			opt.method = 'GET';
		}
		return fetch(C.api + '&f=' + f + (f === 'chat' ? '&id=' + S.chat : ''), opt).then(function (r) {
			return r.text().then(function (t) {
				try { return JSON.parse(t); } catch (e) {
					if (/login|user_token/i.test(t) && /<form/i.test(t)) return { error: 'The admin session has expired. Log in again, then ask once more.' };
					return { error: 'The server answered with an error (' + r.status + ').' };
				}
			});
		}, function () { return { error: 'No connection to the shop server.' }; });
	}

	function render(extra) {
		if (!S.items.length && !extra) {
			bd.innerHTML = '<div class="empty">' + (C.ready ? '<p>Ask about the shop in your own words. I can look things up and prepare changes; nothing changes until you click <b>Apply</b>.</p>'
				+ ['What came in this week and what still needs shipping?', 'Which parts are running low?', 'What is due for VID next and is anything missing?', 'Book the open bank rows I can be sure about.'].map(function (q) { return '<button type="button" data-q="' + esc(q) + '">' + esc(q) + '</button>'; }).join('')
				: '<p>Add your Anthropic API key in the <a href="' + esc(C.settings) + '">assistant settings</a> to start.</p>') + '</div>';
			return;
		}
		bd.innerHTML = S.items.map(function (it) {
			if (it.role === 'tool') return '<div class="tl">' + esc(it.text) + '</div>';
			if (it.role === 'action') {
				var a = it.action, done = a.status !== 'proposed';
				return '<div class="act ' + esc(a.status) + '" data-id="' + a.action_id + '"><p>' + esc(a.summary) + '</p><div class="row2">'
					+ (done ? '<small>' + esc({ applied: 'Applied', failed: 'Failed', dismissed: 'Dismissed' }[a.status] || a.status) + (a.result ? ': ' + esc(a.result) : '') + '</small>'
						: '<button type="button" class="bt pri" data-a="apply">Apply</button><button type="button" class="bt" data-a="dismiss">Dismiss</button>') + '</div></div>';
			}
			if (it.role === 'user') return '<div class="m user">' + esc(it.text) + '</div>';
			return '<div class="m assistant">' + md(it.text) + '</div>';
		}).join('') + (extra || '');
		bd.scrollTop = bd.scrollHeight;
	}

	function showCost(r) {
		if (!r) return;
		if (r.month != null) box.querySelector('#dpcai-cost').textContent = 'this month ' + money(r.month);
		if (r.tokens != null) box.querySelector('#dpcai-tok').textContent = r.tokens ? r.tokens.toLocaleString() + ' tokens \u00b7 ' + money(r.cost) + ' this chat' : '';
	}

	function busy(on) { S.busy = on; send.disabled = on; inp.disabled = false; }

	function ask(text, cont) {
		if (S.busy) return;
		if (!cont) {
			text = (text || '').trim();
			if (!text) return;
			S.items.push({ role: 'user', text: text });
		}
		busy(true);
		render('<div class="wait"><i class="fa fa-circle-o-notch fa-spin"></i> ' + (cont ? 'Still working\u2026' : 'Looking\u2026') + '</div>');
		var page = (document.querySelector('#content .page-header h1') || document.querySelector('h1') || {}).textContent || document.title;
		var q = (location.search.match(/route=([^&]+)/) || [])[1] || '';
		var oid = (location.search.match(/order_id=(\d+)/) || [])[1], pid = (location.search.match(/product_id=(\d+)/) || [])[1];
		api('send', { chat_id: S.chat, message: cont ? '' : text, thorough: th.checked ? 1 : 0, page: cont ? '' : (String(page).trim() + ' (' + decodeURIComponent(q) + (oid ? ', order ' + oid : '') + (pid ? ', product ' + pid : '') + ')') }).then(function (r) {
			busy(false);
			if (r.error) {
				render('<div class="err">' + esc(r.error) + '</div>');
				return;
			}
			S.chat = r.chat_id; remember();
			S.items = r.items;
			showCost(r);
			render();
			if (r.more) ask('', true);
		});
	}

	function load() {
		if (!S.chat) { S.items = []; render(); api('chats').then(showCost); return; }
		api('chat').then(function (r) {
			if (r.error) { S.chat = 0; remember(); S.items = []; render(); return; }
			S.items = r.items; showCost(r); render();
		});
	}

	function open() { box.classList.add('on'); btn.style.display = 'none'; if (!S.loaded) { S.loaded = 1; load(); } setTimeout(function () { inp.focus(); }, 30); try { sessionStorage.setItem('dpcai_open', '1'); } catch (e) {} }
	function close() { box.classList.remove('on'); btn.style.display = ''; btn.focus(); try { sessionStorage.removeItem('dpcai_open'); } catch (e) {} }

	btn.addEventListener('click', open);
	send.addEventListener('click', function () { var t = inp.value; inp.value = ''; grow(); ask(t); });
	th.addEventListener('change', function () { try { localStorage.setItem('dpcai_th', th.checked ? '1' : '0'); } catch (e) {} });
	function grow() { inp.style.height = 'auto'; inp.style.height = Math.min(140, inp.scrollHeight + 2) + 'px'; }
	inp.addEventListener('input', grow);
	inp.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send.click(); } });
	document.addEventListener('keydown', function (e) {
		if ((e.ctrlKey || e.metaKey) && (e.key === 'j' || e.key === 'J')) { e.preventDefault(); box.classList.contains('on') ? close() : open(); }
		else if (e.key === 'Escape' && box.classList.contains('on')) close();
	});

	box.addEventListener('click', function (e) {
		var q = e.target.closest('[data-q]');
		if (q) { ask(q.getAttribute('data-q')); return; }
		var b = e.target.closest('[data-a]');
		if (!b) {
			var c = e.target.closest('[data-chat]');
			if (c) { e.preventDefault(); S.chat = parseInt(c.getAttribute('data-chat'), 10); remember(); load(); }
			return;
		}
		var a = b.getAttribute('data-a');
		if (a === 'close') close();
		else if (a === 'new') { S.chat = 0; remember(); S.items = []; render(); box.querySelector('#dpcai-tok').textContent = ''; inp.focus(); }
		else if (a === 'list') {
			api('chats').then(function (r) {
				showCost(r);
				bd.innerHTML = '<div class="list">' + ((r.chats || []).length ? r.chats.map(function (c) { return '<a href="#" data-chat="' + c.chat_id + '">' + esc(c.title) + '<small>' + esc(c.modified) + ' \u00b7 ' + money(+c.cost) + '</small></a>'; }).join('') : '<p class="empty">No earlier chats.</p>') + '</div>';
			});
		} else if (a === 'apply' || a === 'dismiss') {
			var card = b.closest('.act'), id = card.getAttribute('data-id');
			card.querySelectorAll('button').forEach(function (x) { x.disabled = true; });
			api(a, { action_id: id }, true).then(function (r) {
				var it = S.items.filter(function (x) { return x.action && String(x.action.action_id) === id; })[0];
				if (it) { it.action.status = r.error ? 'failed' : (a === 'apply' ? 'applied' : 'dismissed'); it.action.result = r.error || r.result || ''; }
				render();
			});
		}
	});

	try { if (sessionStorage.getItem('dpcai_open') === '1') open(); } catch (e) {}
})();
