<?php
$_['heading_title'] = 'dpCREATOR Assistant (AI helper in the admin)';
