<?php
// Replaces the Google Fonts links in the page head with the fonts served from this site.
class ControllerExtensionModuleDpcFonts extends Controller {
	public function header(&$route, &$args, &$output) {
		if (!is_string($output)) {
			return;
		}
		$this->shareText($output);
		if (!$this->config->get('module_dpc_fonts_status') || strpos($output, 'fonts.g') === false) {
			return;
		}
		if (!is_file(DIR_APPLICATION . 'view/theme/dpc-fonts/fonts.css')) {
			return;
		}
		$v = filemtime(DIR_APPLICATION . 'view/theme/dpc-fonts/fonts.css');
		$local = 'catalog/view/theme/dpc-fonts/fonts.css?v=' . $v;
		// Preconnect hints to Google are no longer needed
		$output = preg_replace('#<link[^>]+rel="preconnect"[^>]+fonts\.(googleapis|gstatic)\.com[^>]*>\s*#i', '', $output);
		// Stylesheet links and @import rules for Google Fonts become one local stylesheet
		$n = 0;
		$output = preg_replace_callback('#<link[^>]+href="https://fonts\.googleapis\.com/css[^"]*"[^>]*>#i', function () use (&$n, $local) {
			return $n++ ? '' : '<link href="' . $local . '" rel="stylesheet">';
		}, $output);
		$output = preg_replace('#@import\s+url\(\s*[\'"]?https://fonts\.googleapis\.com/css[^)]*\)\s*;?#i', $n ? '' : '@import url(\'' . $local . '\');', $output);
	}

	// Journal fills the share previews (og:description, twitter:description) with the first 300 characters
	// of the page body, cut mid-word. Use the page's own meta description instead when it has one.
	private function shareText(&$output) {
		if (!preg_match('#<meta\s+name="description"\s+content="([^"]+)"#i', $output, $m) || trim($m[1]) === '') {
			return;
		}
		$desc = $m[1];
		$output = preg_replace('#(<meta\s+(?:property|name)="(?:og|twitter):description"\s+content=")[^"]*(")#i', '${1}' . str_replace(array('\\', '$'), array('\\\\', '\\$'), $desc) . '$2', $output);
	}
}
