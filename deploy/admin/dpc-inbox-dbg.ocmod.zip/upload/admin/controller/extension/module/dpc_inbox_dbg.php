<?php
// Temporary: reads the Inbox tables to find a filtering problem. Read-only.
class ControllerExtensionModuleDpcInboxDbg extends Controller {
	public function index() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_inbox')) { return; }
		$p = DB_PREFIX . 'dpc_mail_';
		$out = array();
		$out['rows'] = $this->db->query("SELECT thread_id, account_id, kind, state, trashed, messages, HEX(trashed) h FROM `{$p}thread`")->rows;
		$out['c1'] = $this->db->query("SELECT COUNT(*) n FROM `{$p}thread` t WHERE t.`trashed` = 0 AND t.`kind` = 'person'")->row;
		$out['c2'] = $this->db->query("SELECT COUNT(*) n FROM `{$p}thread` t WHERE t.`kind` = 'person'")->row;
		$out['c3'] = $this->db->query("SELECT COUNT(*) n FROM `{$p}thread` t WHERE t.`trashed` = 0")->row;
		$out['explain'] = $this->db->query("EXPLAIN SELECT COUNT(*) n FROM `{$p}thread` t WHERE t.`trashed` = 0 AND t.`kind` = 'person'")->rows;
		$out['create'] = $this->db->query("SHOW CREATE TABLE `{$p}thread`")->row;
		$out['version'] = $this->db->query("SELECT VERSION() v")->row;
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($out));
	}
}
