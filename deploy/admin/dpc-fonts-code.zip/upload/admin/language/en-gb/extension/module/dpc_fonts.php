<?php
$_['heading_title'] = 'dpCREATOR Local fonts (no Google Fonts)';
