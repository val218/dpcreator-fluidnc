<?php
// dpCREATOR local fonts: serves the shop's web fonts from dpcreator.eu instead of Google Fonts,
// so visitors' browsers no longer contact Google. The font files live in catalog/view/theme/dpc-fonts/.
class ControllerExtensionModuleDpcFonts extends Controller {
	public function install() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_fonts');
		$this->model_setting_event->addEvent('dpc_fonts', 'catalog/controller/common/header/after', 'extension/module/dpc_fonts/header');
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_fonts', array('module_dpc_fonts_status' => 1));
	}

	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_fonts');
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_fonts');
	}

	public function index() {
		$this->load->language('extension/module/dpc_fonts');
		$this->load->model('setting/setting');
		if ($this->request->server['REQUEST_METHOD'] === 'POST' && $this->user->hasPermission('modify', 'extension/module/dpc_fonts')) {
			$this->model_setting_setting->editSetting('module_dpc_fonts', array('module_dpc_fonts_status' => empty($this->request->post['status']) ? 0 : 1));
			$this->response->redirect($this->url->link('extension/module/dpc_fonts', 'user_token=' . $this->session->data['user_token'], true));
			return;
		}
		$on = (int)$this->config->get('module_dpc_fonts_status');
		$css = is_file(DIR_CATALOG . 'view/theme/dpc-fonts/fonts.css');
		$this->document->setTitle('Local fonts');
		$back = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		$html = '<div id="content"><div class="page-header"><div class="container-fluid"><div class="pull-right"><a href="' . $back . '" class="btn btn-default"><i class="fa fa-reply"></i> Extensions</a></div><h1>Local fonts</h1></div></div><div class="container-fluid"><div class="panel panel-default"><div class="panel-body">'
			. '<p>Serves the shop fonts (Roboto, Poppins, Barlow, Barlow Condensed, JetBrains Mono) from dpcreator.eu instead of Google Fonts, so visitors\' IP addresses are not sent to Google.</p>'
			. '<p>Font files: ' . ($css ? '<span class="label label-success">installed</span>' : '<span class="label label-danger">missing</span> (catalog/view/theme/dpc-fonts/fonts.css)') . '</p>'
			. '<form method="post"><label class="checkbox-inline"><input type="checkbox" name="status" value="1"' . ($on ? ' checked' : '') . '> Use the local fonts</label> <button type="submit" class="btn btn-primary btn-sm">Save</button></form>'
			. '<p class="text-muted" style="margin-top:10px">If you add a new Google font in Journal, it is loaded from Google again until it is added here too.</p></div></div></div></div>';
		$this->response->setOutput($this->load->controller('common/header') . $this->load->controller('common/column_left') . $html . $this->load->controller('common/footer'));
	}
}
