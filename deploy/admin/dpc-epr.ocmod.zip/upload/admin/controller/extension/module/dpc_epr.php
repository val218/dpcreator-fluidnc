<?php
// dpCREATOR EPR report: kilograms of electronics and packaging sold, for the Latvian recycling scheme
// (Zaļā josta, AJ Power, Latvijas Zaļais punkts). Weights are kept per product (one unit as sold);
// the report multiplies units sold by those weights and groups them by market.
class ControllerExtensionModuleDpcEpr extends Controller {
	private $error = array();

	// WEEE categories (Directive 2012/19/EU, Annex III)
	private function categories() {
		return array(
			0 => 'Not electrical equipment',
			1 => '1 Temperature exchange equipment',
			2 => '2 Screens and monitors over 100 cm²',
			3 => '3 Lamps',
			4 => '4 Large equipment (over 50 cm)',
			5 => '5 Small equipment (up to 50 cm)',
			6 => '6 Small IT and telecommunication equipment (up to 50 cm)',
		);
	}

	private function eu() {
		return array('AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'LV');
	}

	// ------------------------------------------------------------------ install
	public function install() {
		$this->table();
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_epr', array(
			'module_dpc_epr_status' => 1,
			'module_dpc_epr_statuses' => $this->defaultStatuses(),
			'module_dpc_epr_fee_eee' => '0.22',
			'module_dpc_epr_fee_paper' => '0.054',
			'module_dpc_epr_fee_plastic' => '0.226',
		));
	}

	public function uninstall() {
		// The weights are kept; only the settings go
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_dpc_epr');
	}

	private function table() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_epr_product` (
			`product_id` INT NOT NULL, `eee_category` TINYINT NOT NULL DEFAULT 5,
			`eee_kg` DECIMAL(10,4) NOT NULL DEFAULT 0, `paper_kg` DECIMAL(10,4) NOT NULL DEFAULT 0, `plastic_kg` DECIMAL(10,4) NOT NULL DEFAULT 0,
			`date_modified` DATETIME NULL, PRIMARY KEY (`product_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	// Complete + processing, without unpaid (pending), cancelled, refunded, returned or reversed
	private function defaultStatuses() {
		$ids = array();
		foreach (array('config_processing_status', 'config_complete_status') as $key) {
			foreach ((array)$this->config->get($key) as $id) {
				$ids[(int)$id] = true;
			}
		}
		unset($ids[0]);
		$lang = (int)$this->config->get('config_language_id');
		foreach ($this->db->query("SELECT order_status_id, name FROM `" . DB_PREFIX . "order_status` WHERE language_id = '" . $lang . "'")->rows as $s) {
			if (preg_match('/cancel|refund|return|revers|chargeback|void|denied|failed|expired|pending/i', $s['name'])) {
				unset($ids[(int)$s['order_status_id']]);
			}
		}
		return array_keys($ids);
	}

	private function statuses() {
		$s = $this->config->get('module_dpc_epr_statuses');
		if (!is_array($s)) {
			$s = json_decode((string)$s, true);
		}
		$s = is_array($s) ? array_values(array_filter(array_map('intval', $s))) : array();
		return $s ?: $this->defaultStatuses();
	}

	private function fee($k, $def) {
		$v = $this->config->get('module_dpc_epr_fee_' . $k);
		return ($v === null || $v === '') ? $def : (float)$v;
	}

	private function kg($v) {
		return max(0, round((float)str_replace(',', '.', trim((string)$v)), 4));
	}

	// ------------------------------------------------------------------ page
	public function index() {
		$this->load->language('extension/module/dpc_epr');
		$this->document->setTitle('EPR report');
		$this->table();
		$token = 'user_token=' . $this->session->data['user_token'];
		$canModify = $this->user->hasPermission('modify', 'extension/module/dpc_epr');
		$data['success'] = '';
		$data['error'] = '';

		if ($this->request->server['REQUEST_METHOD'] === 'POST') {
			if (!$canModify) {
				$data['error'] = 'You do not have permission to change the EPR settings.';
			} elseif (isset($this->request->post['action']) && $this->request->post['action'] === 'weights') {
				$n = $this->saveWeights(isset($this->request->post['w']) ? (array)$this->request->post['w'] : array());
				$this->session->data['dpc_epr_ok'] = 'Weights saved for ' . $n . ' product' . ($n === 1 ? '' : 's') . '.';
				$this->response->redirect($this->url->link('extension/module/dpc_epr', $token . '&tab=weights', true));
				return;
			} elseif (isset($this->request->post['action']) && $this->request->post['action'] === 'settings') {
				$this->load->model('setting/setting');
				$st = isset($this->request->post['statuses']) ? array_values(array_map('intval', (array)$this->request->post['statuses'])) : array();
				$this->model_setting_setting->editSetting('module_dpc_epr', array(
					'module_dpc_epr_status' => 1,
					'module_dpc_epr_statuses' => $st,
					'module_dpc_epr_fee_eee' => (string)$this->kg($this->request->post['fee_eee']),
					'module_dpc_epr_fee_paper' => (string)$this->kg($this->request->post['fee_paper']),
					'module_dpc_epr_fee_plastic' => (string)$this->kg($this->request->post['fee_plastic']),
				));
				$this->session->data['dpc_epr_ok'] = $st ? 'Settings saved.' : 'Settings saved. No status was ticked, so the default (complete and processing) is used.';
				$this->response->redirect($this->url->link('extension/module/dpc_epr', $token . '&tab=settings', true));
				return;
			}
		}
		if (!empty($this->session->data['dpc_epr_ok'])) {
			$data['success'] = $this->session->data['dpc_epr_ok'];
			unset($this->session->data['dpc_epr_ok']);
		}

		$f = $this->filters();
		$data['f'] = $f;
		$data['tab'] = isset($this->request->get['tab']) && in_array($this->request->get['tab'], array('report', 'weights', 'settings'), true) ? $this->request->get['tab'] : 'report';
		$data['presets'] = array();
		foreach ($this->presets() as $key => $p) {
			$data['presets'][] = array('label' => $p['label'], 'active' => $p['from'] === $f['from'] && $p['to'] === $f['to'], 'href' => $this->url->link('extension/module/dpc_epr', $token . '&from=' . $p['from'] . '&to=' . $p['to'] . '&store=' . $f['store'], true));
		}
		$data['stores'] = $this->stores();
		$data['report'] = $this->report($f);
		$data['categories'] = $this->categories();
		$data['products'] = $this->products();
		$data['order_statuses'] = $this->db->query("SELECT order_status_id, name FROM `" . DB_PREFIX . "order_status` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY name")->rows;
		foreach ($data['order_statuses'] as &$os) {
			$os['order_status_id'] = (int)$os['order_status_id'];
		}
		unset($os);
		$data['selected_statuses'] = $this->statuses();
		$data['fee_eee'] = $this->fee('eee', 0.22);
		$data['fee_paper'] = $this->fee('paper', 0.054);
		$data['fee_plastic'] = $this->fee('plastic', 0.226);
		$data['can_modify'] = $canModify;
		$data['action'] = $this->url->link('extension/module/dpc_epr', $token, true);
		$data['csv'] = $this->url->link('extension/module/dpc_epr/csv', $token . '&from=' . $f['from'] . '&to=' . $f['to'] . '&store=' . $f['store'], true);
		$data['user_token'] = $this->session->data['user_token'];
		$data['cancel'] = $this->url->link('marketplace/extension', $token . '&type=module', true);
		$data['breadcrumbs'] = array(
			array('text' => 'Home', 'href' => $this->url->link('common/dashboard', $token, true)),
			array('text' => 'Extensions', 'href' => $data['cancel']),
			array('text' => 'EPR report', 'href' => $data['action']),
		);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_epr', $data));
	}

	private function saveWeights($rows) {
		$n = 0;
		$cats = $this->categories();
		foreach ($rows as $pid => $w) {
			$pid = (int)$pid;
			if (!$pid || !is_array($w)) {
				continue;
			}
			$cat = isset($w['cat']) ? (int)$w['cat'] : 5;
			if (!isset($cats[$cat])) {
				$cat = 5;
			}
			$eee = $this->kg(isset($w['eee']) ? $w['eee'] : 0);
			$paper = $this->kg(isset($w['paper']) ? $w['paper'] : 0);
			$plastic = $this->kg(isset($w['plastic']) ? $w['plastic'] : 0);
			$old = $this->db->query("SELECT * FROM `" . DB_PREFIX . "dpc_epr_product` WHERE product_id = '" . $pid . "'")->row;
			if ($old && (int)$old['eee_category'] === $cat && (float)$old['eee_kg'] == $eee && (float)$old['paper_kg'] == $paper && (float)$old['plastic_kg'] == $plastic) {
				continue;
			}
			if (!$old && $eee == 0 && $paper == 0 && $plastic == 0 && $cat === 5) {
				continue;
			}
			$this->db->query("INSERT INTO `" . DB_PREFIX . "dpc_epr_product` SET product_id = '" . $pid . "', eee_category = '" . $cat . "', eee_kg = '" . $eee . "', paper_kg = '" . $paper . "', plastic_kg = '" . $plastic . "', date_modified = NOW()
				ON DUPLICATE KEY UPDATE eee_category = VALUES(eee_category), eee_kg = VALUES(eee_kg), paper_kg = VALUES(paper_kg), plastic_kg = VALUES(plastic_kg), date_modified = NOW()");
			$n++;
		}
		return $n;
	}

	// Physical products (shipping = 1) with their weights
	private function products() {
		$lang = (int)$this->config->get('config_language_id');
		$rows = $this->db->query("SELECT p.product_id, p.model, p.status, pd.name, e.eee_category, e.eee_kg, e.paper_kg, e.plastic_kg
			FROM `" . DB_PREFIX . "product` p LEFT JOIN `" . DB_PREFIX . "product_description` pd ON pd.product_id = p.product_id AND pd.language_id = '" . $lang . "'
			LEFT JOIN `" . DB_PREFIX . "dpc_epr_product` e ON e.product_id = p.product_id
			WHERE p.shipping = 1 ORDER BY p.status DESC, pd.name")->rows;
		foreach ($rows as &$r) {
			$r['name'] = html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8');
			$r['set'] = $r['eee_category'] !== null;
			$r['eee_category'] = $r['eee_category'] === null ? 5 : (int)$r['eee_category'];
			foreach (array('eee_kg', 'paper_kg', 'plastic_kg') as $k) {
				$r[$k] = $r[$k] === null ? '' : rtrim(rtrim(number_format((float)$r[$k], 4, '.', ''), '0'), '.');
			}
		}
		return $rows;
	}

	private function stores() {
		$o = array(array('store_id' => -1, 'name' => 'All stores'), array('store_id' => 0, 'name' => html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8') . ' (default)'));
		foreach ($this->db->query("SELECT store_id, name FROM `" . DB_PREFIX . "store` ORDER BY store_id")->rows as $s) {
			$o[] = array('store_id' => (int)$s['store_id'], 'name' => html_entity_decode($s['name'], ENT_QUOTES, 'UTF-8'));
		}
		return $o;
	}

	private function presets() {
		$y = (int)date('Y');
		$q = (int)ceil(date('n') / 3);
		$lq = $q - 1;
		$ly = $y;
		if ($lq < 1) {
			$lq = 4;
			$ly--;
		}
		$qs = sprintf('%04d-%02d-01', $ly, ($lq - 1) * 3 + 1);
		return array(
			'last_year' => array('label' => 'Last year (' . ($y - 1) . ')', 'from' => ($y - 1) . '-01-01', 'to' => ($y - 1) . '-12-31'),
			'this_year' => array('label' => 'This year (' . $y . ')', 'from' => $y . '-01-01', 'to' => $y . '-12-31'),
			'last_quarter' => array('label' => 'Last quarter (Q' . $lq . ' ' . $ly . ')', 'from' => $qs, 'to' => date('Y-m-t', strtotime($qs . ' +2 months'))),
		);
	}

	private function filters() {
		$g = $this->request->get;
		$p = $this->presets();
		$d = function ($v, $def) { $t = strtotime((string)$v); return ($v !== '' && $t) ? date('Y-m-d', $t) : $def; };
		$from = $d(isset($g['from']) ? $g['from'] : '', $p['last_year']['from']);
		$to = $d(isset($g['to']) ? $g['to'] : '', $p['last_year']['to']);
		if ($to < $from) {
			list($from, $to) = array($to, $from);
		}
		$store = isset($g['store']) && $g['store'] !== '' ? (int)$g['store'] : 0;
		return array('from' => $from, 'to' => $to, 'store' => $store);
	}

	// ------------------------------------------------------------------ the report
	private function report($f) {
		$P = DB_PREFIX;
		$st = $this->statuses();
		$cats = $this->categories();
		$lang = (int)$this->config->get('config_language_id');
		$where = "o.order_status_id IN (" . implode(',', $st ?: array(0)) . ") AND o.date_added BETWEEN '" . $this->db->escape($f['from']) . " 00:00:00' AND '" . $this->db->escape($f['to']) . " 23:59:59'";
		if ($f['store'] >= 0) {
			$where .= " AND o.store_id = '" . (int)$f['store'] . "'";
		}
		// The goods go where they are shipped; without a shipping address, the payment country counts
		$rows = $this->db->query("SELECT op.product_id, MAX(op.name) AS name, MAX(op.model) AS model,
				COALESCE(NULLIF(cs.iso_code_2, ''), cp.iso_code_2, '') AS iso, MAX(COALESCE(cs.name, cp.name, '')) AS country, SUM(op.quantity) AS units,
				e.eee_category, e.eee_kg, e.paper_kg, e.plastic_kg
			FROM `{$P}order_product` op JOIN `{$P}order` o ON o.order_id = op.order_id JOIN `{$P}product` p ON p.product_id = op.product_id
			LEFT JOIN `{$P}country` cs ON cs.country_id = o.shipping_country_id LEFT JOIN `{$P}country` cp ON cp.country_id = o.payment_country_id
			LEFT JOIN `{$P}dpc_epr_product` e ON e.product_id = op.product_id
			WHERE " . $where . " AND p.shipping = 1
			GROUP BY op.product_id, iso ORDER BY name, iso")->rows;
		$eu = $this->eu();
		$markets = array(
			'LV' => array('key' => 'LV', 'label' => 'Latvia', 'note' => 'Goes in the scheme report', 'units' => 0, 'eee' => 0, 'paper' => 0, 'plastic' => 0, 'cats' => array()),
			'EU' => array('key' => 'EU', 'label' => 'Other EU countries', 'note' => 'Each country has its own producer rules; see per country below', 'units' => 0, 'eee' => 0, 'paper' => 0, 'plastic' => 0, 'cats' => array()),
			'GB' => array('key' => 'GB', 'label' => 'United Kingdom', 'note' => 'Not reported in Latvia; belongs to the UK Ltd', 'units' => 0, 'eee' => 0, 'paper' => 0, 'plastic' => 0, 'cats' => array()),
			'XX' => array('key' => 'XX', 'label' => 'Outside the EU', 'note' => 'Not reported in Latvia', 'units' => 0, 'eee' => 0, 'paper' => 0, 'plastic' => 0, 'cats' => array()),
		);
		$countries = array();
		$detail = array();
		$missing = array();
		foreach ($rows as $r) {
			$iso = strtoupper((string)$r['iso']);
			$m = $iso === 'LV' ? 'LV' : (in_array($iso, $eu, true) ? 'EU' : ($iso === 'GB' ? 'GB' : 'XX'));
			$units = (float)$r['units'];
			$has = $r['eee_category'] !== null && ((float)$r['eee_kg'] + (float)$r['paper_kg'] + (float)$r['plastic_kg']) > 0;
			$cat = $r['eee_category'] === null ? 5 : (int)$r['eee_category'];
			$eee = $units * (float)$r['eee_kg'];
			$paper = $units * (float)$r['paper_kg'];
			$plastic = $units * (float)$r['plastic_kg'];
			$name = html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8');
			if (!$has) {
				$missing[(int)$r['product_id']] = array('product_id' => (int)$r['product_id'], 'name' => $name, 'model' => $r['model'], 'units' => (isset($missing[(int)$r['product_id']]) ? $missing[(int)$r['product_id']]['units'] : 0) + $units);
			}
			$mk = &$markets[$m];
			$mk['units'] += $units;
			$mk['eee'] += $cat ? $eee : 0;
			$mk['paper'] += $paper;
			$mk['plastic'] += $plastic;
			if ($cat) {
				$mk['cats'][$cat] = (isset($mk['cats'][$cat]) ? $mk['cats'][$cat] : 0) + $eee;
			}
			unset($mk);
			if ($m === 'EU' || $m === 'LV') {
				if (!isset($countries[$iso])) {
					$countries[$iso] = array('iso' => $iso, 'name' => $r['country'], 'units' => 0, 'eee' => 0, 'paper' => 0, 'plastic' => 0);
				}
				$countries[$iso]['units'] += $units;
				$countries[$iso]['eee'] += $cat ? $eee : 0;
				$countries[$iso]['paper'] += $paper;
				$countries[$iso]['plastic'] += $plastic;
			}
			$detail[] = array('product_id' => (int)$r['product_id'], 'name' => $name, 'model' => $r['model'], 'iso' => $iso ?: '?', 'country' => $r['country'], 'market' => $markets[$m]['label'],
				'category' => $cat, 'category_name' => isset($cats[$cat]) ? $cats[$cat] : $cat, 'units' => $units,
				'eee_each' => (float)$r['eee_kg'], 'paper_each' => (float)$r['paper_kg'], 'plastic_each' => (float)$r['plastic_kg'],
				'eee' => $cat ? $eee : 0, 'paper' => $paper, 'plastic' => $plastic, 'missing' => !$has);
		}
		$fee = array('eee' => $this->fee('eee', 0.22), 'paper' => $this->fee('paper', 0.054), 'plastic' => $this->fee('plastic', 0.226));
		foreach ($markets as &$mk) {
			$cl = array();
			foreach ($mk['cats'] as $c => $kg) {
				if ($kg <= 0) {
					continue;
				}
				$cl[] = array('category' => $c, 'name' => $cats[$c], 'kg' => round($kg, 3));
			}
			$mk['cats'] = $cl;
			foreach (array('eee', 'paper', 'plastic') as $k) {
				$mk[$k] = round($mk[$k], 3);
			}
			$mk['fee'] = round($mk['eee'] * $fee['eee'] + $mk['paper'] * $fee['paper'] + $mk['plastic'] * $fee['plastic'], 2);
		}
		unset($mk);
		ksort($countries);
		foreach ($countries as &$c) {
			foreach (array('eee', 'paper', 'plastic') as $k) {
				$c[$k] = round($c[$k], 3);
			}
		}
		unset($c);
		return array('markets' => array_values($markets), 'lv' => $markets['LV'], 'countries' => array_values($countries), 'detail' => $detail, 'missing' => array_values($missing), 'fee' => $fee, 'statuses' => $st);
	}

	// ------------------------------------------------------------------ CSV
	public function csv() {
		if (!$this->user->hasPermission('access', 'extension/module/dpc_epr')) {
			$this->response->redirect($this->url->link('error/permission', 'user_token=' . $this->session->data['user_token'], true));
			return;
		}
		$this->table();
		$f = $this->filters();
		$r = $this->report($f);
		$num = function ($v, $d = 3) { return number_format((float)$v, $d, '.', ''); };
		$out = fopen('php://temp', 'w+');
		fwrite($out, "\xEF\xBB\xBF");
		$store = 'All stores';
		foreach ($this->stores() as $s) {
			if ((int)$s['store_id'] === (int)$f['store']) {
				$store = $s['name'];
			}
		}
		fputcsv($out, array('EPR report', $f['from'] . ' - ' . $f['to'], $store));
		fputcsv($out, array());
		fputcsv($out, array('Totals by market', 'Units', 'Electronics kg', 'Paper and cardboard kg', 'Plastic kg', 'Estimated fee EUR', 'Note'));
		foreach ($r['markets'] as $m) {
			fputcsv($out, array($m['label'], $num($m['units'], 0), $num($m['eee']), $num($m['paper']), $num($m['plastic']), $num($m['fee'], 2), $m['note']));
		}
		fputcsv($out, array());
		fputcsv($out, array('Electronics by category', 'Market', 'kg'));
		foreach ($r['markets'] as $m) {
			foreach ($m['cats'] as $c) {
				fputcsv($out, array($c['name'], $m['label'], $num($c['kg'])));
			}
		}
		fputcsv($out, array());
		fputcsv($out, array('EU countries', 'Country code', 'Units', 'Electronics kg', 'Paper and cardboard kg', 'Plastic kg'));
		foreach ($r['countries'] as $c) {
			fputcsv($out, array($c['name'], $c['iso'], $num($c['units'], 0), $num($c['eee']), $num($c['paper']), $num($c['plastic'])));
		}
		fputcsv($out, array());
		fputcsv($out, array('Product', 'Model', 'Country code', 'Country', 'Market', 'Category', 'Units', 'Electronics kg each', 'Paper kg each', 'Plastic kg each', 'Electronics kg', 'Paper kg', 'Plastic kg', 'Weights missing'));
		foreach ($r['detail'] as $d) {
			fputcsv($out, array($d['name'], $d['model'], $d['iso'], $d['country'], $d['market'], $d['category_name'], $num($d['units'], 0), $num($d['eee_each'], 4), $num($d['paper_each'], 4), $num($d['plastic_each'], 4), $num($d['eee']), $num($d['paper']), $num($d['plastic']), $d['missing'] ? 'yes' : ''));
		}
		rewind($out);
		$csv = stream_get_contents($out);
		fclose($out);
		$this->response->addHeader('Content-Type: text/csv; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="epr-' . $f['from'] . '-' . $f['to'] . ($f['store'] >= 0 ? '-store' . (int)$f['store'] : '') . '.csv"');
		$this->response->setOutput($csv);
	}
}
