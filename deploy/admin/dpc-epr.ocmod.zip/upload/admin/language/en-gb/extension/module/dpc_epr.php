<?php
$_['heading_title'] = 'dpCREATOR EPR report (e-waste and packaging)';
