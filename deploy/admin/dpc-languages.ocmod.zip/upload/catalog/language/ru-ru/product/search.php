<?php
// Heading
$_['heading_title']     = 'Поиск';
$_['heading_tag']       = 'Тег - ';

// Text
$_['text_search']       = 'Товары, соответствующие условиям поиска';
$_['text_keyword']      = 'Ключевые слова';
$_['text_category']     = 'Все категории';
$_['text_sub_category'] = 'Искать в подкатегориях';
$_['text_empty']        = 'Нет товаров, соответствующих условиям поиска.';
$_['text_quantity']     = 'Кол-во:';
$_['text_manufacturer'] = 'Бренд:';
$_['text_model']        = 'Код товара:';
$_['text_points']       = 'Бонусные баллы:';
$_['text_price']        = 'Цена:';
$_['text_tax']          = 'Без налога:';
$_['text_reviews']      = 'Отзывов: %s.';
$_['text_compare']      = 'Сравнение товаров (%s)';
$_['text_sort']         = 'Сортировка:';
$_['text_default']      = 'По умолчанию';
$_['text_name_asc']     = 'Название (А - Я)';
$_['text_name_desc']    = 'Название (Я - А)';
$_['text_price_asc']    = 'Цена (по возрастанию)';
$_['text_price_desc']   = 'Цена (по убыванию)';
$_['text_rating_asc']   = 'Рейтинг (по возрастанию)';
$_['text_rating_desc']  = 'Рейтинг (по убыванию)';
$_['text_model_asc']    = 'Модель (А - Я)';
$_['text_model_desc']   = 'Модель (Я - А)';
$_['text_limit']        = 'Показать:';

// Entry
$_['entry_search']      = 'Условия поиска';
$_['entry_description'] = 'Искать в описаниях товаров';
