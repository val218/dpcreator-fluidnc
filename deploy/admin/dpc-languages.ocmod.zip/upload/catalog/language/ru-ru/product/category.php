<?php
// Text
$_['text_refine']       = 'Уточнить поиск';
$_['text_product']      = 'Товары';
$_['text_error']        = 'Категория не найдена!';
$_['text_empty']        = 'В этой категории пока нет товаров.';
$_['text_quantity']     = 'Кол-во:';
$_['text_manufacturer'] = 'Бренд:';
$_['text_model']        = 'Код товара:';
$_['text_points']       = 'Бонусные баллы:';
$_['text_price']        = 'Цена:';
$_['text_tax']          = 'Без налога:';
$_['text_compare']      = 'Сравнение товаров (%s)';
$_['text_sort']         = 'Сортировка:';
$_['text_default']      = 'По умолчанию';
$_['text_name_asc']     = 'Название (А - Я)';
$_['text_name_desc']    = 'Название (Я - А)';
$_['text_price_asc']    = 'Цена (по возрастанию)';
$_['text_price_desc']   = 'Цена (по убыванию)';
$_['text_rating_asc']   = 'Рейтинг (по возрастанию)';
$_['text_rating_desc']  = 'Рейтинг (по убыванию)';
$_['text_model_asc']    = 'Модель (А - Я)';
$_['text_model_desc']   = 'Модель (Я - А)';
$_['text_limit']        = 'Показать:';
