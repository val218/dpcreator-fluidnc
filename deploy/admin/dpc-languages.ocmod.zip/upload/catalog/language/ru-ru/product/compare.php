<?php
// Heading
$_['heading_title']     = 'Сравнение товаров';

// Text
$_['text_product']      = 'Характеристики товара';
$_['text_name']         = 'Товар';
$_['text_image']        = 'Изображение';
$_['text_price']        = 'Цена';
$_['text_model']        = 'Модель';
$_['text_manufacturer'] = 'Бренд';
$_['text_availability'] = 'Наличие';
$_['text_instock']      = 'В наличии';
$_['text_rating']       = 'Рейтинг';
$_['text_reviews']      = 'Отзывов: %s.';
$_['text_summary']      = 'Краткое описание';
$_['text_weight']       = 'Вес';
$_['text_dimension']    = 'Размеры (Д x Ш x В)';
$_['text_compare']      = 'Сравнение товаров (%s)';
$_['text_success']      = 'Товар <a href="%s">%s</a> добавлен в <a href="%s">сравнение</a>!';
$_['text_remove']       = 'Список сравнения обновлен!';
$_['text_empty']        = 'Вы не выбрали товары для сравнения.';
