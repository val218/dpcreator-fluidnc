<?php
// Text
$_['text_search']              = 'Поиск';
$_['text_brand']               = 'Бренд';
$_['text_manufacturer']        = 'Бренд:';
$_['text_model']               = 'Код товара:';
$_['text_reward']              = 'Бонусные баллы:';
$_['text_points']              = 'Цена в бонусных баллах:';
$_['text_stock']               = 'Наличие:';
$_['text_instock']             = 'В наличии';
$_['text_tax']                 = 'Без налога:';
$_['text_discount']            = ' и более ';
$_['text_option']              = 'Доступные опции';
$_['text_minimum']             = 'Минимальное количество для заказа: %s';
$_['text_reviews']             = 'Отзывов: %s';
$_['text_write']               = 'Написать отзыв';
$_['text_login']               = 'Чтобы оставить отзыв, <a href="%s">войдите</a> или <a href="%s">зарегистрируйтесь</a>';
$_['text_no_reviews']          = 'У этого товара пока нет отзывов.';
$_['text_note']                = '<span class="text-danger">Примечание:</span> HTML не поддерживается!';
$_['text_success']             = 'Спасибо за отзыв! Он отправлен администратору на проверку.';
$_['text_related']             = 'Сопутствующие товары';
$_['text_tags']                = 'Теги:';
$_['text_error']               = 'Товар не найден!';
$_['text_payment_recurring']   = 'Профиль платежа';
$_['text_trial_description']   = '%s каждые %d %s, платежей: %d, затем';
$_['text_payment_description'] = '%s каждые %d %s, платежей: %d';
$_['text_payment_cancel']      = '%s каждые %d %s до отмены';
$_['text_day']                 = 'дн.';
$_['text_week']                = 'нед.';
$_['text_semi_month']          = 'полмес.';
$_['text_month']               = 'мес.';
$_['text_year']                = 'г.';

// Entry
$_['entry_qty']                = 'Кол-во';
$_['entry_name']               = 'Ваше имя';
$_['entry_review']             = 'Ваш отзыв';
$_['entry_rating']             = 'Оценка';
$_['entry_good']               = 'Хорошо';
$_['entry_bad']                = 'Плохо';

// Tabs
$_['tab_description']          = 'Описание';
$_['tab_attribute']            = 'Характеристики';
$_['tab_review']               = 'Отзывы (%s)';

// Error
$_['error_name']               = 'Внимание: имя должно содержать от 3 до 25 символов!';
$_['error_text']               = 'Внимание: текст отзыва должен содержать от 25 до 1000 символов!';
$_['error_rating']             = 'Внимание: выберите оценку!';
$_['error_product']            = "Внимание: для отзыва нужно указать товар!";
