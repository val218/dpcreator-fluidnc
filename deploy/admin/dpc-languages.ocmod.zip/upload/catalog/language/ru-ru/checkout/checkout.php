<?php
// Heading
$_['heading_title']                  = 'Оформление заказа';

// Text
$_['text_cart']                      = 'Корзина';
$_['text_checkout_option']           = 'Шаг %s: способ оформления';
$_['text_checkout_account']          = 'Шаг %s: аккаунт и платежные данные';
$_['text_checkout_payment_address']  = 'Шаг %s: платежные данные';
$_['text_checkout_shipping_address'] = 'Шаг %s: данные для доставки';
$_['text_checkout_shipping_method']  = 'Шаг %s: способ доставки';
$_['text_checkout_payment_method']   = 'Шаг %s: способ оплаты';
$_['text_checkout_confirm']          = 'Шаг %s: подтверждение заказа';
$_['text_modify']                    = 'Изменить &raquo;';
$_['text_new_customer']              = 'Новый покупатель';
$_['text_returning_customer']        = 'Постоянный покупатель';
$_['text_checkout']                  = 'Способ оформления:';
$_['text_i_am_returning_customer']   = 'Я уже зарегистрирован(а)';
$_['text_register']                  = 'Регистрация';
$_['text_guest']                     = 'Оформить без регистрации';
$_['text_register_account']          = 'Создав аккаунт, вы сможете быстрее оформлять покупки, следить за статусом заказа и просматривать историю своих заказов.';
$_['text_forgotten']                 = 'Забыли пароль?';
$_['text_your_details']              = 'Ваши личные данные';
$_['text_your_address']              = 'Ваш адрес';
$_['text_your_password']             = 'Ваш пароль';
$_['text_agree']                     = 'Я прочитал(а) и принимаю <a href="%s" class="agree"><b>%s</b></a>';
$_['text_address_new']               = 'Использовать новый адрес';
$_['text_address_existing']          = 'Использовать сохраненный адрес';
$_['text_shipping_method']           = 'Выберите способ доставки для этого заказа.';
$_['text_payment_method']            = 'Выберите способ оплаты для этого заказа.';
$_['text_comments']                  = 'Комментарий к заказу';
$_['text_recurring_item']            = 'Регулярный платеж';
$_['text_payment_recurring']         = 'Профиль платежа';
$_['text_trial_description']         = '%s каждые %d %s, платежей: %d, затем';
$_['text_payment_description']       = '%s каждые %d %s, платежей: %d';
$_['text_payment_cancel']            = '%s каждые %d %s до отмены';
$_['text_day']                       = 'дн.';
$_['text_week']                      = 'нед.';
$_['text_semi_month']                = 'полмес.';
$_['text_month']                     = 'мес.';
$_['text_year']                      = 'г.';

// Column
$_['column_name']                    = 'Название товара';
$_['column_model']                   = 'Модель';
$_['column_quantity']                = 'Количество';
$_['column_price']                   = 'Цена за шт.';
$_['column_total']                   = 'Итого';

// Entry
$_['entry_email_address']            = 'E-mail';
$_['entry_email']                    = 'E-mail';
$_['entry_password']                 = 'Пароль';
$_['entry_confirm']                  = 'Подтверждение пароля';
$_['entry_firstname']                = 'Имя';
$_['entry_lastname']                 = 'Фамилия';
$_['entry_telephone']                = 'Телефон';
$_['entry_address']                  = 'Выберите адрес';
$_['entry_company']                  = 'Компания';
$_['entry_customer_group']           = 'Группа покупателей';
$_['entry_address_1']                = 'Адрес';
$_['entry_address_2']                = 'Адрес (строка 2)';
$_['entry_postcode']                 = 'Почтовый индекс';
$_['entry_city']                     = 'Город';
$_['entry_country']                  = 'Страна';
$_['entry_zone']                     = 'Регион / область';
$_['entry_newsletter']               = 'Я хочу подписаться на рассылку %s.';
$_['entry_shipping']                 = 'Адрес доставки совпадает с платежным адресом.';

// Error
$_['error_warning']                  = 'При обработке вашего заказа возникла проблема! Если она повторится, попробуйте выбрать другой способ оплаты или свяжитесь с владельцем магазина, <a href="%s">нажав здесь</a>.';
$_['error_login']                    = 'Внимание: неверный e-mail и/или пароль.';
$_['error_attempts']                 = 'Внимание: превышено допустимое число попыток входа. Попробуйте снова через 1 час.';
$_['error_approved']                 = 'Внимание: ваш аккаунт должен быть одобрен, прежде чем вы сможете войти.';
$_['error_exists']                   = 'Внимание: этот e-mail уже зарегистрирован!';
$_['error_firstname']                = 'Имя должно содержать от 1 до 32 символов!';
$_['error_lastname']                 = 'Фамилия должна содержать от 1 до 32 символов!';
$_['error_email']                    = 'Неверный адрес e-mail!';
$_['error_telephone']                = 'Телефон должен содержать от 3 до 32 символов!';
$_['error_password']                 = 'Пароль должен содержать от 4 до 20 символов!';
$_['error_confirm']                  = 'Подтверждение не совпадает с паролем!';
$_['error_address_1']                = 'Адрес должен содержать от 3 до 128 символов!';
$_['error_city']                     = 'Название города должно содержать от 2 до 128 символов!';
$_['error_postcode']                 = 'Почтовый индекс должен содержать от 2 до 10 символов!';
$_['error_country']                  = 'Выберите страну!';
$_['error_zone']                     = 'Выберите регион / область!';
$_['error_agree']                    = 'Внимание: вы должны принять условия «%s»!';
$_['error_address']                  = 'Внимание: выберите адрес!';
$_['error_shipping']                 = 'Внимание: выберите способ доставки!';
$_['error_no_shipping']              = 'Внимание: нет доступных способов доставки. Пожалуйста, <a href="%s">свяжитесь с нами</a>, и мы поможем!';
$_['error_payment']                  = 'Внимание: выберите способ оплаты!';
$_['error_no_payment']               = 'Внимание: нет доступных способов оплаты. Пожалуйста, <a href="%s">свяжитесь с нами</a>, и мы поможем!';
$_['error_custom_field']             = 'Поле «%s» обязательно!';
