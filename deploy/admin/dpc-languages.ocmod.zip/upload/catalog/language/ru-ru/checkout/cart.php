<?php
// Heading
$_['heading_title']            = 'Корзина';

// Text
$_['text_success']             = 'Товар <a href="%s">%s</a> добавлен в <a href="%s">корзину</a>!';
$_['text_remove']              = 'Корзина обновлена!';
$_['text_login']               = 'Внимание: чтобы видеть цены, <a href="%s">войдите</a> или <a href="%s">создайте аккаунт</a>!';
$_['text_items']               = 'Товаров: %s (%s)';
$_['text_points']              = 'Бонусные баллы: %s';
$_['text_next']                = 'Что вы хотите сделать дальше?';
$_['text_next_choice']         = 'Укажите код скидки или бонусные баллы, если хотите их использовать, или рассчитайте стоимость доставки.';
$_['text_empty']               = 'Ваша корзина пуста!';
$_['text_day']                 = 'дн.';
$_['text_week']                = 'нед.';
$_['text_semi_month']          = 'полмес.';
$_['text_month']               = 'мес.';
$_['text_year']                = 'г.';
$_['text_trial']               = '%s каждые %s %s, платежей: %s, затем ';
$_['text_recurring']           = '%s каждые %s %s';
$_['text_recurring_item']      = 'Регулярный платеж';
$_['text_payment_recurring']   = 'Профиль платежа';
$_['text_trial_description']   = '%s каждые %d %s, платежей: %d, затем';
$_['text_payment_description'] = '%s каждые %d %s, платежей: %d';
$_['text_payment_cancel']      = '%s каждые %d %s до отмены';

// Column
$_['column_image']             = 'Изображение';
$_['column_name']              = 'Название товара';
$_['column_model']             = 'Модель';
$_['column_quantity']          = 'Количество';
$_['column_price']             = 'Цена за шт.';
$_['column_total']             = 'Итого';

// Error
$_['error_stock']              = 'Товаров, отмеченных ***, нет в наличии или нет в нужном количестве!';
$_['error_minimum']            = 'Минимальное количество для заказа %s: %s!';
$_['error_required']           = 'Поле «%s» обязательно!';
$_['error_product']            = 'Внимание: в вашей корзине нет товаров!';
$_['error_recurring_required'] = 'Выберите регулярный платеж!';
