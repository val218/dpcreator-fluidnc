<?php
// Text
$_['text_information']  = 'Информация';
$_['text_service']      = 'Поддержка';
$_['text_extra']        = 'Дополнительно';
$_['text_contact']      = 'Контакты';
$_['text_return']       = 'Возврат товара';
$_['text_sitemap']      = 'Карта сайта';
$_['text_manufacturer'] = 'Бренды';
$_['text_voucher']      = 'Подарочные сертификаты';
$_['text_affiliate']    = 'Партнерская программа';
$_['text_special']      = 'Акции';
$_['text_account']      = 'Личный кабинет';
$_['text_order']        = 'История заказов';
$_['text_wishlist']     = 'Избранное';
$_['text_newsletter']   = 'Рассылка';
$_['text_powered']      = 'Работает на <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
