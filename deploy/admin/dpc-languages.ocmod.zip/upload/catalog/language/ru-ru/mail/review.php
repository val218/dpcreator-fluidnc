<?php
// Text
$_['text_subject']  = '%s - Отзыв о товаре';
$_['text_waiting']  = 'Новый отзыв о товаре ожидает проверки.';
$_['text_product']  = 'Товар: %s';
$_['text_reviewer'] = 'Автор отзыва: %s';
$_['text_rating']   = 'Оценка: %s';
$_['text_review']   = 'Текст отзыва:';
