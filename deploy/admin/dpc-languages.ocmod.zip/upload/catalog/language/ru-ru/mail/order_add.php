<?php
// Text
$_['text_subject']          = '%s - Заказ %s';
$_['text_greeting']         = 'Спасибо за интерес к товарам %s. Ваш заказ получен и будет обработан после подтверждения оплаты.';
$_['text_link']             = 'Чтобы посмотреть заказ, перейдите по ссылке ниже:';
$_['text_order_detail']     = 'Детали заказа';
$_['text_instruction']      = 'Инструкции';
$_['text_order_id']         = '№ заказа:';
$_['text_date_added']       = 'Дата добавления:';
$_['text_order_status']     = 'Статус заказа:';
$_['text_payment_method']   = 'Способ оплаты:';
$_['text_shipping_method']  = 'Способ доставки:';
$_['text_email']            = 'E-mail:';
$_['text_telephone']        = 'Телефон:';
$_['text_ip']               = 'IP-адрес:';
$_['text_payment_address']  = 'Платежный адрес';
$_['text_shipping_address'] = 'Адрес доставки';
$_['text_products']         = 'Товары';
$_['text_product']          = 'Товар';
$_['text_model']            = 'Модель';
$_['text_quantity']         = 'Количество';
$_['text_price']            = 'Цена';
$_['text_order_total']      = 'Сумма заказа';
$_['text_total']            = 'Итого';
$_['text_download']         = 'После подтверждения оплаты вы сможете скачать купленные файлы по ссылке ниже:';
$_['text_comment']          = 'Комментарий к вашему заказу:';
$_['text_footer']           = 'Если у вас есть вопросы, просто ответьте на это письмо.';
