<?php
// Heading
$_['heading_title'] = 'Избранное';

// Text
$_['text_account']  = 'Личный кабинет';
$_['text_instock']  = 'В наличии';
$_['text_wishlist'] = 'Избранное (%s)';
$_['text_login']    = 'Вы должны <a href="%s">войти</a> или <a href="%s">создать аккаунт</a>, чтобы сохранить <a href="%s">%s</a> в <a href="%s">избранное</a>!';
$_['text_success']  = 'Товар <a href="%s">%s</a> добавлен в <a href="%s">избранное</a>!';
$_['text_remove']   = 'Избранное обновлено!';
$_['text_empty']    = 'В избранном пока ничего нет.';

// Column
$_['column_image']  = 'Изображение';
$_['column_name']   = 'Название товара';
$_['column_model']  = 'Модель';
$_['column_stock']  = 'Наличие';
$_['column_price']  = 'Цена за шт.';
$_['column_action'] = 'Действие';
