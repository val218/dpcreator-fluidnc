<?php
// Heading
$_['heading_title']      = 'Ваши бонусные баллы';

// Column
$_['column_date_added']  = 'Дата добавления';
$_['column_description'] = 'Описание';
$_['column_points']      = 'Баллы';

// Text
$_['text_account']       = 'Личный кабинет';
$_['text_reward']        = 'Бонусные баллы';
$_['text_total']         = 'Всего бонусных баллов:';
$_['text_empty']         = 'У вас пока нет бонусных баллов!';
