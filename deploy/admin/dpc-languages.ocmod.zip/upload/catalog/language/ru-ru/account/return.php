<?php
// Heading
$_['heading_title']      = 'Возврат товара';

// Text
$_['text_account']       = 'Личный кабинет';
$_['text_return']        = 'Информация о возврате';
$_['text_return_detail'] = 'Детали возврата';
$_['text_description']   = 'Заполните форму ниже, чтобы запросить номер возврата (RMA).';
$_['text_order']         = 'Информация о заказе';
$_['text_product']       = 'Информация о товаре';
$_['text_reason']        = 'Причина возврата';
$_['text_message']       = '<p>Спасибо, ваша заявка на возврат отправлена. Она передана в соответствующий отдел на обработку.</p><p> О статусе заявки мы сообщим вам по e-mail.</p>';
$_['text_return_id']     = '№ возврата:';
$_['text_order_id']      = '№ заказа:';
$_['text_date_ordered']  = 'Дата заказа:';
$_['text_status']        = 'Статус:';
$_['text_date_added']    = 'Дата добавления:';
$_['text_comment']       = 'Комментарий к возврату';
$_['text_history']       = 'История возврата';
$_['text_empty']         = 'Вы еще не оформляли возвратов!';
$_['text_agree']         = 'Я прочитал(а) и принимаю <a href="%s" class="agree"><b>%s</b></a>';

// Column
$_['column_return_id']   = '№ возврата';
$_['column_order_id']    = '№ заказа';
$_['column_status']      = 'Статус';
$_['column_date_added']  = 'Дата добавления';
$_['column_customer']    = 'Покупатель';
$_['column_product']     = 'Название товара';
$_['column_model']       = 'Модель';
$_['column_quantity']    = 'Количество';
$_['column_price']       = 'Цена';
$_['column_opened']      = 'Вскрыт';
$_['column_comment']     = 'Комментарий';
$_['column_reason']      = 'Причина';
$_['column_action']      = 'Действие';

// Entry
$_['entry_order_id']     = '№ заказа';
$_['entry_date_ordered'] = 'Дата заказа';
$_['entry_firstname']    = 'Имя';
$_['entry_lastname']     = 'Фамилия';
$_['entry_email']        = 'E-mail';
$_['entry_telephone']    = 'Телефон';
$_['entry_product']      = 'Название товара';
$_['entry_model']        = 'Код товара';
$_['entry_quantity']     = 'Количество';
$_['entry_reason']       = 'Причина возврата';
$_['entry_opened']       = 'Товар вскрыт';
$_['entry_fault_detail'] = 'Описание дефекта или другие подробности';

// Error
$_['text_error']         = 'Запрошенный возврат не найден!';
$_['error_order_id']     = 'Укажите номер заказа!';
$_['error_firstname']    = 'Имя должно содержать от 1 до 32 символов!';
$_['error_lastname']     = 'Фамилия должна содержать от 1 до 32 символов!';
$_['error_email']        = 'Неверный адрес e-mail!';
$_['error_telephone']    = 'Телефон должен содержать от 3 до 32 символов!';
$_['error_product']      = 'Название товара должно содержать больше 3 и меньше 255 символов!';
$_['error_model']        = 'Модель товара должна содержать больше 3 и меньше 64 символов!';
$_['error_reason']       = 'Выберите причину возврата!';
$_['error_agree']        = 'Внимание: вы должны принять условия «%s»!';
