<?php
// Heading
$_['heading_title']     = 'Загрузки';

// Text
$_['text_account']      = 'Личный кабинет';
$_['text_downloads']    = 'Загрузки';
$_['text_empty']        = 'У вас пока нет заказов с файлами для скачивания!';

// Column
$_['column_order_id']   = '№ заказа';
$_['column_name']       = 'Название';
$_['column_size']       = 'Размер';
$_['column_date_added'] = 'Дата добавления';
