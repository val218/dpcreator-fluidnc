<?php
// Heading
$_['heading_title']       = 'Личный кабинет';

// Text
$_['text_account']        = 'Личный кабинет';
$_['text_my_account']     = 'Мой аккаунт';
$_['text_my_orders']      = 'Мои заказы';
$_['text_my_affiliate']   = 'Партнерский аккаунт';
$_['text_my_newsletter']  = 'Рассылка';
$_['text_edit']           = 'Изменить личные данные';
$_['text_password']       = 'Изменить пароль';
$_['text_address']        = 'Изменить адресную книгу';
$_['text_credit_card']    = 'Сохраненные банковские карты';
$_['text_wishlist']       = 'Изменить избранное';
$_['text_order']          = 'История заказов';
$_['text_download']       = 'Загрузки';
$_['text_reward']         = 'Ваши бонусные баллы';
$_['text_return']         = 'Ваши заявки на возврат';
$_['text_transaction']    = 'Ваши транзакции';
$_['text_newsletter']     = 'Подписаться / отписаться от рассылки';
$_['text_recurring']      = 'Регулярные платежи';
$_['text_transactions']   = 'Транзакции';
$_['text_affiliate_add']  = 'Зарегистрировать партнерский аккаунт';
$_['text_affiliate_edit'] = 'Изменить партнерские данные';
$_['text_tracking']       = 'Партнерский код отслеживания';
