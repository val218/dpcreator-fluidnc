<?php
// Heading
$_['heading_title']  = 'Смена пароля';

// Text
$_['text_account']   = 'Личный кабинет';
$_['text_password']  = 'Ваш пароль';
$_['text_success']   = 'Ваш пароль успешно изменен.';

// Entry
$_['entry_password'] = 'Пароль';
$_['entry_confirm']  = 'Подтверждение пароля';

// Error
$_['error_password'] = 'Пароль должен содержать от 4 до 20 символов!';
$_['error_confirm']  = 'Подтверждение не совпадает с паролем!';
