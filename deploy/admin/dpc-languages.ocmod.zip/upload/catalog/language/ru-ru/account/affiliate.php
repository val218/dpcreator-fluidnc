<?php
// Heading
$_['heading_title']             = 'Ваши партнерские данные';

// Text
$_['text_account']              = 'Личный кабинет';
$_['text_affiliate']            = 'Партнерская программа';
$_['text_my_affiliate']         = 'Партнерский аккаунт';
$_['text_payment']              = 'Платежные данные';
$_['text_cheque']               = 'Чек';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Банковский перевод';
$_['text_success']              = 'Ваши данные успешно обновлены.';
$_['text_agree']                = 'Я прочитал(а) и принимаю <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_company']             = 'Компания';
$_['entry_website']             = 'Веб-сайт';
$_['entry_tax']                 = 'Налоговый номер';
$_['entry_payment']             = 'Способ выплаты';
$_['entry_cheque']              = 'Получатель чека';
$_['entry_paypal']              = 'E-mail аккаунта PayPal';
$_['entry_bank_name']           = 'Название банка';
$_['entry_bank_branch_number']  = 'Номер ABA/BSB (номер отделения)';
$_['entry_bank_swift_code']     = 'SWIFT-код';
$_['entry_bank_account_name']   = 'Владелец счета';
$_['entry_bank_account_number'] = 'Номер счета';

// Error
$_['error_agree']               = 'Внимание: вы должны принять условия «%s»!';
$_['error_cheque']              = 'Укажите получателя чека!';
$_['error_paypal']              = 'Неверный e-mail PayPal!';
$_['error_bank_account_name']   = 'Укажите владельца счета!';
$_['error_bank_account_number'] = 'Укажите номер счета!';
$_['error_custom_field']        = 'Поле «%s» обязательно!';
