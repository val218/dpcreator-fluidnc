<?php
// Heading
$_['heading_title']         = 'История заказов';

// Text
$_['text_account']          = 'Личный кабинет';
$_['text_order']            = 'Информация о заказе';
$_['text_order_detail']     = 'Детали заказа';
$_['text_invoice_no']       = '№ счета:';
$_['text_order_id']         = '№ заказа:';
$_['text_date_added']       = 'Дата добавления:';
$_['text_shipping_address'] = 'Адрес доставки';
$_['text_shipping_method']  = 'Способ доставки:';
$_['text_payment_address']  = 'Платежный адрес';
$_['text_payment_method']   = 'Способ оплаты:';
$_['text_comment']          = 'Комментарий к заказу';
$_['text_history']          = 'История заказа';
$_['text_success']          = 'Товар <a href="%s">%s</a> добавлен в <a href="%s">корзину</a>!';
$_['text_empty']            = 'Вы еще не делали заказов!';
$_['text_error']            = 'Запрошенный заказ не найден!';

// Column
$_['column_order_id']       = '№ заказа';
$_['column_customer']       = 'Покупатель';
$_['column_product']        = 'Кол-во товаров';
$_['column_name']           = 'Название товара';
$_['column_model']          = 'Модель';
$_['column_quantity']       = 'Количество';
$_['column_price']          = 'Цена';
$_['column_total']          = 'Итого';
$_['column_action']         = 'Действие';
$_['column_date_added']     = 'Дата добавления';
$_['column_status']         = 'Статус';
$_['column_comment']        = 'Комментарий';

// Error
$_['error_reorder']         = 'Товар %s сейчас недоступен для повторного заказа.';
