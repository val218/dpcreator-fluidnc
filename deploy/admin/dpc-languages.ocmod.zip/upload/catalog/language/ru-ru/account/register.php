<?php
// Heading
$_['heading_title']        = 'Регистрация';

// Text
$_['text_account']         = 'Личный кабинет';
$_['text_register']        = 'Регистрация';
$_['text_account_already'] = 'Если у вас уже есть аккаунт, войдите на <a href="%s">странице входа</a>.';
$_['text_your_details']    = 'Ваши личные данные';
$_['text_newsletter']      = 'Рассылка';
$_['text_your_password']   = 'Ваш пароль';
$_['text_agree']           = 'Я прочитал(а) и принимаю <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_customer_group'] = 'Группа покупателей';
$_['entry_firstname']      = 'Имя';
$_['entry_lastname']       = 'Фамилия';
$_['entry_email']          = 'E-mail';
$_['entry_telephone']      = 'Телефон';
$_['entry_newsletter']     = 'Подписаться';
$_['entry_password']       = 'Пароль';
$_['entry_confirm']        = 'Подтверждение пароля';

// Error
$_['error_exists']         = 'Внимание: этот e-mail уже зарегистрирован!';
$_['error_firstname']      = 'Имя должно содержать от 1 до 32 символов!';
$_['error_lastname']       = 'Фамилия должна содержать от 1 до 32 символов!';
$_['error_email']          = 'Неверный адрес e-mail!';
$_['error_telephone']      = 'Телефон должен содержать от 3 до 32 символов!';
$_['error_custom_field']   = 'Поле «%s» обязательно!';
$_['error_password']       = 'Пароль должен содержать от 4 до 20 символов!';
$_['error_confirm']        = 'Подтверждение не совпадает с паролем!';
$_['error_agree']          = 'Внимание: вы должны принять условия «%s»!';
