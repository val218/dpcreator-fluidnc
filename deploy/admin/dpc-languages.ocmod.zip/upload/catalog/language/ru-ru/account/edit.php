<?php
// Heading
$_['heading_title']      = 'Мои личные данные';

// Text
$_['text_account']       = 'Личный кабинет';
$_['text_edit']          = 'Изменить данные';
$_['text_your_details']  = 'Ваши личные данные';
$_['text_success']       = 'Ваши данные успешно обновлены.';

// Entry
$_['entry_firstname']    = 'Имя';
$_['entry_lastname']     = 'Фамилия';
$_['entry_email']        = 'E-mail';
$_['entry_telephone']    = 'Телефон';

// Error
$_['error_exists']       = 'Внимание: этот e-mail уже зарегистрирован!';
$_['error_firstname']    = 'Имя должно содержать от 1 до 32 символов!';
$_['error_lastname']     = 'Фамилия должна содержать от 1 до 32 символов!';
$_['error_email']        = 'Неверный адрес e-mail!';
$_['error_telephone']    = 'Телефон должен содержать от 3 до 32 символов!';
$_['error_custom_field'] = 'Поле «%s» обязательно!';
