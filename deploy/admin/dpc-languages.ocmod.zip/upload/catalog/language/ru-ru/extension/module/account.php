<?php
// Heading
$_['heading_title']    = 'Личный кабинет';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Вход';
$_['text_logout']      = 'Выход';
$_['text_forgotten']   = 'Забыли пароль?';
$_['text_account']     = 'Мой аккаунт';
$_['text_edit']        = 'Личные данные';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Адресная книга';
$_['text_wishlist']    = 'Избранное';
$_['text_order']       = 'История заказов';
$_['text_download']    = 'Загрузки';
$_['text_reward']      = 'Бонусные баллы';
$_['text_return']      = 'Возвраты';
$_['text_transaction'] = 'Транзакции';
$_['text_newsletter']  = 'Рассылка';
$_['text_recurring']   = 'Регулярные платежи';
