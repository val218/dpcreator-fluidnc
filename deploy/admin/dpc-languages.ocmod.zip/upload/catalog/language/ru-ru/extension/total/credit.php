<?php
// Text
$_['text_credit']   = 'Баланс магазина';
$_['text_order_id'] = '№ заказа: #%s';
