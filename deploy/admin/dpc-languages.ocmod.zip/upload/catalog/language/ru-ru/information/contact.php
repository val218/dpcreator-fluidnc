<?php
// Heading
$_['heading_title']  = 'Контакты';

// Text
$_['text_location']  = 'Где мы находимся';
$_['text_store']     = 'Наши магазины';
$_['text_contact']   = 'Форма обратной связи';
$_['text_address']   = 'Адрес';
$_['text_telephone'] = 'Телефон';
$_['text_fax']       = 'Факс';
$_['text_open']      = 'Часы работы';
$_['text_comment']   = 'Комментарий';
$_['text_message']   = '<p>Ваше сообщение успешно отправлено владельцу магазина!</p>';

// Entry
$_['entry_name']     = 'Ваше имя';
$_['entry_email']    = 'E-mail';
$_['entry_enquiry']  = 'Сообщение';

// Email
$_['email_subject']  = 'Сообщение от %s';

// Errors
$_['error_name']     = 'Имя должно содержать от 3 до 32 символов!';
$_['error_email']    = 'Неверный адрес e-mail!';
$_['error_enquiry']  = 'Сообщение должно содержать от 10 до 3000 символов!';
