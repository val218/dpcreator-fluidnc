<?php
// Text
$_['text_information']  = 'Informācija';
$_['text_service']      = 'Klientu apkalpošana';
$_['text_extra']        = 'Papildus';
$_['text_contact']      = 'Kontakti';
$_['text_return']       = 'Preču atgriešana';
$_['text_sitemap']      = 'Vietnes karte';
$_['text_manufacturer'] = 'Zīmoli';
$_['text_voucher']      = 'Dāvanu kartes';
$_['text_affiliate']    = 'Partneriem';
$_['text_special']      = 'Īpašie piedāvājumi';
$_['text_account']      = 'Mans konts';
$_['text_order']        = 'Pasūtījumu vēsture';
$_['text_wishlist']     = 'Vēlmju saraksts';
$_['text_newsletter']   = 'Jaunumu vēstule';
$_['text_powered']      = 'Darbina <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';