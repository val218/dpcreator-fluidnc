<?php
// Text
$_['text_items']     = 'Preces: %s - %s';
$_['text_empty']     = 'Jūsu iepirkumu grozs ir tukšs!';
$_['text_cart']      = 'Skatīt grozu';
$_['text_checkout']  = 'Noformēt pasūtījumu';
$_['text_recurring'] = 'Maksājumu plāns';