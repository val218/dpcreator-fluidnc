<?php
// Heading
$_['heading_title']    = 'Apkope';

// Text
$_['text_maintenance'] = 'Apkope';
$_['text_message']     = '<h1 style="text-align:center;">Pašlaik notiek plānota apkope. <br/>Atgriezīsimies, cik ātri vien iespējams. Lūdzu, ieskatieties vēlāk.</h1>';