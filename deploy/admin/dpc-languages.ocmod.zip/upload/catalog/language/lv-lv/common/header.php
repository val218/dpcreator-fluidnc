<?php
// Text
$_['text_home']          = 'Sākums';
$_['text_wishlist']      = 'Vēlmju saraksts (%s)';
$_['text_shopping_cart'] = 'Iepirkumu grozs';
$_['text_category']      = 'Kategorijas';
$_['text_account']       = 'Mans konts';
$_['text_register']      = 'Reģistrēties';
$_['text_login']         = 'Pieslēgties';
$_['text_order']         = 'Pasūtījumu vēsture';
$_['text_transaction']   = 'Darījumi';
$_['text_download']      = 'Lejupielādes';
$_['text_logout']        = 'Iziet';
$_['text_checkout']      = 'Noformēt pasūtījumu';
$_['text_search']        = 'Meklēt';
$_['text_all']           = 'Rādīt visu';