<?php
// Heading
$_['heading_title'] = 'Pieprasītā lapa nav atrasta!';

// Text
$_['text_error']    = 'Pieprasītā lapa nav atrasta.';