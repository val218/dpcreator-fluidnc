<?php
// Text
$_['text_search']              = 'Meklēt';
$_['text_brand']               = 'Zīmols';
$_['text_manufacturer']        = 'Zīmols:';
$_['text_model']               = 'Preces kods:';
$_['text_reward']              = 'Bonusa punkti:';
$_['text_points']              = 'Cena bonusa punktos:';
$_['text_stock']               = 'Pieejamība:';
$_['text_instock']             = 'Ir noliktavā';
$_['text_tax']                 = 'Bez nodokļiem:';
$_['text_discount']            = ' vai vairāk ';
$_['text_option']              = 'Pieejamās izvēles';
$_['text_minimum']             = 'Šīs preces minimālais pasūtījuma daudzums ir %s';
$_['text_reviews']             = 'Atsauksmes: %s';
$_['text_write']               = 'Rakstīt atsauksmi';
$_['text_login']               = 'Lūdzu, <a href="%s">pieslēdzieties</a> vai <a href="%s">reģistrējieties</a>, lai rakstītu atsauksmi';
$_['text_no_reviews']          = 'Šai precei vēl nav atsauksmju.';
$_['text_note']                = '<span class="text-danger">Piezīme:</span> HTML netiek pārveidots!';
$_['text_success']             = 'Paldies par atsauksmi! Tā ir nosūtīta administratoram apstiprināšanai.';
$_['text_related']             = 'Saistītās preces';
$_['text_tags']                = 'Birkas:';
$_['text_error']               = 'Prece nav atrasta!';
$_['text_payment_recurring']   = 'Maksājumu plāns';
$_['text_trial_description']   = '%s ik pēc %d %s, maksājumu skaits: %d, pēc tam';
$_['text_payment_description'] = '%s ik pēc %d %s, maksājumu skaits: %d';
$_['text_payment_cancel']      = '%s ik pēc %d %s līdz atcelšanai';
$_['text_day']                 = 'dien.';
$_['text_week']                = 'ned.';
$_['text_semi_month']          = 'pusmēn.';
$_['text_month']               = 'mēn.';
$_['text_year']                = 'g.';

// Entry
$_['entry_qty']                = 'Daudz.';
$_['entry_name']               = 'Jūsu vārds';
$_['entry_review']             = 'Jūsu atsauksme';
$_['entry_rating']             = 'Vērtējums';
$_['entry_good']               = 'Labi';
$_['entry_bad']                = 'Slikti';

// Tabs
$_['tab_description']          = 'Apraksts';
$_['tab_attribute']            = 'Specifikācija';
$_['tab_review']               = 'Atsauksmes (%s)';

// Error
$_['error_name']               = 'Uzmanību: vārdam jābūt no 3 līdz 25 rakstzīmēm!';
$_['error_text']               = 'Uzmanību: atsauksmes tekstam jābūt no 25 līdz 1000 rakstzīmēm!';
$_['error_rating']             = 'Uzmanību: lūdzu, izvēlieties vērtējumu!';
$_['error_product']            = 'Uzmanību: lai pievienotu atsauksmi, jānorāda prece!';