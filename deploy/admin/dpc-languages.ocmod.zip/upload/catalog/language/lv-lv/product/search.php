<?php
// Heading
$_['heading_title']     = 'Meklēt';
$_['heading_tag']       = 'Birka - ';

// Text
$_['text_search']       = 'Meklēšanas kritērijiem atbilstošās preces';
$_['text_keyword']      = 'Atslēgvārdi';
$_['text_category']     = 'Visas kategorijas';
$_['text_sub_category'] = 'Meklēt apakškategorijās';
$_['text_empty']        = 'Neviena prece neatbilst meklēšanas kritērijiem.';
$_['text_quantity']     = 'Daudz.:';
$_['text_manufacturer'] = 'Zīmols:';
$_['text_model']        = 'Preces kods:';
$_['text_points']       = 'Bonusa punkti:';
$_['text_price']        = 'Cena:';
$_['text_tax']          = 'Bez nodokļiem:';
$_['text_reviews']      = 'Atsauksmju skaits: %s.';
$_['text_compare']      = 'Salīdzināšana (%s)';
$_['text_sort']         = 'Kārtot pēc:';
$_['text_default']      = 'Noklusējums';
$_['text_name_asc']     = 'Nosaukums (A - Z)';
$_['text_name_desc']    = 'Nosaukums (Z - A)';
$_['text_price_asc']    = 'Cena (zemākā &gt; augstākā)';
$_['text_price_desc']   = 'Cena (augstākā &gt; zemākā)';
$_['text_rating_asc']   = 'Vērtējums (zemākais)';
$_['text_rating_desc']  = 'Vērtējums (augstākais)';
$_['text_model_asc']    = 'Modelis (A - Z)';
$_['text_model_desc']   = 'Modelis (Z - A)';
$_['text_limit']        = 'Rādīt:';

// Entry
$_['entry_search']      = 'Meklēšanas kritēriji';
$_['entry_description'] = 'Meklēt arī preču aprakstos';