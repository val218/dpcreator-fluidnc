<?php
// Heading
$_['heading_title']     = 'Preču salīdzināšana';

// Text
$_['text_product']      = 'Preces informācija';
$_['text_name']         = 'Prece';
$_['text_image']        = 'Attēls';
$_['text_price']        = 'Cena';
$_['text_model']        = 'Modelis';
$_['text_manufacturer'] = 'Zīmols';
$_['text_availability'] = 'Pieejamība';
$_['text_instock']      = 'Ir noliktavā';
$_['text_rating']       = 'Vērtējums';
$_['text_reviews']      = 'Atsauksmju skaits: %s.';
$_['text_summary']      = 'Kopsavilkums';
$_['text_weight']       = 'Svars';
$_['text_dimension']    = 'Izmēri (G x P x A)';
$_['text_compare']      = 'Salīdzināšana (%s)';
$_['text_success']      = 'Prece <a href="%s">%s</a> pievienota <a href="%s">salīdzināšanai</a>!';
$_['text_remove']       = 'Salīdzināmo preču saraksts atjaunināts!';
$_['text_empty']        = 'Jūs neesat izvēlējušies nevienu preci salīdzināšanai.';