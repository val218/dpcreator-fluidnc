<?php
// Heading
$_['heading_title']     = 'Īpašie piedāvājumi';

// Text
$_['text_empty']        = 'Pašlaik nav īpašo piedāvājumu.';
$_['text_quantity']     = 'Daudz.:';
$_['text_manufacturer'] = 'Zīmols:';
$_['text_model']        = 'Preces kods:';
$_['text_points']       = 'Bonusa punkti:';
$_['text_price']        = 'Cena:';
$_['text_tax']          = 'Bez nodokļiem:';
$_['text_compare']      = 'Salīdzināšana (%s)';
$_['text_sort']         = 'Kārtot pēc:';
$_['text_default']      = 'Noklusējums';
$_['text_name_asc']     = 'Nosaukums (A - Z)';
$_['text_name_desc']    = 'Nosaukums (Z - A)';
$_['text_price_asc']    = 'Cena (zemākā &gt; augstākā)';
$_['text_price_desc']   = 'Cena (augstākā &gt; zemākā)';
$_['text_rating_asc']   = 'Vērtējums (zemākais)';
$_['text_rating_desc']  = 'Vērtējums (augstākais)';
$_['text_model_asc']    = 'Modelis (A - Z)';
$_['text_model_desc']   = 'Modelis (Z - A)';
$_['text_limit']        = 'Rādīt:';