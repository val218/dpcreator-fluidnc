<?php
// Heading
$_['heading_title'] = 'Maksājums neizdevās!';

// Text
$_['text_basket']   = 'Iepirkumu grozs';
$_['text_checkout'] = 'Pasūtījuma noformēšana';
$_['text_failure']  = 'Maksājums neizdevās';
$_['text_message']  = '<p>Apstrādājot jūsu maksājumu, radās problēma, un pasūtījums netika pabeigts.</p>

<p>Iespējamie iemesli:</p>
<ul>
  <li>Nepietiekami līdzekļi</li>
  <li>Neizdevās verifikācija</li>
</ul>

<p>Lūdzu, mēģiniet pasūtīt vēlreiz, izmantojot citu maksājuma veidu.</p>

<p>Ja problēma atkārtojas, lūdzu, <a href="%s">sazinieties ar mums</a> un norādiet tā pasūtījuma datus, kuru mēģināt veikt.</p>
';