<?php
// Heading
$_['heading_title']        = 'Jūsu pasūtījums ir pieņemts!';

// Text
$_['text_basket']          = 'Iepirkumu grozs';
$_['text_checkout']        = 'Pasūtījuma noformēšana';
$_['text_success']         = 'Gatavs';
$_['text_customer']        = '<p>Jūsu pasūtījums ir veiksmīgi apstrādāts!</p><p>Pasūtījumu vēsturi varat skatīt sadaļā <a href="%s">Mans konts</a>, noklikšķinot uz <a href="%s">Vēsture</a>.</p><p>Ja pirkumam ir pievienotas lejupielādes, tās varat atrast konta sadaļā <a href="%s">Lejupielādes</a>.</p><p>Ar jautājumiem lūdzu vērsties pie <a href="%s">veikala īpašnieka</a>.</p><p>Paldies, ka iepirkāties pie mums!</p>';
$_['text_guest']           = '<p>Jūsu pasūtījums ir veiksmīgi apstrādāts!</p><p>Ar jautājumiem lūdzu vērsties pie <a href="%s">veikala īpašnieka</a>.</p><p>Paldies, ka iepirkāties pie mums!</p>';