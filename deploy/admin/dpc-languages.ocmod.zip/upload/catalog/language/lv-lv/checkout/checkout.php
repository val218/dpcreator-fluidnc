<?php
// Heading
$_['heading_title']                  = 'Pasūtījuma noformēšana';

// Text
$_['text_cart']                      = 'Iepirkumu grozs';
$_['text_checkout_option']           = '%s. solis: noformēšanas veids';
$_['text_checkout_account']          = '%s. solis: konts un norēķinu dati';
$_['text_checkout_payment_address']  = '%s. solis: norēķinu dati';
$_['text_checkout_shipping_address'] = '%s. solis: piegādes dati';
$_['text_checkout_shipping_method']  = '%s. solis: piegādes veids';
$_['text_checkout_payment_method']   = '%s. solis: maksājuma veids';
$_['text_checkout_confirm']          = '%s. solis: pasūtījuma apstiprināšana';
$_['text_modify']                    = 'Mainīt &raquo;';
$_['text_new_customer']              = 'Jauns klients';
$_['text_returning_customer']        = 'Esošs klients';
$_['text_checkout']                  = 'Noformēšanas veids:';
$_['text_i_am_returning_customer']   = 'Man jau ir konts';
$_['text_register']                  = 'Reģistrēties';
$_['text_guest']                     = 'Pirkt bez reģistrācijas';
$_['text_register_account']          = 'Izveidojot kontu, jūs varēsiet iepirkties ātrāk, sekot pasūtījuma statusam un redzēt savus iepriekšējos pasūtījumus.';
$_['text_forgotten']                 = 'Aizmirsāt paroli?';
$_['text_your_details']              = 'Jūsu personas dati';
$_['text_your_address']              = 'Jūsu adrese';
$_['text_your_password']             = 'Jūsu parole';
$_['text_agree']                     = 'Esmu izlasījis(-usi) un piekrītu: <a href="%s" class="agree"><b>%s</b></a>';
$_['text_address_new']               = 'Izmantot jaunu adresi';
$_['text_address_existing']          = 'Izmantot esošu adresi';
$_['text_shipping_method']           = 'Lūdzu, izvēlieties šim pasūtījumam vēlamo piegādes veidu.';
$_['text_payment_method']            = 'Lūdzu, izvēlieties šim pasūtījumam vēlamo maksājuma veidu.';
$_['text_comments']                  = 'Pievienot komentāru pasūtījumam';
$_['text_recurring_item']            = 'Regulārā maksājuma prece';
$_['text_payment_recurring']         = 'Maksājumu plāns';
$_['text_trial_description']         = '%s ik pēc %d %s, maksājumu skaits: %d, pēc tam';
$_['text_payment_description']       = '%s ik pēc %d %s, maksājumu skaits: %d';
$_['text_payment_cancel']            = '%s ik pēc %d %s līdz atcelšanai';
$_['text_day']                       = 'dien.';
$_['text_week']                      = 'ned.';
$_['text_semi_month']                = 'pusmēn.';
$_['text_month']                     = 'mēn.';
$_['text_year']                      = 'g.';

// Column
$_['column_name']                    = 'Preces nosaukums';
$_['column_model']                   = 'Modelis';
$_['column_quantity']                = 'Daudzums';
$_['column_price']                   = 'Vienības cena';
$_['column_total']                   = 'Kopā';

// Entry
$_['entry_email_address']            = 'E-pasta adrese';
$_['entry_email']                    = 'E-pasts';
$_['entry_password']                 = 'Parole';
$_['entry_confirm']                  = 'Parole vēlreiz';
$_['entry_firstname']                = 'Vārds';
$_['entry_lastname']                 = 'Uzvārds';
$_['entry_telephone']                = 'Tālrunis';
$_['entry_address']                  = 'Izvēlieties adresi';
$_['entry_company']                  = 'Uzņēmums';
$_['entry_customer_group']           = 'Klientu grupa';
$_['entry_address_1']                = 'Adrese';
$_['entry_address_2']                = 'Adrese (papildu)';
$_['entry_postcode']                 = 'Pasta indekss';
$_['entry_city']                     = 'Pilsēta';
$_['entry_country']                  = 'Valsts';
$_['entry_zone']                     = 'Novads / reģions';
$_['entry_newsletter']               = 'Vēlos saņemt %s jaunumu vēstuli.';
$_['entry_shipping']                 = 'Mana piegādes un norēķinu adrese ir vienāda.';

// Error
$_['error_warning']                  = 'Apstrādājot jūsu pasūtījumu, radās problēma! Ja problēma atkārtojas, lūdzu, izvēlieties citu maksājuma veidu vai sazinieties ar veikala īpašnieku, <a href="%s">noklikšķinot šeit</a>.';
$_['error_login']                    = 'Uzmanību: nepareiza e-pasta adrese un/vai parole.';
$_['error_attempts']                 = 'Uzmanību: pārsniegts atļauto pieslēgšanās mēģinājumu skaits. Lūdzu, mēģiniet vēlreiz pēc 1 stundas.';
$_['error_approved']                 = 'Uzmanību: pirms pieslēgšanās jūsu kontam jābūt apstiprinātam.';
$_['error_exists']                   = 'Uzmanību: šī e-pasta adrese jau ir reģistrēta!';
$_['error_firstname']                = 'Vārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_lastname']                 = 'Uzvārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_email']                    = 'E-pasta adrese nav derīga!';
$_['error_telephone']                = 'Tālruņa numuram jābūt no 3 līdz 32 rakstzīmēm!';
$_['error_password']                 = 'Parolei jābūt no 4 līdz 20 rakstzīmēm!';
$_['error_confirm']                  = 'Paroles nesakrīt!';
$_['error_address_1']                = 'Adresei jābūt no 3 līdz 128 rakstzīmēm!';
$_['error_city']                     = 'Pilsētai jābūt no 2 līdz 128 rakstzīmēm!';
$_['error_postcode']                 = 'Pasta indeksam jābūt no 2 līdz 10 rakstzīmēm!';
$_['error_country']                  = 'Lūdzu, izvēlieties valsti!';
$_['error_zone']                     = 'Lūdzu, izvēlieties novadu / reģionu!';
$_['error_agree']                    = 'Uzmanību: jums jāpiekrīt: %s!';
$_['error_address']                  = 'Uzmanību: lūdzu, izvēlieties adresi!';
$_['error_shipping']                 = 'Uzmanību: lūdzu, izvēlieties piegādes veidu!';
$_['error_no_shipping']              = 'Uzmanību: nav pieejams neviens piegādes veids. Lūdzu, <a href="%s">sazinieties ar mums</a>, un mēs palīdzēsim!';
$_['error_payment']                  = 'Uzmanību: lūdzu, izvēlieties maksājuma veidu!';
$_['error_no_payment']               = 'Uzmanību: nav pieejams neviens maksājuma veids. Lūdzu, <a href="%s">sazinieties ar mums</a>, un mēs palīdzēsim!';
$_['error_custom_field']             = 'Lūdzu, norādiet: %s!';