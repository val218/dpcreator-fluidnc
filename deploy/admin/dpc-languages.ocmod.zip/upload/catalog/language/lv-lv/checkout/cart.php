<?php
// Heading
$_['heading_title']            = 'Iepirkumu grozs';

// Text
$_['text_success']             = 'Prece <a href="%s">%s</a> ielikta jūsu <a href="%s">iepirkumu grozā</a>!';
$_['text_remove']              = 'Iepirkumu grozs atjaunināts!';
$_['text_login']               = 'Uzmanību: lai redzētu cenas, jums <a href="%s">jāpieslēdzas</a> vai <a href="%s">jāizveido konts</a>!';
$_['text_items']               = 'Preces: %s - %s';
$_['text_points']              = 'Bonusa punkti: %s';
$_['text_next']                = 'Ko vēlaties darīt tālāk?';
$_['text_next_choice']         = 'Izvēlieties, ja vēlaties izmantot atlaides kodu vai bonusa punktus, vai aprēķināt piegādes izmaksas.';
$_['text_empty']               = 'Jūsu iepirkumu grozs ir tukšs!';
$_['text_day']                 = 'dien.';
$_['text_week']                = 'ned.';
$_['text_semi_month']          = 'pusmēn.';
$_['text_month']               = 'mēn.';
$_['text_year']                = 'g.';
$_['text_trial']               = '%s ik pēc %s %s, maksājumu skaits: %s, pēc tam ';
$_['text_recurring']           = '%s ik pēc %s %s';
$_['text_recurring_item']      = 'Regulārā maksājuma prece';
$_['text_payment_recurring']   = 'Maksājumu plāns';
$_['text_trial_description']   = '%s ik pēc %d %s, maksājumu skaits: %d, pēc tam';
$_['text_payment_description'] = '%s ik pēc %d %s, maksājumu skaits: %d';
$_['text_payment_cancel']      = '%s ik pēc %d %s līdz atcelšanai';

// Column
$_['column_image']             = 'Attēls';
$_['column_name']              = 'Preces nosaukums';
$_['column_model']             = 'Modelis';
$_['column_quantity']          = 'Daudzums';
$_['column_price']             = 'Vienības cena';
$_['column_total']             = 'Kopā';

// Error
$_['error_stock']              = 'Ar *** atzīmētās preces nav pieejamas vēlamajā daudzumā vai nav noliktavā!';
$_['error_minimum']            = 'Preces %s minimālais pasūtījuma daudzums ir %s!';
$_['error_required']           = 'Lūdzu, norādiet: %s!';
$_['error_product']            = 'Uzmanību: jūsu grozā nav preču!';
$_['error_recurring_required'] = 'Lūdzu, izvēlieties maksājumu plānu!';
