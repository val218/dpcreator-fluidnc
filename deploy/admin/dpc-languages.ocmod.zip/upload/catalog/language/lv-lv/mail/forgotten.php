<?php
// Text
$_['text_subject']  = '%s - paroles atjaunošanas pieprasījums';
$_['text_greeting'] = 'Pieprasīta jauna parole %s klienta kontam.';
$_['text_change']   = 'Lai atjaunotu paroli, noklikšķiniet uz zemāk esošās saites:';
$_['text_ip']       = ' Pieprasījums veikts no IP adreses:';
