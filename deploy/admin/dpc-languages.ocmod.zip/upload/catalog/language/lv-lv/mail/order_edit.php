<?php
// Text
$_['text_subject']      = '%s - pasūtījuma %s statusa maiņa';
$_['text_order_id']     = 'Pasūtījuma Nr.:';
$_['text_date_added']   = 'Pievienots:';
$_['text_order_status'] = 'Jūsu pasūtījuma statuss ir mainīts uz:';
$_['text_comment']      = 'Jūsu pasūtījuma komentāri:';
$_['text_link']         = 'Lai apskatītu savu pasūtījumu, noklikšķiniet uz zemāk esošās saites:';
$_['text_footer']       = 'Ja jums ir jautājumi, lūdzu, atbildiet uz šo e-pastu.';