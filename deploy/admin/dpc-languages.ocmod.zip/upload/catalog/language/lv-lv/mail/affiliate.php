<?php
// Text
$_['text_subject']        = '%s - Partneru programma';
$_['text_welcome']        = 'Paldies, ka pievienojāties %s partneru programmai!';
$_['text_login']          = 'Jūsu konts ir izveidots, un jūs varat pieslēgties ar savu e-pasta adresi un paroli mūsu vietnē vai šajā adresē:';
$_['text_approval']       = 'Pirms pieslēgšanās jūsu kontam jābūt apstiprinātam. Pēc apstiprināšanas varēsiet pieslēgties ar savu e-pasta adresi un paroli mūsu vietnē vai šajā adresē:';
$_['text_service']        = 'Pēc pieslēgšanās varēsiet veidot izsekošanas kodus, sekot komisijas maksājumiem un labot sava konta informāciju.';
$_['text_thanks']         = 'Paldies,';
$_['text_new_affiliate']  = 'Jauns partneris';
$_['text_signup']         = 'Reģistrējies jauns partneris:';
$_['text_website']        = 'Tīmekļa vietne:';
$_['text_customer_group'] = 'Klientu grupa:';
$_['text_firstname']      = 'Vārds:';
$_['text_lastname']       = 'Uzvārds:';
$_['text_company']        = 'Uzņēmums:';
$_['text_email']          = 'E-pasts:';
$_['text_telephone']      = 'Tālrunis:';