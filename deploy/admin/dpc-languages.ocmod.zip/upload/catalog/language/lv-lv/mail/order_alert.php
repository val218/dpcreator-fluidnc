<?php
// Text
$_['text_subject']      = '%s - pasūtījums %s';
$_['text_received']     = 'Saņemts jauns pasūtījums.';
$_['text_order_id']     = 'Pasūtījuma Nr.:';
$_['text_date_added']   = 'Pievienots:';
$_['text_order_status'] = 'Pasūtījuma statuss:';
$_['text_product']      = 'Preces';
$_['text_total']        = 'Summa';
$_['text_comment']      = 'Pasūtījuma komentāri:';
