<?php
// Text
$_['text_subject']          = '%s - pasūtījums %s';
$_['text_greeting']         = 'Paldies par interesi par %s precēm. Jūsu pasūtījums ir saņemts, un to apstrādāsim, tiklīdz būs apstiprināts maksājums.';
$_['text_link']             = 'Lai apskatītu savu pasūtījumu, noklikšķiniet uz zemāk esošās saites:';
$_['text_order_detail']     = 'Pasūtījuma dati';
$_['text_instruction']      = 'Norādījumi';
$_['text_order_id']         = 'Pasūtījuma Nr.:';
$_['text_date_added']       = 'Pievienots:';
$_['text_order_status']     = 'Pasūtījuma statuss:';
$_['text_payment_method']   = 'Maksājuma veids:';
$_['text_shipping_method']  = 'Piegādes veids:';
$_['text_email']            = 'E-pasts:';
$_['text_telephone']        = 'Tālrunis:';
$_['text_ip']               = 'IP adrese:';
$_['text_payment_address']  = 'Maksātāja adrese';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_products']         = 'Preces';
$_['text_product']          = 'Prece';
$_['text_model']            = 'Modelis';
$_['text_quantity']         = 'Daudzums';
$_['text_price']            = 'Cena';
$_['text_order_total']      = 'Pasūtījuma summa';
$_['text_total']            = 'Kopā';
$_['text_download']         = 'Kad maksājums būs apstiprināts, lejupielādējamās preces varēsiet saņemt, noklikšķinot uz zemāk esošās saites:';
$_['text_comment']          = 'Jūsu pasūtījuma komentāri:';
$_['text_footer']           = 'Ja jums ir jautājumi, lūdzu, atbildiet uz šo e-pastu.';