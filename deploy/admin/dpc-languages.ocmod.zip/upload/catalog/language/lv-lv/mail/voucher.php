<?php
// Text
$_['text_subject']  = '%s jums nosūtīja dāvanu karti';
$_['text_greeting'] = 'Apsveicam! Jūs esat saņēmuši dāvanu karti %s vērtībā';
$_['text_from']     = 'Šo dāvanu karti jums nosūtīja %s';
$_['text_message']  = 'Ar ziņu:';
$_['text_redeem']   = 'Lai izmantotu šo dāvanu karti, pierakstiet tās kodu <b>%s</b>, tad noklikšķiniet uz zemāk esošās saites un iegādājieties preci, kurai vēlaties to izmantot. Dāvanu kartes kodu varat ievadīt iepirkumu groza lapā, pirms noformējat pasūtījumu.';
$_['text_footer']   = 'Ja jums ir jautājumi, lūdzu, atbildiet uz šo e-pastu.';