<?php
// Text
$_['text_subject']  = '%s - preces atsauksme';
$_['text_waiting']  = 'Jauna preces atsauksme gaida apstiprinājumu.';
$_['text_product']  = 'Prece: %s';
$_['text_reviewer'] = 'Autors: %s';
$_['text_rating']   = 'Vērtējums: %s';
$_['text_review']   = 'Atsauksmes teksts:';