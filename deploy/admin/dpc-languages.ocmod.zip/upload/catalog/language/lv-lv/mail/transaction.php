<?php
// Text
$_['text_subject']  = '%s - partnera komisija';
$_['text_received'] = 'Apsveicam! Jūs esat saņēmuši komisijas maksājumu no %s partneru programmas';
$_['text_amount']   = 'Jūs saņēmāt:';
$_['text_total']    = 'Jūsu komisijas kopsumma tagad ir:';