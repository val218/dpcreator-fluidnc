<?php
// Text
$_['text_error'] = 'Informācijas lapa nav atrasta!';