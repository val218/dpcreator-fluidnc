<?php
// Heading
$_['heading_title']    = 'Vietnes karte';

// Text
$_['text_special']     = 'Īpašie piedāvājumi';
$_['text_account']     = 'Mans konts';
$_['text_edit']        = 'Konta informācija';
$_['text_password']    = 'Parole';
$_['text_address']     = 'Adrešu grāmata';
$_['text_history']     = 'Pasūtījumu vēsture';
$_['text_download']    = 'Lejupielādes';
$_['text_cart']        = 'Iepirkumu grozs';
$_['text_checkout']    = 'Pasūtījuma noformēšana';
$_['text_search']      = 'Meklēt';
$_['text_information'] = 'Informācija';
$_['text_contact']     = 'Kontakti';