<?php
// Heading
$_['heading_title']  = 'Kontakti';

// Text
$_['text_location']  = 'Mūsu atrašanās vieta';
$_['text_store']     = 'Mūsu veikali';
$_['text_contact']   = 'Saziņas forma';
$_['text_address']   = 'Adrese';
$_['text_telephone'] = 'Tālrunis';
$_['text_fax']       = 'Fakss';
$_['text_open']      = 'Darba laiks';
$_['text_comment']   = 'Komentāri';
$_['text_message']   = '<p>Jūsu ziņa ir veiksmīgi nosūtīta veikala īpašniekam!</p>'; 

// Entry
$_['entry_name']     = 'Jūsu vārds';
$_['entry_email']    = 'E-pasta adrese';
$_['entry_enquiry']  = 'Jautājums';

// Email
$_['email_subject']  = 'Jautājums %s';

// Errors
$_['error_name']     = 'Vārdam jābūt no 3 līdz 32 rakstzīmēm!';
$_['error_email']    = 'E-pasta adrese nav derīga!';
$_['error_enquiry']  = 'Jautājumam jābūt no 10 līdz 3000 rakstzīmēm!';