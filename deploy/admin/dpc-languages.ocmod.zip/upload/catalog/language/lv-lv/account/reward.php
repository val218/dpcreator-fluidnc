<?php
// Heading
$_['heading_title']      = 'Jūsu bonusa punkti';

// Column
$_['column_date_added']  = 'Pievienots';
$_['column_description'] = 'Apraksts';
$_['column_points']      = 'Punkti';

// Text
$_['text_account']       = 'Konts';
$_['text_reward']        = 'Bonusa punkti';
$_['text_total']         = 'Jūsu bonusa punktu kopskaits:';
$_['text_empty']         = 'Jums nav bonusa punktu!';