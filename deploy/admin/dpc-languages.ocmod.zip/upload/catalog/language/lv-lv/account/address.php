<?php
// Heading
$_['heading_title']      = 'Adrešu grāmata';

// Text
$_['text_account']       = 'Konts';
$_['text_address_book']  = 'Adrešu grāmatas ieraksti';
$_['text_address_add']   = 'Pievienot adresi';
$_['text_address_edit']  = 'Labot adresi';
$_['text_add']           = 'Adrese veiksmīgi pievienota';
$_['text_edit']          = 'Adrese veiksmīgi atjaunināta';
$_['text_delete']        = 'Adrese veiksmīgi dzēsta';
$_['text_empty']         = 'Jūsu kontā nav saglabātu adrešu.';
$_['text_confirm']       = 'Vai tiešām?';

// Entry
$_['entry_firstname']    = 'Vārds';
$_['entry_lastname']     = 'Uzvārds';
$_['entry_company']      = 'Uzņēmums';
$_['entry_address_1']    = 'Adrese';
$_['entry_address_2']    = 'Adrese (papildu)';
$_['entry_postcode']     = 'Pasta indekss';
$_['entry_city']         = 'Pilsēta';
$_['entry_country']      = 'Valsts';
$_['entry_zone']         = 'Novads / reģions';
$_['entry_default']      = 'Noklusējuma adrese';

// Error
$_['error_delete']       = 'Uzmanību: jums jābūt saglabātai vismaz vienai adresei!';
$_['error_default']      = 'Uzmanību: noklusējuma adresi nevar dzēst!';
$_['error_firstname']    = 'Vārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_lastname']     = 'Uzvārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_address_1']    = 'Adresei jābūt no 3 līdz 128 rakstzīmēm!';
$_['error_postcode']     = 'Pasta indeksam jābūt no 2 līdz 10 rakstzīmēm!';
$_['error_city']         = 'Pilsētai jābūt no 2 līdz 128 rakstzīmēm!';
$_['error_country']      = 'Lūdzu, izvēlieties valsti!';
$_['error_zone']         = 'Lūdzu, izvēlieties novadu / reģionu!';
$_['error_custom_field'] = 'Lūdzu, norādiet: %s!';