<?php
// Heading
$_['heading_title']                = 'Pieslēgšanās';

// Text
$_['text_account']                 = 'Konts';
$_['text_login']                   = 'Pieslēgties';
$_['text_new_customer']            = 'Jauns klients';
$_['text_register']                = 'Reģistrēties';
$_['text_register_account']        = 'Izveidojot kontu, jūs varēsiet iepirkties ātrāk, sekot pasūtījuma statusam un redzēt savus iepriekšējos pasūtījumus.';
$_['text_returning_customer']      = 'Esošs klients';
$_['text_i_am_returning_customer'] = 'Man jau ir konts';
$_['text_forgotten']               = 'Aizmirsāt paroli?';

// Entry
$_['entry_email']                  = 'E-pasta adrese';
$_['entry_password']               = 'Parole';

// Error
$_['error_login']                  = 'Uzmanību: nepareiza e-pasta adrese un/vai parole.';
$_['error_attempts']               = 'Uzmanību: pārsniegts atļauto pieslēgšanās mēģinājumu skaits. Lūdzu, mēģiniet vēlreiz pēc 1 stundas.';
$_['error_approved']               = 'Uzmanību: pirms pieslēgšanās jūsu kontam jābūt apstiprinātam.';