<?php
// Heading
$_['heading_title']     = 'Lejupielādes';

// Text
$_['text_account']      = 'Konts';
$_['text_downloads']    = 'Lejupielādes';
$_['text_empty']        = 'Jums vēl nav pasūtījumu ar lejupielādējamām precēm!';

// Column
$_['column_order_id']   = 'Pasūtījuma Nr.';
$_['column_name']       = 'Nosaukums';
$_['column_size']       = 'Izmērs';
$_['column_date_added'] = 'Pievienots';