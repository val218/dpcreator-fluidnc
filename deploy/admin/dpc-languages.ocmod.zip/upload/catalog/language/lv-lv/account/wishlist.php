<?php
// Heading
$_['heading_title'] = 'Mans vēlmju saraksts';

// Text
$_['text_account']  = 'Konts';
$_['text_instock']  = 'Ir noliktavā';
$_['text_wishlist'] = 'Vēlmju saraksts (%s)';
$_['text_login']    = 'Lai saglabātu <a href="%s">%s</a> savā <a href="%s">vēlmju sarakstā</a>, jums <a href="%s">jāpieslēdzas</a> vai <a href="%s">jāizveido konts</a>!';
$_['text_success']  = 'Prece <a href="%s">%s</a> pievienota jūsu <a href="%s">vēlmju sarakstam</a>!';
$_['text_remove']   = 'Vēlmju saraksts atjaunināts!';
$_['text_empty']    = 'Jūsu vēlmju saraksts ir tukšs.';

// Column
$_['column_image']  = 'Attēls';
$_['column_name']   = 'Preces nosaukums';
$_['column_model']  = 'Modelis';
$_['column_stock']  = 'Pieejamība';
$_['column_price']  = 'Vienības cena';
$_['column_action'] = 'Darbība';