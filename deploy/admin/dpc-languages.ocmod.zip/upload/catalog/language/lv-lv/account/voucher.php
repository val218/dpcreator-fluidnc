<?php
// Heading
$_['heading_title']    = 'Iegādāties dāvanu karti';

// Text
$_['text_account']     = 'Konts';
$_['text_voucher']     = 'Dāvanu karte';
$_['text_description'] = 'Šī dāvanu karte tiks nosūtīta saņēmējam pa e-pastu pēc tam, kad jūsu pasūtījums būs apmaksāts.';
$_['text_agree']       = 'Es saprotu, ka dāvanu kartes netiek atmaksātas.';
$_['text_message']     = '<p>Paldies, ka iegādājāties dāvanu karti! Kad būsiet pabeiguši pasūtījumu, dāvanu kartes saņēmējam tiks nosūtīts e-pasts ar norādēm, kā to izmantot.</p>';
$_['text_for']         = '%s dāvanu karte – %s';

// Entry
$_['entry_to_name']    = 'Saņēmēja vārds';
$_['entry_to_email']   = 'Saņēmēja e-pasts';
$_['entry_from_name']  = 'Jūsu vārds';
$_['entry_from_email'] = 'Jūsu e-pasts';
$_['entry_theme']      = 'Dāvanu kartes noformējums';
$_['entry_message']    = 'Ziņa';
$_['entry_amount']     = 'Summa';

// Help
$_['help_message']     = 'Nav obligāti';
$_['help_amount']      = 'Vērtībai jābūt no %s līdz %s';

// Error
$_['error_to_name']    = 'Saņēmēja vārdam jābūt no 1 līdz 64 rakstzīmēm!';
$_['error_from_name']  = 'Jūsu vārdam jābūt no 1 līdz 64 rakstzīmēm!';
$_['error_email']      = 'E-pasta adrese nav derīga!';
$_['error_theme']      = 'Lūdzu, izvēlieties noformējumu!';
$_['error_amount']     = 'Summai jābūt no %s līdz %s!';
$_['error_agree']      = 'Uzmanību: jums jāapstiprina, ka saprotat, ka dāvanu kartes netiek atmaksātas!';