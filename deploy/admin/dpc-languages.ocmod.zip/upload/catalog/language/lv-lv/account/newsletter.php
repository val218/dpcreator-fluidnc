<?php
// Heading
$_['heading_title']    = 'Jaunumu vēstules abonements';

// Text
$_['text_account']     = 'Konts';
$_['text_newsletter']  = 'Jaunumu vēstule';
$_['text_success']     = 'Jūsu jaunumu vēstules abonements ir veiksmīgi atjaunināts!';

// Entry
$_['entry_newsletter'] = 'Abonēt';