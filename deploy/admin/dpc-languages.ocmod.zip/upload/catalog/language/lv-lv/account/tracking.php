<?php
// Heading
$_['heading_title']    = 'Partnera izsekošana';

// Text
$_['text_account']     = 'Konts';
$_['text_description'] = 'Lai jūs saņemtu atlīdzību par pie mums nosūtītajiem klientiem, mums tie jāizseko, pievienojot izsekošanas kodu saitēm, kas ved uz mūsu vietni. Ar zemāk esošajiem rīkiem varat izveidot saites uz vietni %s.';

// Entry
$_['entry_code']       = 'Jūsu izsekošanas kods';
$_['entry_generator']  = 'Izsekošanas saišu ģenerators';
$_['entry_link']       = 'Izsekošanas saite';

// Help
$_['help_generator']  = 'Ierakstiet tās preces nosaukumu, uz kuru vēlaties izveidot saiti';