<?php
// Heading
$_['heading_title']      = 'Preču atgriešana';

// Text
$_['text_account']       = 'Konts';
$_['text_return']        = 'Atgriešanas informācija';
$_['text_return_detail'] = 'Atgriešanas dati';
$_['text_description']   = 'Lūdzu, aizpildiet zemāk esošo formu, lai saņemtu atgriešanas (RMA) numuru.';
$_['text_order']         = 'Pasūtījuma informācija';
$_['text_product']       = 'Preces informācija';
$_['text_reason']        = 'Atgriešanas iemesls';
$_['text_message']       = '<p>Paldies, jūsu atgriešanas pieprasījums ir saņemts. Tas ir nodots apstrādei atbildīgajai nodaļai.</p><p> Par pieprasījuma statusu jūs informēsim pa e-pastu.</p>';
$_['text_return_id']     = 'Atgriešanas Nr.:';
$_['text_order_id']      = 'Pasūtījuma Nr.:';
$_['text_date_ordered']  = 'Pasūtījuma datums:';
$_['text_status']        = 'Statuss:';
$_['text_date_added']    = 'Pievienots:';
$_['text_comment']       = 'Atgriešanas komentāri';
$_['text_history']       = 'Atgriešanas vēsture';
$_['text_empty']         = 'Jums vēl nav neviena atgriešanas pieprasījuma!';
$_['text_agree']         = 'Esmu izlasījis(-usi) un piekrītu: <a href="%s" class="agree"><b>%s</b></a>';

// Column
$_['column_return_id']   = 'Atgriešanas Nr.';
$_['column_order_id']    = 'Pasūtījuma Nr.';
$_['column_status']      = 'Statuss';
$_['column_date_added']  = 'Pievienots';
$_['column_customer']    = 'Klients';
$_['column_product']     = 'Preces nosaukums';
$_['column_model']       = 'Modelis';
$_['column_quantity']    = 'Daudzums';
$_['column_price']       = 'Cena';
$_['column_opened']      = 'Atvērta';
$_['column_comment']     = 'Komentārs';
$_['column_reason']      = 'Iemesls';
$_['column_action']      = 'Darbība';

// Entry
$_['entry_order_id']     = 'Pasūtījuma Nr.';
$_['entry_date_ordered'] = 'Pasūtījuma datums';
$_['entry_firstname']    = 'Vārds';
$_['entry_lastname']     = 'Uzvārds';
$_['entry_email']        = 'E-pasts';
$_['entry_telephone']    = 'Tālrunis';
$_['entry_product']      = 'Preces nosaukums';
$_['entry_model']        = 'Preces kods';
$_['entry_quantity']     = 'Daudzums';
$_['entry_reason']       = 'Atgriešanas iemesls';
$_['entry_opened']       = 'Prece ir atvērta';
$_['entry_fault_detail'] = 'Defekta apraksts vai citas piezīmes';

// Error
$_['text_error']         = 'Pieprasītie atgriešanas ieraksti nav atrasti!';
$_['error_order_id']     = 'Lūdzu, norādiet pasūtījuma numuru!';
$_['error_firstname']    = 'Vārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_lastname']     = 'Uzvārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_email']        = 'E-pasta adrese nav derīga!';
$_['error_telephone']    = 'Tālruņa numuram jābūt no 3 līdz 32 rakstzīmēm!';
$_['error_product']      = 'Preces nosaukumam jābūt garākam par 3 un īsākam par 255 rakstzīmēm!';
$_['error_model']        = 'Preces modelim jābūt garākam par 3 un īsākam par 64 rakstzīmēm!';
$_['error_reason']       = 'Lūdzu, izvēlieties atgriešanas iemeslu!';
$_['error_agree']        = 'Uzmanību: jums jāpiekrīt: %s!';