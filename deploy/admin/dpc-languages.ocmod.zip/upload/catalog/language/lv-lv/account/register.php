<?php
// Heading
$_['heading_title']        = 'Reģistrēties';

// Text
$_['text_account']         = 'Konts';
$_['text_register']        = 'Reģistrācija';
$_['text_account_already'] = 'Ja jums jau ir konts, lūdzu, <a href="%s">pieslēdzieties šeit</a>.';
$_['text_your_details']    = 'Jūsu personas dati';
$_['text_newsletter']      = 'Jaunumu vēstule';
$_['text_your_password']   = 'Jūsu parole';
$_['text_agree']           = 'Esmu izlasījis(-usi) un piekrītu: <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_customer_group'] = 'Klientu grupa';
$_['entry_firstname']      = 'Vārds';
$_['entry_lastname']       = 'Uzvārds';
$_['entry_email']          = 'E-pasts';
$_['entry_telephone']      = 'Tālrunis';
$_['entry_newsletter']     = 'Abonēt';
$_['entry_password']       = 'Parole';
$_['entry_confirm']        = 'Parole vēlreiz';

// Error
$_['error_exists']         = 'Uzmanību: šī e-pasta adrese jau ir reģistrēta!';
$_['error_firstname']      = 'Vārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_lastname']       = 'Uzvārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_email']          = 'E-pasta adrese nav derīga!';
$_['error_telephone']      = 'Tālruņa numuram jābūt no 3 līdz 32 rakstzīmēm!';
$_['error_custom_field']   = 'Lūdzu, norādiet: %s!';
$_['error_password']       = 'Parolei jābūt no 4 līdz 20 rakstzīmēm!';
$_['error_confirm']        = 'Paroles nesakrīt!';
$_['error_agree']          = 'Uzmanību: jums jāpiekrīt: %s!';