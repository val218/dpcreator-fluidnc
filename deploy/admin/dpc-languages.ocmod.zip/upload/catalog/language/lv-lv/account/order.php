<?php
// Heading
$_['heading_title']         = 'Pasūtījumu vēsture';

// Text
$_['text_account']          = 'Konts';
$_['text_order']            = 'Pasūtījuma informācija';
$_['text_order_detail']     = 'Pasūtījuma dati';
$_['text_invoice_no']       = 'Rēķina Nr.:';
$_['text_order_id']         = 'Pasūtījuma Nr.:';
$_['text_date_added']       = 'Pievienots:';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_shipping_method']  = 'Piegādes veids:';
$_['text_payment_address']  = 'Maksātāja adrese';
$_['text_payment_method']   = 'Maksājuma veids:';
$_['text_comment']          = 'Pasūtījuma komentāri';
$_['text_history']          = 'Pasūtījuma vēsture';
$_['text_success']          = 'Prece <a href="%s">%s</a> ielikta jūsu <a href="%s">iepirkumu grozā</a>!';
$_['text_empty']            = 'Jums vēl nav neviena pasūtījuma!';
$_['text_error']            = 'Pieprasītais pasūtījums nav atrasts!';

// Column
$_['column_order_id']       = 'Pasūtījuma Nr.';
$_['column_customer']       = 'Klients';
$_['column_product']        = 'Preču skaits';
$_['column_name']           = 'Preces nosaukums';
$_['column_model']          = 'Modelis';
$_['column_quantity']       = 'Daudzums';
$_['column_price']          = 'Cena';
$_['column_total']          = 'Kopā';
$_['column_action']         = 'Darbība';
$_['column_date_added']     = 'Pievienots';
$_['column_status']         = 'Statuss';
$_['column_comment']        = 'Komentārs';

// Error
$_['error_reorder']         = 'Preci %s pašlaik nav iespējams pasūtīt vēlreiz.';