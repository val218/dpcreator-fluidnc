<?php
// Heading
$_['heading_title']             = 'Jūsu partnera informācija';

// Text
$_['text_account']              = 'Konts';
$_['text_affiliate']            = 'Partneris';
$_['text_my_affiliate']         = 'Mans partnera konts';
$_['text_payment']              = 'Maksājuma informācija';
$_['text_cheque']               = 'Čeks';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Bankas pārskaitījums';
$_['text_success']              = 'Jūsu konts ir veiksmīgi atjaunināts.';
$_['text_agree']                = 'Esmu izlasījis(-usi) un piekrītu: <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_company']             = 'Uzņēmums';
$_['entry_website']             = 'Tīmekļa vietne';
$_['entry_tax']                 = 'Nodokļu maksātāja numurs';
$_['entry_payment']             = 'Maksājuma veids';
$_['entry_cheque']              = 'Čeka saņēmēja vārds';
$_['entry_paypal']              = 'PayPal e-pasta konts';
$_['entry_bank_name']           = 'Bankas nosaukums';
$_['entry_bank_branch_number']  = 'ABA/BSB numurs (filiāles numurs)';
$_['entry_bank_swift_code']     = 'SWIFT kods';
$_['entry_bank_account_name']   = 'Konta īpašnieks';
$_['entry_bank_account_number'] = 'Konta numurs';

// Error
$_['error_agree']               = 'Uzmanību: jums jāpiekrīt: %s!';
$_['error_cheque']              = 'Lūdzu, norādiet čeka saņēmēja vārdu!';
$_['error_paypal']              = 'PayPal e-pasta adrese nav derīga!';
$_['error_bank_account_name']   = 'Lūdzu, norādiet konta īpašnieku!';
$_['error_bank_account_number'] = 'Lūdzu, norādiet konta numuru!';
$_['error_custom_field']        = 'Lūdzu, norādiet: %s!';