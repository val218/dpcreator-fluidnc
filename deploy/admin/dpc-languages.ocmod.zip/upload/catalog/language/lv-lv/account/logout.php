<?php
// Heading
$_['heading_title'] = 'Iziet no konta';

// Text
$_['text_message']  = '<p>Jūs esat izgājuši no sava konta. Tagad varat droši atstāt datoru.</p><p>Jūsu iepirkumu grozs ir saglabāts, un tajā esošās preces tiks atjaunotas, kad atkal pieslēgsieties savam kontam.</p>';
$_['text_account']  = 'Konts';
$_['text_logout']   = 'Iziet';