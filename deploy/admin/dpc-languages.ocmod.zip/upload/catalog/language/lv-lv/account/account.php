<?php
// Heading
$_['heading_title']       = 'Mans konts';

// Text
$_['text_account']        = 'Konts';
$_['text_my_account']     = 'Mans konts';
$_['text_my_orders']      = 'Mani pasūtījumi';
$_['text_my_affiliate']   = 'Mans partnera konts';
$_['text_my_newsletter']  = 'Jaunumu vēstule';
$_['text_edit']           = 'Labot konta informāciju';
$_['text_password']       = 'Mainīt paroli';
$_['text_address']        = 'Labot adrešu grāmatu';
$_['text_credit_card']    = 'Pārvaldīt saglabātās kredītkartes';
$_['text_wishlist']       = 'Labot vēlmju sarakstu';
$_['text_order']          = 'Skatīt pasūtījumu vēsturi';
$_['text_download']       = 'Lejupielādes';
$_['text_reward']         = 'Jūsu bonusa punkti';
$_['text_return']         = 'Skatīt atgriešanas pieprasījumus';
$_['text_transaction']    = 'Jūsu darījumi';
$_['text_newsletter']     = 'Pierakstīties / atteikties no jaunumu vēstules';
$_['text_recurring']      = 'Regulārie maksājumi';
$_['text_transactions']   = 'Darījumi';
$_['text_affiliate_add']  = 'Reģistrēties kā partnerim';
$_['text_affiliate_edit'] = 'Labot partnera informāciju';
$_['text_tracking']       = 'Partnera izsekošanas kods';