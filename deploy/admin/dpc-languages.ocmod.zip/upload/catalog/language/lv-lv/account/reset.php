<?php
// Heading
$_['heading_title']  = 'Atjaunot paroli';

// Text
$_['text_account']   = 'Konts';
$_['text_password']  = 'Ievadiet jauno paroli.';
$_['text_success']   = 'Jūsu parole ir veiksmīgi nomainīta.';

// Entry
$_['entry_password'] = 'Parole';
$_['entry_confirm']  = 'Apstiprināt';

// Error
$_['error_password'] = 'Parolei jābūt no 4 līdz 20 rakstzīmēm!';
$_['error_confirm']  = 'Parole un paroles apstiprinājums nesakrīt!';
$_['error_code']     = 'Paroles atjaunošanas kods nav derīgs vai jau ir izmantots!';