<?php
// Heading
$_['heading_title'] = 'Jūsu konts ir izveidots!';

// Text
$_['text_message']  = '<p>Apsveicam! Jūsu jaunais konts ir veiksmīgi izveidots!</p> <p>Tagad varat izmantot reģistrēta klienta priekšrocības, lai iepirktos pie mums ērtāk.</p> <p>Ja jums ir JEBKĀDI jautājumi par šī interneta veikala darbību, lūdzu, rakstiet veikala īpašniekam.</p> <p>Uz norādīto e-pasta adresi ir nosūtīts apstiprinājums. Ja stundas laikā to nesaņemat, lūdzu, <a href="%s">sazinieties ar mums</a>.</p>';
$_['text_approval'] = '<p>Paldies, ka reģistrējāties veikalā %s!</p><p>Kad veikala īpašnieks aktivizēs jūsu kontu, jūs saņemsiet paziņojumu pa e-pastu.</p><p>Ja jums ir JEBKĀDI jautājumi par šī interneta veikala darbību, lūdzu, <a href="%s">sazinieties ar veikala īpašnieku</a>.</p>';
$_['text_account']  = 'Konts';
$_['text_success']  = 'Gatavs';