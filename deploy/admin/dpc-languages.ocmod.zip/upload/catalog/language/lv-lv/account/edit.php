<?php
// Heading
$_['heading_title']      = 'Mana konta informācija';

// Text
$_['text_account']       = 'Konts';
$_['text_edit']          = 'Labot informāciju';
$_['text_your_details']  = 'Jūsu personas dati';
$_['text_success']       = 'Jūsu konts ir veiksmīgi atjaunināts.';

// Entry
$_['entry_firstname']    = 'Vārds';
$_['entry_lastname']     = 'Uzvārds';
$_['entry_email']        = 'E-pasts';
$_['entry_telephone']    = 'Tālrunis';

// Error
$_['error_exists']       = 'Uzmanību: šī e-pasta adrese jau ir reģistrēta!';
$_['error_firstname']    = 'Vārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_lastname']     = 'Uzvārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_email']        = 'E-pasta adrese nav derīga!';
$_['error_telephone']    = 'Tālruņa numuram jābūt no 3 līdz 32 rakstzīmēm!';
$_['error_custom_field'] = 'Lūdzu, norādiet: %s!';