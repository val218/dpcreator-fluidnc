<?php
// Heading
$_['heading_title']   = 'Aizmirsāt paroli?';

// Text
$_['text_account']    = 'Konts';
$_['text_forgotten']  = 'Aizmirsta parole';
$_['text_your_email'] = 'Jūsu e-pasta adrese';
$_['text_email']      = 'Ievadiet sava konta e-pasta adresi. Nospiediet „Iesniegt”, un mēs jums nosūtīsim saiti paroles atjaunošanai.';
$_['text_success']    = 'Uz jūsu e-pasta adresi ir nosūtīta vēstule ar apstiprinājuma saiti.';

// Entry
$_['entry_email']     = 'E-pasta adrese';
$_['entry_password']  = 'Jaunā parole';
$_['entry_confirm']   = 'Apstiprināt';

// Error
$_['error_email']     = 'Uzmanību: šī e-pasta adrese mūsu datos nav atrasta, lūdzu, mēģiniet vēlreiz!';
$_['error_approved']  = 'Uzmanību: pirms pieslēgšanās jūsu kontam jābūt apstiprinātam.';
$_['error_password']  = 'Parolei jābūt no 4 līdz 20 rakstzīmēm!';
$_['error_confirm']   = 'Parole un paroles apstiprinājums nesakrīt!';