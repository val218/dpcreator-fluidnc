<?php
// Heading
$_['heading_title']                        = 'Regulārie maksājumi';

// Text
$_['text_account']                         = 'Konts';
$_['text_recurring']                       = 'Regulārā maksājuma informācija';
$_['text_recurring_detail']                = 'Regulārā maksājuma dati';
$_['text_order_recurring_id']              = 'Regulārā maksājuma ID:';
$_['text_date_added']                      = 'Pievienots:';
$_['text_status']                          = 'Statuss:';
$_['text_payment_method']                  = 'Maksājuma veids:';
$_['text_order_id']                        = 'Pasūtījuma Nr.:';
$_['text_product']                         = 'Prece:';
$_['text_quantity']                        = 'Daudzums:';
$_['text_description']                     = 'Apraksts';
$_['text_reference']                       = 'Atsauce';
$_['text_transaction']                     = 'Darījumi';
$_['text_status_1']                        = 'Aktīvs';
$_['text_status_2']                        = 'Neaktīvs';
$_['text_status_3']                        = 'Atcelts';
$_['text_status_4']                        = 'Apturēts';
$_['text_status_5']                        = 'Beidzies';
$_['text_status_6']                        = 'Gaida';
$_['text_transaction_date_added']          = 'Izveidots';
$_['text_transaction_payment']             = 'Maksājums';
$_['text_transaction_outstanding_payment'] = 'Neapmaksāts maksājums';
$_['text_transaction_skipped']             = 'Maksājums izlaists';
$_['text_transaction_failed']              = 'Maksājums neizdevās';
$_['text_transaction_cancelled']           = 'Atcelts';
$_['text_transaction_suspended']           = 'Apturēts';
$_['text_transaction_suspended_failed']    = 'Apturēts neizdevušās maksājuma dēļ';
$_['text_transaction_outstanding_failed']  = 'Neapmaksātā maksājuma iekasēšana neizdevās';
$_['text_transaction_expired']             = 'Beidzies';
$_['text_empty']                           = 'Regulārie maksājumi nav atrasti!';
$_['text_error']                           = 'Pieprasītais regulārais pasūtījums nav atrasts!';
$_['text_cancelled']                       = 'Regulārais maksājums ir atcelts';

// Column
$_['column_date_added']                    = 'Pievienots';
$_['column_type']                          = 'Veids';
$_['column_amount']                        = 'Summa';
$_['column_status']                        = 'Statuss';
$_['column_product']                       = 'Prece';
$_['column_order_recurring_id']            = 'Regulārā maksājuma ID';

// Error
$_['error_not_cancelled']                  = 'Kļūda: %s';
$_['error_not_found']                      = 'Regulāro maksājumu neizdevās atcelt';

// Button
$_['button_return']                        = 'Atgriezties';