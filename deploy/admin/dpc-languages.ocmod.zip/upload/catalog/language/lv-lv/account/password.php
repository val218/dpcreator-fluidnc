<?php
// Heading
$_['heading_title']  = 'Mainīt paroli';

// Text
$_['text_account']   = 'Konts';
$_['text_password']  = 'Jūsu parole';
$_['text_success']   = 'Jūsu parole ir veiksmīgi nomainīta.';

// Entry
$_['entry_password'] = 'Parole';
$_['entry_confirm']  = 'Parole vēlreiz';

// Error
$_['error_password'] = 'Parolei jābūt no 4 līdz 20 rakstzīmēm!';
$_['error_confirm']  = 'Paroles nesakrīt!';