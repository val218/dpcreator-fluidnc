<?php
// Text
$_['text_upload']    = 'Fails veiksmīgi augšupielādēts!';

// Error
$_['error_filename'] = 'Faila nosaukumam jābūt no 3 līdz 64 rakstzīmēm!';
$_['error_filetype'] = 'Nederīgs faila tips!';
$_['error_upload']   = 'Lūdzu, augšupielādējiet failu!';