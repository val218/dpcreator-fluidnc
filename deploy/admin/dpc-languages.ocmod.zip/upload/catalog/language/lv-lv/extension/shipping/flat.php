<?php
// Text
$_['text_title']       = 'Fiksēta cena';
$_['text_description'] = 'Fiksēta piegādes cena';