<?php
// Heading
$_['heading_title'] = 'Izmantot dāvanu karti';

// Text
$_['text_voucher']  = 'Dāvanu karte (%s)';
$_['text_success']  = 'Dāvanu kartes atlaide ir piemērota!';

// Entry
$_['entry_voucher'] = 'Ievadiet dāvanu kartes kodu';

// Error
$_['error_voucher'] = 'Uzmanību: dāvanu karte nav derīga vai tās atlikums ir izlietots!';
$_['error_empty']   = 'Uzmanību: lūdzu, ievadiet dāvanu kartes kodu!';