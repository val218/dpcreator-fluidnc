<?php
// Heading
$_['heading_title']        = 'Aprēķināt piegādi un nodokļus';

// Text
$_['text_success']         = 'Piegādes aprēķins ir piemērots!';
$_['text_shipping']        = 'Ievadiet piegādes vietu, lai aprēķinātu piegādes izmaksas.';
$_['text_shipping_method'] = 'Lūdzu, izvēlieties šim pasūtījumam vēlamo piegādes veidu.';

// Entry
$_['entry_country']        = 'Valsts';
$_['entry_zone']           = 'Novads / reģions';
$_['entry_postcode']       = 'Pasta indekss';

// Error
$_['error_postcode']       = 'Pasta indeksam jābūt no 2 līdz 10 rakstzīmēm!';
$_['error_country']        = 'Lūdzu, izvēlieties valsti!';
$_['error_zone']           = 'Lūdzu, izvēlieties novadu / reģionu!';
$_['error_shipping']       = 'Uzmanību: lūdzu, izvēlieties piegādes veidu!';
$_['error_no_shipping']    = 'Uzmanību: nav pieejams neviens piegādes veids. Lūdzu, <a href="%s">sazinieties ar mums</a>, un mēs palīdzēsim!';