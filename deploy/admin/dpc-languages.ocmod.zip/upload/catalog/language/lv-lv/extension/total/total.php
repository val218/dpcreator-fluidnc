<?php
// Text
$_['text_total'] = 'Kopā';