<?php
// Heading
$_['heading_title'] = 'Izmantot kupona kodu';

// Text
$_['text_coupon']   = 'Kupons (%s)';
$_['text_success']  = 'Kupona atlaide ir piemērota!';

// Entry
$_['entry_coupon']  = 'Ievadiet kupona kodu';

// Error
$_['error_coupon']  = 'Uzmanību: kupons nav derīgs, tam beidzies termiņš vai sasniegts izmantošanas limits!';
$_['error_empty']   = 'Uzmanību: lūdzu, ievadiet kupona kodu!';