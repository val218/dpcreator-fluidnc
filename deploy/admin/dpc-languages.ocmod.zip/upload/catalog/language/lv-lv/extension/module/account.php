<?php
// Heading
$_['heading_title']    = 'Konts';

// Text
$_['text_register']    = 'Reģistrēties';
$_['text_login']       = 'Pieslēgties';
$_['text_logout']      = 'Iziet';
$_['text_forgotten']   = 'Aizmirsāt paroli?';
$_['text_account']     = 'Mans konts';
$_['text_edit']        = 'Labot kontu';
$_['text_password']    = 'Parole';
$_['text_address']     = 'Adrešu grāmata';
$_['text_wishlist']    = 'Vēlmju saraksts';
$_['text_order']       = 'Pasūtījumu vēsture';
$_['text_download']    = 'Lejupielādes';
$_['text_reward']      = 'Bonusa punkti';
$_['text_return']      = 'Preču atgriešana';
$_['text_transaction'] = 'Darījumi';
$_['text_newsletter']  = 'Jaunumu vēstule';
$_['text_recurring']   = 'Regulārie maksājumi';