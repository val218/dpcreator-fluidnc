<?php
// Text
$_['text_title'] = 'Maksājums saņemot';