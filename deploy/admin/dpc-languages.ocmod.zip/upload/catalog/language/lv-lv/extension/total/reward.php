<?php
// Heading
$_['heading_title'] = 'Izmantot bonusa punktus (pieejami: %s)';

// Text
$_['text_reward']   = 'Bonusa punkti (%s)';
$_['text_order_id'] = 'Pasūtījuma Nr.: #%s';
$_['text_success']  = 'Bonusa punktu atlaide ir piemērota!';

// Entry
$_['entry_reward']  = 'Izmantojamie punkti (maks. %s)';

// Error
$_['error_reward']  = 'Uzmanību: lūdzu, ievadiet izmantojamo bonusa punktu skaitu!';
$_['error_points']  = 'Uzmanību: jums nav %s bonusa punktu!';
$_['error_maximum'] = 'Uzmanību: maksimālais izmantojamo punktu skaits ir %s!';