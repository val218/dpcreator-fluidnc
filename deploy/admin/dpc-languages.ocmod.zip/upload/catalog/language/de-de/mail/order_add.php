<?php
// Text
$_['text_subject']          = '%s - Bestellung %s';
$_['text_greeting']         = 'Vielen Dank für Ihr Interesse an den Produkten von %s. Ihre Bestellung ist bei uns eingegangen und wird bearbeitet, sobald die Zahlung bestätigt ist.';
$_['text_link']             = 'Klicken Sie auf den folgenden Link, um Ihre Bestellung anzusehen:';
$_['text_order_detail']     = 'Bestelldetails';
$_['text_instruction']      = 'Hinweise';
$_['text_order_id']         = 'Bestellnr.:';
$_['text_date_added']       = 'Bestelldatum:';
$_['text_order_status']     = 'Bestellstatus:';
$_['text_payment_method']   = 'Zahlungsart:';
$_['text_shipping_method']  = 'Versandart:';
$_['text_email']            = 'E-Mail:';
$_['text_telephone']        = 'Telefon:';
$_['text_ip']               = 'IP-Adresse:';
$_['text_payment_address']  = 'Rechnungsadresse';
$_['text_shipping_address'] = 'Lieferadresse';
$_['text_products']         = 'Produkte';
$_['text_product']          = 'Produkt';
$_['text_model']            = 'Modell';
$_['text_quantity']         = 'Menge';
$_['text_price']            = 'Preis';
$_['text_order_total']      = 'Bestellsumme';
$_['text_total']            = 'Gesamt';
$_['text_download']         = 'Sobald Ihre Zahlung bestätigt ist, können Sie Ihre Download-Produkte über den folgenden Link abrufen:';
$_['text_comment']          = 'Anmerkungen zu Ihrer Bestellung:';
$_['text_footer']           = 'Bei Fragen antworten Sie einfach auf diese E-Mail.';