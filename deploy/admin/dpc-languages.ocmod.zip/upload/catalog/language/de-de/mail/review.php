<?php
// Text
$_['text_subject']  = '%s - Produktbewertung';
$_['text_waiting']  = 'Eine neue Produktbewertung wartet auf Freigabe.';
$_['text_product']  = 'Produkt: %s';
$_['text_reviewer'] = 'Verfasser: %s';
$_['text_rating']   = 'Bewertung: %s';
$_['text_review']   = 'Bewertungstext:';