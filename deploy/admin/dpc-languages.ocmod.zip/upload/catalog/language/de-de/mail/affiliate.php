<?php
// Text
$_['text_subject']        = '%s - Partnerprogramm';
$_['text_welcome']        = 'Vielen Dank für Ihre Teilnahme am Partnerprogramm von %s!';
$_['text_login']          = 'Ihr Konto wurde erstellt. Sie können sich jetzt mit Ihrer E-Mail-Adresse und Ihrem Passwort auf unserer Website oder unter folgender Adresse anmelden:';
$_['text_approval']       = 'Ihr Konto muss erst freigeschaltet werden, bevor Sie sich anmelden können. Nach der Freischaltung können Sie sich mit Ihrer E-Mail-Adresse und Ihrem Passwort auf unserer Website oder unter folgender Adresse anmelden:';
$_['text_service']        = 'Nach der Anmeldung können Sie Trackingcodes erstellen, Provisionszahlungen verfolgen und Ihre Kontodaten bearbeiten.';
$_['text_thanks']         = 'Vielen Dank,';
$_['text_new_affiliate']  = 'Neuer Partner';
$_['text_signup']         = 'Ein neuer Partner hat sich registriert:';
$_['text_website']        = 'Website:';
$_['text_customer_group'] = 'Kundengruppe:';
$_['text_firstname']      = 'Vorname:';
$_['text_lastname']       = 'Nachname:';
$_['text_company']        = 'Firma:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Telefon:';