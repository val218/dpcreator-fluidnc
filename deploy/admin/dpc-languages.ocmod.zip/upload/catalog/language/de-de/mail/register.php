<?php
// Text
$_['text_subject']        = '%s - Vielen Dank für Ihre Registrierung';
$_['text_welcome']        = 'Willkommen und vielen Dank für Ihre Registrierung bei %s!';
$_['text_login']          = 'Ihr Konto wurde erstellt. Sie können sich jetzt mit Ihrer E-Mail-Adresse und Ihrem Passwort auf unserer Website oder unter folgender Adresse anmelden:';
$_['text_approval']       = 'Ihr Konto muss erst freigeschaltet werden, bevor Sie sich anmelden können. Nach der Freischaltung können Sie sich mit Ihrer E-Mail-Adresse und Ihrem Passwort auf unserer Website oder unter folgender Adresse anmelden:';
$_['text_service']        = 'Nach der Anmeldung stehen Ihnen weitere Funktionen zur Verfügung, z. B. frühere Bestellungen ansehen, Rechnungen drucken und Ihre Kontodaten bearbeiten.';
$_['text_thanks']         = 'Vielen Dank,';
$_['text_new_customer']   = 'Neuer Kunde';
$_['text_signup']         = 'Ein neuer Kunde hat sich registriert:';
$_['text_customer_group'] = 'Kundengruppe:';
$_['text_firstname']      = 'Vorname:';
$_['text_lastname']       = 'Nachname:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Telefon:';