<?php
// Text
$_['text_subject']  = 'Sie haben einen Geschenkgutschein von %s erhalten';
$_['text_greeting'] = 'Herzlichen Glückwunsch, Sie haben einen Geschenkgutschein im Wert von %s erhalten';
$_['text_from']     = 'Dieser Geschenkgutschein wurde Ihnen von %s geschickt';
$_['text_message']  = 'Mit folgender Nachricht';
$_['text_redeem']   = 'Um diesen Geschenkgutschein einzulösen, notieren Sie sich den Code <b>%s</b>. Klicken Sie dann auf den folgenden Link und kaufen Sie das Produkt, für das Sie den Gutschein verwenden möchten. Den Gutscheincode geben Sie im Warenkorb ein, bevor Sie zur Kasse gehen.';
$_['text_footer']   = 'Bei Fragen antworten Sie einfach auf diese E-Mail.';