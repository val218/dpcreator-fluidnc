<?php
// Text
$_['text_subject']  = '%s - Partnerprovision';
$_['text_received'] = 'Herzlichen Glückwunsch! Sie haben eine Provisionszahlung aus dem Partnerprogramm von %s erhalten';
$_['text_amount']   = 'Sie haben erhalten:';
$_['text_total']    = 'Ihre Provision beträgt jetzt insgesamt:';