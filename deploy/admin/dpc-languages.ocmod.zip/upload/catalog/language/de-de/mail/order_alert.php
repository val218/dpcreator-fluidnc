<?php
// Text
$_['text_subject']      = '%s - Bestellung %s';
$_['text_received']     = 'Sie haben eine neue Bestellung erhalten.';
$_['text_order_id']     = 'Bestellnr.:';
$_['text_date_added']   = 'Bestelldatum:';
$_['text_order_status'] = 'Bestellstatus:';
$_['text_product']      = 'Produkte';
$_['text_total']        = 'Summen';
$_['text_comment']      = 'Anmerkungen zur Bestellung:';
