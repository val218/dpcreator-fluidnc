<?php
// Text
$_['text_subject']      = '%s - Aktualisierung der Bestellung %s';
$_['text_order_id']     = 'Bestellnr.:';
$_['text_date_added']   = 'Bestelldatum:';
$_['text_order_status'] = 'Ihre Bestellung hat jetzt folgenden Status:';
$_['text_comment']      = 'Anmerkungen zu Ihrer Bestellung:';
$_['text_link']         = 'Klicken Sie auf den folgenden Link, um Ihre Bestellung anzusehen:';
$_['text_footer']       = 'Bei Fragen antworten Sie einfach auf diese E-Mail.';