<?php
// Text
$_['text_subject']  = '%s - Passwort zurücksetzen';
$_['text_greeting'] = 'Für das Kundenkonto bei %s wurde ein neues Passwort angefordert.';
$_['text_change']   = 'Klicken Sie auf den folgenden Link, um Ihr Passwort zurückzusetzen:';
$_['text_ip']       = ' Diese Anfrage wurde von folgender IP-Adresse gestellt:';
