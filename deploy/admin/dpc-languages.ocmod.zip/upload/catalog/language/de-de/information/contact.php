<?php
// Heading
$_['heading_title']  = 'Kontakt';

// Text
$_['text_location']  = 'Unser Standort';
$_['text_store']     = 'Unsere Filialen';
$_['text_contact']   = 'Kontaktformular';
$_['text_address']   = 'Adresse';
$_['text_telephone'] = 'Telefon';
$_['text_fax']       = 'Fax';
$_['text_open']      = 'Öffnungszeiten';
$_['text_comment']   = 'Anmerkungen';
$_['text_message']   = '<p>Ihre Anfrage wurde erfolgreich an den Shopbetreiber gesendet!</p>'; 

// Entry
$_['entry_name']     = 'Ihr Name';
$_['entry_email']    = 'E-Mail-Adresse';
$_['entry_enquiry']  = 'Ihre Anfrage';

// Email
$_['email_subject']  = 'Anfrage %s';

// Errors
$_['error_name']     = 'Der Name muss zwischen 3 und 32 Zeichen lang sein!';
$_['error_email']    = 'Die E-Mail-Adresse scheint ungültig zu sein!';
$_['error_enquiry']  = 'Die Anfrage muss zwischen 10 und 3000 Zeichen lang sein!';