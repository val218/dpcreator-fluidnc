<?php
// Heading
$_['heading_title']    = 'Konto';

// Text
$_['text_register']    = 'Registrieren';
$_['text_login']       = 'Anmelden';
$_['text_logout']      = 'Abmelden';
$_['text_forgotten']   = 'Passwort vergessen';
$_['text_account']     = 'Mein Konto';
$_['text_edit']        = 'Konto bearbeiten';
$_['text_password']    = 'Passwort';
$_['text_address']     = 'Adressbuch';
$_['text_wishlist']    = 'Wunschzettel';
$_['text_order']       = 'Bestellverlauf';
$_['text_download']    = 'Downloads';
$_['text_reward']      = 'Bonuspunkte';
$_['text_return']      = 'Rücksendungen';
$_['text_transaction'] = 'Transaktionen';
$_['text_newsletter']  = 'Newsletter';
$_['text_recurring']   = 'Wiederkehrende Zahlungen';