<?php
// Heading
$_['heading_title'] = 'Gutscheincode einlösen';

// Text
$_['text_coupon']   = 'Gutschein (%s)';
$_['text_success']  = 'Ihr Gutscheinrabatt wurde angewendet!';

// Entry
$_['entry_coupon']  = 'Gutscheincode hier eingeben';

// Error
$_['error_coupon']  = 'Achtung: Der Gutschein ist ungültig, abgelaufen oder hat sein Nutzungslimit erreicht!';
$_['error_empty']   = 'Achtung: Bitte geben Sie einen Gutscheincode ein!';