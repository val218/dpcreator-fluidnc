<?php
// Heading
$_['heading_title'] = 'Bonuspunkte einlösen (%s verfügbar)';

// Text
$_['text_reward']   = 'Bonuspunkte (%s)';
$_['text_order_id'] = 'Bestellnr.: #%s';
$_['text_success']  = 'Ihr Bonuspunkte-Rabatt wurde angewendet!';

// Entry
$_['entry_reward']  = 'Einzulösende Punkte (max. %s)';

// Error
$_['error_reward']  = 'Achtung: Bitte geben Sie die Anzahl der Bonuspunkte ein, die Sie einlösen möchten!';
$_['error_points']  = 'Achtung: Sie haben keine %s Bonuspunkte!';
$_['error_maximum'] = 'Achtung: Sie können höchstens %s Punkte einlösen!';