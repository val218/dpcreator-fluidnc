<?php
// Text
$_['text_title'] = 'Kostenlose Bestellung';