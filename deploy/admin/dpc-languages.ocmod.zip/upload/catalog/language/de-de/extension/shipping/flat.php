<?php
// Text
$_['text_title']       = 'Pauschale';
$_['text_description'] = 'Versandkostenpauschale';