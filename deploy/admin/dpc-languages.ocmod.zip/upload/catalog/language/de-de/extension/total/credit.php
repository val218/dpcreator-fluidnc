<?php
// Text
$_['text_credit']   = 'Guthaben';
$_['text_order_id'] = 'Bestellnr.: #%s';