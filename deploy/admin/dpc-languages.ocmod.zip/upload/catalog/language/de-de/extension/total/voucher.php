<?php
// Heading
$_['heading_title'] = 'Geschenkgutschein einlösen';

// Text
$_['text_voucher']  = 'Geschenkgutschein (%s)';
$_['text_success']  = 'Ihr Geschenkgutschein wurde angewendet!';

// Entry
$_['entry_voucher'] = 'Gutscheincode hier eingeben';

// Error
$_['error_voucher'] = 'Achtung: Der Geschenkgutschein ist ungültig oder das Guthaben ist aufgebraucht!';
$_['error_empty']   = 'Achtung: Bitte geben Sie einen Gutscheincode ein!';