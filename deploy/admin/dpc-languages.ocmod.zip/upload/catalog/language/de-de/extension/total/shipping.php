<?php
// Heading
$_['heading_title']        = 'Versandkosten &amp; Steuern berechnen';

// Text
$_['text_success']         = 'Ihre Versandkostenschätzung wurde übernommen!';
$_['text_shipping']        = 'Geben Sie Ihr Lieferziel ein, um die Versandkosten zu berechnen.';
$_['text_shipping_method'] = 'Bitte wählen Sie die gewünschte Versandart für diese Bestellung.';

// Entry
$_['entry_country']        = 'Land';
$_['entry_zone']           = 'Bundesland / Region';
$_['entry_postcode']       = 'Postleitzahl';

// Error
$_['error_postcode']       = 'Die Postleitzahl muss zwischen 2 und 10 Zeichen lang sein!';
$_['error_country']        = 'Bitte wählen Sie ein Land!';
$_['error_zone']           = 'Bitte wählen Sie ein Bundesland / eine Region!';
$_['error_shipping']       = 'Achtung: Bitte wählen Sie eine Versandart!';
$_['error_no_shipping']    = 'Achtung: Es sind keine Versandarten verfügbar. Bitte <a href="%s">kontaktieren Sie uns</a>, wir helfen Ihnen gern!';