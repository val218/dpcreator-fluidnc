<?php
// Text
$_['text_upload']    = 'Ihre Datei wurde erfolgreich hochgeladen!';

// Error
$_['error_filename'] = 'Der Dateiname muss zwischen 3 und 64 Zeichen lang sein!';
$_['error_filetype'] = 'Ungültiger Dateityp!';
$_['error_upload']   = 'Bitte laden Sie eine Datei hoch!';