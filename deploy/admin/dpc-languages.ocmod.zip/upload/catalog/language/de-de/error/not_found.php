<?php
// Heading
$_['heading_title'] = 'Die gewünschte Seite wurde nicht gefunden!';

// Text
$_['text_error']    = 'Die gewünschte Seite wurde nicht gefunden.';