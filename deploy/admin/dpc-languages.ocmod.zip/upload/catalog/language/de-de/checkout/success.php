<?php
// Heading
$_['heading_title']        = 'Ihre Bestellung ist eingegangen!';

// Text
$_['text_basket']          = 'Warenkorb';
$_['text_checkout']        = 'Kasse';
$_['text_success']         = 'Erfolgreich';
$_['text_customer']        = '<p>Ihre Bestellung wurde erfolgreich bearbeitet!</p><p>Ihren Bestellverlauf finden Sie unter <a href="%s">Mein Konto</a> im Bereich <a href="%s">Bestellverlauf</a>.</p><p>Enthält Ihre Bestellung Downloads, finden Sie diese im Kontobereich <a href="%s">Downloads</a>.</p><p>Bei Fragen wenden Sie sich bitte an den <a href="%s">Shopbetreiber</a>.</p><p>Vielen Dank für Ihren Einkauf!</p>';
$_['text_guest']           = '<p>Ihre Bestellung wurde erfolgreich bearbeitet!</p><p>Bei Fragen wenden Sie sich bitte an den <a href="%s">Shopbetreiber</a>.</p><p>Vielen Dank für Ihren Einkauf!</p>';