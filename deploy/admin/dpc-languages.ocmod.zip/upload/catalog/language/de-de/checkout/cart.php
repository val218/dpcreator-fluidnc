<?php
// Heading
$_['heading_title']            = 'Warenkorb';

// Text
$_['text_success']             = 'Sie haben <a href="%s">%s</a> in Ihren <a href="%s">Warenkorb</a> gelegt!';
$_['text_remove']              = 'Ihr Warenkorb wurde geändert!';
$_['text_login']               = 'Hinweis: Bitte <a href="%s">melden Sie sich an</a> oder <a href="%s">erstellen Sie ein Konto</a>, um die Preise zu sehen!';
$_['text_items']               = '%s Artikel - %s';
$_['text_points']              = 'Bonuspunkte: %s';
$_['text_next']                = 'Wie möchten Sie fortfahren?';
$_['text_next_choice']         = 'Wählen Sie hier, ob Sie einen Rabattcode oder Bonuspunkte einlösen oder Ihre Versandkosten berechnen möchten.';
$_['text_empty']               = 'Ihr Warenkorb ist leer!';
$_['text_day']                 = 'Tag';
$_['text_week']                = 'Woche';
$_['text_semi_month']          = 'Halbmonat';
$_['text_month']               = 'Monat';
$_['text_year']                = 'Jahr';
$_['text_trial']               = '%s alle %s %s für %s Zahlungen, danach ';
$_['text_recurring']           = '%s alle %s %s';
$_['text_recurring_item']      = 'Abo-Artikel';
$_['text_payment_recurring']   = 'Zahlungsprofil';
$_['text_trial_description']   = '%s alle %d %s für %d Zahlung(en), danach';
$_['text_payment_description'] = '%s alle %d %s für %d Zahlung(en)';
$_['text_payment_cancel']      = '%s alle %d %s bis zur Kündigung';

// Column
$_['column_image']             = 'Bild';
$_['column_name']              = 'Produktname';
$_['column_model']             = 'Modell';
$_['column_quantity']          = 'Menge';
$_['column_price']             = 'Stückpreis';
$_['column_total']             = 'Gesamt';

// Error
$_['error_stock']              = 'Mit *** markierte Produkte sind nicht in der gewünschten Menge oder nicht auf Lager!';
$_['error_minimum']            = 'Die Mindestbestellmenge für %s beträgt %s!';
$_['error_required']           = '%s erforderlich!';
$_['error_product']            = 'Achtung: Ihr Warenkorb enthält keine Produkte!';
$_['error_recurring_required'] = 'Bitte wählen Sie ein Zahlungsprofil!';
