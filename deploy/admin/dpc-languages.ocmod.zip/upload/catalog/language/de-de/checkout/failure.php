<?php
// Heading
$_['heading_title'] = 'Zahlung fehlgeschlagen!';

// Text
$_['text_basket']   = 'Warenkorb';
$_['text_checkout'] = 'Kasse';
$_['text_failure']  = 'Zahlung fehlgeschlagen';
$_['text_message']  = '<p>Bei der Verarbeitung Ihrer Zahlung ist ein Problem aufgetreten, die Bestellung wurde nicht abgeschlossen.</p>

<p>Mögliche Gründe:</p>
<ul>
  <li>Nicht genügend Guthaben</li>
  <li>Verifizierung fehlgeschlagen</li>
</ul>

<p>Bitte bestellen Sie erneut und wählen Sie eine andere Zahlungsart.</p>

<p>Falls das Problem weiterhin besteht, <a href="%s">kontaktieren Sie uns</a> bitte mit den Angaben zu Ihrer Bestellung.</p>
';