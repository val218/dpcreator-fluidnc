<?php
// Heading
$_['heading_title']                  = 'Kasse';

// Text
$_['text_cart']                      = 'Warenkorb';
$_['text_checkout_option']           = 'Schritt %s: Bestelloptionen';
$_['text_checkout_account']          = 'Schritt %s: Konto &amp; Rechnungsdaten';
$_['text_checkout_payment_address']  = 'Schritt %s: Rechnungsdaten';
$_['text_checkout_shipping_address'] = 'Schritt %s: Lieferdaten';
$_['text_checkout_shipping_method']  = 'Schritt %s: Versandart';
$_['text_checkout_payment_method']   = 'Schritt %s: Zahlungsart';
$_['text_checkout_confirm']          = 'Schritt %s: Bestellung bestätigen';
$_['text_modify']                    = 'Ändern &raquo;';
$_['text_new_customer']              = 'Neukunde';
$_['text_returning_customer']        = 'Bestehender Kunde';
$_['text_checkout']                  = 'Bestelloptionen:';
$_['text_i_am_returning_customer']   = 'Ich bin bereits Kunde';
$_['text_register']                  = 'Konto erstellen';
$_['text_guest']                     = 'Als Gast bestellen';
$_['text_register_account']          = 'Mit einem Kundenkonto kaufen Sie schneller ein, sehen jederzeit den Status Ihrer Bestellung und behalten den Überblick über Ihre bisherigen Bestellungen.';
$_['text_forgotten']                 = 'Passwort vergessen';
$_['text_your_details']              = 'Ihre persönlichen Daten';
$_['text_your_address']              = 'Ihre Adresse';
$_['text_your_password']             = 'Ihr Passwort';
$_['text_agree']                     = 'Ich habe die <a href="%s" class="agree"><b>%s</b></a> gelesen und bin damit einverstanden';
$_['text_address_new']               = 'Ich möchte eine neue Adresse verwenden';
$_['text_address_existing']          = 'Ich möchte eine vorhandene Adresse verwenden';
$_['text_shipping_method']           = 'Bitte wählen Sie die gewünschte Versandart für diese Bestellung.';
$_['text_payment_method']            = 'Bitte wählen Sie die gewünschte Zahlungsart für diese Bestellung.';
$_['text_comments']                  = 'Anmerkungen zu Ihrer Bestellung';
$_['text_recurring_item']            = 'Abo-Artikel';
$_['text_payment_recurring']         = 'Zahlungsprofil';
$_['text_trial_description']         = '%s alle %d %s für %d Zahlung(en), danach';
$_['text_payment_description']       = '%s alle %d %s für %d Zahlung(en)';
$_['text_payment_cancel']            = '%s alle %d %s bis zur Kündigung';
$_['text_day']                       = 'Tag';
$_['text_week']                      = 'Woche';
$_['text_semi_month']                = 'Halbmonat';
$_['text_month']                     = 'Monat';
$_['text_year']                      = 'Jahr';

// Column
$_['column_name']                    = 'Produktname';
$_['column_model']                   = 'Modell';
$_['column_quantity']                = 'Menge';
$_['column_price']                   = 'Stückpreis';
$_['column_total']                   = 'Gesamt';

// Entry
$_['entry_email_address']            = 'E-Mail-Adresse';
$_['entry_email']                    = 'E-Mail';
$_['entry_password']                 = 'Passwort';
$_['entry_confirm']                  = 'Passwort bestätigen';
$_['entry_firstname']                = 'Vorname';
$_['entry_lastname']                 = 'Nachname';
$_['entry_telephone']                = 'Telefon';
$_['entry_address']                  = 'Adresse wählen';
$_['entry_company']                  = 'Firma';
$_['entry_customer_group']           = 'Kundengruppe';
$_['entry_address_1']                = 'Straße und Hausnummer';
$_['entry_address_2']                = 'Adresszusatz';
$_['entry_postcode']                 = 'Postleitzahl';
$_['entry_city']                     = 'Ort';
$_['entry_country']                  = 'Land';
$_['entry_zone']                     = 'Bundesland / Region';
$_['entry_newsletter']               = 'Ich möchte den Newsletter von %s abonnieren.';
$_['entry_shipping']                 = 'Liefer- und Rechnungsadresse sind identisch.';

// Error
$_['error_warning']                  = 'Bei der Verarbeitung Ihrer Bestellung ist ein Problem aufgetreten! Falls das Problem weiterhin besteht, wählen Sie bitte eine andere Zahlungsart oder <a href="%s">kontaktieren Sie den Shopbetreiber</a>.';
$_['error_login']                    = 'Achtung: E-Mail-Adresse und/oder Passwort sind nicht korrekt.';
$_['error_attempts']                 = 'Achtung: Sie haben die zulässige Anzahl an Anmeldeversuchen überschritten. Bitte versuchen Sie es in 1 Stunde erneut.';
$_['error_approved']                 = 'Achtung: Ihr Konto muss erst freigeschaltet werden, bevor Sie sich anmelden können.';
$_['error_exists']                   = 'Achtung: Diese E-Mail-Adresse ist bereits registriert!';
$_['error_firstname']                = 'Der Vorname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_lastname']                 = 'Der Nachname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_email']                    = 'Die E-Mail-Adresse scheint ungültig zu sein!';
$_['error_telephone']                = 'Die Telefonnummer muss zwischen 3 und 32 Zeichen lang sein!';
$_['error_password']                 = 'Das Passwort muss zwischen 4 und 20 Zeichen lang sein!';
$_['error_confirm']                  = 'Die Passwortbestätigung stimmt nicht mit dem Passwort überein!';
$_['error_address_1']                = 'Straße und Hausnummer müssen zwischen 3 und 128 Zeichen lang sein!';
$_['error_city']                     = 'Der Ort muss zwischen 2 und 128 Zeichen lang sein!';
$_['error_postcode']                 = 'Die Postleitzahl muss zwischen 2 und 10 Zeichen lang sein!';
$_['error_country']                  = 'Bitte wählen Sie ein Land!';
$_['error_zone']                     = 'Bitte wählen Sie ein Bundesland / eine Region!';
$_['error_agree']                    = 'Achtung: Bitte akzeptieren Sie die %s!';
$_['error_address']                  = 'Achtung: Bitte wählen Sie eine Adresse!';
$_['error_shipping']                 = 'Achtung: Bitte wählen Sie eine Versandart!';
$_['error_no_shipping']              = 'Achtung: Es sind keine Versandarten verfügbar. Bitte <a href="%s">kontaktieren Sie uns</a>, wir helfen Ihnen gern!';
$_['error_payment']                  = 'Achtung: Bitte wählen Sie eine Zahlungsart!';
$_['error_no_payment']               = 'Achtung: Es sind keine Zahlungsarten verfügbar. Bitte <a href="%s">kontaktieren Sie uns</a>, wir helfen Ihnen gern!';
$_['error_custom_field']             = '%s erforderlich!';