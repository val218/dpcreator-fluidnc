<?php
// Heading
$_['heading_title'] = 'Ihr Konto wurde erstellt!';

// Text
$_['text_message']  = '<p>Herzlichen Glückwunsch! Ihr neues Konto wurde erfolgreich erstellt!</p> <p>Ab sofort können Sie alle Vorteile als Kunde nutzen und noch bequemer bei uns einkaufen.</p> <p>Wenn Sie Fragen zu diesem Onlineshop haben, schreiben Sie dem Shopbetreiber gern eine E-Mail.</p> <p>Eine Bestätigung wurde an die angegebene E-Mail-Adresse gesendet. Falls Sie sie nicht innerhalb einer Stunde erhalten, <a href="%s">kontaktieren Sie uns</a> bitte.</p>';
$_['text_approval'] = '<p>Vielen Dank für Ihre Registrierung bei %s!</p><p>Sie erhalten eine E-Mail, sobald Ihr Konto vom Shopbetreiber freigeschaltet wurde.</p><p>Wenn Sie Fragen zu diesem Onlineshop haben, <a href="%s">kontaktieren Sie bitte den Shopbetreiber</a>.</p>';
$_['text_account']  = 'Konto';
$_['text_success']  = 'Erfolgreich';