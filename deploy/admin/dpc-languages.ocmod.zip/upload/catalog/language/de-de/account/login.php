<?php
// Heading
$_['heading_title']                = 'Anmelden';

// Text
$_['text_account']                 = 'Konto';
$_['text_login']                   = 'Anmelden';
$_['text_new_customer']            = 'Neukunde';
$_['text_register']                = 'Konto erstellen';
$_['text_register_account']        = 'Mit einem Kundenkonto kaufen Sie schneller ein, sehen jederzeit den Status Ihrer Bestellung und behalten den Überblick über Ihre bisherigen Bestellungen.';
$_['text_returning_customer']      = 'Bestehender Kunde';
$_['text_i_am_returning_customer'] = 'Ich bin bereits Kunde';
$_['text_forgotten']               = 'Passwort vergessen';

// Entry
$_['entry_email']                  = 'E-Mail-Adresse';
$_['entry_password']               = 'Passwort';

// Error
$_['error_login']                  = 'Achtung: E-Mail-Adresse und/oder Passwort sind nicht korrekt.';
$_['error_attempts']               = 'Achtung: Sie haben die zulässige Anzahl an Anmeldeversuchen überschritten. Bitte versuchen Sie es in 1 Stunde erneut.';
$_['error_approved']               = 'Achtung: Ihr Konto muss erst freigeschaltet werden, bevor Sie sich anmelden können.';