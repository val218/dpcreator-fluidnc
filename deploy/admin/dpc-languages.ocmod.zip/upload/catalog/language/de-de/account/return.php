<?php
// Heading
$_['heading_title']      = 'Rücksendungen';

// Text
$_['text_account']       = 'Konto';
$_['text_return']        = 'Rücksendeinformationen';
$_['text_return_detail'] = 'Rücksendedetails';
$_['text_description']   = 'Bitte füllen Sie das folgende Formular aus, um eine Rücksendenummer (RMA) anzufordern.';
$_['text_order']         = 'Bestellinformationen';
$_['text_product']       = 'Produktinformationen';
$_['text_reason']        = 'Rücksendegrund';
$_['text_message']       = '<p>Vielen Dank für Ihre Rücksendeanfrage. Sie wurde zur Bearbeitung an die zuständige Abteilung weitergeleitet.</p><p> Über den Stand Ihrer Anfrage informieren wir Sie per E-Mail.</p>';
$_['text_return_id']     = 'Rücksendenr.:';
$_['text_order_id']      = 'Bestellnr.:';
$_['text_date_ordered']  = 'Bestelldatum:';
$_['text_status']        = 'Status:';
$_['text_date_added']    = 'Erstellt am:';
$_['text_comment']       = 'Anmerkungen zur Rücksendung';
$_['text_history']       = 'Rücksendeverlauf';
$_['text_empty']         = 'Sie haben bisher keine Rücksendungen getätigt!';
$_['text_agree']         = 'Ich habe die <a href="%s" class="agree"><b>%s</b></a> gelesen und bin damit einverstanden';

// Column
$_['column_return_id']   = 'Rücksendenr.';
$_['column_order_id']    = 'Bestellnr.';
$_['column_status']      = 'Status';
$_['column_date_added']  = 'Datum';
$_['column_customer']    = 'Kunde';
$_['column_product']     = 'Produktname';
$_['column_model']       = 'Modell';
$_['column_quantity']    = 'Menge';
$_['column_price']       = 'Preis';
$_['column_opened']      = 'Geöffnet';
$_['column_comment']     = 'Anmerkung';
$_['column_reason']      = 'Grund';
$_['column_action']      = 'Aktion';

// Entry
$_['entry_order_id']     = 'Bestellnummer';
$_['entry_date_ordered'] = 'Bestelldatum';
$_['entry_firstname']    = 'Vorname';
$_['entry_lastname']     = 'Nachname';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telefon';
$_['entry_product']      = 'Produktname';
$_['entry_model']        = 'Artikelnummer';
$_['entry_quantity']     = 'Menge';
$_['entry_reason']       = 'Rücksendegrund';
$_['entry_opened']       = 'Produkt wurde geöffnet';
$_['entry_fault_detail'] = 'Fehlerbeschreibung oder weitere Angaben';

// Error
$_['text_error']         = 'Die gewünschte Rücksendung wurde nicht gefunden!';
$_['error_order_id']     = 'Bestellnummer erforderlich!';
$_['error_firstname']    = 'Der Vorname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_lastname']     = 'Der Nachname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_email']        = 'Die E-Mail-Adresse scheint ungültig zu sein!';
$_['error_telephone']    = 'Die Telefonnummer muss zwischen 3 und 32 Zeichen lang sein!';
$_['error_product']      = 'Der Produktname muss mehr als 3 und weniger als 255 Zeichen lang sein!';
$_['error_model']        = 'Die Artikelnummer muss mehr als 3 und weniger als 64 Zeichen lang sein!';
$_['error_reason']       = 'Bitte wählen Sie einen Rücksendegrund!';
$_['error_agree']        = 'Achtung: Bitte akzeptieren Sie die %s!';