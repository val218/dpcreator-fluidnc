<?php
// Heading
$_['heading_title']  = 'Passwort ändern';

// Text
$_['text_account']   = 'Konto';
$_['text_password']  = 'Ihr Passwort';
$_['text_success']   = 'Ihr Passwort wurde erfolgreich geändert.';

// Entry
$_['entry_password'] = 'Passwort';
$_['entry_confirm']  = 'Passwort bestätigen';

// Error
$_['error_password'] = 'Das Passwort muss zwischen 4 und 20 Zeichen lang sein!';
$_['error_confirm']  = 'Die Passwortbestätigung stimmt nicht mit dem Passwort überein!';