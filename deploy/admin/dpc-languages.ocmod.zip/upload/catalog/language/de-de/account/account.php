<?php
// Heading
$_['heading_title']       = 'Mein Konto';

// Text
$_['text_account']        = 'Konto';
$_['text_my_account']     = 'Mein Konto';
$_['text_my_orders']      = 'Meine Bestellungen';
$_['text_my_affiliate']   = 'Mein Partnerkonto';
$_['text_my_newsletter']  = 'Newsletter';
$_['text_edit']           = 'Kontodaten bearbeiten';
$_['text_password']       = 'Passwort ändern';
$_['text_address']        = 'Adressbuch bearbeiten';
$_['text_credit_card']    = 'Gespeicherte Kreditkarten verwalten';
$_['text_wishlist']       = 'Wunschzettel bearbeiten';
$_['text_order']          = 'Bestellverlauf ansehen';
$_['text_download']       = 'Downloads';
$_['text_reward']         = 'Ihre Bonuspunkte';
$_['text_return']         = 'Ihre Rücksendeanfragen ansehen';
$_['text_transaction']    = 'Ihre Transaktionen';
$_['text_newsletter']     = 'Newsletter abonnieren / abbestellen';
$_['text_recurring']      = 'Wiederkehrende Zahlungen';
$_['text_transactions']   = 'Transaktionen';
$_['text_affiliate_add']  = 'Als Partner registrieren';
$_['text_affiliate_edit'] = 'Partnerdaten bearbeiten';
$_['text_tracking']       = 'Eigener Partner-Trackingcode';