<?php
// Heading
$_['heading_title']      = 'Adressbuch';

// Text
$_['text_account']       = 'Konto';
$_['text_address_book']  = 'Einträge im Adressbuch';
$_['text_address_add']   = 'Adresse hinzufügen';
$_['text_address_edit']  = 'Adresse bearbeiten';
$_['text_add']           = 'Ihre Adresse wurde erfolgreich hinzugefügt.';
$_['text_edit']          = 'Ihre Adresse wurde erfolgreich aktualisiert.';
$_['text_delete']        = 'Ihre Adresse wurde erfolgreich gelöscht.';
$_['text_empty']         = 'In Ihrem Konto sind keine Adressen gespeichert.';
$_['text_confirm']       = 'Sind Sie sicher?';

// Entry
$_['entry_firstname']    = 'Vorname';
$_['entry_lastname']     = 'Nachname';
$_['entry_company']      = 'Firma';
$_['entry_address_1']    = 'Straße und Hausnummer';
$_['entry_address_2']    = 'Adresszusatz';
$_['entry_postcode']     = 'Postleitzahl';
$_['entry_city']         = 'Ort';
$_['entry_country']      = 'Land';
$_['entry_zone']         = 'Bundesland / Region';
$_['entry_default']      = 'Standardadresse';

// Error
$_['error_delete']       = 'Achtung: Sie müssen mindestens eine Adresse haben!';
$_['error_default']      = 'Achtung: Ihre Standardadresse kann nicht gelöscht werden!';
$_['error_firstname']    = 'Der Vorname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_lastname']     = 'Der Nachname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_address_1']    = 'Die Adresse muss zwischen 3 und 128 Zeichen lang sein!';
$_['error_postcode']     = 'Die Postleitzahl muss zwischen 2 und 10 Zeichen lang sein!';
$_['error_city']         = 'Der Ort muss zwischen 2 und 128 Zeichen lang sein!';
$_['error_country']      = 'Bitte wählen Sie ein Land!';
$_['error_zone']         = 'Bitte wählen Sie ein Bundesland / eine Region!';
$_['error_custom_field'] = '%s erforderlich!';