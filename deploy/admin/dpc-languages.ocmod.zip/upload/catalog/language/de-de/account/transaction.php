<?php
// Heading
$_['heading_title']      = 'Ihre Transaktionen';

// Column
$_['column_date_added']  = 'Datum';
$_['column_description'] = 'Beschreibung';
$_['column_amount']      = 'Betrag (%s)';

// Text
$_['text_account']       = 'Konto';
$_['text_transaction']   = 'Ihre Transaktionen';
$_['text_total']         = 'Ihr aktuelles Guthaben:';
$_['text_empty']         = 'Sie haben noch keine Transaktionen!';