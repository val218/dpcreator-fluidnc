<?php
// Heading
$_['heading_title'] = 'Mein Wunschzettel';

// Text
$_['text_account']  = 'Konto';
$_['text_instock']  = 'Auf Lager';
$_['text_wishlist'] = 'Wunschzettel (%s)';
$_['text_login']    = 'Bitte <a href="%s">melden Sie sich an</a> oder <a href="%s">erstellen Sie ein Konto</a>, um <a href="%s">%s</a> auf Ihren <a href="%s">Wunschzettel</a> zu setzen!';
$_['text_success']  = 'Sie haben <a href="%s">%s</a> auf Ihren <a href="%s">Wunschzettel</a> gesetzt!';
$_['text_remove']   = 'Ihr Wunschzettel wurde geändert!';
$_['text_empty']    = 'Ihr Wunschzettel ist leer.';

// Column
$_['column_image']  = 'Bild';
$_['column_name']   = 'Produktname';
$_['column_model']  = 'Modell';
$_['column_stock']  = 'Lagerbestand';
$_['column_price']  = 'Stückpreis';
$_['column_action'] = 'Aktion';