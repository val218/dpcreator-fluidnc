<?php
// Heading
$_['heading_title'] = 'Abmelden';

// Text
$_['text_message']  = '<p>Sie wurden von Ihrem Konto abgemeldet. Sie können den Computer jetzt sicher verlassen.</p><p>Ihr Warenkorb wurde gespeichert. Die Artikel darin werden wiederhergestellt, sobald Sie sich wieder anmelden.</p>';
$_['text_account']  = 'Konto';
$_['text_logout']   = 'Abmelden';