<?php
// Heading
$_['heading_title']             = 'Ihre Partnerdaten';

// Text
$_['text_account']              = 'Konto';
$_['text_affiliate']            = 'Partnerprogramm';
$_['text_my_affiliate']         = 'Mein Partnerkonto';
$_['text_payment']              = 'Zahlungsinformationen';
$_['text_cheque']               = 'Scheck';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Banküberweisung';
$_['text_success']              = 'Ihr Konto wurde erfolgreich aktualisiert.';
$_['text_agree']                = 'Ich habe die <a href="%s" class="agree"><b>%s</b></a> gelesen und bin damit einverstanden';

// Entry
$_['entry_company']             = 'Firma';
$_['entry_website']             = 'Website';
$_['entry_tax']                 = 'Steuernummer';
$_['entry_payment']             = 'Zahlungsart';
$_['entry_cheque']              = 'Scheckempfänger';
$_['entry_paypal']              = 'PayPal-E-Mail-Konto';
$_['entry_bank_name']           = 'Name der Bank';
$_['entry_bank_branch_number']  = 'ABA/BSB-Nummer (Filialnummer)';
$_['entry_bank_swift_code']     = 'SWIFT-Code';
$_['entry_bank_account_name']   = 'Kontoinhaber';
$_['entry_bank_account_number'] = 'Kontonummer';

// Error
$_['error_agree']               = 'Achtung: Bitte akzeptieren Sie die %s!';
$_['error_cheque']              = 'Scheckempfänger erforderlich!';
$_['error_paypal']              = 'Die PayPal-E-Mail-Adresse scheint ungültig zu sein!';
$_['error_bank_account_name']   = 'Kontoinhaber erforderlich!';
$_['error_bank_account_number'] = 'Kontonummer erforderlich!';
$_['error_custom_field']        = '%s erforderlich!';