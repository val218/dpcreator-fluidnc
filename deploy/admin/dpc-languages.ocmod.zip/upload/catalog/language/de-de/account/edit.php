<?php
// Heading
$_['heading_title']      = 'Meine Kontodaten';

// Text
$_['text_account']       = 'Konto';
$_['text_edit']          = 'Daten bearbeiten';
$_['text_your_details']  = 'Ihre persönlichen Daten';
$_['text_success']       = 'Ihr Konto wurde erfolgreich aktualisiert.';

// Entry
$_['entry_firstname']    = 'Vorname';
$_['entry_lastname']     = 'Nachname';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telefon';

// Error
$_['error_exists']       = 'Achtung: Diese E-Mail-Adresse ist bereits registriert!';
$_['error_firstname']    = 'Der Vorname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_lastname']     = 'Der Nachname muss zwischen 1 und 32 Zeichen lang sein!';
$_['error_email']        = 'Die E-Mail-Adresse scheint ungültig zu sein!';
$_['error_telephone']    = 'Die Telefonnummer muss zwischen 3 und 32 Zeichen lang sein!';
$_['error_custom_field'] = '%s erforderlich!';