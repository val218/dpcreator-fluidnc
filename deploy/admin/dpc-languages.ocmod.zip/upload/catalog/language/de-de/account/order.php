<?php
// Heading
$_['heading_title']         = 'Bestellverlauf';

// Text
$_['text_account']          = 'Konto';
$_['text_order']            = 'Bestellinformationen';
$_['text_order_detail']     = 'Bestelldetails';
$_['text_invoice_no']       = 'Rechnungsnr.:';
$_['text_order_id']         = 'Bestellnr.:';
$_['text_date_added']       = 'Bestelldatum:';
$_['text_shipping_address'] = 'Lieferadresse';
$_['text_shipping_method']  = 'Versandart:';
$_['text_payment_address']  = 'Rechnungsadresse';
$_['text_payment_method']   = 'Zahlungsart:';
$_['text_comment']          = 'Anmerkungen zur Bestellung';
$_['text_history']          = 'Bestellverlauf';
$_['text_success']          = 'Sie haben <a href="%s">%s</a> in Ihren <a href="%s">Warenkorb</a> gelegt!';
$_['text_empty']            = 'Sie haben bisher keine Bestellungen getätigt!';
$_['text_error']            = 'Die gewünschte Bestellung wurde nicht gefunden!';

// Column
$_['column_order_id']       = 'Bestellnr.';
$_['column_customer']       = 'Kunde';
$_['column_product']        = 'Anzahl Produkte';
$_['column_name']           = 'Produktname';
$_['column_model']          = 'Modell';
$_['column_quantity']       = 'Menge';
$_['column_price']          = 'Preis';
$_['column_total']          = 'Gesamt';
$_['column_action']         = 'Aktion';
$_['column_date_added']     = 'Datum';
$_['column_status']         = 'Status';
$_['column_comment']        = 'Anmerkung';

// Error
$_['error_reorder']         = '%s kann derzeit nicht erneut bestellt werden.';