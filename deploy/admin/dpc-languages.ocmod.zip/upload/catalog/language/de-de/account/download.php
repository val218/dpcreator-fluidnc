<?php
// Heading
$_['heading_title']     = 'Meine Downloads';

// Text
$_['text_account']      = 'Konto';
$_['text_downloads']    = 'Downloads';
$_['text_empty']        = 'Sie haben bisher keine Bestellungen mit Downloads getätigt!';

// Column
$_['column_order_id']   = 'Bestellnummer';
$_['column_name']       = 'Name';
$_['column_size']       = 'Größe';
$_['column_date_added'] = 'Hinzugefügt am';