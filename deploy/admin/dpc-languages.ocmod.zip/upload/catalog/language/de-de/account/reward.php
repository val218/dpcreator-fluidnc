<?php
// Heading
$_['heading_title']      = 'Ihre Bonuspunkte';

// Column
$_['column_date_added']  = 'Datum';
$_['column_description'] = 'Beschreibung';
$_['column_points']      = 'Punkte';

// Text
$_['text_account']       = 'Konto';
$_['text_reward']        = 'Bonuspunkte';
$_['text_total']         = 'Ihre Bonuspunkte insgesamt:';
$_['text_empty']         = 'Sie haben noch keine Bonuspunkte!';