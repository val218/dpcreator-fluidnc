<?php
// Heading
$_['heading_title']   = 'Passwort vergessen?';

// Text
$_['text_account']    = 'Konto';
$_['text_forgotten']  = 'Passwort vergessen';
$_['text_your_email'] = 'Ihre E-Mail-Adresse';
$_['text_email']      = 'Geben Sie die E-Mail-Adresse Ihres Kontos ein. Klicken Sie auf „Absenden“, um einen Link zum Zurücksetzen Ihres Passworts per E-Mail zu erhalten.';
$_['text_success']    = 'Eine E-Mail mit einem Bestätigungslink wurde an Ihre E-Mail-Adresse gesendet.';

// Entry
$_['entry_email']     = 'E-Mail-Adresse';
$_['entry_password']  = 'Neues Passwort';
$_['entry_confirm']   = 'Bestätigen';

// Error
$_['error_email']     = 'Achtung: Diese E-Mail-Adresse wurde nicht gefunden, bitte versuchen Sie es erneut!';
$_['error_approved']  = 'Achtung: Ihr Konto muss erst freigeschaltet werden, bevor Sie sich anmelden können.';
$_['error_password']  = 'Das Passwort muss zwischen 4 und 20 Zeichen lang sein!';
$_['error_confirm']   = 'Passwort und Passwortbestätigung stimmen nicht überein!';