<?php
// Heading
$_['heading_title']  = 'Passwort zurücksetzen';

// Text
$_['text_account']   = 'Konto';
$_['text_password']  = 'Geben Sie Ihr neues Passwort ein.';
$_['text_success']   = 'Ihr Passwort wurde erfolgreich geändert.';

// Entry
$_['entry_password'] = 'Passwort';
$_['entry_confirm']  = 'Bestätigen';

// Error
$_['error_password'] = 'Das Passwort muss zwischen 4 und 20 Zeichen lang sein!';
$_['error_confirm']  = 'Passwort und Passwortbestätigung stimmen nicht überein!';
$_['error_code']     = 'Der Code zum Zurücksetzen des Passworts ist ungültig oder wurde bereits verwendet!';