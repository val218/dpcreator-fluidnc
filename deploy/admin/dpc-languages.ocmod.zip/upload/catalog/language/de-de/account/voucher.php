<?php
// Heading
$_['heading_title']    = 'Geschenkgutschein kaufen';

// Text
$_['text_account']     = 'Konto';
$_['text_voucher']     = 'Geschenkgutschein';
$_['text_description'] = 'Der Geschenkgutschein wird dem Empfänger per E-Mail zugesendet, sobald Ihre Bestellung bezahlt ist.';
$_['text_agree']       = 'Mir ist bekannt, dass Geschenkgutscheine nicht erstattet werden können.';
$_['text_message']     = '<p>Vielen Dank für den Kauf eines Geschenkgutscheins! Sobald Ihre Bestellung abgeschlossen ist, erhält der Empfänger eine E-Mail mit allen Angaben zum Einlösen des Gutscheins.</p>';
$_['text_for']         = '%s Geschenkgutschein für %s';

// Entry
$_['entry_to_name']    = 'Name des Empfängers';
$_['entry_to_email']   = 'E-Mail des Empfängers';
$_['entry_from_name']  = 'Ihr Name';
$_['entry_from_email'] = 'Ihre E-Mail';
$_['entry_theme']      = 'Gutscheinmotiv';
$_['entry_message']    = 'Nachricht';
$_['entry_amount']     = 'Betrag';

// Help
$_['help_message']     = 'Optional';
$_['help_amount']      = 'Der Betrag muss zwischen %s und %s liegen';

// Error
$_['error_to_name']    = 'Der Name des Empfängers muss zwischen 1 und 64 Zeichen lang sein!';
$_['error_from_name']  = 'Ihr Name muss zwischen 1 und 64 Zeichen lang sein!';
$_['error_email']      = 'Die E-Mail-Adresse scheint ungültig zu sein!';
$_['error_theme']      = 'Bitte wählen Sie ein Motiv!';
$_['error_amount']     = 'Der Betrag muss zwischen %s und %s liegen!';
$_['error_agree']      = 'Achtung: Sie müssen bestätigen, dass Geschenkgutscheine nicht erstattet werden können!';