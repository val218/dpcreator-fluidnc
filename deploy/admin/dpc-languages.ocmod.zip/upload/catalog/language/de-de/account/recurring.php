<?php
// Heading
$_['heading_title']                        = 'Wiederkehrende Zahlungen';

// Text
$_['text_account']                         = 'Konto';
$_['text_recurring']                       = 'Informationen zur wiederkehrenden Zahlung';
$_['text_recurring_detail']                = 'Details zur wiederkehrenden Zahlung';
$_['text_order_recurring_id']              = 'Abo-Nr.:';
$_['text_date_added']                      = 'Erstellt am:';
$_['text_status']                          = 'Status:';
$_['text_payment_method']                  = 'Zahlungsart:';
$_['text_order_id']                        = 'Bestellnr.:';
$_['text_product']                         = 'Produkt:';
$_['text_quantity']                        = 'Menge:';
$_['text_description']                     = 'Beschreibung';
$_['text_reference']                       = 'Referenz';
$_['text_transaction']                     = 'Transaktionen';
$_['text_status_1']                        = 'Aktiv';
$_['text_status_2']                        = 'Inaktiv';
$_['text_status_3']                        = 'Storniert';
$_['text_status_4']                        = 'Ausgesetzt';
$_['text_status_5']                        = 'Abgelaufen';
$_['text_status_6']                        = 'Ausstehend';
$_['text_transaction_date_added']          = 'Erstellt';
$_['text_transaction_payment']             = 'Zahlung';
$_['text_transaction_outstanding_payment'] = 'Offene Zahlung';
$_['text_transaction_skipped']             = 'Zahlung übersprungen';
$_['text_transaction_failed']              = 'Zahlung fehlgeschlagen';
$_['text_transaction_cancelled']           = 'Storniert';
$_['text_transaction_suspended']           = 'Ausgesetzt';
$_['text_transaction_suspended_failed']    = 'Ausgesetzt wegen fehlgeschlagener Zahlung';
$_['text_transaction_outstanding_failed']  = 'Offene Zahlung fehlgeschlagen';
$_['text_transaction_expired']             = 'Abgelaufen';
$_['text_empty']                           = 'Keine wiederkehrenden Zahlungen gefunden!';
$_['text_error']                           = 'Die gewünschte wiederkehrende Bestellung wurde nicht gefunden!';
$_['text_cancelled']                       = 'Die wiederkehrende Zahlung wurde storniert.';

// Column
$_['column_date_added']                    = 'Datum';
$_['column_type']                          = 'Typ';
$_['column_amount']                        = 'Betrag';
$_['column_status']                        = 'Status';
$_['column_product']                       = 'Produkt';
$_['column_order_recurring_id']            = 'Abo-Nr.';

// Error
$_['error_not_cancelled']                  = 'Fehler: %s';
$_['error_not_found']                      = 'Die wiederkehrende Zahlung konnte nicht storniert werden.';

// Button
$_['button_return']                        = 'Zurücksenden';