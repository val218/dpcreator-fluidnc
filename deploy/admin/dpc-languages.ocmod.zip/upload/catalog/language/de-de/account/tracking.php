<?php
// Heading
$_['heading_title']    = 'Partner-Tracking';

// Text
$_['text_account']     = 'Konto';
$_['text_description'] = 'Damit Sie für Ihre Empfehlungen bezahlt werden, müssen wir sie nachverfolgen können. Dazu fügen wir einen Trackingcode in die Links zu uns ein. Mit den folgenden Werkzeugen können Sie Links zur Website %s erstellen.';

// Entry
$_['entry_code']       = 'Ihr Trackingcode';
$_['entry_generator']  = 'Tracking-Link-Generator';
$_['entry_link']       = 'Tracking-Link';

// Help
$_['help_generator']  = 'Geben Sie den Namen des Produkts ein, auf das Sie verlinken möchten';