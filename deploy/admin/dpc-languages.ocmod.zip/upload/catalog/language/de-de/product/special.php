<?php
// Heading
$_['heading_title']     = 'Angebote';

// Text
$_['text_empty']        = 'Derzeit gibt es keine Angebote.';
$_['text_quantity']     = 'Menge:';
$_['text_manufacturer'] = 'Marke:';
$_['text_model']        = 'Artikelnummer:';
$_['text_points']       = 'Bonuspunkte:';
$_['text_price']        = 'Preis:';
$_['text_tax']          = 'Netto:';
$_['text_compare']      = 'Produktvergleich (%s)';
$_['text_sort']         = 'Sortieren nach:';
$_['text_default']      = 'Standard';
$_['text_name_asc']     = 'Name (A - Z)';
$_['text_name_desc']    = 'Name (Z - A)';
$_['text_price_asc']    = 'Preis (niedrig &gt; hoch)';
$_['text_price_desc']   = 'Preis (hoch &gt; niedrig)';
$_['text_rating_asc']   = 'Bewertung (niedrigste)';
$_['text_rating_desc']  = 'Bewertung (höchste)';
$_['text_model_asc']    = 'Modell (A - Z)';
$_['text_model_desc']   = 'Modell (Z - A)';
$_['text_limit']        = 'Anzeigen:';