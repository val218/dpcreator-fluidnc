<?php
// Text
$_['text_search']              = 'Suche';
$_['text_brand']               = 'Marke';
$_['text_manufacturer']        = 'Marke:';
$_['text_model']               = 'Artikelnummer:';
$_['text_reward']              = 'Bonuspunkte:';
$_['text_points']              = 'Preis in Bonuspunkten:';
$_['text_stock']               = 'Verfügbarkeit:';
$_['text_instock']             = 'Auf Lager';
$_['text_tax']                 = 'Netto:';
$_['text_discount']            = ' oder mehr ';
$_['text_option']              = 'Verfügbare Optionen';
$_['text_minimum']             = 'Die Mindestbestellmenge für dieses Produkt beträgt %s';
$_['text_reviews']             = '%s Bewertungen';
$_['text_write']               = 'Bewertung schreiben';
$_['text_login']               = 'Bitte <a href="%s">melden Sie sich an</a> oder <a href="%s">registrieren Sie sich</a>, um eine Bewertung zu schreiben';
$_['text_no_reviews']          = 'Für dieses Produkt gibt es noch keine Bewertungen.';
$_['text_note']                = '<span class="text-danger">Hinweis:</span> HTML wird nicht übersetzt!';
$_['text_success']             = 'Vielen Dank für Ihre Bewertung. Sie wurde zur Freigabe an den Webmaster gesendet.';
$_['text_related']             = 'Ähnliche Produkte';
$_['text_tags']                = 'Tags:';
$_['text_error']               = 'Produkt nicht gefunden!';
$_['text_payment_recurring']   = 'Zahlungsprofil';
$_['text_trial_description']   = '%s alle %d %s für %d Zahlung(en), danach';
$_['text_payment_description'] = '%s alle %d %s für %d Zahlung(en)';
$_['text_payment_cancel']      = '%s alle %d %s bis zur Kündigung';
$_['text_day']                 = 'Tag';
$_['text_week']                = 'Woche';
$_['text_semi_month']          = 'Halbmonat';
$_['text_month']               = 'Monat';
$_['text_year']                = 'Jahr';

// Entry
$_['entry_qty']                = 'Menge';
$_['entry_name']               = 'Ihr Name';
$_['entry_review']             = 'Ihre Bewertung';
$_['entry_rating']             = 'Bewertung';
$_['entry_good']               = 'Gut';
$_['entry_bad']                = 'Schlecht';

// Tabs
$_['tab_description']          = 'Beschreibung';
$_['tab_attribute']            = 'Technische Daten';
$_['tab_review']               = 'Bewertungen (%s)';

// Error
$_['error_name']               = 'Achtung: Der Name muss zwischen 3 und 25 Zeichen lang sein!';
$_['error_text']               = 'Achtung: Der Bewertungstext muss zwischen 25 und 1000 Zeichen lang sein!';
$_['error_rating']             = 'Achtung: Bitte wählen Sie eine Bewertung!';
$_['error_product']            = "Achtung: Für eine Bewertung ist ein Produkt erforderlich!";