<?php
// Text
$_['text_home']          = 'Startseite';
$_['text_wishlist']      = 'Wunschzettel (%s)';
$_['text_shopping_cart'] = 'Warenkorb';
$_['text_category']      = 'Kategorien';
$_['text_account']       = 'Mein Konto';
$_['text_register']      = 'Registrieren';
$_['text_login']         = 'Anmelden';
$_['text_order']         = 'Bestellverlauf';
$_['text_transaction']   = 'Transaktionen';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Abmelden';
$_['text_checkout']      = 'Zur Kasse';
$_['text_search']        = 'Suche';
$_['text_all']           = 'Alle anzeigen';