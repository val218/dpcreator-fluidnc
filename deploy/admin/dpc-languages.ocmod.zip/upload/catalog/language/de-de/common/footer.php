<?php
// Text
$_['text_information']  = 'Informationen';
$_['text_service']      = 'Kundenservice';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Kontakt';
$_['text_return']       = 'Rücksendungen';
$_['text_sitemap']      = 'Sitemap';
$_['text_manufacturer'] = 'Marken';
$_['text_voucher']      = 'Geschenkgutscheine';
$_['text_affiliate']    = 'Partnerprogramm';
$_['text_special']      = 'Angebote';
$_['text_account']      = 'Mein Konto';
$_['text_order']        = 'Bestellverlauf';
$_['text_wishlist']     = 'Wunschzettel';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Powered by <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';