<?php
// Text
$_['text_items']     = '%s Artikel - %s';
$_['text_empty']     = 'Ihr Warenkorb ist leer!';
$_['text_cart']      = 'Warenkorb ansehen';
$_['text_checkout']  = 'Zur Kasse';
$_['text_recurring'] = 'Zahlungsprofil';