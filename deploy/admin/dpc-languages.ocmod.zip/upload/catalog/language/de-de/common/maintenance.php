<?php
// Heading
$_['heading_title']    = 'Wartungsarbeiten';

// Text
$_['text_maintenance'] = 'Wartungsarbeiten';
$_['text_message']     = '<h1 style="text-align:center;">Wir führen gerade geplante Wartungsarbeiten durch. <br/>Wir sind so bald wie möglich wieder für Sie da. Bitte schauen Sie in Kürze wieder vorbei.</h1>';