/* dpCREATOR WebUI installer, WROOM-32 part (Flash Firmware page).
 *
 * Loaded after the WebUI installer on the page. It replaces DPCWebUiInstaller.install with a
 * version that first asks the board which chip it is ($Board/ID itself does not say):
 *   - [MSG:BoardMem:psram=0:ok] after $Board/ID -> ESP32 (WROOM-32) build (an S3 reports 8192:ok)
 *   - $I   [VER:... FluidNC <build> (esp32-<variant>) :...]  -> ESP32 build, (esp32s3-...) -> S3
 *   - [MSG:BoardChip:esp32] if a later firmware sends it
 *   - opts.chip from the setup steps (the board the customer picked) when the board says nothing
 * ESP32-S3: the full WebUI, licensed to the board (unchanged, /webui.php?f=install).
 * ESP32 (WROOM-32): WebUI Lite, free, no licence: /webui.php?f=lite (webui-lite-index.html of the
 *   webui-latest release, gzipped) goes into the flash as index.html.gz, the stock page kept once
 *   as legacy.html.gz, the same as on the R3. Nothing is deleted before the new page is safely
 *   on the board (sent as webui.tmp, size checked, then renamed).
 */
(function (root) {
  "use strict";
  const W = root.DPCWebUiInstaller;
  if (!W || W.liteReady) return;
  const CTRLZ = 0x1a;
  const FS = {
    localfs: { list: "$LocalFS/List", del: "$LocalFS/Delete=", ren: "$LocalFS/Rename=", tmp: "/localfs/webui.tmp", index: "/localfs/index.html.gz", legacy: "/localfs/legacy.html.gz" },
  };
  const names = (r) => (r.lines || []).map((l) => (/\[FILE:\s*([^|\]]+)\|SIZE:(\d+)/.exec(l) || [])[1]).filter(Boolean).map((s) => s.trim().replace(/^.*\//, ""));
  const sizeOf = (r, n) => { const m = (r.lines || []).map((l) => /\[FILE:\s*([^|\]]+)\|SIZE:(\d+)/.exec(l)).find((m) => m && m[1].trim().replace(/^.*\//, "") === n); return m ? +m[2] : -1; };

  /** "esp32" | "esp32s3" | "" from the $I answer and any BoardChip line. */
  function chipFrom(lines) {
    for (const l of lines) {
      let m = /\[MSG:BoardChip:(esp32s3|esp32)\b/i.exec(l);
      if (m) return m[1].toLowerCase();
      m = /^\[VER:.*\((esp32s3|esp32)-[^)]*\)/i.exec(l);
      if (m) return m[1].toLowerCase();
    }
    return "";
  }

  async function install(port, api, ui, opts) {
    opts = opts || {};
    const log = ui.log;
    const link = W.Link(port, log);
    await new Promise((r) => setTimeout(r, 600));
    link.drain();

    ui.step("Reading the board");
    let idm = null;
    for (let i = 0; i < 2 && !idm; i++) {
      link.drain();
      await link.send("$Board/ID");
      idm = await link.line(/\[MSG:BoardID:([0-9A-F]{12}):api=(\d+)\]/, 3000);
    }
    let mem = null;
    const extra = [];
    if (idm) {
      // [MSG:BoardMem:..] and [MSG:BoardChip:..] may follow, then ok
      for (;;) {
        const m = await link.line(/^\[MSG:Board(Mem|Chip):.*\]$|^ok$/, 1000);
        if (!m || m[0] === "ok") break;
        extra.push(m[0]);
        if (m[1] === "Mem") mem = /\[MSG:BoardMem:psram=(\d+):(ok|bad)(?::([^\]]*))?\]/.exec(m[0]);
      }
    }
    if (!idm) {
      throw new Error("This board's firmware does not report its ID. Update the controller firmware first " +
        "(Controller firmware tab), then install the WebUI.");
    }
    const iv = await W.command(link, "$I", 3000);
    let chip = chipFrom(extra.concat(iv.lines || []));
    if (!chip && mem) chip = mem[2] === "ok" && +mem[1] === 0 ? "esp32" : "";
    const told = String(opts.chip || "").toLowerCase();
    if (!chip && (told === "esp32" || told === "esp32s3")) chip = told;
    const lite = chip === "esp32";
    if (!lite && mem && mem[2] === "bad") {
      throw new Error("This board's ESP32-S3 module is not supported: " + (mem[3] || "no PSRAM found.") +
        " The WebUI was not installed and none of your board licences was used.");
    }
    const board = idm[1];
    ui.board(board);

    link.drain();
    await link.write(new Uint8Array([0x3f]));
    const stl = await link.line(/^<([A-Za-z]+)/, 3000);
    if (stl && !/^(Idle|Alarm)$/.test(stl[1])) throw new Error("The machine is " + stl[1] + ". Stop the job and try again when it is Idle.");

    const P = FS.localfs;
    let list0 = null;

    ui.step(lite ? "Getting WebUI Lite (free for WROOM-32 boards)" : "Getting the WebUI licensed to this board");
    const file = lite ? await shop.fetchLite(board) : await api.fetchFile(board);
    const bytes = file.bytes;
    if (bytes[bytes.length - 1] === CTRLZ) throw new Error("Unexpected file from the shop, please try again.");

    ui.step(lite ? "Sending WebUI Lite to the board" : "Sending the WebUI to the board");
    if (!list0) list0 = await W.command(link, P.list, 5000);
    const have = names(list0);
    if (have.includes("webui.tmp")) await W.command(link, P.del + P.tmp, 4000);

    link.drain();
    await link.send("$Xmodem/Receive=" + P.tmp);
    await W.xmodemSend(link, bytes, ui.progress);
    const done = await link.line(/Received (\d+) bytes|Reception failed.*|^error:.*/, 8000);
    if (!done || !done[1]) throw new Error("The board did not store the file" + (done ? ": " + done[0] : "."));
    if (+done[1] !== bytes.length) {
      await W.command(link, P.del + P.tmp, 4000);
      throw new Error("The board stored " + done[1] + " of " + bytes.length + " bytes. Nothing was changed; please try again.");
    }
    await link.line(/^ok$/, 2000);

    ui.step(lite ? "Switching the board to WebUI Lite" : "Switching the board to the new WebUI");
    if (have.includes("index.html.gz")) {
      if (!have.includes("legacy.html.gz")) {
        // keep the stock FluidNC page once, as the Classic UI
        const r = await W.command(link, P.ren + P.index + ">" + P.legacy, 5000);
        if (!r.ok) throw new Error("Could not keep the Classic UI (" + (r.error || "") + "). The new WebUI is on the board as webui.tmp.");
      } else {
        const r = await W.command(link, P.del + P.index, 5000);
        if (!r.ok) throw new Error("Could not remove the old WebUI (" + (r.error || "") + ").");
      }
    }
    const r = await W.command(link, P.ren + P.tmp + ">" + P.index, 5000);
    if (!r.ok) throw new Error("Could not activate the new WebUI (" + (r.error || "") + "). Try the install again.");

    const list1 = await W.command(link, P.list, 5000);
    if (sizeOf(list1, "index.html.gz") !== bytes.length) throw new Error("The new WebUI could not be checked on the board. Try the install again.");
    return { board, version: file.version, size: bytes.length, lite, chip: chip || "", path: P.index };
  }

  async function getGz(url, board) {
    const r = await fetch(url, {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-DPC-Installer": "1" },
      body: JSON.stringify({ board }),
    });
    if (!r.ok) {
      let j = {};
      try { j = await r.json(); } catch (e) {}
      const why = {
        login_required: "Log in to your dpcreator.eu account first (WebUI Lite is free).",
        too_many_installs: "Too many installs in the last hour. Please try again later.",
        not_available: "WebUI Lite is not published yet. Please try again later.",
      }[j.error] || "The shop could not prepare WebUI Lite (" + (j.error || r.status) + ").";
      const e = new Error(why); e.code = j.error; throw e;
    }
    const bytes = new Uint8Array(await r.arrayBuffer());
    const want = r.headers.get("X-DPC-Sha256");
    if (want && root.crypto && root.crypto.subtle) {
      const h = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))).map((b) => b.toString(16).padStart(2, "0")).join("");
      if (h !== want) throw new Error("The download was damaged. Please try again.");
    }
    return { bytes, version: r.headers.get("X-DPC-Version") || "" };
  }

  const shop = {
    liteVersion: () => fetch("/webui.php?f=lite-version", { cache: "no-store" }).then((r) => (r.ok ? r.json() : {})).catch(() => ({})),
    fetchLite: (board) => getGz("/webui.php?f=lite", board),
  };

  W.fullInstall = W.install;
  W.install = install;
  W.chipFrom = chipFrom;
  W.shop.liteVersion = shop.liteVersion;
  W.shop.fetchLite = shop.fetchLite;
  W.liteReady = true;

  // WebUI tab: WROOM-32 owners need no licence, so offer WebUI Lite there too.
  function liteCard() {
    const st = document.getElementById("dpcw-state");
    if (!st || document.getElementById("dpcw-lite")) return;
    const box = document.createElement("div");
    box.id = "dpcw-lite";
    box.style.cssText = "margin:12px 0;padding:10px 12px;border:1px solid rgba(128,128,128,.35);border-radius:8px;font-size:14px";
    box.innerHTML = "<b>ESP32 (WROOM-32) board?</b> WebUI Lite is free: the same WebUI with the features a WROOM-32 can't run turned off. " +
      "It works with Studio Basic. <span id=\"dpcw-lite-ver\"></span><br>" +
      "<button type=\"button\" class=\"dpc-fw-btn dpc-fw-btn-flash\" id=\"dpcw-lite-go\" style=\"margin-top:8px;cursor:pointer\">Install WebUI Lite</button> " +
      "<span id=\"dpcw-lite-msg\" style=\"font-size:13px\"></span><pre id=\"dpcw-lite-log\" style=\"display:none;max-height:160px;overflow:auto;font-size:11px\"></pre>";
    st.parentNode.insertBefore(box, st.nextSibling);
    const go = document.getElementById("dpcw-lite-go"), msg = document.getElementById("dpcw-lite-msg"), lg = document.getElementById("dpcw-lite-log");
    shop.liteVersion().then((v) => {
      if (v && v.version) document.getElementById("dpcw-lite-ver").textContent = "(build " + v.version.split(" ")[0] + ")";
      else { go.disabled = true; go.textContent = "WebUI Lite: coming soon"; }
    });
    if (!("serial" in navigator)) { go.disabled = true; go.textContent = "Needs Chrome or Edge on a computer"; }
    go.onclick = async () => {
      let port = null;
      try { port = await W.openSerial(); } catch (e) { return; }
      go.disabled = true; lg.textContent = ""; lg.style.display = "";
      try {
        const r = await install(port, W.shop, {
          log: (l) => { lg.textContent += l + "\n"; lg.scrollTop = lg.scrollHeight; },
          step: (s) => { msg.textContent = s + "…"; },
          board: () => {},
          progress: (p) => { msg.textContent = "Sending… " + Math.round(p * 100) + "%"; },
        }, { chip: "esp32" });
        msg.innerHTML = r.lite ? "<b>WebUI Lite is installed.</b> Open the board's address (for example http://fluidnc.local) and reload with Ctrl+F5."
          : "<b>This board is an ESP32-S3: the full WebUI was installed.</b>";
      } catch (e) {
        msg.textContent = e.message || String(e);
      } finally {
        go.disabled = false;
        if (port) port.close();
      }
    };
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", liteCard); else liteCard();
})(typeof window !== "undefined" ? window : globalThis);
