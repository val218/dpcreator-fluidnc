Configuration templates from the FluidNC community, https://github.com/bdring/fluidnc-config-files
Copied unchanged; licensed under the GNU General Public License v3.0 (LICENSE-GPL-3.0.txt).
Offered on dpcreator.eu as starting points for boards with an ESP32 (WROOM-32). Not tested by dpCREATOR.
