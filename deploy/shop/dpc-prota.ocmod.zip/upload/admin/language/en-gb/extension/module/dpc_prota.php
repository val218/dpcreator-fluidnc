<?php
$_['heading_title'] = 'dpCREATOR look (black, Inter)';
