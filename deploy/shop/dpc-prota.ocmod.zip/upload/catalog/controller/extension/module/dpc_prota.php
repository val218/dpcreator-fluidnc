<?php
/* dpCREATOR look (black, Inter, thin headings): adds its stylesheet at the end of <head> on every shop page. */
class ControllerExtensionModuleDpcProta extends Controller {
	const V = '22';
	public function head(&$route, &$data, &$output) {
		if (!$this->config->get('module_dpc_prota_status') || strpos($output, 'dpc-prota.css') !== false) return;
		$base = $this->config->get('config_ssl') ? $this->config->get('config_ssl') : $this->config->get('config_url');
		$link = '<link rel="stylesheet" id="dpc-prota.css" href="' . $base . 'catalog/view/theme/dpc-prota/prota.css?v=' . self::V . '">';
		$pos = stripos($output, '</head>');
		if ($pos !== false) $output = substr($output, 0, $pos) . $link . substr($output, $pos);
	}
}
