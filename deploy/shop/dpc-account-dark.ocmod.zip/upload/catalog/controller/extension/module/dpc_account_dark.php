<?php
/* dpCREATOR: dark colours for Modern Customer Account on the Journal3 dark skin. Runs after Modern Account's event. */
class ControllerExtensionModuleDpcAccountDark extends Controller {
	public function after(&$route, &$data, &$output) {
		if (!$this->config->get('module_dpc_account_dark_status') || strpos($output, 'id="mca"') === false) return;
		$css = '<style id="dpc-mca-dark">'
		. 'body #mca{--mca-ink:#EEF2F5;--mca-muted:#9AA7B4;--mca-line:#26303A;--mca-soft:#1B232C;--mca-tint:color-mix(in srgb,var(--mca-accent) 18%,#151B22);--mca-tint2:color-mix(in srgb,var(--mca-accent) 30%,#151B22);font-family:inherit}'
		. 'body #mca a{color:#7CCBF7}body #mca .mca-btn-fill,body #mca .mca-btn-fill:hover{color:#fff}'
		. 'body #mca .mca-nav,body #mca .mca-card,body #mca .mca-tile,body #mca .mca-product{background:#151B22;border-color:#26303A}'
		. 'body #mca .mca-nav-a.mca-on,body #mca .mca-avatar{color:#7CCBF7}'
		. 'body #mca .mca-who,body #mca .mca-logout,body #mca .mca-table td,body #mca .mca-table tr{border-color:#26303A}'
		. 'body #mca .mca-step-bar,body #mca .mca-bar{background:#26303A}'
		. 'body #mca .mca-coupon{background:#10151B;border-color:#3A5A86}body #mca .mca-coupon-old{background:#10151B;border-color:#26303A}'
		. 'body #mca .mca-btn-line{background:transparent;border-color:#7CCBF7;color:#7CCBF7}'
		. 'body #mca .mca-tag-hunt,body #mca .mca-coin-on{background:#3A2E12;color:#F2C46B}body #mca .mca-hint{background:#2A2312;color:#F2DDB0}'
		. 'body #mca .mca-tag-old,body #mca .mca-chip,body #mca .mca-chip-closed{background:#26303A;color:#C3CCD5}'
		. 'body #mca .mca-chip-delivered,body #mca .mca-check-on .mca-tick{background:#173A27;color:#7FD6A2}'
		. 'body #mca .mca-chip-placed,body #mca .mca-chip-preparing{background:#3A2614;color:#F2B27A}'
		. 'body #mca .mca-address{border-color:#33404C}body #mca .mca-tick{border-color:#5A6774}'
		. 'body #mca input,body #mca select{background:#10151B;color:#EEF2F5;border-color:#33404C}'
		. '</style>';
		$output = str_replace('<div id="mca"', $css . '<div id="mca"', $output);
	}
}
