<?php
$_['heading_title'] = 'Account page: dark colours (dpCREATOR)';
