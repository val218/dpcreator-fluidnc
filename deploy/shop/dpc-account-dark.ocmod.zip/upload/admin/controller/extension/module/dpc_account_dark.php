<?php
class ControllerExtensionModuleDpcAccountDark extends Controller {
	public function install() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_account_dark');
		$this->model_setting_event->addEvent('dpc_account_dark', 'catalog/view/account/account/after', 'extension/module/dpc_account_dark/after', 1, 5);
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_dpc_account_dark', array('module_dpc_account_dark_status' => 1));
	}
	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_account_dark');
	}
	public function index() {
		$this->load->model('setting/setting');
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->user->hasPermission('modify', 'extension/module/dpc_account_dark')) {
			$this->model_setting_setting->editSetting('module_dpc_account_dark', array('module_dpc_account_dark_status' => empty($this->request->post['status']) ? 0 : 1));
			$this->session->data['success'] = 'Saved.';
			$this->response->redirect($this->url->link('extension/module/dpc_account_dark', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->document->setTitle('Account page: dark colours');
		$data['status'] = $this->config->get('module_dpc_account_dark_status');
		$data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
		unset($this->session->data['success']);
		$data['action'] = $this->url->link('extension/module/dpc_account_dark', 'user_token=' . $this->session->data['user_token'], true);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_account_dark', $data));
	}
}
