<?php
// dpCREATOR social login: Google and Facebook (OAuth 2.0, server-side code flow).
class DpcSocial {
	const P = array(
		'google' => array(
			'auth' => 'https://accounts.google.com/o/oauth2/v2/auth',
			'token' => 'https://oauth2.googleapis.com/token',
			'user' => 'https://openidconnect.googleapis.com/v1/userinfo',
			'scope' => 'openid email profile'
		),
		'facebook' => array(
			'auth' => 'https://www.facebook.com/v19.0/dialog/oauth',
			'token' => 'https://graph.facebook.com/v19.0/oauth/access_token',
			'user' => 'https://graph.facebook.com/v19.0/me?fields=id,first_name,last_name,email',
			'scope' => 'email,public_profile'
		)
	);

	public static function table($db) {
		$db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_social` (
			`provider` VARCHAR(16) NOT NULL,
			`subject` VARCHAR(64) NOT NULL,
			`customer_id` INT(11) NOT NULL,
			`email` VARCHAR(96) NOT NULL DEFAULT '',
			`created` DATETIME NOT NULL,
			`last_login` DATETIME NOT NULL,
			PRIMARY KEY (`provider`, `subject`),
			KEY `customer` (`customer_id`)
		) DEFAULT CHARSET=utf8mb4");
	}

	public static function http($url, $post = null) {
		$ch = curl_init($url);
		curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => array('Accept: application/json')));
		if ($post !== null) {
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		}
		$body = curl_exec($ch);
		$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$j = json_decode((string)$body, true);
		return array($code, is_array($j) ? $j : array());
	}

	public static function bearer($url, $token) {
		$ch = curl_init($url);
		curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => array('Accept: application/json', 'Authorization: Bearer ' . $token)));
		$body = curl_exec($ch);
		$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$j = json_decode((string)$body, true);
		return array($code, is_array($j) ? $j : array());
	}
}
