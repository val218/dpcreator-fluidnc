<?php
$_['heading_title'] = 'Social login (Google, Facebook)';
