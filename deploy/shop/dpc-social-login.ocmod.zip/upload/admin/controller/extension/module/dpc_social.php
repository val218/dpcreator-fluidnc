<?php
// dpCREATOR social login: settings (Google and Facebook app keys are entered here by the shop owner).
class ControllerExtensionModuleDpcSocial extends Controller {
	private $error = array();

	public function install() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_social');
		$this->model_setting_event->addEvent('dpc_social', 'catalog/view/common/footer/after', 'extension/module/dpc_social/eventFooter');
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_social` (
			`provider` VARCHAR(16) NOT NULL, `subject` VARCHAR(64) NOT NULL, `customer_id` INT(11) NOT NULL,
			`email` VARCHAR(96) NOT NULL DEFAULT '', `created` DATETIME NOT NULL, `last_login` DATETIME NOT NULL,
			PRIMARY KEY (`provider`, `subject`), KEY `customer` (`customer_id`)) DEFAULT CHARSET=utf8mb4");
	}

	public function uninstall() {
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('dpc_social');
	}

	public function index() {
		$this->document->setTitle('Social login (Google, Facebook)');
		$this->load->model('setting/setting');
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->user->hasPermission('modify', 'extension/module/dpc_social')) {
			$keep = $this->model_setting_setting->getSetting('module_dpc_social');
			$post = $this->request->post;
			foreach (array('google', 'facebook') as $p) {
				// an empty secret field keeps the saved secret (it is never shown again)
				if (isset($post['module_dpc_social_' . $p . '_secret']) && trim($post['module_dpc_social_' . $p . '_secret']) === '' && !empty($keep['module_dpc_social_' . $p . '_secret']) && empty($post['clear_' . $p])) {
					$post['module_dpc_social_' . $p . '_secret'] = $keep['module_dpc_social_' . $p . '_secret'];
				}
				unset($post['clear_' . $p]);
				$post['module_dpc_social_' . $p . '_id'] = trim((string)($post['module_dpc_social_' . $p . '_id'] ?? ''));
				$post['module_dpc_social_' . $p . '_secret'] = trim((string)($post['module_dpc_social_' . $p . '_secret'] ?? ''));
			}
			$this->model_setting_setting->editSetting('module_dpc_social', $post);
			$this->session->data['success'] = 'Saved.';
			$this->response->redirect($this->url->link('extension/module/dpc_social', 'user_token=' . $this->session->data['user_token'], true));
		}
		$s = $this->model_setting_setting->getSetting('module_dpc_social');
		$data = array();
		$data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
		unset($this->session->data['success']);
		$data['status'] = !empty($s['module_dpc_social_status']);
		foreach (array('google', 'facebook') as $p) {
			$data[$p . '_id'] = isset($s['module_dpc_social_' . $p . '_id']) ? $s['module_dpc_social_' . $p . '_id'] : '';
			$data[$p . '_has_secret'] = !empty($s['module_dpc_social_' . $p . '_secret']);
		}
		// redirect URIs and site addresses for every store
		$this->load->model('setting/store');
		$stores = array(array('name' => $this->config->get('config_name'), 'url' => HTTPS_CATALOG));
		foreach ($this->model_setting_store->getStores() as $st) {
			$stores[] = array('name' => $st['name'], 'url' => $st['ssl'] ?: $st['url']);
		}
		$data['stores'] = array();
		foreach ($stores as $st) {
			$u = rtrim($st['url'], '/');
			$data['stores'][] = array('name' => $st['name'], 'origin' => preg_replace('~^(https?://[^/]+).*$~', '$1', $u), 'google' => $u . '/index.php?route=extension/module/dpc_social/callback&p=google', 'facebook' => $u . '/index.php?route=extension/module/dpc_social/callback&p=facebook');
		}
		$data['linked'] = 0;
		$t = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "dpc_social'");
		if ($t->num_rows) {
			$data['linked'] = (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_social`")->row['n'];
		}
		$data['action'] = $this->url->link('extension/module/dpc_social', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		$data['privacy'] = (int)$this->config->get('config_account_id');
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/dpc_social', $data));
	}
}
