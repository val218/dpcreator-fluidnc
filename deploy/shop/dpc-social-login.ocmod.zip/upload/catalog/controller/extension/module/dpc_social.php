<?php
// dpCREATOR social login (Google, Facebook) for OpenCart 3.
//   start:    index.php?route=extension/module/dpc_social/start&p=google|facebook[&r=<return url>]
//   callback: index.php?route=extension/module/dpc_social/callback&p=google|facebook   (the redirect URI to register)
//   confirm:  first sign-in with a new email shows a short "create account" step with the privacy tick box
require_once(DIR_SYSTEM . 'library/dpcsocial.php');

class ControllerExtensionModuleDpcSocial extends Controller {
	private function on($p) {
		if (!$this->config->get('module_dpc_social_status') || !isset(DpcSocial::P[$p])) {
			return false;
		}
		return $this->config->get('module_dpc_social_' . $p . '_id') && $this->config->get('module_dpc_social_' . $p . '_secret');
	}

	private function redirectUri($p) {
		$base = !empty($this->request->server['HTTPS']) && $this->request->server['HTTPS'] !== 'off' ? $this->config->get('config_ssl') : $this->config->get('config_url');
		return rtrim($base, '/') . '/index.php?route=extension/module/dpc_social/callback&p=' . $p;
	}

	private function fail($msg) {
		$this->session->data['error'] = $msg;
		$this->response->redirect($this->url->link('account/login', '', true));
	}

	private function t($k) {
		$lang = substr((string)$this->config->get('config_language'), 0, 2);
		$T = array(
			'off' => array('en' => 'This sign-in option is not available.', 'lv' => 'Šī pieteikšanās iespēja nav pieejama.', 'de' => 'Diese Anmeldeoption ist nicht verfügbar.', 'ru' => 'Этот способ входа недоступен.'),
			'cancel' => array('en' => 'Sign-in was cancelled or failed. Please try again or use your email and password.', 'lv' => 'Pieteikšanās tika atcelta vai neizdevās. Mēģiniet vēlreiz vai izmantojiet e-pastu un paroli.', 'de' => 'Die Anmeldung wurde abgebrochen oder ist fehlgeschlagen. Bitte versuchen Sie es erneut oder nutzen Sie E-Mail und Passwort.', 'ru' => 'Вход отменён или не удался. Попробуйте ещё раз или войдите по email и паролю.'),
			'noemail' => array('en' => 'Your account did not share a verified email address, so we can\'t sign you in this way. Please register with your email instead.', 'lv' => 'Jūsu konts nenodeva apstiprinātu e-pasta adresi, tāpēc šādi pieteikties nevar. Lūdzu, reģistrējieties ar e-pastu.', 'de' => 'Ihr Konto hat keine bestätigte E-Mail-Adresse übermittelt, daher ist diese Anmeldung nicht möglich. Bitte registrieren Sie sich mit Ihrer E-Mail.', 'ru' => 'Ваш аккаунт не передал подтверждённый email, поэтому так войти нельзя. Зарегистрируйтесь по email.'),
			'locked' => array('en' => 'This customer account is disabled or waiting for approval. Please contact us.', 'lv' => 'Šis klienta konts ir atslēgts vai gaida apstiprinājumu. Lūdzu, sazinieties ar mums.', 'de' => 'Dieses Kundenkonto ist deaktiviert oder wartet auf Freigabe. Bitte kontaktieren Sie uns.', 'ru' => 'Этот аккаунт отключён или ожидает подтверждения. Свяжитесь с нами.'),
			'c_title' => array('en' => 'Create your account', 'lv' => 'Izveidojiet savu kontu', 'de' => 'Konto erstellen', 'ru' => 'Создайте аккаунт'),
			'c_text' => array('en' => 'We\'ll create a customer account with these details. You can sign in with %s next time, or set a password later.', 'lv' => 'Mēs izveidosim klienta kontu ar šiem datiem. Nākamreiz varēsiet pieteikties ar %s vai vēlāk iestatīt paroli.', 'de' => 'Wir erstellen ein Kundenkonto mit diesen Daten. Beim nächsten Mal melden Sie sich mit %s an oder legen später ein Passwort fest.', 'ru' => 'Мы создадим аккаунт с этими данными. В следующий раз можно войти через %s или позже задать пароль.'),
			'c_name' => array('en' => 'Name', 'lv' => 'Vārds', 'de' => 'Name', 'ru' => 'Имя'),
			'c_agree' => array('en' => 'I have read and agree to the', 'lv' => 'Esmu izlasījis un piekrītu', 'de' => 'Ich habe gelesen und stimme zu:', 'ru' => 'Я прочитал(а) и согласен(на) с'),
			'c_btn' => array('en' => 'Create account and sign in', 'lv' => 'Izveidot kontu un pieteikties', 'de' => 'Konto erstellen und anmelden', 'ru' => 'Создать аккаунт и войти'),
			'c_need' => array('en' => 'Please tick the box to continue.', 'lv' => 'Lai turpinātu, atzīmējiet rūtiņu.', 'de' => 'Bitte setzen Sie das Häkchen, um fortzufahren.', 'ru' => 'Отметьте флажок, чтобы продолжить.'),
			'c_back' => array('en' => 'Cancel', 'lv' => 'Atcelt', 'de' => 'Abbrechen', 'ru' => 'Отмена')
		);
		return isset($T[$k][$lang]) ? $T[$k][$lang] : $T[$k]['en'];
	}

	public function start() {
		$p = isset($this->request->get['p']) ? (string)$this->request->get['p'] : '';
		if (!$this->on($p)) {
			return $this->fail($this->t('off'));
		}
		$state = bin2hex(random_bytes(16));
		$this->session->data['dpc_social_state'] = $state;
		$this->session->data['dpc_social_p'] = $p;
		$ret = isset($this->request->get['r']) ? html_entity_decode((string)$this->request->get['r'], ENT_QUOTES, 'UTF-8') : '';
		$own = array((string)$this->config->get('config_url'), (string)$this->config->get('config_ssl'));
		$ok = false;
		foreach ($own as $o) {
			if ($o !== '' && strpos($ret, $o) === 0) {
				$ok = true;
			}
		}
		$this->session->data['dpc_social_return'] = $ok && strpos($ret, 'account/logout') === false ? $ret : '';
		$q = array(
			'client_id' => $this->config->get('module_dpc_social_' . $p . '_id'),
			'redirect_uri' => $this->redirectUri($p),
			'response_type' => 'code',
			'scope' => DpcSocial::P[$p]['scope'],
			'state' => $state
		);
		if ($p === 'google') {
			$q['prompt'] = 'select_account';
		}
		$this->response->redirect(DpcSocial::P[$p]['auth'] . '?' . http_build_query($q));
	}

	public function callback() {
		$p = isset($this->request->get['p']) ? (string)$this->request->get['p'] : '';
		$state = isset($this->session->data['dpc_social_state']) ? $this->session->data['dpc_social_state'] : '';
		unset($this->session->data['dpc_social_state']);
		if (!$this->on($p) || $state === '' || !isset($this->request->get['state']) || !hash_equals($state, (string)$this->request->get['state']) || empty($this->request->get['code'])) {
			return $this->fail($this->t('cancel'));
		}
		list($code, $tok) = DpcSocial::http(DpcSocial::P[$p]['token'], array(
			'client_id' => $this->config->get('module_dpc_social_' . $p . '_id'),
			'client_secret' => html_entity_decode((string)$this->config->get('module_dpc_social_' . $p . '_secret'), ENT_QUOTES, 'UTF-8'),
			'redirect_uri' => $this->redirectUri($p),
			'code' => (string)$this->request->get['code'],
			'grant_type' => 'authorization_code'
		));
		if ($code !== 200 || empty($tok['access_token'])) {
			return $this->fail($this->t('cancel'));
		}
		list($code, $u) = DpcSocial::bearer(DpcSocial::P[$p]['user'], $tok['access_token']);
		if ($code !== 200) {
			return $this->fail($this->t('cancel'));
		}
		if ($p === 'google') {
			$sub = isset($u['sub']) ? (string)$u['sub'] : '';
			$email = !empty($u['email_verified']) && !empty($u['email']) ? (string)$u['email'] : '';
			$first = isset($u['given_name']) ? (string)$u['given_name'] : '';
			$last = isset($u['family_name']) ? (string)$u['family_name'] : '';
		} else {
			$sub = isset($u['id']) ? (string)$u['id'] : '';
			$email = !empty($u['email']) ? (string)$u['email'] : ''; // Facebook only returns confirmed addresses
			$first = isset($u['first_name']) ? (string)$u['first_name'] : '';
			$last = isset($u['last_name']) ? (string)$u['last_name'] : '';
		}
		if ($sub === '') {
			return $this->fail($this->t('cancel'));
		}
		DpcSocial::table($this->db);
		// 1. known link
		$link = $this->db->query("SELECT s.customer_id, c.email, c.status FROM `" . DB_PREFIX . "dpc_social` s JOIN `" . DB_PREFIX . "customer` c ON c.customer_id = s.customer_id WHERE s.provider = '" . $this->db->escape($p) . "' AND s.subject = '" . $this->db->escape($sub) . "'")->row;
		if ($link) {
			return $this->finish($p, $sub, $link['email']);
		}
		if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
			return $this->fail($this->t('noemail'));
		}
		// 2. existing customer with the same verified email
		$c = $this->db->query("SELECT customer_id, email FROM `" . DB_PREFIX . "customer` WHERE LOWER(email) = '" . $this->db->escape(utf8_strtolower($email)) . "'")->row;
		if ($c) {
			return $this->finish($p, $sub, $c['email']);
		}
		// 3. new customer: confirm step (privacy policy)
		$this->session->data['dpc_social_new'] = array('p' => $p, 'sub' => $sub, 'email' => $email, 'first' => utf8_substr(trim($first), 0, 32), 'last' => utf8_substr(trim($last), 0, 32), 't' => time());
		$this->response->redirect($this->url->link('extension/module/dpc_social/confirm', '', true));
	}

	private function finish($p, $sub, $email) {
		if (!$this->customer->login($email, '', true)) {
			return $this->fail($this->t('locked'));
		}
		$this->db->query("INSERT INTO `" . DB_PREFIX . "dpc_social` SET provider = '" . $this->db->escape($p) . "', subject = '" . $this->db->escape($sub) . "', customer_id = '" . (int)$this->customer->getId() . "', email = '" . $this->db->escape($email) . "', created = NOW(), last_login = NOW() ON DUPLICATE KEY UPDATE customer_id = VALUES(customer_id), email = VALUES(email), last_login = NOW()");
		unset($this->session->data['guest']);
		$this->load->model('account/address');
		if ($this->config->get('config_tax_customer') == 'payment') {
			$this->session->data['payment_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
		}
		if ($this->config->get('config_tax_customer') == 'shipping') {
			$this->session->data['shipping_address'] = $this->model_account_address->getAddress($this->customer->getAddressId());
		}
		if (isset($this->session->data['wishlist']) && is_array($this->session->data['wishlist'])) {
			$this->load->model('account/wishlist');
			foreach ($this->session->data['wishlist'] as $key => $product_id) {
				$this->model_account_wishlist->addWishlist($product_id);
				unset($this->session->data['wishlist'][$key]);
			}
		}
		$this->load->model('account/customer');
		if (method_exists($this->model_account_customer, 'addLogin')) {
			$this->model_account_customer->addLogin($this->customer->getId(), $this->request->server['REMOTE_ADDR']);
		}
		$ret = isset($this->session->data['dpc_social_return']) ? $this->session->data['dpc_social_return'] : '';
		unset($this->session->data['dpc_social_return'], $this->session->data['dpc_social_new']);
		$this->response->redirect($ret !== '' ? $ret : $this->url->link('account/account', '', true));
	}

	public function confirm() {
		$n = isset($this->session->data['dpc_social_new']) ? $this->session->data['dpc_social_new'] : null;
		if (!$n || time() - $n['t'] > 900) {
			unset($this->session->data['dpc_social_new']);
			return $this->response->redirect($this->url->link('account/login', '', true));
		}
		$err = '';
		$pid = (int)$this->config->get('config_account_id');
		if ($this->request->server['REQUEST_METHOD'] === 'POST') {
			$first = utf8_substr(trim((string)($this->request->post['firstname'] ?? '')), 0, 32);
			$last = utf8_substr(trim((string)($this->request->post['lastname'] ?? '')), 0, 32);
			if ($pid && empty($this->request->post['agree'])) {
				$err = $this->t('c_need');
			} elseif ($first === '') {
				$err = $this->t('c_need');
			} else {
				$this->load->model('account/customer');
				ob_start(); // a failing welcome e-mail must not stop the sign-in
				try {
					$this->model_account_customer->addCustomer(array(
					'customer_group_id' => (int)$this->config->get('config_customer_group_id'),
					'firstname' => $first, 'lastname' => $last !== '' ? $last : '-',
					'email' => $n['email'], 'telephone' => '',
					'password' => bin2hex(random_bytes(24)),
					'newsletter' => 0, 'custom_field' => array()
					));
				} catch (\Throwable $e) {
					// the customer row is written before the welcome e-mail is sent
				}
				ob_end_clean();
				return $this->finish($n['p'], $n['sub'], $n['email']);
			}
		}
		$this->document->setTitle($this->t('c_title'));
		$h = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
		$agree = '';
		if ($pid) {
			$this->load->model('catalog/information');
			$info = $this->model_catalog_information->getInformation($pid);
			if ($info) {
				$agree = '<div class="checkbox"><label><input type="checkbox" name="agree" value="1"> ' . $h($this->t('c_agree')) . ' <a href="' . $h($this->url->link('information/information', 'information_id=' . $pid, true)) . '" target="_blank" rel="noopener"><b>' . $h($info['title']) . '</b></a></label></div>';
			}
		}
		$html = '<div class="container" id="dpc-social-confirm" style="max-width:560px;margin:40px auto">'
			. '<h1>' . $h($this->t('c_title')) . '</h1>'
			. ($err ? '<div class="alert alert-danger">' . $h($err) . '</div>' : '')
			. '<p>' . $h(sprintf($this->t('c_text'), ucfirst($n['p']))) . '</p>'
			. '<form method="post" action="' . $h($this->url->link('extension/module/dpc_social/confirm', '', true)) . '">'
			. '<div class="form-group"><label>E-mail</label><input class="form-control" value="' . $h($n['email']) . '" disabled></div>'
			. '<div class="form-group"><label>' . $h($this->t('c_name')) . '</label><div class="row"><div class="col-sm-6"><input class="form-control" name="firstname" value="' . $h($n['first']) . '" required></div><div class="col-sm-6"><input class="form-control" name="lastname" value="' . $h($n['last']) . '"></div></div></div>'
			. $agree
			. '<button type="submit" class="btn btn-primary">' . $h($this->t('c_btn')) . '</button> <a class="btn btn-link" href="' . $h($this->url->link('account/login', '', true)) . '">' . $h($this->t('c_back')) . '</a>'
			. '</form></div>';
		$data = array('dpc_html' => $html);
		$data['header'] = $this->load->controller('common/header');
		$data['footer'] = $this->load->controller('common/footer');
		$data['column_left'] = '';
		$data['column_right'] = '';
		$data['content_top'] = '';
		$data['content_bottom'] = '';
		$this->response->setOutput($data['header'] . $html . $data['footer']);
	}

	// Event catalog/view/common/footer/after: add the button script to every shop page (the script only acts on login, register and checkout pages)
	public function eventFooter(&$route, &$args, &$output) {
		if (!$this->config->get('module_dpc_social_status') || $this->customer->isLogged()) {
			return;
		}
		$on = array();
		foreach (array('google', 'facebook') as $p) {
			if ($this->on($p)) {
				$on[] = $p;
			}
		}
		if (!$on) {
			return;
		}
		$tag = '<script>window.dpcSocial=' . json_encode(array('providers' => $on, 'start' => 'index.php?route=extension/module/dpc_social/start', 'lang' => substr((string)$this->config->get('config_language'), 0, 2))) . ';</script><script src="catalog/view/javascript/dpc-social.js?v=1" defer></script>';
		$i = strripos($output, '</body>');
		$output = $i === false ? $output . $tag : substr($output, 0, $i) . $tag . substr($output, $i);
	}

	// Small JSON for the button script: which providers are on.
	public function providers() {
		$out = array();
		foreach (array('google', 'facebook') as $p) {
			if ($this->on($p)) {
				$out[] = $p;
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode(array('providers' => $out, 'logged' => $this->customer->isLogged() ? 1 : 0)));
	}
}
