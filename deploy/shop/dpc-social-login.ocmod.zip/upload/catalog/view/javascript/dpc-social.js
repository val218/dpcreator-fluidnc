/* dpCREATOR social login buttons: shown above the login and register forms and in the checkout login step. */
(function () {
  var C = window.dpcSocial; if (!C || !C.providers || !C.providers.length) return;
  var T = {
    en: { google: 'Sign in with Google', facebook: 'Continue with Facebook', or: 'or' },
    lv: { google: 'Pieteikties ar Google', facebook: 'Turpināt ar Facebook', or: 'vai' },
    de: { google: 'Mit Google anmelden', facebook: 'Weiter mit Facebook', or: 'oder' },
    ru: { google: 'Войти через Google', facebook: 'Продолжить с Facebook', or: 'или' }
  };
  var L = T[C.lang] || T.en;
  var G = '<svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.6 5.4 2.7 13.3l7.9 6.1C12.5 13.6 17.8 9.5 24 9.5z"/><path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 6.9l7.4 5.7c4.3-4 6.9-9.9 6.9-17.1z"/><path fill="#FBBC05" d="M10.6 28.6c-.5-1.4-.8-3-.8-4.6s.3-3.2.8-4.6l-7.9-6.1C1 16.6 0 20.2 0 24s1 7.4 2.7 10.7l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.4-5.7c-2.1 1.4-4.8 2.2-8.5 2.2-6.2 0-11.5-4.1-13.4-9.9l-7.9 6.1C6.6 42.6 14.6 48 24 48z"/></svg>';
  var F = '<svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.96.93-1.96 1.89v2.25h3.33l-.53 3.49h-2.8V24C19.61 23.1 24 18.1 24 12.07z"/></svg>';
  var css = '.dpc-soc{margin:0 0 18px;display:flex;flex-direction:column;gap:10px;max-width:360px}' +
    '.dpc-soc a{display:flex;align-items:center;justify-content:center;gap:10px;height:42px;border-radius:6px;font-weight:600;font-size:15px;text-decoration:none!important;font-family:inherit}' +
    '.dpc-soc .g{background:#fff;color:#1f1f1f!important;border:1px solid #747775}.dpc-soc .f{background:#1877F2;color:#fff!important;border:1px solid #1877F2}' +
    '.dpc-soc a:focus-visible{outline:2px solid #1877F2;outline-offset:2px}' +
    '.dpc-soc .or{display:flex;align-items:center;gap:10px;opacity:.7;font-size:13px;margin-top:4px}.dpc-soc .or:before,.dpc-soc .or:after{content:"";flex:1;border-top:1px solid currentColor;opacity:.35}';
  function block() {
    var d = document.createElement('div'); d.className = 'dpc-soc';
    var ret = encodeURIComponent(location.href.indexOf('account/login') > -1 || location.href.indexOf('account/register') > -1 ? '' : location.href);
    C.providers.forEach(function (p) {
      var a = document.createElement('a');
      a.href = C.start + '&p=' + p + (ret ? '&r=' + ret : '');
      a.className = p === 'google' ? 'g' : 'f';
      a.innerHTML = (p === 'google' ? G : F) + '<span>' + L[p] + '</span>';
      d.appendChild(a);
    });
    var o = document.createElement('div'); o.className = 'or'; o.textContent = L.or; d.appendChild(o);
    return d;
  }
  function place() {
    var done = false;
    var targets = document.querySelectorAll('#account-login form, #account-register form, form[action*="account/login"], form[action*="account/register"], .quick-checkout-wrapper .login-form, .checkout-login, #collapse-checkout-option .panel-body');
    for (var i = 0; i < targets.length; i++) {
      var t = targets[i];
      if (t.closest('.dpc-soc-done') || t.previousElementSibling && t.previousElementSibling.classList && t.previousElementSibling.classList.contains('dpc-soc')) continue;
      if (t.closest('header, .header, #cart, .dropdown-menu')) continue;
      t.parentNode.insertBefore(block(), t);
      t.classList.add('dpc-soc-done');
      done = true;
    }
    return done;
  }
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  function go() { place(); try { new MutationObserver(function () { place(); }).observe(document.body, { childList: true, subtree: true }); } catch (e) {} }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
})();
