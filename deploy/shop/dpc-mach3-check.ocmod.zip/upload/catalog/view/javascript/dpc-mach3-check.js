/* dpCREATOR: free Mach3 profile check for the dpCREATOR Link (parallel port).
   The profile is read in the browser and never uploaded. Only if the visitor signs up
   is the short text summary of the result sent, together with their email. */
(function () {
  'use strict';
  var root = document.getElementById('dpc-m3');
  if (!root) return;

  var OUT = [1, 2, 3, 4, 5, 6, 7, 8, 9, 14, 16, 17];
  var INP = [10, 11, 12, 13, 15];
  var AX = ['X', 'Y', 'Z', 'A', 'B', 'C'];
  var IN_NAMES = ['X ++ (limit)', 'X -- (limit)', 'X Home', 'Y ++ (limit)', 'Y -- (limit)', 'Y Home', 'Z ++ (limit)', 'Z -- (limit)', 'Z Home',
    'A ++ (limit)', 'A -- (limit)', 'A Home', 'B ++ (limit)', 'B -- (limit)', 'B Home', 'C ++ (limit)', 'C -- (limit)', 'C Home',
    'Input #1', 'Input #2', 'Input #3', 'Input #4', 'Probe', 'Index', 'Limit Ovrd', 'EStop', 'THC On', 'THC Up', 'THC Down'];
  for (var i = 1; i <= 15; i++) IN_NAMES.push('OEM Trig #' + i);
  IN_NAMES.push('Timing', 'Jog X++', 'Jog X--', 'Jog Y++', 'Jog Y--', 'Jog Z++', 'Jog Z--', 'Jog A++', 'Jog A--');
  var OUT_NAMES = ['Digit Trig', 'Enable1', 'Enable2', 'Enable3', 'Enable4', 'Enable5', 'Enable6', 'Output #1', 'Output #2', 'Output #3', 'Output #4', 'Output #5', 'Output #6', 'Charge Pump', 'Charge Pump2'];
  for (i = 7; i <= 22; i++) OUT_NAMES.push('Output #' + i);

  var T = {
    en: {
      pick: 'Choose your Mach3 profile (.xml)',
      drop: 'or drop the file here',
      hint: 'Usually in the Mach3 folder, for example C:\\Mach3\\Mach3Mill.xml, or the .xml named after your own profile. The file stays on your computer: it is read in your browser and never uploaded.',
      again: 'Check another profile',
      v_ok: 'Your machine fits the Link',
      v_ok_d: 'Everything in this profile maps to the Link\'s parallel port.',
      v_check: 'Probably fits, but a few things need a closer look',
      v_check_d: 'Send us the result below and we\'ll check it with you.',
      v_no: 'Your machine doesn\'t fit the Link as it is',
      v_no_d: 'The items marked red can\'t be done with the Link\'s single parallel port. The dpCREATOR R3 controller may suit this machine instead: ask us.',
      v_bad: 'This doesn\'t look like a Mach3 profile',
      v_bad_d: 'Choose the .xml file from the Mach3 folder that has the name of the profile you start Mach3 with.',
      found: 'What we found',
      pins: 'Pin map of your parallel port',
      pin: 'Pin', use: 'Used for', free: 'free',
      inv: ' (inverted)',
      port2: 'Uses a second parallel port (port 2). The Link has one 25-pin port.',
      ext: 'Some signals are set on port {n}, which belongs to a motion controller (for example a SmoothStepper or UC300), not to the PC\'s parallel port. The profile doesn\'t show which DB25 pins they use, so we need to look at it with you.',
      ax_ok: '{a} axis: step on pin {s}, direction on pin {d}.',
      ax_pin: '{a} axis uses pin {p}, which is not an output pin on the Link (outputs: 1-9, 14, 16, 17).',
      ax_none: '{a} axis is switched on but has no step or direction pin on the parallel port.',
      ax_bc: '{a} axis is switched on. The Link drives four axes (X, Y, Z, A).',
      no_axes: 'No axes are switched on in this profile.',
      sp_pwm: 'Spindle speed by PWM on pin {p}.',
      sp_step: 'The spindle runs as a step/direction motor (pin {p}). The Link doesn\'t support step/direction spindles.',
      thc: 'Plasma torch height control (THC) is set up. The Link doesn\'t support it.',
      in_ok: '{n}: pin {p}{i}.',
      in_bad: '{n} is on pin {p}. On the Link, inputs can only be on pins 10, 11, 12, 13 and 15.',
      in_count: 'Input pins used: {n} of 5.',
      shared: 'Pin {p} is shared by {n}. That\'s fine for switches wired in series.',
      out_ok: '{n}: pin {p}{i}.',
      out_bad: '{n} is on pin {p}, which is not an output pin on the Link.',
      charge: 'Charge pump on pin {p}: many breakout boards keep the drivers off without this signal. Charge-pump output is planned for the Link; we\'ll confirm it before launch.',
      enc: 'An MPG handwheel or encoder is wired to the parallel port. The Link doesn\'t read these; the SmartTabUI pendant has a handwheel instead.',
      lead_h: 'Tell me when the Link is ready',
      lead_d: 'We\'ll email you once when the Link can be ordered, with your result. We get the result summary above, not your file.',
      email: 'Your email',
      note: 'Anything we should know about your machine? (optional)',
      consent: 'Email me about the dpCREATOR Link. I can ask to be removed at any time.',
      privacy: 'Privacy policy',
      send: 'Send',
      sent: 'Thanks! We\'ll email you when the Link is ready.',
      err: 'That didn\'t work. Check the email address and the tick box, or write to info@dpcreator.eu.'
    },
    lv: {
      pick: 'Izvēlieties savu Mach3 profilu (.xml)',
      drop: 'vai ievelciet failu šeit',
      hint: 'Parasti Mach3 mapē, piemēram C:\\Mach3\\Mach3Mill.xml, vai .xml ar jūsu profila nosaukumu. Fails paliek jūsu datorā: to nolasa pārlūkā, un tas netiek augšupielādēts.',
      again: 'Pārbaudīt citu profilu',
      v_ok: 'Jūsu mašīna der Link',
      v_ok_d: 'Viss šajā profilā atbilst Link paralēlajam portam.',
      v_check: 'Visticamāk der, bet dažas lietas jāapskata tuvāk',
      v_check_d: 'Nosūtiet mums rezultātu zemāk, un mēs to pārbaudīsim kopā ar jums.',
      v_no: 'Jūsu mašīna pašreizējā veidā neder Link',
      v_no_d: 'Sarkanās lietas nevar izdarīt ar Link vienīgo paralēlo portu. Šai mašīnai varētu derēt dpCREATOR R3 kontrolieris: jautājiet mums.',
      v_bad: 'Tas neizskatās pēc Mach3 profila',
      v_bad_d: 'Izvēlieties .xml failu no Mach3 mapes ar tā profila nosaukumu, ar kuru palaižat Mach3.',
      found: 'Ko atradām',
      pins: 'Jūsu paralēlā porta kontaktu karte',
      pin: 'Kontakts', use: 'Izmantots', free: 'brīvs',
      inv: ' (invertēts)',
      port2: 'Izmanto otru paralēlo portu (port 2). Link ir viens 25 kontaktu ports.',
      ext: 'Daži signāli ir iestatīti uz port {n}, kas pieder kustības kontrolierim (piemēram, SmoothStepper vai UC300), nevis datora paralēlajam portam. Profils nerāda, kurus DB25 kontaktus tie izmanto, tāpēc to jāapskata kopā ar jums.',
      ax_ok: '{a} ass: step uz kontakta {s}, virziens uz kontakta {d}.',
      ax_pin: '{a} ass izmanto kontaktu {p}, kas nav Link izejas kontakts (izejas: 1–9, 14, 16, 17).',
      ax_none: '{a} ass ir ieslēgta, bet tai nav step vai virziena kontakta paralēlajā portā.',
      ax_bc: '{a} ass ir ieslēgta. Link vada četras asis (X, Y, Z, A).',
      no_axes: 'Šajā profilā nav ieslēgta neviena ass.',
      sp_pwm: 'Vārpstas ātrums ar PWM uz kontakta {p}.',
      sp_step: 'Vārpsta darbojas kā step/direction motors (kontakts {p}). Link neatbalsta step/direction vārpstas.',
      thc: 'Iestatīta plazmas degļa augstuma kontrole (THC). Link to neatbalsta.',
      in_ok: '{n}: kontakts {p}{i}.',
      in_bad: '{n} ir uz kontakta {p}. Link ieejas var būt tikai uz kontaktiem 10, 11, 12, 13 un 15.',
      in_count: 'Izmantoti ieeju kontakti: {n} no 5.',
      shared: 'Kontaktu {p} kopīgi izmanto {n}. Tas ir labi virknē slēgtiem slēdžiem.',
      out_ok: '{n}: kontakts {p}{i}.',
      out_bad: '{n} ir uz kontakta {p}, kas nav Link izejas kontakts.',
      charge: 'Charge pump uz kontakta {p}: daudzas savienojuma plates bez šī signāla neieslēdz draiverus. Charge pump izeja Link ir plānota; to apstiprināsim pirms pārdošanas sākuma.',
      enc: 'Paralēlajam portam ir pieslēgts MPG rokrats vai enkoderis. Link tos nenolasa; SmartTabUI pultij ir savs rokrats.',
      lead_h: 'Paziņojiet man, kad Link būs gatavs',
      lead_d: 'Mēs jums vienreiz uzrakstīsim, kad Link varēs pasūtīt, kopā ar jūsu rezultātu. Mēs saņemam augstāk redzamo rezultāta kopsavilkumu, nevis jūsu failu.',
      email: 'Jūsu e-pasts',
      note: 'Vai ir kas jāzina par jūsu mašīnu? (nav obligāti)',
      consent: 'Rakstiet man par dpCREATOR Link. Es jebkurā laikā varu lūgt mani dzēst.',
      privacy: 'Privātuma politika',
      send: 'Nosūtīt',
      sent: 'Paldies! Mēs jums uzrakstīsim, kad Link būs gatavs.',
      err: 'Neizdevās. Pārbaudiet e-pasta adresi un atzīmi vai rakstiet uz info@dpcreator.eu.'
    },
    de: {
      pick: 'Mach3-Profil (.xml) auswählen',
      drop: 'oder die Datei hierher ziehen',
      hint: 'Meist im Mach3-Ordner, zum Beispiel C:\\Mach3\\Mach3Mill.xml, oder die .xml mit dem Namen Ihres eigenen Profils. Die Datei bleibt auf Ihrem Computer: Sie wird im Browser gelesen und nie hochgeladen.',
      again: 'Ein anderes Profil prüfen',
      v_ok: 'Ihre Maschine passt zum Link',
      v_ok_d: 'Alles in diesem Profil lässt sich auf den Parallelport des Link abbilden.',
      v_check: 'Passt wahrscheinlich, aber ein paar Dinge brauchen einen genaueren Blick',
      v_check_d: 'Schicken Sie uns das Ergebnis unten, dann prüfen wir es mit Ihnen.',
      v_no: 'Ihre Maschine passt so nicht zum Link',
      v_no_d: 'Die rot markierten Punkte sind mit dem einen Parallelport des Link nicht möglich. Der dpCREATOR R3 Controller könnte für diese Maschine passen: fragen Sie uns.',
      v_bad: 'Das sieht nicht wie ein Mach3-Profil aus',
      v_bad_d: 'Wählen Sie die .xml-Datei im Mach3-Ordner, die den Namen des Profils trägt, mit dem Sie Mach3 starten.',
      found: 'Was wir gefunden haben',
      pins: 'Pinbelegung Ihres Parallelports',
      pin: 'Pin', use: 'Belegt mit', free: 'frei',
      inv: ' (invertiert)',
      port2: 'Nutzt einen zweiten Parallelport (Port 2). Der Link hat einen 25-poligen Port.',
      ext: 'Einige Signale liegen auf Port {n}, der zu einem Motion-Controller gehört (zum Beispiel SmoothStepper oder UC300), nicht zum Parallelport des PCs. Das Profil zeigt nicht, welche DB25-Pins sie nutzen, deshalb schauen wir es mit Ihnen an.',
      ax_ok: '{a}-Achse: Step auf Pin {s}, Richtung auf Pin {d}.',
      ax_pin: '{a}-Achse nutzt Pin {p}, der beim Link kein Ausgang ist (Ausgänge: 1–9, 14, 16, 17).',
      ax_none: '{a}-Achse ist eingeschaltet, hat aber keinen Step- oder Richtungs-Pin am Parallelport.',
      ax_bc: '{a}-Achse ist eingeschaltet. Der Link steuert vier Achsen (X, Y, Z, A).',
      no_axes: 'In diesem Profil ist keine Achse eingeschaltet.',
      sp_pwm: 'Spindeldrehzahl per PWM auf Pin {p}.',
      sp_step: 'Die Spindel läuft als Step/Dir-Motor (Pin {p}). Der Link unterstützt keine Step/Dir-Spindeln.',
      thc: 'Eine Plasma-Brennerhöhensteuerung (THC) ist eingerichtet. Der Link unterstützt sie nicht.',
      in_ok: '{n}: Pin {p}{i}.',
      in_bad: '{n} liegt auf Pin {p}. Beim Link können Eingänge nur auf Pin 10, 11, 12, 13 und 15 liegen.',
      in_count: 'Genutzte Eingangs-Pins: {n} von 5.',
      shared: 'Pin {p} wird geteilt von {n}. Das passt für in Reihe geschaltete Schalter.',
      out_ok: '{n}: Pin {p}{i}.',
      out_bad: '{n} liegt auf Pin {p}, der beim Link kein Ausgang ist.',
      charge: 'Charge Pump auf Pin {p}: viele Breakout-Boards schalten die Treiber ohne dieses Signal nicht ein. Ein Charge-Pump-Ausgang ist für den Link geplant; wir bestätigen ihn vor dem Verkaufsstart.',
      enc: 'Ein MPG-Handrad oder Encoder ist am Parallelport angeschlossen. Der Link liest diese nicht; das SmartTabUI-Handbediengerät hat stattdessen ein Handrad.',
      lead_h: 'Bitte benachrichtigen, wenn der Link fertig ist',
      lead_d: 'Wir schreiben Ihnen einmal, sobald der Link bestellbar ist, mit Ihrem Ergebnis. Wir erhalten die Zusammenfassung oben, nicht Ihre Datei.',
      email: 'Ihre E-Mail',
      note: 'Sollten wir etwas über Ihre Maschine wissen? (optional)',
      consent: 'Schreibt mir zum dpCREATOR Link. Ich kann jederzeit verlangen, gelöscht zu werden.',
      privacy: 'Datenschutzerklärung',
      send: 'Senden',
      sent: 'Danke! Wir schreiben Ihnen, sobald der Link fertig ist.',
      err: 'Das hat nicht geklappt. Prüfen Sie die E-Mail-Adresse und das Häkchen, oder schreiben Sie an info@dpcreator.eu.'
    },
    ru: {
      pick: 'Выберите профиль Mach3 (.xml)',
      drop: 'или перетащите файл сюда',
      hint: 'Обычно в папке Mach3, например C:\\Mach3\\Mach3Mill.xml, или .xml с именем вашего профиля. Файл остаётся на вашем компьютере: он читается в браузере и никуда не загружается.',
      again: 'Проверить другой профиль',
      v_ok: 'Ваш станок подходит для Link',
      v_ok_d: 'Всё в этом профиле подходит к параллельному порту Link.',
      v_check: 'Скорее всего подходит, но кое-что нужно посмотреть внимательнее',
      v_check_d: 'Отправьте нам результат ниже, и мы проверим его вместе с вами.',
      v_no: 'В нынешнем виде ваш станок не подходит для Link',
      v_no_d: 'Пункты, отмеченные красным, невозможны с одним параллельным портом Link. Этому станку может подойти контроллер dpCREATOR R3: спросите нас.',
      v_bad: 'Это не похоже на профиль Mach3',
      v_bad_d: 'Выберите .xml из папки Mach3 с именем профиля, с которым вы запускаете Mach3.',
      found: 'Что мы нашли',
      pins: 'Карта контактов вашего параллельного порта',
      pin: 'Контакт', use: 'Назначение', free: 'свободен',
      inv: ' (инвертирован)',
      port2: 'Используется второй параллельный порт (port 2). У Link один 25-контактный порт.',
      ext: 'Некоторые сигналы назначены на port {n}, который принадлежит контроллеру движения (например, SmoothStepper или UC300), а не параллельному порту ПК. Профиль не показывает, какие контакты DB25 они используют, поэтому нужно посмотреть вместе с вами.',
      ax_ok: 'Ось {a}: step на контакте {s}, направление на контакте {d}.',
      ax_pin: 'Ось {a} использует контакт {p}, который у Link не является выходом (выходы: 1–9, 14, 16, 17).',
      ax_none: 'Ось {a} включена, но у неё нет контакта step или направления на параллельном порту.',
      ax_bc: 'Ось {a} включена. Link управляет четырьмя осями (X, Y, Z, A).',
      no_axes: 'В этом профиле не включена ни одна ось.',
      sp_pwm: 'Скорость шпинделя через PWM на контакте {p}.',
      sp_step: 'Шпиндель работает как мотор step/direction (контакт {p}). Link не поддерживает шпиндели step/direction.',
      thc: 'Настроен контроль высоты плазменного резака (THC). Link его не поддерживает.',
      in_ok: '{n}: контакт {p}{i}.',
      in_bad: '{n} на контакте {p}. У Link входы могут быть только на контактах 10, 11, 12, 13 и 15.',
      in_count: 'Использовано входных контактов: {n} из 5.',
      shared: 'Контакт {p} общий для: {n}. Это нормально для последовательно соединённых концевиков.',
      out_ok: '{n}: контакт {p}{i}.',
      out_bad: '{n} на контакте {p}, который у Link не является выходом.',
      charge: 'Charge pump на контакте {p}: многие платы опторазвязки без этого сигнала не включают драйверы. Выход charge pump для Link запланирован; мы подтвердим его до начала продаж.',
      enc: 'К параллельному порту подключён маховик MPG или энкодер. Link их не читает; у пульта SmartTabUI есть свой маховик.',
      lead_h: 'Сообщите мне, когда Link будет готов',
      lead_d: 'Мы напишем вам один раз, когда Link можно будет заказать, вместе с вашим результатом. Мы получаем сводку результата выше, а не ваш файл.',
      email: 'Ваш email',
      note: 'Что нам стоит знать о вашем станке? (необязательно)',
      consent: 'Пишите мне о dpCREATOR Link. Я могу в любой момент попросить удалить мои данные.',
      privacy: 'Политика конфиденциальности',
      send: 'Отправить',
      sent: 'Спасибо! Мы напишем вам, когда Link будет готов.',
      err: 'Не получилось. Проверьте адрес email и галочку или напишите на info@dpcreator.eu.'
    }
  };

  var lang = (root.getAttribute('data-lang') || document.documentElement.lang || 'en').toLowerCase().slice(0, 2);
  if (lang === 'lt') lang = 'lv';
  var L = T[lang] || T.en;
  function tr(k, p) {
    var s = L[k] || T.en[k] || k;
    if (p) for (var x in p) s = s.split('{' + x + '}').join(p[x]);
    return s;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  var css = '#dpc-m3{--ok:#2E7D4F;--chk:#B26A00;--no:#C42B1C;--note:#1F6FB8;max-width:860px}' +
    '#dpc-m3 .m3-drop{display:block;border:2px dashed currentColor;border-radius:12px;padding:28px 20px;text-align:center;cursor:pointer;opacity:.9}' +
    '#dpc-m3 .m3-drop.on{opacity:1;border-style:solid}' +
    '#dpc-m3 .m3-drop b{display:block;font-size:20px;margin-bottom:4px}' +
    '#dpc-m3 .m3-hint{font-size:13.5px;opacity:.75;margin:10px 0 0}' +
    '#dpc-m3 .m3-v{border-left:6px solid var(--c);padding:14px 18px;margin:22px 0 8px;border-radius:6px;background:rgba(127,127,127,.08)}' +
    '#dpc-m3 .m3-v h3{margin:0 0 4px;font-size:22px}#dpc-m3 .m3-v p{margin:0}' +
    '#dpc-m3 ul.m3-l{list-style:none;padding:0;margin:8px 0 18px}' +
    '#dpc-m3 ul.m3-l li{padding:7px 0 7px 26px;position:relative;border-bottom:1px solid rgba(127,127,127,.18)}' +
    '#dpc-m3 ul.m3-l li:before{content:"";position:absolute;left:4px;top:13px;width:11px;height:11px;border-radius:50%;background:var(--c)}' +
    '#dpc-m3 table.m3-t{border-collapse:collapse;width:100%;font-size:14px;margin:8px 0 18px}' +
    '#dpc-m3 table.m3-t td,#dpc-m3 table.m3-t th{border:1px solid rgba(127,127,127,.3);padding:5px 8px;text-align:left}' +
    '#dpc-m3 .m3-free{opacity:.5}' +
    '#dpc-m3 form.m3-f{border:1px solid rgba(127,127,127,.35);border-radius:10px;padding:16px 18px;margin-top:10px}' +
    '#dpc-m3 form.m3-f h3{margin:0 0 6px;font-size:20px}' +
    '#dpc-m3 form.m3-f input[type=email],#dpc-m3 form.m3-f textarea{width:100%;max-width:520px;display:block;margin:6px 0 10px;padding:8px 10px;border-radius:6px;border:1px solid rgba(127,127,127,.5);background:transparent;color:inherit;font:inherit}' +
    '#dpc-m3 form.m3-f label.c{display:flex;gap:8px;align-items:flex-start;font-size:14px;margin:4px 0 12px}' +
    '#dpc-m3 .m3-hp{position:absolute;left:-9999px}' +
    '#dpc-m3 .m3-btn{display:inline-block;padding:9px 18px;border-radius:6px;border:0;background:#1F6FB8;color:#fff;font-weight:600;cursor:pointer}' +
    '#dpc-m3 .m3-msg{margin-top:10px;font-weight:600}' +
    '#dpc-m3 .m3-again{background:none;border:0;color:inherit;text-decoration:underline;cursor:pointer;padding:0;margin:4px 0 0}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  function start() {
    root.innerHTML = '<label class="m3-drop" tabindex="0"><b>' + esc(tr('pick')) + '</b><span>' + esc(tr('drop')) + '</span>' +
      '<input type="file" accept=".xml,text/xml" style="display:none"></label><p class="m3-hint">' + esc(tr('hint')) + '</p>';
    var lab = root.querySelector('.m3-drop'), inp = root.querySelector('input[type=file]');
    inp.addEventListener('change', function () { if (inp.files[0]) read(inp.files[0]); });
    lab.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inp.click(); } });
    ['dragenter', 'dragover'].forEach(function (ev) { lab.addEventListener(ev, function (e) { e.preventDefault(); lab.classList.add('on'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { lab.addEventListener(ev, function (e) { e.preventDefault(); lab.classList.remove('on'); }); });
    lab.addEventListener('drop', function (e) { var f = e.dataTransfer.files[0]; if (f) read(f); });
  }

  function read(f) {
    var r = new FileReader();
    r.onload = function () { show(check(String(r.result || ''))); };
    r.readAsText(f.slice(0, 3000000), 'windows-1252');
  }

  function check(s) {
    function g(k) { var m = s.match(new RegExp('<' + k + '>([^<]*)</' + k + '>')); return m ? m[1].trim() : null; }
    function n(k) { var v = g(k); return v === null ? 0 : parseInt(v, 10) || 0; }
    if (g('Motor0Active') === null || g('Port1Add') === null) return { verdict: 'bad', items: [], pins: {} };
    var items = [], pins = {}, extPorts = {};
    function add(level, key, p) { items.push({ l: level, t: tr(key, p) }); }
    function usePin(p, what) { (pins[p] = pins[p] || []).push(what); }
    var port2 = n('Port2On') === 1;

    // axes
    var axes = 0;
    for (var m = 0; m < 6; m++) {
      if (n('Motor' + m + 'Active') !== 1) continue;
      axes++;
      var a = AX[m];
      if (m >= 4) { add('no', 'ax_bc', { a: a }); continue; }
      var sp = n('Motor' + m + 'StepPort'), s1 = n('Motor' + m + 'StepPin'), dp = n('Motor' + m + 'DirPort'), d1 = n('Motor' + m + 'DirPin');
      if (sp >= 3 || dp >= 3) { extPorts[Math.max(sp, dp)] = 1; continue; }
      if (sp === 2 || dp === 2) { port2 = true; continue; }
      if (!s1 || !d1) { add('chk', 'ax_none', { a: a }); continue; }
      var bad = [s1, d1].filter(function (p) { return OUT.indexOf(p) < 0; });
      if (bad.length) { add('no', 'ax_pin', { a: a, p: bad.join(', ') }); continue; }
      usePin(s1, a + ' step' + (n('Motor' + m + 'StepNeg') ? tr('inv') : ''));
      usePin(d1, a + ' dir' + (n('Motor' + m + 'DirNeg') ? tr('inv') : ''));
      add('ok', 'ax_ok', { a: a, s: s1, d: d1 });
    }
    if (!axes) add('chk', 'no_axes');

    // spindle (motor 6)
    if (n('Motor6Active') === 1) {
      var spp = n('Motor6StepPort'), spn = n('Motor6StepPin');
      if (spp >= 3) extPorts[spp] = 1;
      else if (spp === 2) port2 = true;
      else if (spn) {
        if (g('PWM') === '1') {
          if (OUT.indexOf(spn) < 0) add('no', 'out_bad', { n: 'Spindle PWM', p: spn });
          else { usePin(spn, 'Spindle PWM'); add('ok', 'sp_pwm', { p: spn }); }
        } else add('no', 'sp_step', { p: spn });
      }
    }

    // THC
    var thc = [26, 27, 28].some(function (i) { return n('Input' + i + 'Active') === 1 && n('Input' + i + 'Emulated') !== 1; }) || g('EnableTHC') === 'True';
    if (thc) add('no', 'thc');

    // inputs
    var inPins = {};
    for (var i = 0; i < IN_NAMES.length; i++) {
      if (i >= 26 && i <= 28) continue;
      if (n('Input' + i + 'Active') !== 1 || n('Input' + i + 'Emulated') === 1) continue;
      var ip = n('Input' + i + 'Port'), pn = n('Input' + i + 'Pin'), nm = IN_NAMES[i];
      if (!ip || !pn) continue;
      if (ip >= 3) { extPorts[ip] = 1; continue; }
      if (ip === 2) { port2 = true; continue; }
      if (INP.indexOf(pn) < 0) { add('no', 'in_bad', { n: nm, p: pn }); continue; }
      (inPins[pn] = inPins[pn] || []).push(nm + (n('Input' + i + 'Neg') ? tr('inv') : ''));
    }
    var ipk = Object.keys(inPins);
    ipk.forEach(function (p) {
      inPins[p].forEach(function (w) { usePin(+p, w); });
      if (inPins[p].length > 1) add('ok', 'shared', { p: p, n: inPins[p].join(', ') });
      else add('ok', 'in_ok', { n: inPins[p][0], p: p, i: '' });
    });
    if (ipk.length) add('ok', 'in_count', { n: ipk.length });

    // outputs
    for (var o = 0; o < OUT_NAMES.length; o++) {
      if (n('Output' + o + 'Active') !== 1) continue;
      var op = n('Output' + o + 'Port'), opn = n('Output' + o + 'Pin'), on = OUT_NAMES[o];
      if (!op || !opn) continue;
      if (op >= 3) { extPorts[op] = 1; continue; }
      if (op === 2) { port2 = true; continue; }
      if (OUT.indexOf(opn) < 0) { add('no', 'out_bad', { n: on, p: opn }); continue; }
      usePin(opn, on + (n('Output' + o + 'Neg') ? tr('inv') : ''));
      if (o === 13 || o === 14) add('note', 'charge', { p: opn });
      else add('ok', 'out_ok', { n: on, p: opn, i: n('Output' + o + 'Neg') ? tr('inv') : '' });
    }

    // MPG / encoders on the parallel port
    var enc = false;
    for (var e = 0; e < 8; e++) {
      if (n('Encoder' + e + 'Active') === 1 && (n('Encoder' + e + 'APort') === 1 || n('Encoder' + e + 'APort') === 2)) enc = true;
    }
    if (enc) add('no', 'enc');

    if (port2) add('no', 'port2');
    Object.keys(extPorts).forEach(function (p) { add('chk', 'ext', { n: p }); });

    var order = { no: 0, chk: 1, note: 2, ok: 3 };
    items.sort(function (x, y) { return order[x.l] - order[y.l]; });
    var verdict = items.some(function (x) { return x.l === 'no'; }) ? 'no' : (items.some(function (x) { return x.l === 'chk'; }) ? 'check' : 'ok');
    return { verdict: verdict, items: items, pins: pins };
  }

  function show(r) {
    var C = { ok: 'var(--ok)', check: 'var(--chk)', no: 'var(--no)', bad: 'var(--chk)' };
    var LC = { ok: 'var(--ok)', chk: 'var(--chk)', no: 'var(--no)', note: 'var(--note)' };
    var h = '<div class="m3-v" style="--c:' + C[r.verdict] + '"><h3>' + esc(tr('v_' + r.verdict)) + '</h3><p>' + esc(tr('v_' + r.verdict + '_d')) + '</p></div>';
    if (r.verdict !== 'bad') {
      h += '<h3>' + esc(tr('found')) + '</h3><ul class="m3-l">' + r.items.map(function (x) { return '<li style="--c:' + LC[x.l] + '">' + esc(x.t) + '</li>'; }).join('') + '</ul>';
      h += '<h3>' + esc(tr('pins')) + '</h3><table class="m3-t"><tr><th>' + esc(tr('pin')) + '</th><th>' + esc(tr('use')) + '</th></tr>';
      OUT.concat(INP).sort(function (a, b) { return a - b; }).forEach(function (p) {
        var u = r.pins[p];
        h += '<tr><td>' + p + '</td><td' + (u ? '' : ' class="m3-free"') + '>' + esc(u ? u.join(', ') : tr('free')) + '</td></tr>';
      });
      h += '</table>';
    }
    h += '<button type="button" class="m3-again">' + esc(tr('again')) + '</button>';
    if (r.verdict !== 'bad') h += form(r);
    root.innerHTML = h;
    root.querySelector('.m3-again').addEventListener('click', start);
    var f = root.querySelector('form');
    if (f) f.addEventListener('submit', function (e) { e.preventDefault(); send(f, r); });
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function form(r) {
    var priv = root.getAttribute('data-privacy') || '';
    return '<form class="m3-f" novalidate><h3>' + esc(tr('lead_h')) + '</h3><p>' + esc(tr('lead_d')) + '</p>' +
      '<label>' + esc(tr('email')) + '<input type="email" name="email" required autocomplete="email"></label>' +
      '<label>' + esc(tr('note')) + '<textarea name="note" rows="3" maxlength="1000"></textarea></label>' +
      '<input class="m3-hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">' +
      '<label class="c"><input type="checkbox" name="consent" value="1" required><span>' + esc(tr('consent')) +
      (priv ? ' <a href="' + esc(priv) + '" target="_blank" rel="noopener">' + esc(tr('privacy')) + '</a>' : '') + '</span></label>' +
      '<button class="m3-btn" type="submit">' + esc(tr('send')) + '</button><div class="m3-msg" role="status"></div></form>';
  }

  function summary(r) {
    var lv = { ok: '[OK]', chk: '[CHECK]', no: '[NO]', note: '[NOTE]' };
    var s = r.items.map(function (x) { return lv[x.l] + ' ' + x.t; }).join('\n');
    s += '\n\nPins:\n' + Object.keys(r.pins).sort(function (a, b) { return a - b; }).map(function (p) { return p + ': ' + r.pins[p].join(', '); }).join('\n');
    return s;
  }

  function send(f, r) {
    var msg = f.querySelector('.m3-msg'), b = f.querySelector('button');
    var fd = new FormData(f);
    if (!f.email.value || !f.consent.checked) { msg.textContent = tr('err'); return; }
    fd.append('lang', lang); fd.append('verdict', r.verdict); fd.append('summary', summary(r));
    b.disabled = true;
    fetch('index.php?route=extension/module/dpc_link_lead/save', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (x) { return x.json(); })
      .then(function (j) { if (j && j.ok) { f.innerHTML = '<p class="m3-msg">' + esc(tr('sent')) + '</p>'; } else { msg.textContent = tr('err'); b.disabled = false; } })
      .catch(function () { msg.textContent = tr('err'); b.disabled = false; });
  }

  start();
})();
