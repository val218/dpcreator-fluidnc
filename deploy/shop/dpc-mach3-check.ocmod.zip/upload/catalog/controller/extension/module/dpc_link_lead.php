<?php
// dpCREATOR Link: "tell me when it's ready" sign-ups from the free Mach3 check page.
// Stores the email, language and the check summary (never the uploaded file) and mails info@.
class ControllerExtensionModuleDpcLinkLead extends Controller {
	private function table() {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "dpc_link_lead` (
			`lead_id` INT(11) NOT NULL AUTO_INCREMENT,
			`email` VARCHAR(96) NOT NULL,
			`lang` VARCHAR(8) NOT NULL DEFAULT '',
			`verdict` VARCHAR(16) NOT NULL DEFAULT '',
			`summary` TEXT NOT NULL,
			`note` VARCHAR(1000) NOT NULL DEFAULT '',
			`ip` VARCHAR(45) NOT NULL DEFAULT '',
			`created` DATETIME NOT NULL,
			PRIMARY KEY (`lead_id`),
			KEY `email` (`email`),
			KEY `ip` (`ip`, `created`)
		) DEFAULT CHARSET=utf8mb4");
	}

	private function out($a) {
		$this->response->addHeader('Content-Type: application/json');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput(json_encode($a));
	}

	public function save() {
		try {
			if (($this->request->server['REQUEST_METHOD'] ?? '') !== 'POST') {
				return $this->out(array('ok' => 0));
			}
			$p = $this->request->post;
			if (!empty($p['website'])) { // honeypot
				return $this->out(array('ok' => 1));
			}
			$email = trim(html_entity_decode((string)($p['email'] ?? ''), ENT_QUOTES, 'UTF-8'));
			if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 96 || empty($p['consent'])) {
				return $this->out(array('ok' => 0, 'error' => 'email'));
			}
			$this->table();
			$ip = substr((string)($this->request->server['REMOTE_ADDR'] ?? ''), 0, 45);
			$n = (int)$this->db->query("SELECT COUNT(*) AS n FROM `" . DB_PREFIX . "dpc_link_lead` WHERE `ip` = '" . $this->db->escape($ip) . "' AND `created` > NOW() - INTERVAL 1 HOUR")->row['n'];
			if ($n >= 5) {
				return $this->out(array('ok' => 0, 'error' => 'busy'));
			}
			$lang = preg_replace('/[^a-z-]/', '', strtolower((string)($p['lang'] ?? '')));
			$verdict = preg_replace('/[^a-z_]/', '', (string)($p['verdict'] ?? ''));
			$summary = mb_substr(html_entity_decode((string)($p['summary'] ?? ''), ENT_QUOTES, 'UTF-8'), 0, 6000);
			$note = mb_substr(trim(html_entity_decode((string)($p['note'] ?? ''), ENT_QUOTES, 'UTF-8')), 0, 1000);
			$this->db->query("INSERT INTO `" . DB_PREFIX . "dpc_link_lead` SET `email` = '" . $this->db->escape($email) . "', `lang` = '" . $this->db->escape(substr($lang, 0, 8)) . "', `verdict` = '" . $this->db->escape(substr($verdict, 0, 16)) . "', `summary` = '" . $this->db->escape($summary) . "', `note` = '" . $this->db->escape($note) . "', `ip` = '" . $this->db->escape($ip) . "', `created` = NOW()");

			$text = "Link sign-up from the Mach3 check page\n\nEmail: " . $email . "\nLanguage: " . $lang . "\nResult: " . $verdict . "\n" . ($note !== '' ? "\nTheir note:\n" . $note . "\n" : '') . "\nCheck summary:\n" . $summary . "\n";
			ob_start(); // a mail warning must not break the JSON answer
			try {
				if (!class_exists('Mail')) {
					require_once(DIR_SYSTEM . 'library/mail.php');
				}
				$engine = $this->config->get('config_mail_engine') ?: 'mail';
				$mail = new Mail($engine);
				$mail->parameter = $this->config->get('config_mail_parameter');
				$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
				$mail->smtp_username = $this->config->get('config_mail_smtp_username');
				$mail->smtp_password = html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
				$mail->smtp_port = $this->config->get('config_mail_smtp_port');
				$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
				$mail->setTo('info@dpcreator.eu');
				$mail->setFrom($this->config->get('config_email'));
				$mail->setReplyTo($email);
				$mail->setSender('dpCREATOR Mach3 check');
				$mail->setSubject('Link sign-up: ' . $email . ' (' . $verdict . ')');
				$mail->setText($text);
				$mail->send();
			} catch (\Throwable $e) {
				// the sign-up is saved even if the mail fails
			}
			ob_end_clean();
			return $this->out(array('ok' => 1));
		} catch (\Throwable $e) {
			return $this->out(array('ok' => 0, 'error' => 'server'));
		}
	}
}
