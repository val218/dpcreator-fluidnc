/* dpCREATOR machine setup on the Flash Firmware page.
 *
 *   0  Your board: dpCREATOR R3/R2, another ESP32-S3 board, or an ESP32 (WROOM-32) board from the
 *      FluidNC community list (its config templates, GPL-3.0, in ../dpc-boards/); picks the build
 *   1  Machine configuration: pick a config.yaml (checked at once), build one, start from the board's
 *      template, or keep the board's
 *   1b Apps to put on the controller after flashing: WebUI, Studio, Motion (greyed without a licence;
 *      on an ESP32 WROOM-32 they go on the SD card)
 *   2  Flash (ESP Web Tools dialog, as before) - warns that "Erase device" also wipes the config
 *   3  Write config.yaml back over USB (XModem, like Board tools > Files), restart, read the boot log
 *   4  First-run checks on the machine
 *
 * Needs on the page: <div id="dpcs-flow" data-manifest=".." data-name=".."></div>,
 * window.DPCBoardTools (Board tools script), dpcFlash() (page script).
 * Copyright (c) 2026 dpCREATOR (Val). All rights reserved.
 */
(function () {
  "use strict";
  const S = window.DPCSetup, G = window.DPCSetupSVG;
  const mount = document.getElementById("dpcs-flow");
  if (!S || !G || !mount) return;
  const BASE = (document.currentScript && document.currentScript.src || "").replace(/[^/]*$/, "") || "/catalog/view/javascript/dpc-setup/";
  const ITEMS_URL = "https://raw.githubusercontent.com/val218/dpcreator-fluidnc/fluidnc-4.1.1-w5500/FluidNC/docs/config_items.yaml";
  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.prototype.slice.call((el || document).querySelectorAll(sel));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const hasSerial = "serial" in navigator;

  // ------------------------------------------------------------ schema (firmware key list)
  let schemaP = null, schemaSrc = "";
  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }
  function schema() {
    if (schemaP) return schemaP;
    schemaP = (async () => {
      if (!window.jsyaml) await loadScript(BASE + "js-yaml.min.js");
      let doc = null;
      try {
        const r = await fetch(ITEMS_URL, { cache: "no-cache" });
        if (r.ok) { doc = window.jsyaml.load(await r.text()); schemaSrc = "firmware repo (latest)"; }
      } catch (e) { /* offline or blocked: use the copy shipped with the page */ }
      if (!doc) { doc = await (await fetch(BASE + "config_items.json")).json(); schemaSrc = "copy shipped with this page"; }
      return S.Schema(doc);
    })();
    return schemaP;
  }
  async function check(text, opts) {
    const sc = await schema();
    return S.validate(text, sc, Object.assign({ chip: (st.board && st.board.chip) || "esp32s3" }, opts || {}));
  }

  // ------------------------------------------------------------ styles
  const css = document.createElement("style");
  css.textContent = `
#dpcs-flow,#dpcs-modal{--c-bg:#0f1318;--c-card:#161c23;--c-card2:#1b232c;--c-line:#28323d;--c-text:#dde3e8;--c-mute:#8e9ba7;--c-acc:#2b8fe0;--c-acc2:#4fb4ee;--c-ok:#2fb36a;--c-warn:#d9a21b;--c-err:#e0564c;--c-pos:#e0564c;--c-sig:#4fb4ee}
html.dpc-light #dpcs-flow,html.dpc-light #dpcs-modal{--c-bg:#f6f7f9;--c-card:#fff;--c-card2:#f1f4f7;--c-line:#d8dee5;--c-text:#1d252c;--c-mute:#5d6975;--c-acc:#1f6fb8;--c-acc2:#1f6fb8;--c-ok:#17803f;--c-warn:#8a6100;--c-err:#c0392b;--c-pos:#c0392b;--c-sig:#1f6fb8}
#dpcs-flow{margin:14px 0 4px;color:var(--c-text)}
#dpcs-flow ol.dpcs-steps{list-style:none;margin:0;padding:0;counter-reset:s}
#dpcs-flow .dpcs-step{position:relative;padding:0 0 18px 40px;margin:0;border-left:2px solid var(--c-line);margin-left:13px}
#dpcs-flow .dpcs-step:last-child{border-left-color:transparent}
#dpcs-flow .dpcs-step::before{counter-increment:s;content:counter(s);position:absolute;left:-15px;top:-2px;width:28px;height:28px;border-radius:50%;background:var(--c-card2);border:2px solid var(--c-line);font:700 14px/24px Barlow,system-ui,sans-serif;text-align:center;color:var(--c-mute)}
#dpcs-flow .dpcs-step.done::before{content:"✓";background:var(--c-ok);border-color:var(--c-ok);color:#fff}
#dpcs-flow .dpcs-step.now::before{border-color:var(--c-acc);color:var(--c-text)}
#dpcs-flow h4{margin:0 0 6px;font:600 17px/1.3 "Barlow Condensed",Barlow,sans-serif;color:var(--c-text);text-transform:none;letter-spacing:0}
#dpcs-flow p{margin:0 0 10px;color:var(--c-mute);font-size:14px;line-height:1.5}
#dpcs-flow .dpcs-choices{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;margin:8px 0 10px}
#dpcs-flow .dpcs-app a,#dpcs-flow .dpcs-panel a{color:var(--c-acc2)}
#dpcs-flow .dpcs-app.off .nm{opacity:.5}
@media (max-width:760px){#dpcs-flow .dpcs-choices{grid-template-columns:1fr}}
.dpcs-choice{display:flex;flex-direction:column;gap:4px;text-align:left;padding:12px 13px;border:1px solid var(--c-line);border-radius:8px;background:var(--c-card);color:var(--c-text);font:inherit;cursor:pointer;transition:border-color .15s,background-color .15s}
.dpcs-choice b{font-size:14.5px}.dpcs-choice span{font-size:12.5px;color:var(--c-mute);line-height:1.4}
.dpcs-choice:hover{border-color:var(--c-acc)}.dpcs-choice[aria-pressed=true]{border-color:var(--c-acc);background:var(--c-card2);box-shadow:inset 3px 0 0 var(--c-acc)}
.dpcs-choice:focus-visible,.dpcs-btn:focus-visible,#dpcs-modal button:focus-visible,#dpcs-modal .tgt:focus-visible{outline:2px solid var(--c-acc);outline-offset:2px}
#dpcs-flow a.dpcs-btn:not(.ghost){color:#fff!important}
.dpcs-btn{display:inline-flex;align-items:center;gap:6px;padding:9px 16px;border-radius:6px;border:1px solid var(--c-acc);background:var(--c-acc);color:#fff;font:600 14px Barlow,system-ui,sans-serif;cursor:pointer;text-decoration:none!important}
.dpcs-btn:hover{filter:brightness(1.1)}.dpcs-btn[disabled]{opacity:.45;cursor:default;filter:none}
.dpcs-btn.ghost{background:transparent!important;color:var(--c-text)!important;border:1px solid var(--c-line)!important}.dpcs-btn.ghost:hover{border-color:var(--c-acc)}
.dpcs-btn.small{padding:5px 10px;font-size:13px}
.dpcs-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0}
.dpcs-panel{border:1px solid var(--c-line);border-radius:8px;background:var(--c-card);padding:12px 14px;margin:6px 0 10px}
.dpcs-note{padding:9px 12px;border-radius:6px;border-left:3px solid var(--c-acc);background:rgba(43,143,224,.1);font-size:13.5px;line-height:1.45;margin:8px 0;color:var(--c-text)}
.dpcs-note.warn{border-left-color:var(--c-warn);background:rgba(217,162,27,.12)}.dpcs-note.err{border-left-color:var(--c-err);background:rgba(224,86,76,.12)}.dpcs-note.ok{border-left-color:var(--c-ok);background:rgba(47,179,106,.12)}
.dpcs-probs{list-style:none;margin:6px 0;padding:0;max-height:260px;overflow:auto;font-size:13px}
.dpcs-probs li{display:grid;grid-template-columns:62px 1fr;gap:8px;padding:6px 0;border-bottom:1px solid var(--c-line);line-height:1.4}
.dpcs-probs .lv{font-weight:700;font-size:11.5px}.dpcs-probs .error .lv{color:var(--c-err)}.dpcs-probs .warn .lv{color:var(--c-warn)}.dpcs-probs .info .lv{color:var(--c-mute)}
.dpcs-probs a{color:var(--c-acc2);cursor:pointer}
.dpcs-sum{display:flex;flex-wrap:wrap;gap:10px;align-items:center;font-size:14px}
.dpcs-pill{display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:700;border:1px solid var(--c-line)}
.dpcs-pill.ok{color:var(--c-ok);border-color:var(--c-ok)}.dpcs-pill.err{color:var(--c-err);border-color:var(--c-err)}.dpcs-pill.warn{color:var(--c-warn);border-color:var(--c-warn)}
.dpcs-edit{width:100%;min-height:260px;font:12.5px/1.45 ui-monospace,Menlo,Consolas,monospace;background:var(--c-bg);color:var(--c-text);border:1px solid var(--c-line);border-radius:6px;padding:10px;white-space:pre;tab-size:2}
.dpcs-log{max-height:220px;overflow:auto;background:var(--c-bg);border:1px solid var(--c-line);border-radius:6px;padding:8px 10px;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;margin:8px 0;color:var(--c-mute)}
.dpcs-log .e{color:var(--c-err)}.dpcs-log .o{color:var(--c-acc2)}
.dpcs-bar{height:6px;background:var(--c-line);border-radius:3px;overflow:hidden;margin:8px 0}.dpcs-bar div{height:100%;width:0;background:var(--c-acc);transition:width .2s}
.dpcs-checks{list-style:none;margin:6px 0;padding:0;counter-reset:c}
.dpcs-axpick{gap:6px}.dpcs-axbtn{min-width:44px;padding:6px 12px;border-radius:6px;border:2px solid var(--ax);background:transparent;color:var(--ax);font:700 15px Barlow,system-ui,sans-serif;cursor:pointer}
.dpcs-axbtn.on{background:var(--ax);color:#fff}.dpcs-axbtn:focus-visible{outline:2px solid var(--c-text);outline-offset:2px}
.dpcs-axtag{display:inline-block;min-width:26px;text-align:center;padding:1px 6px;border-radius:5px;background:var(--ax);color:#fff;font-weight:700}
.dpcs-dirtag{display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;border-radius:50%;border:2px solid var(--ax);color:var(--ax);font-weight:700;margin-right:4px}
.dpcs-checks>li{counter-increment:c;border:1px solid var(--c-line);border-radius:8px;background:var(--c-card);padding:10px 12px 10px 40px;margin:0 0 8px;position:relative}
.dpcs-checks>li::before{content:counter(c);position:absolute;left:12px;top:10px;width:20px;height:20px;border-radius:50%;background:var(--c-card2);font:700 12px/20px Barlow,sans-serif;text-align:center;color:var(--c-mute)}
.dpcs-checks>li.pass::before{content:"✓";background:var(--c-ok);color:#fff}.dpcs-checks>li.fail::before{content:"!";background:var(--c-err);color:#fff}
.dpcs-checks>li>b{display:block;margin-bottom:3px;font-size:14px}
.dpcs-checks input[type=number],.dpcs-checks select{background:var(--c-bg);color:var(--c-text);border:1px solid var(--c-line);border-radius:6px;padding:5px 8px;font:14px Barlow,system-ui,sans-serif}
.dpcs-checks label{display:inline-flex;align-items:center;gap:6px;color:var(--c-mute);font-size:13.5px}.dpcs-checks p{margin:0 0 6px!important;font-size:13px!important}
.dpcs-checks code,#dpcs-modal code{font:12.5px ui-monospace,Menlo,Consolas,monospace;background:var(--c-card2);padding:1px 5px;border-radius:4px}
.dpcs-pn{display:flex;gap:6px;flex-wrap:wrap;margin:6px 0}.dpcs-pn span{min-width:30px;padding:4px 8px;border-radius:5px;border:1px solid var(--c-line);text-align:center;font-weight:700;color:var(--c-mute)}.dpcs-pn span.on{background:var(--c-err);border-color:var(--c-err);color:#fff}
.dpcs-pn span[data-pn=X]{color:#e0564c;border-color:#e0564c}.dpcs-pn span[data-pn=Y]{color:#2fb36a;border-color:#2fb36a}.dpcs-pn span[data-pn=Z]{color:#2b8fe0;border-color:#2b8fe0}.dpcs-pn span[data-pn=A]{color:#d9a21b;border-color:#d9a21b}
.dpcs-pn span[data-pn=X].on{background:#e0564c;color:#fff}.dpcs-pn span[data-pn=Y].on{background:#2fb36a;color:#fff}.dpcs-pn span[data-pn=Z].on{background:#2b8fe0;color:#fff}.dpcs-pn span[data-pn=A].on{background:#d9a21b;color:#fff}
.dpcs-hidden{display:none!important}
/* builder */
#dpcs-modal[hidden]{display:none!important}
#dpcs-modal{position:fixed;inset:0;z-index:100001;background:var(--c-bg);color:var(--c-text);display:flex;flex-direction:column;font:15px/1.5 Barlow,system-ui,sans-serif}
#dpcs-modal header.dpcs-top{display:flex;align-items:center;gap:12px;padding:10px 18px;border-bottom:1px solid var(--c-line);background:var(--c-card);position:static}
@media (max-width:520px){#dpcs-modal .dpcs-prog{display:none}#dpcs-modal header h3{font-size:17px}}
#dpcs-modal header h3{margin:0;font:600 19px "Barlow Condensed",Barlow,sans-serif;color:var(--c-text);flex:1;text-transform:none;letter-spacing:0}
#dpcs-modal .dpcs-prog{display:flex;gap:3px;flex:2;max-width:520px}#dpcs-modal .dpcs-prog i{flex:1;height:5px;border-radius:3px;background:var(--c-line)}#dpcs-modal .dpcs-prog i.on{background:var(--c-acc)}
#dpcs-modal .dpcs-main{flex:1;display:grid;grid-template-columns:minmax(0,1fr) minmax(320px,40%);min-height:0}
#dpcs-modal .dpcs-q{overflow:auto;padding:22px 26px 30px}
#dpcs-modal .dpcs-yaml{border-left:1px solid var(--c-line);background:var(--c-card);display:flex;flex-direction:column;min-height:0}
#dpcs-modal .dpcs-yaml .hd{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid var(--c-line);font-size:13px;color:var(--c-mute)}
#dpcs-modal .dpcs-yaml pre{position:relative;flex:1;overflow:auto;margin:0;padding:10px 12px;font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;color:var(--c-text);background:transparent;border:0;white-space:pre}
#dpcs-modal .dpcs-yaml pre .c{color:var(--c-mute)}#dpcs-modal .dpcs-yaml pre .k{color:var(--c-acc2)}#dpcs-modal .dpcs-yaml pre .chg{background:rgba(43,143,224,.18)}
#dpcs-modal footer{display:flex;gap:10px;align-items:center;padding:10px 18px;border-top:1px solid var(--c-line);background:var(--c-card);position:static}
#dpcs-modal footer .sp{flex:1;color:var(--c-mute);font-size:13px}
#dpcs-modal h2{font:600 26px/1.2 "Barlow Condensed",Barlow,sans-serif;margin:0 0 6px;color:var(--c-text);text-transform:none;letter-spacing:0}
#dpcs-modal h5{font:600 16px "Barlow Condensed",Barlow,sans-serif;margin:18px 0 6px;color:var(--c-text);text-transform:none;letter-spacing:0}
#dpcs-modal .lead{color:var(--c-mute);margin:0 0 16px;max-width:62ch}
#dpcs-modal .opts{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:8px;margin:8px 0 14px}
#dpcs-modal .opt{text-align:left;padding:11px 12px;border:1px solid var(--c-line);border-radius:8px;background:var(--c-card);color:var(--c-text);font:inherit;cursor:pointer}
#dpcs-modal .opt b{display:block;font-size:14.5px}#dpcs-modal .opt span{display:block;font-size:12.5px;color:var(--c-mute);line-height:1.35;margin-top:2px}
#dpcs-modal .opt:hover{border-color:var(--c-acc)}#dpcs-modal .opt[aria-pressed=true]{border-color:var(--c-acc);box-shadow:inset 3px 0 0 var(--c-acc);background:var(--c-card2)}
#dpcs-modal .opt[disabled]{opacity:.45;cursor:not-allowed}
#dpcs-modal label.f{display:flex;flex-direction:column;gap:3px;font-size:13px;color:var(--c-mute)}
#dpcs-modal input[type=text],#dpcs-modal input[type=number],#dpcs-modal select{background:var(--c-bg);color:var(--c-text);border:1px solid var(--c-line);border-radius:6px;padding:7px 9px;font:14px Barlow,system-ui,sans-serif;min-width:0}
#dpcs-modal .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:8px 0}
#dpcs-modal .axcard{border:1px solid var(--c-line);border-radius:8px;background:var(--c-card);padding:12px 14px;margin:0 0 12px}
#dpcs-modal .axcard h6{margin:0 0 6px;font:700 15px Barlow,sans-serif;color:var(--c-text);text-transform:none;letter-spacing:0}
#dpcs-modal .seg{display:inline-flex;border:1px solid var(--c-line);border-radius:7px;overflow:hidden;flex-wrap:wrap}
#dpcs-modal .seg button{background:transparent;border:0;border-right:1px solid var(--c-line);color:var(--c-text);padding:6px 12px;font:600 13.5px Barlow,sans-serif;cursor:pointer}
#dpcs-modal .seg button:last-child{border-right:0}#dpcs-modal .seg button[aria-pressed=true]{background:var(--c-acc);color:#fff}#dpcs-modal .seg button[disabled]{opacity:.4;cursor:not-allowed}
#dpcs-modal .chk{display:flex;gap:9px;align-items:flex-start;padding:9px 0;border-bottom:1px solid var(--c-line);cursor:pointer}
#dpcs-modal .chk input{margin-top:4px;width:17px;height:17px;accent-color:var(--c-acc)}#dpcs-modal .chk b{display:block;font-size:14.5px}#dpcs-modal .chk span{font-size:13px;color:var(--c-mute)}
#dpcs-modal .res{font:700 22px "Barlow Condensed",sans-serif;color:var(--c-acc2)}
#dpcs-modal table.t{border-collapse:collapse;font-size:13px;margin:6px 0}#dpcs-modal table.t td,#dpcs-modal table.t th{border:1px solid var(--c-line);padding:4px 10px;text-align:center}
.dpcs-svg{width:100%;max-width:560px;height:auto;display:block;margin:8px 0;font-family:Barlow,system-ui,sans-serif}
.dpcs-svg-z{max-width:240px}.dpcs-svg-sm{max-width:440px}
.dpcs-svg .pcb{fill:#173a2a;stroke:#2c5c43}.dpcs-svg .pcb-t,.dpcs-svg .chip-t{fill:#cfe7da;font-size:13px;font-weight:700}
.dpcs-svg .chip{fill:#222;stroke:#444}.dpcs-svg .blk{fill:#2a6a43;stroke:#3f8f5d}.dpcs-svg .blk.on{fill:#1f5f99;stroke:#4fb4ee;stroke-width:2}.dpcs-svg .blk.off{fill:#3a3f44;stroke:#555}
.dpcs-svg .pin{fill:#c9a24a}.dpcs-svg .pin-t{fill:#d9e6de;font-size:9.5px}.dpcs-svg .pin-t.big{font-size:12.5px;fill:var(--c-text)}
.dpcs-svg .blk-t{fill:var(--c-text);font-size:13px;font-weight:700}.dpcs-svg .ax-t{fill:#4fb4ee;font-size:13px;font-weight:700}.dpcs-svg .lim-t{fill:#d9a21b;font-size:10.5px}
.dpcs-svg .x{stroke:#e0564c;stroke-width:3}.dpcs-svg .bad text{fill:#9aa}
.dpcs-svg .tgt{cursor:pointer}.dpcs-svg .tgt:hover .blk:not(.off),.dpcs-svg .tgt:hover .sw{stroke:#4fb4ee;stroke-width:3}
.dpcs-svg .frame{fill:none;stroke:var(--c-mute);stroke-width:2}.dpcs-svg .bed{fill:rgba(127,140,155,.18);stroke:var(--c-mute)}.dpcs-svg .bed.moving{fill:rgba(217,162,27,.18);stroke:#d9a21b}
.dpcs-svg .gantry{fill:var(--c-card2);stroke:var(--c-mute);stroke-width:1.5}.dpcs-svg .tool{fill:#2b8fe0}.dpcs-svg .tool-t{fill:#fff;font-size:9px;font-weight:700}
.dpcs-svg .arw{stroke:#2fb36a;stroke-width:3;fill:none}.dpcs-svg .ar{fill:#2fb36a}.dpcs-svg .arw-t{fill:#2fb36a;font-size:12px;font-weight:700}.dpcs-svg .bedarw{stroke:#d9a21b}
.dpcs-svg .lbl{fill:var(--c-mute);font-size:11.5px}.dpcs-svg .sw{fill:var(--c-card);stroke:#d9a21b;stroke-width:2}.dpcs-svg .tgt.on .sw{fill:#d9a21b}.dpcs-svg .sw-t{fill:#fff;font-size:13px;font-weight:700}
.dpcs-svg .wire{fill:none;stroke-width:3}.dpcs-svg .wire.pos{stroke:var(--c-pos)}.dpcs-svg .wire.sig{stroke:var(--c-sig)}.dpcs-svg .wire.bad{stroke:var(--c-mute);stroke-dasharray:5 4}.dpcs-svg .wire.gnd{stroke:var(--c-mute)}
.dpcs-svg .drv{fill:var(--c-card2);stroke:var(--c-mute)}.dpcs-svg .thread{stroke:var(--c-mute)}.dpcs-svg .track{stroke:var(--c-line);stroke-width:6;stroke-linecap:round}
.dpcs-svg .sw-sym circle{fill:var(--c-text)}
.dpcs-pics{display:flex;gap:10px;flex-wrap:wrap;margin:6px 0}
.dpcs-pic{flex:1;min-width:170px;max-width:260px;padding:8px;border:1px solid var(--c-line);border-radius:8px;background:var(--c-card);color:var(--c-text);font:600 13.5px Barlow,sans-serif;cursor:pointer;text-align:center}
.dpcs-pic svg{width:100%;height:auto;display:block;margin-bottom:6px}.dpcs-pic[aria-pressed=true]{border-color:var(--c-acc);box-shadow:inset 0 -3px 0 var(--c-acc)}
.dpcs-pic .frame{fill:none;stroke:var(--c-mute);stroke-width:2}.dpcs-pic .bed{fill:rgba(127,140,155,.18);stroke:var(--c-mute)}.dpcs-pic .bed.moving{fill:rgba(217,162,27,.2);stroke:#d9a21b}.dpcs-pic .gantry{fill:var(--c-card2);stroke:var(--c-mute)}.dpcs-pic .tool{fill:#2b8fe0}.dpcs-pic .arw{stroke:#2fb36a;stroke-width:3;fill:none}.dpcs-pic .ar{fill:#2fb36a}
@media (prefers-reduced-motion:no-preference){.dpcs-svg .bed.moving{animation:dpcsBed 3s ease-in-out infinite alternate}}
@keyframes dpcsBed{from{transform:translateY(-10px)}to{transform:translateY(12px)}}
@media (max-width:900px){#dpcs-modal .dpcs-main{grid-template-columns:1fr}#dpcs-modal .dpcs-yaml{display:none}#dpcs-modal.show-yaml .dpcs-yaml{display:flex;position:absolute;inset:56px 0 58px 0;z-index:2}#dpcs-modal .dpcs-q{padding:16px}}
@media (min-width:901px){#dpcs-modal .yaml-toggle{display:none}}
html.dpcs-open,html.dpcs-open body{overflow:hidden!important}html.dpcs-open body>*:not(#dpcs-modal){visibility:hidden}
#dpcs-modal .dpcs-q,#dpcs-modal .dpcs-yaml pre{overscroll-behavior:contain;contain:layout paint}
#dpcs-modal header .for{color:var(--c-mute);font:500 14px Barlow,sans-serif;margin-left:8px}@media (max-width:520px){#dpcs-modal header .for{display:none}}
#dpcs-modal footer [data-back]{border-color:var(--c-mute)!important;min-width:110px}
.dpcs-caution{border:1px solid var(--c-warn);border-left-width:4px;background:rgba(217,162,27,.12);padding:11px 14px;border-radius:6px;margin:10px 0;font-size:14px;line-height:1.5;color:var(--c-text)}.dpcs-caution strong{display:block;font-size:15px;margin-bottom:3px;color:var(--c-warn)}
#dpcs-modal .dpcs-caution{max-width:72ch}
`;
  document.head.appendChild(css);

  // ------------------------------------------------------------ flow state
  const st = {
    choice: null,      // "file" | "build" | "board"
    config: null,      // {text, name, source}
    result: null,      // validator result
    flashed: false,
    dialogPort: null,  // SerialPort used by ESP Web Tools
    erase: false,
    session: null, port: null,
    board: null,       // {id, label, chip, fw, configs?}
    apps: null,        // Set of app keys to install after flashing (null = not chosen yet: the licensed ones)
    appAccess: {},     // key -> {ok, why, link, label}
  };

  // ------------------------------------------------------------ boards
  const BOARDS_BASE = BASE.replace(/dpc-setup\/$/, "dpc-boards/");
  const OWN_BOARDS = [
    { id: "r3", label: "dpCREATOR R3", group: "dpCREATOR", chip: "esp32s3", fw: "controller" },
    { id: "r2", label: "dpCREATOR R2", group: "dpCREATOR", chip: "esp32s3", fw: "controller" },
    { id: "s3", label: "Other ESP32-S3 board (8 MB PSRAM: N8R8, N16R8, N32R8V)", group: "Other boards", chip: "esp32s3", fw: "controller" },
    { id: "wroom", label: "Other ESP32 (WROOM-32) board", group: "Other boards", chip: "esp32", fw: "controller32" },
  ];
  let catalogP = null;
  function catalog() {
    if (!catalogP) catalogP = fetch(BOARDS_BASE + "index.json").then((r) => (r.ok ? r.json() : { boards: [] })).catch(() => ({ boards: [] }));
    return catalogP;
  }
  function allBoards(cat) {
    return OWN_BOARDS.concat((cat.boards || []).map((b) => {
      const s3 = b.chip === "esp32s3";
      return { id: "c-" + b.id, label: b.label, group: s3 ? "ESP32-S3 boards" : "ESP32 (WROOM-32) boards: FluidNC community configs", chip: s3 ? "esp32s3" : "esp32", fw: s3 ? "controller" : "controller32", configs: b.configs, source: b.source || "community", note: b.note || "" };
    }));
  }
  const fwKey = () => (st.board && st.board.fw) || "controller";
  const withFw = (url) => String(url || "").replace(/([?&]fw=)controller(?=&|$)/, "$1" + fwKey());

  function render() {
    mount.innerHTML = `
<ol class="dpcs-steps">
  <li class="dpcs-step done" id="dpcs-s0">
    <h4>Your board</h4>
    <p>The board decides which build is flashed and which pins are checked.</p>
    <div class="dpcs-row"><select id="dpcs-board" aria-label="Your board" style="background:var(--c-bg);color:var(--c-text);border:1px solid var(--c-line);border-radius:6px;padding:8px 10px;font:14px Barlow,system-ui,sans-serif;max-width:100%"></select></div>
    <div id="dpcs-c0"></div>
  </li>
  <li class="dpcs-step now" id="dpcs-s1">
    <h4>Machine configuration</h4>
    <p>The firmware needs a <code>config.yaml</code> that matches your board and machine. Flashing replaces the one on the board, so choose it first: it is checked now and written back after flashing.</p>
    <div class="dpcs-choices" role="group" aria-label="Where the configuration comes from">
      <button type="button" class="dpcs-choice" data-choice="file" aria-pressed="false"><b>I have a config.yaml</b><span>Pick the file. It is checked at once against the firmware's own list of settings.</span></button>
      <button type="button" class="dpcs-choice dpcs-hidden" data-choice="template" aria-pressed="false"><b>Start from a board template</b><span id="dpcs-tpl-sub">Ready configs for this board from the FluidNC community, checked at once.</span></button>
      <button type="button" class="dpcs-choice" data-choice="build" aria-pressed="false"><b>Build my machine</b><span>Answer a few questions with pictures and get a commented config.yaml.</span></button>
      <button type="button" class="dpcs-choice" data-choice="board" aria-pressed="false"${hasSerial ? "" : " disabled"}><b>Keep the config on the board</b><span>Firmware update: read the board's current config.yaml over USB and check it first.</span></button>
    </div>
    <input type="file" id="dpcs-file" class="dpcs-hidden" accept=".yaml,.yml,.txt" tabindex="-1" aria-hidden="true">
    <div id="dpcs-c1"></div>
    <div id="dpcs-ready"></div>
  </li>
  <li class="dpcs-step" id="dpcs-sa">
    <h4>Apps on the controller</h4>
    <p>Choose what to put on the controller after flashing. Apps you have a licence for can be ticked; the others are greyed out.</p>
    <div id="dpcs-apps"><div class="dpcs-note">Checking your licences…</div></div>
  </li>
  <li class="dpcs-step" id="dpcs-sn">
    <h4>Network and login</h4>
    <p>A freshly flashed board has no access point and no password, so only USB reaches it. Enter them now: they are set over USB after flashing, then the board restarts on your network.</p>
    <div id="dpcs-net"></div>
  </li>
  <li class="dpcs-step" id="dpcs-s2">
    <h4>Flash the firmware</h4>
    <p>Connect the controller by USB and flash. In the flasher, <b>Erase device</b> also wipes the board's files, including <code>config.yaml</code>: that's fine, your configuration is written back in the next step.</p>
    <div class="dpcs-row"><button type="button" class="dpcs-btn" id="dpcs-flash">⚡ Flash via browser</button><a class="dpcs-btn ghost" href="${esc(mount.dataset.fwBin || mount.dataset.bin || "")}" id="dpcs-bin">⇓ Download .bin</a></div>
    <div id="dpcs-c2"></div>
  </li>
  <li class="dpcs-step" id="dpcs-s3">
    <h4>Write the configuration and check it</h4>
    <p>After flashing: the page reconnects over USB, writes <code>config.yaml</code> the same way Board tools → Files does, restarts the board and reads its boot log.</p>
    <div class="dpcs-row"><button type="button" class="dpcs-btn" id="dpcs-write" disabled>Write config.yaml to the board</button></div>
    <div id="dpcs-c3"></div>
  </li>
  <li class="dpcs-step" id="dpcs-s4">
    <h4>First run on the machine</h4>
    <p>Most problems only show up on the real machine: directions, steps/mm, switches and work zero. Go through these once, with a hand near the power switch.</p>
    <div id="dpcs-c4"><button type="button" class="dpcs-btn ghost" id="dpcs-checks-open">Show the first-run checks</button></div>
  </li>
</ol>`;
    $$(".dpcs-choice", mount).forEach((b) => (b.onclick = () => choose(b.dataset.choice)));
    $("#dpcs-file").onchange = onFile;
    $("#dpcs-flash").onclick = onFlash;
    $("#dpcs-write").onclick = () => writeBack();
    $("#dpcs-checks-open").onclick = () => renderChecks();
    if (!(mount.dataset.fwBin || mount.dataset.bin)) $("#dpcs-bin").remove();
    initBoards();
  }

  async function initBoards() {
    const sel = $("#dpcs-board");
    const fill = (list) => {
      const groups = {};
      list.forEach((b) => (groups[b.group] = groups[b.group] || []).push(b));
      sel.innerHTML = Object.keys(groups).map((g) => '<optgroup label="' + esc(g) + '">' + groups[g].map((b) => '<option value="' + esc(b.id) + '">' + esc(b.label) + "</option>").join("") + "</optgroup>").join("");
    };
    fill(OWN_BOARDS);
    sel.onchange = () => setBoard(sel.value);
    setBoard(st.board ? st.board.id : "r3", true);
    const cat = await catalog();
    const list = allBoards(cat);
    const keep = st.board ? st.board.id : "r3";
    fill(list);
    setBoard(list.some((b) => b.id === keep) ? keep : "r3", true);
  }

  let boardsList = OWN_BOARDS;
  async function setBoard(id, quiet) {
    const cat = await catalog();
    boardsList = allBoards(cat);
    const b = boardsList.find((x) => x.id === id) || OWN_BOARDS[0];
    const changedChip = st.board && st.board.chip !== b.chip;
    st.board = b;
    $("#dpcs-board").value = b.id;
    const tpl = $('[data-choice="template"]', mount);
    tpl.classList.toggle("dpcs-hidden", !(b.configs && b.configs.length));
    if (b.configs) $("#dpcs-tpl-sub").textContent = b.configs.length + " ready config" + (b.configs.length > 1 ? "s" : "") + " for the " + b.label + (b.source === "dpcreator" ? " made by dpCREATOR" : " from the FluidNC community") + ", checked at once.";
    if (st.choice === "template" && !b.configs) { st.choice = null; $$(".dpcs-choice", mount).forEach((x) => x.setAttribute("aria-pressed", "false")); $("#dpcs-c1").innerHTML = ""; }
    if (st.choice === "template" && b.configs) showTemplates();
    const c0 = $("#dpcs-c0");
    if (b.chip === "esp32") {
      c0.innerHTML = '<div class="dpcs-note">Flashes the <b>dpCREATOR firmware built for the classic ESP32 (WROOM-32)</b>: FluidNC 4.1.1 with Wi-Fi (no W5500 Ethernet). WebUI Lite goes into the board\'s flash; Studio and Motion go on its <b>SD card</b>, so put a FAT32 SD card in the board.</div><div id="dpcs-c0b"></div>';
      fetch("/fw.php?fw=controller32&f=version", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).catch(() => null).then((v) => {
        if (st.board !== b) return;
        st.fwMissing = !(v && v.version);
        $("#dpcs-c0b").innerHTML = st.fwMissing ? '<div class="dpcs-note warn">The ESP32 (WROOM-32) build is not on the shop yet; it is being finished. You can prepare the configuration and the apps now and flash when it is here.</div>' : '<p style="margin:4px 0 0;font-size:12.5px">Build ' + esc(String(v.version).split(" ")[0]) + "</p>";
        flashState();
      });
    } else {
      st.fwMissing = false;
      c0.innerHTML = '<div class="dpcs-note">Flashes the <b>dpCREATOR firmware for the ESP32-S3</b>: FluidNC 4.1.1 with W5500 Ethernet and Wi-Fi. Needs an ESP32-S3 module with 8 MB PSRAM (N8R8, N16R8 or N32R8V). The apps go in the controller\'s flash.</div>';
    }
    const dl = $("#dpcs-bin");
    if (dl) dl.href = withFw(mount.dataset.fwBin || mount.dataset.bin || "");
    flashState();
    access();
    renderApps();
    renderNet();
    if (changedChip && st.config) useConfig(st.config.text, st.config.name, st.config.source);
    if (!quiet) save();
  }

  function flashState() {
    const b = $("#dpcs-flash");
    if (!b || (st.access && !st.access.entitled)) return;
    b.disabled = !!st.fwMissing;
  }

  // Shown wherever a community config is offered or used.
  function cautionHtml(b) {
    if (b && b.source === "dpcreator") return '<div class="dpcs-caution"><strong>Use with caution</strong>Made by dpCREATOR from the board\'s published pins and not yet tried on this board. Check every pin against the board\'s own documentation before you connect motors.</div>';
    return '<div class="dpcs-caution"><strong>Use with caution: these configs come from public sources</strong>They were shared by FluidNC users and are copied unchanged. dpCREATOR has not tested them on your board. Check every pin against your board and its revision, set your machine\'s steps/mm, speeds and travel, and keep the E-stop at hand for the first moves.</div>';
  }
  const tplCache = {};
  function tplText(file) {
    if (tplCache[file]) return Promise.resolve(tplCache[file]);
    return fetch(BOARDS_BASE + file).then((r) => { if (!r.ok) throw new Error("HTTP " + r.status); return r.text(); }).then((t) => (tplCache[file] = t));
  }
  // What a template is: the board it was written for, its kinematics, I2S pins, the axes and their values.
  function tplInfo(text) {
    const root = S.parseConfig(text).root;
    const val = (n, k) => { const x = n && S.get(n, k); return x && x.value != null ? x.value : null; };
    const kin = S.get(root, "kinematics");
    const axN = S.get(root, "axes");
    const axes = (axN ? axN.children : []).filter((n) => /^[xyzabc]$/i.test(n.key)).map((n) => {
      const hom = S.get(n, "homing");
      const spm = +val(n, "steps_per_mm") || 0;
      return {
        axis: n.key.toLowerCase(), tplSpm: spm, spmOverride: spm || "", wantRate: +val(n, "max_rate_mm_per_min") || 1000, accel: +val(n, "acceleration_mm_per_sec2") || 100,
        travel: +val(n, "max_travel_mm") || 100, homeDir: hom ? (String(val(hom, "positive_direction")).toLowerCase() === "true" ? "max" : "min") : null,
        calc: { motorSteps: 200, micro: 16, drive: "belt", teeth: 20, pitch: 2, lead: 8 }, moves: "tool",
      };
    });
    return { board: val(root, "board") || "", name: val(root, "name") || "", kin: kin && kin.children[0] ? kin.children[0].key : "Cartesian", i2so: /\bi2so\.\d/i.test(text), axes };
  }
  const tplFor = (wf, label) => '<div class="dpcs-tplfor"><p style="margin:6px 0 0;font-size:13px">' + (wf ? 'Written for: <b data-no-i18n>' + esc(wf) + "</b>" : "") + "</p>" +
    (wf && label && !sameBoard(wf, label) ? '<div class="dpcs-note warn">This config was written for a different board or revision than the one you picked. Pick another one, or check every pin against your board.</div>' : "") + "</div>";

  async function showTemplates() {
    const b = st.board;
    if (!b || !b.configs) return;
    const box = $("#dpcs-c1");
    box.innerHTML = '<div class="dpcs-panel"><p style="margin:0 0 6px">Pick the template closest to your machine. It is checked against the firmware\'s settings at once; change it in the editor after.</p>' +
      '<div class="dpcs-row"><select id="dpcs-tpl" style="background:var(--c-bg);color:var(--c-text);border:1px solid var(--c-line);border-radius:6px;padding:7px 9px;font:14px Barlow,system-ui,sans-serif;max-width:100%">' +
      b.configs.map((c, i) => '<option value="' + i + '">' + esc(c.title) + (c.name && c.name.toLowerCase() !== c.title.toLowerCase() ? " - " + esc(c.name.slice(0, 60)) : "") + (c.errors ? " (" + c.errors + " problem" + (c.errors > 1 ? "s" : "") + " to fix)" : "") + "</option>").join("") +
      '</select><button type="button" class="dpcs-btn small" id="dpcs-tpl-use">Use this config</button></div>' + tplFor("") +
      cautionHtml(b) +
      (b.source === "dpcreator"
        ? '<p style="margin:6px 0 0;font-size:12px">Starting points made by dpCREATOR from the board\'s published pins (' + esc(b.note) + ').</p></div>'
        : '<p style="margin:6px 0 0;font-size:12px">Source: <a href="https://github.com/bdring/fluidnc-config-files" target="_blank" rel="noopener">FluidNC community config files</a>, licensed GPL-3.0. Want to change the mechanics with questions? Use <b>Build my machine</b>: it starts from these pins.</p></div>');
    const sel = $("#dpcs-tpl");
    const showFor = () => {
      const c = b.configs[+sel.value];
      tplText(c.file).then((t) => { if (sel.isConnected && b.configs[+sel.value] === c) $(".dpcs-tplfor", box).outerHTML = tplFor(tplInfo(t).board, b.label); }).catch(() => {});
    };
    sel.onchange = showFor;
    showFor();
    $("#dpcs-tpl-use").onclick = async () => {
      const c = b.configs[+sel.value];
      try {
        useConfig(await tplText(c.file), "config.yaml", b.label + " template \"" + c.title + "\"" + (b.source === "dpcreator" ? " (dpCREATOR, not yet tried)" : " (FluidNC community)"));
      } catch (e) { $("#dpcs-ready").innerHTML = '<div class="dpcs-note err">Could not load the template (' + esc(e.message || e) + ").</div>"; }
    };
  }

  // ------------------------------------------------------------ apps on the controller
  const APPS = [
    { key: "webui", name: "dpCREATOR WebUI", desc: "Run the machine from any browser: 3D toolpath, job recovery, live Z adjust." },
    { key: "studio", name: "dpCREATOR Studio", desc: "Design and make G-code in the browser; Send puts the job on the SD card." },
    { key: "motion", name: "dpCREATOR Motion", desc: "Build your machine part by part, teach positions and run sequences." },
  ];
  const appAccessP = {};
  function appAccess(key) {
    if (appAccessP[key]) return appAccessP[key];
    const get = (u) => fetch(u, { credentials: "same-origin", cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    appAccessP[key] = (async () => {
      if (key === "webui-lite") {
        const W = window.DPCWebUiInstaller;
        const v = W && W.shop && W.shop.liteVersion ? await W.shop.liteVersion() : null;
        if (!v || !v.version) return { ok: false, why: "WebUI Lite for WROOM-32 boards (free, works with Studio Basic) is coming soon. Until then the stock FluidNC WebUI comes with this build." };
        const a = await get("/studio.php?f=access");
        if (!a || !a.logged_in) return { ok: false, why: "WebUI Lite is free with an account: log in first.", link: LOGIN, linkText: "Log in" };
        return { ok: true, label: "WebUI Lite, free for WROOM-32 boards: the same WebUI with the features a WROOM-32 can't run turned off" };
      }
      if (key === "webui") {
        const a = await get("/webui.php?f=access");
        if (!a) return { ok: false, why: "Not available right now." };
        if (!a.logged_in) return { ok: false, why: "Log in to use your licence.", link: LOGIN, linkText: "Log in" };
        if (!a.entitled) return { ok: false, why: "No WebUI licence on this account. Free with the dpCREATOR R3; €39 for other ESP32-S3 boards.", link: "index.php?route=product/product&product_id=383", linkText: "Get the WebUI" };
        return { ok: true, label: a.via === "hardware" ? "included with your dpCREATOR hardware" : "licence active" };
      }
      if (key === "studio") {
        const a = await get("/studio.php?f=access");
        if (!a) return { ok: false, why: "Not available right now." };
        if (!a.logged_in) return { ok: false, why: "Free with an account: log in first.", link: LOGIN, linkText: "Log in" };
        const p = await get("/studio-pro.php?f=access");
        return { ok: true, label: p && p.pro && !p.trial ? "Studio Pro, licensed to your account" : "Studio Basic, free with your account" };
      }
      const a = await get("/motion.php?f=access");
      if (!a) return { ok: false, why: "Not available right now." };
      if (!a.logged_in) return { ok: false, why: "Log in to use your licence.", link: LOGIN, linkText: "Log in" };
      if (!a.entitled) return { ok: false, why: "No Motion licence on this account. Free with the R3; €19.99 for other boards while Motion is in beta, €29.99 after.", link: "index.php?route=product/product&product_id=391", linkText: "Get Motion" };
      return { ok: true, label: { hardware: "included with your dpCREATOR R3", bought: "licence active", beta: "beta licence (R&D Club)", admin: "shop admin" }[a.via] || "licence active" };
    })();
    return appAccessP[key];
  }

  async function renderApps() {
    const box = $("#dpcs-apps");
    if (!box) return;
    const b = st.board || OWN_BOARDS[0];
    const res = {};
    for (const a of APPS) res[a.key] = await appAccess(a.key === "webui" && b.chip === "esp32" ? "webui-lite" : a.key);
    st.appAccess = res;
    if (!st.apps) st.apps = new Set(APPS.filter((a) => res[a.key].ok).map((a) => a.key));
    APPS.forEach((a) => { if (!res[a.key].ok) st.apps.delete(a.key); });
    const where = b.chip === "esp32" ? "right after the configuration is written: WebUI Lite in the flash, Studio and Motion on the SD card (<code>/sd/…</code>)." : "in the controller's flash right after the configuration is written.";
    box.innerHTML = '<div class="dpcs-panel">' + APPS.map((a) => {
      const r = res[a.key];
      return '<label class="dpcs-app' + (r.ok ? "" : " off") + '" style="display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--c-line);cursor:' + (r.ok ? "pointer" : "not-allowed") + '">' +
        '<input type="checkbox" data-app="' + a.key + '"' + (r.ok ? "" : " disabled") + (st.apps.has(a.key) ? " checked" : "") + ' style="margin-top:4px;width:17px;height:17px;accent-color:var(--c-acc)">' +
        '<span><span class="nm"><b style="display:block;font-size:14.5px">' + esc(a.name) + "</b>" +
        '<span style="font-size:13px;color:var(--c-mute)">' + esc(a.desc) + "</span></span><br>" +
        '<span style="font-size:12.5px;color:' + (r.ok ? "var(--c-ok)" : "var(--c-mute)") + '">' + esc(r.ok ? r.label : r.why) + "</span>" +
        (!r.ok && r.link ? ' <a href="' + esc(r.link) + '" style="font-size:12.5px;opacity:1">' + esc(r.linkText) + "</a>" : "") + "</span></label>";
    }).join("") +
      '<p style="margin:8px 0 0;font-size:12.5px">They are installed ' + where + " " +
      (b.chip === "esp32" ? "Put a FAT32 SD card in the board first. " : "") +
      'Firmware already on the board? <a href="#" id="dpcs-apps-now">Install the ticked apps now</a> (no flashing).</p></div>';
    $$("input[data-app]", box).forEach((i) => (i.onchange = () => { if (i.checked) st.apps.add(i.dataset.app); else st.apps.delete(i.dataset.app); save(); }));
    $("#dpcs-apps-now").onclick = async (e) => {
      e.preventDefault();
      if (!hasSerial) return;
      let sp = await findPort(st.sp || st.dialogPort);
      if (!sp) { try { sp = await navigator.serial.requestPort(); } catch (x) { return; } }
      await closeSession();
      $("#dpcs-apps").insertAdjacentHTML("beforeend", '<div id="dpcs-apps-out"></div>');
      await installApps(sp, $("#dpcs-apps-out"));
    };
  }

  // ------------------------------------------------------------ network and login (set over USB after flashing)
  // Kept in memory only (never saved in the browser). st.net = {mode, host, ssid, wpass, login}
  function renderNet() {
    const box = $("#dpcs-net");
    if (!box) return;
    const b = st.board || OWN_BOARDS[0];
    const eth = b.id === "r3" || b.id === "r2";
    const n = st.net || (st.net = { mode: eth ? "eth" : "wifi", host: "fluidnc", ssid: "", wpass: "", login: "", login2: "" });
    if (!eth && n.mode === "eth") n.mode = "wifi";
    const inp = 'style="background:var(--c-bg);color:var(--c-text);border:1px solid var(--c-line);border-radius:6px;padding:8px 10px;font:14px Barlow,system-ui,sans-serif;width:100%;box-sizing:border-box;display:block;margin-top:3px"';
    const radio = (v, label, sub) => '<label class="dpcs-app" style="display:flex;gap:10px;align-items:flex-start;padding:6px 0;cursor:pointer"><input type="radio" name="dpcs-netmode" value="' + v + '"' + (n.mode === v ? " checked" : "") + ' style="margin-top:4px;accent-color:var(--c-acc)"><span><b>' + label + '</b><br><span style="font-size:13px;color:var(--c-mute)">' + sub + "</span></span></label>";
    box.innerHTML = '<div class="dpcs-panel">' +
      (eth ? radio("eth", "Ethernet cable", "Plug the board into your router. It gets its address there (DHCP); nothing to type.") : "") +
      radio("wifi", "Wi-Fi", "The board joins your Wi-Fi network.") +
      radio("keep", "Keep the board's network settings", "Firmware update on a board that is already on your network.") +
      '<div id="dpcs-wifi" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;margin:8px 0"' + (n.mode === "wifi" ? "" : " hidden") + '>' +
      '<label style="font-size:13px;color:var(--c-mute)">Wi-Fi network (SSID)<input id="dpcs-ssid" autocomplete="off" ' + inp + ' value="' + esc(n.ssid) + '"></label>' +
      '<label style="font-size:13px;color:var(--c-mute)">Wi-Fi password<input id="dpcs-wpass" type="password" autocomplete="off" ' + inp + ' value="' + esc(n.wpass) + '"></label>' +
      '<div style="grid-column:1/-1;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button type="button" class="dpcs-btn ghost small" id="dpcs-scan">Find networks</button>' +
      '<select id="dpcs-aps" ' + inp.replace("width:100%", "width:auto;min-width:220px;flex:1").replace("display:block;", "") + (st.aps && st.aps.length ? "" : " hidden") + '>' + apOptions(n.ssid) + '</select>' +
      '<span id="dpcs-scanmsg" style="font-size:12.5px;color:var(--c-mute);flex-basis:100%">' + (st.aps && st.aps.length ? "" : "The board searches for networks over USB once the firmware is on it (step 5). You can also type the name.") + '</span></div></div>' +
      (n.mode !== "keep" ? '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;margin:8px 0">' +
        '<label style="font-size:13px;color:var(--c-mute)">Board name on the network<input id="dpcs-host" ' + inp + ' value="' + esc(n.host) + '"><span style="font-size:12px" id="dpcs-hosthint">opens as http://' + esc(n.host || "fluidnc") + '.local</span></label>' +
        '<label style="font-size:13px;color:var(--c-mute)">Login password (8 characters or more)<input id="dpcs-login" type="password" autocomplete="new-password" ' + inp + ' value="' + esc(n.login) + '"></label>' +
        '<label style="font-size:13px;color:var(--c-mute)">Login password again<input id="dpcs-login2" type="password" autocomplete="new-password" ' + inp + ' value="' + esc(n.login2) + '"></label></div>' +
        '<p style="margin:0;font-size:12.5px">The login protects the board on your network: the WebUI and the apps ask for it. Leave it empty to set it on the first visit instead. Nothing here is stored by this page.</p>' : "") +
      '<div id="dpcs-netmsg"></div>' +
      '<p style="margin:8px 0 0;font-size:12.5px">Board already flashed? <a href="#" id="dpcs-net-now">Set the network and login now over USB</a>.</p></div>';
    $$('input[name="dpcs-netmode"]', box).forEach((r) => (r.onchange = () => { n.mode = r.value; renderNet(); }));
    const bind = (id, k) => { const e = $("#" + id); if (e) e.oninput = () => { n[k] = id === "dpcs-host" ? e.value.replace(/[^A-Za-z0-9-]/g, "").slice(0, 32) : e.value; if (id === "dpcs-host") { if (e.value !== n[k]) e.value = n[k]; $("#dpcs-hosthint").textContent = "opens as http://" + (n[k] || "fluidnc") + ".local"; } netCheck(); }; };
    bind("dpcs-ssid", "ssid"); bind("dpcs-wpass", "wpass"); bind("dpcs-host", "host"); bind("dpcs-login", "login"); bind("dpcs-login2", "login2");
    const scan = $("#dpcs-scan"), aps = $("#dpcs-aps");
    if (aps) aps.onchange = () => { if (!aps.value) return; n.ssid = aps.value; $("#dpcs-ssid").value = aps.value; netCheck(); const w = $("#dpcs-wpass"); if (w) w.focus(); };
    if (scan) scan.onclick = () => scanNetworks(scan);
    $("#dpcs-net-now").onclick = async (e) => {
      e.preventDefault();
      if (!netCheck(true) || !hasSerial) return;
      let sp = await findPort(st.sp || st.dialogPort);
      if (!sp) { try { sp = await navigator.serial.requestPort(); } catch (x) { return; } }
      await closeSession();
      await applyNetwork(sp, $("#dpcs-netmsg"));
    };
    netCheck();
  }
  /** The networks the board found (st.aps), as <option>s; the one typed is selected. */
  function apOptions(cur) {
    const list = st.aps || [];
    const bars = (dbm) => (dbm >= -55 ? "▂▄▆█" : dbm >= -67 ? "▂▄▆" : dbm >= -78 ? "▂▄" : "▂");
    return '<option value="">Choose a network</option>' + list.map((a) => '<option value="' + esc(a.ssid) + '"' + (a.ssid === cur ? " selected" : "") + ">" + esc(a.ssid) + "  " + bars(a.signal) + (a.secure ? "  🔒" : "") + "</option>").join("");
  }
  /** Ask the board over USB which Wi-Fi networks it sees ($WiFi/ListAPs). Needs FluidNC on the board. */
  async function scanNetworks(btn) {
    const msg = $("#dpcs-scanmsg");
    const say = (t) => { if (msg) msg.textContent = t; };
    if (!hasSerial) { say("Searching needs Chrome or Edge on a computer. Type the network name instead."); return; }
    let sp = await findPort(st.sp || st.dialogPort);
    if (!sp) { try { sp = await navigator.serial.requestPort(); } catch (x) { return; } }
    btn.disabled = true;
    say("Connecting to the board over USB…");
    await closeSession();
    let s = null;
    try {
      try { s = await startSession(sp, null); } catch (e) { throw new Error("Could not open the USB port. Close other programs that use it and try again."); }
      if (!(await waitReady(s.session, 8000))) throw new Error("The board does not answer. Flash the firmware first (step 5), then search again, or type the network name.");
      say("The board is looking for networks…");
      const r = await s.session.cmd("$WiFi/ListAPs", 20000);
      const text = (r.lines || []).filter((l) => !/^\[MSG:/.test(l)).join("");
      const a = text.indexOf("{"), b = text.lastIndexOf("}");
      if (!r.ok || a < 0) throw new Error("The board could not search for networks. Type the network name instead.");
      const j = JSON.parse(text.slice(a, b + 1));
      const seen = new Map();
      for (const ap of j.AP_LIST || j.data || []) {
        if (!ap.SSID) continue;
        const prev = seen.get(ap.SSID);
        if (!prev || +ap.SIGNAL > prev.signal) seen.set(ap.SSID, { ssid: ap.SSID, signal: +ap.SIGNAL, secure: ap.IS_PROTECTED === true || ap.IS_PROTECTED === "1" || ap.IS_PROTECTED === 1 });
      }
      st.aps = [...seen.values()].sort((x, y) => y.signal - x.signal);
      st.sp = sp;
      if (!st.aps.length) throw new Error("The board found no Wi-Fi networks. Move it closer to the router, or type the name.");
      const sel = $("#dpcs-aps");
      if (sel) { sel.innerHTML = apOptions(st.net.ssid); sel.hidden = false; sel.focus(); }
      say(st.aps.length === 1 ? "1 network found. Pick it, then enter its password." : st.aps.length + " networks found. Pick yours, then enter its password.");
    } catch (e) {
      say(e.message || String(e));
    } finally {
      if (s) { try { await s.port.close(); } catch (x) {} }
      btn.disabled = false;
    }
  }
  function netCheck(loud) {
    const n = st.net, m = $("#dpcs-netmsg");
    let err = "";
    if (n.mode === "wifi" && !n.ssid.trim()) err = "Enter the Wi-Fi network name.";
    else if (n.mode !== "keep" && n.login && n.login.length < 8) err = "The login password needs 8 characters or more.";
    else if (n.mode !== "keep" && n.login !== n.login2) err = "The two login passwords are not the same.";
    if (m && (loud || (err && (n.ssid || n.login)))) m.innerHTML = err ? '<div class="dpcs-note warn">' + esc(err) + "</div>" : "";
    else if (m && !err) m.innerHTML = "";
    return !err;
  }
  function netWanted() {
    const n = st.net;
    return !!n && n.mode !== "keep" && netCheck() && (n.mode === "wifi" || !!n.login || (n.host && n.host !== "fluidnc"));
  }

  /** Set Wi-Fi / name / login over USB, restart, and read the board's address from its boot log. */
  async function applyNetwork(sp, outEl) {
    const n = st.net;
    outEl.innerHTML = '<div class="dpcs-panel"><b>Network and login</b><div id="dpcs-nmsg" class="dpcs-note">Talking to the board…</div><details><summary style="font-size:12px;color:var(--c-mute)">Details</summary><div class="dpcs-log" id="dpcs-nlog"></div></details></div>';
    const say = (t, cls) => { const e = $("#dpcs-nmsg"); e.className = "dpcs-note" + (cls ? " " + cls : ""); e.innerHTML = t; };
    let s = null;
    try {
      for (let i = 0; i < 6 && !s; i++) { try { s = await startSession(sp, $("#dpcs-nlog")); } catch (e) { await sleep(800); sp = (await findPort(sp)) || sp; } }
      if (!s) throw new Error("Could not open the USB port. Close other programs that use it and try again.");
      if (!(await waitReady(s.session, 15000))) throw new Error("The board does not answer over USB.");
      const cmds = [];
      if (n.host && n.host !== "fluidnc") cmds.push("$Hostname=" + n.host);
      if (n.mode === "wifi") cmds.push("$Sta/SSID=" + n.ssid.trim(), "$Sta/Password=" + n.wpass, "$WiFi/Mode=STA");
      for (const c of cmds) {
        const r = await s.session.cmd(c, 4000);
        if (!r.ok) throw new Error("The board refused " + c.split("=")[0] + " (" + (r.error || "no answer") + ").");
      }
      if (n.login) {
        const r = await s.session.cmd("$Auth/Set=" + n.login, 4000);
        const lines = (r.lines || []).join(" ");
        const bad = /\[MSG:Auth:err:([^\]]*)\]/.exec(lines);
        if (bad) throw new Error("Login password: " + bad[1]);
        if (!/\[MSG:Auth:set\]/.test(lines) && !r.ok) throw new Error("The board did not take the login password.");
      }
      say("Restarting the board on your network…");
      let before = s.lines.length;
      s.session.send("$Bye");
      await sleep(2500);
      if (s.session.closed) {
        try { await s.port.close(); } catch (e) {}
        s = null;
        for (let i = 0; i < 15 && !s; i++) { await sleep(1000); const p2 = await findPort(sp); if (!p2) continue; try { s = await startSession(p2, $("#dpcs-nlog")); sp = p2; before = 0; } catch (e) { s = null; } }
      }
      let ip = "";
      const end = Date.now() + 25000;
      while (s && !ip && Date.now() < end) {
        const m = s.lines.slice(before).map((l) => /(?:Connected - IP is|Ethernet IP is)\s+(\d+\.\d+\.\d+\.\d+)/.exec(l)).find(Boolean);
        if (m) ip = m[1]; else await sleep(500);
      }
      const host = (n.host || "fluidnc") + ".local";
      if (ip) say('<b>The board is on your network.</b> Open <a href="http://' + ip + '/" target="_blank" rel="noopener">http://' + ip + "/</a> or <code>http://" + esc(host) + "/</code>" + (n.login ? " and log in with your password." : ". The first visit asks you to set a login password."), "ok");
      else say("Settings saved and the board restarted, but it did not report an address yet. " + (n.mode === "wifi" ? "Check the Wi-Fi name and password (Board tools → Network), " : "Check the cable, ") + "or try <code>http://" + esc(host) + "/</code>.", "warn");
      if (s) { st.session = s.session; st.port = s.port; st.lines = s.lines; st.sp = sp; }
      return !!ip;
    } catch (e) {
      say(esc(e.message || e), "err");
      if (s) { try { await s.port.close(); } catch (x) {} }
      return false;
    }
  }

  /** Install the ticked apps over USB with the page's installers (WebUI / Studio / Motion cards). */
  async function installApps(sp, outEl) {
    const keys = APPS.map((a) => a.key).filter((k) => st.apps && st.apps.has(k) && st.appAccess[k] && st.appAccess[k].ok);
    if (!keys.length) return true;
    const W = window.DPCWebUiInstaller;
    const sd = (st.board && st.board.chip) === "esp32";
    outEl.innerHTML = '<div class="dpcs-panel"><b>Installing the apps</b><div class="dpcs-bar"><div id="dpcs-abar"></div></div><div id="dpcs-amsg" class="dpcs-note">Starting…</div><ul class="dpcs-probs" id="dpcs-alist"></ul><details><summary style="font-size:12px;color:var(--c-mute)">Details</summary><div class="dpcs-log" id="dpcs-alog"></div></details></div>';
    const amsg = (t, cls) => { const m = $("#dpcs-amsg"); m.className = "dpcs-note" + (cls ? " " + cls : ""); m.innerHTML = t; };
    const alog = logger($("#dpcs-alog"));
    const item = (ok, html) => $("#dpcs-alist").insertAdjacentHTML("beforeend", '<li class="' + (ok ? "info" : "error") + '"><span class="lv">' + (ok ? "OK" : "FAILED") + "</span><span>" + html + "</span></li>");
    let allOk = true;
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], app = APPS.find((a) => a.key === k);
      amsg("Installing " + esc(app.name) + " (" + (i + 1) + " of " + keys.length + ")…");
      const ui = { log: (l) => alog(l, /^> /.test(l) ? "out" : "in"), step: (s) => amsg(esc(app.name) + ": " + esc(s) + "…"), board: () => {}, progress: (p) => ($("#dpcs-abar").style.width = Math.round(((i + p) / keys.length) * 100) + "%") };
      let port = null;
      try {
        if (!W) throw new Error("The installer is not on this page. Reload the page.");
        port = await openPort(sp);
        let r;
        if (k === "webui") {
          r = await W.install(port, W.shop, ui, { chip: st.board && st.board.chip });
          item(true, (r && r.lite ? "WebUI Lite" : esc(app.name)) + ": open <code>http://&lt;your board&gt;/</code> and reload with Ctrl+F5.");
        } else {
          const I = k === "studio" ? window.DPCStudioInstaller : window.DPCMotionInstaller;
          if (!I) throw new Error("The " + app.name + " installer is not on this page. Reload the page.");
          if (I.shop && I.shop.access) await I.shop.access();
          r = await I.install(W, port, I.shop.fetchFile, ui, { sd });
          item(true, esc(app.name) + ": open <code>http://&lt;your board&gt;" + esc(r.path) + "</code>.");
        }
      } catch (e) {
        allOk = false;
        item(false, esc(app.name) + ": " + esc(e.message || e));
      } finally {
        if (port) { try { await port.close(); } catch (e) {} }
        await sleep(400);
      }
    }
    $("#dpcs-abar").style.width = "100%";
    amsg(allOk ? "Apps installed." : "Some apps were not installed: see above. You can try them again from their own tabs.", allOk ? "ok" : "warn");
    return allOk;
  }

  // Flashing needs an account (free): the same check the page's other firmware cards use.
  const LOGIN = "index.php?route=account/login&return=index.php%3Froute%3Dinformation%2Finformation%26information_id%3D8";
  function access() {
    const fw = fwKey();
    fetch("/fw.php?fw=" + fw + "&f=access", { credentials: "same-origin" }).then((r) => r.json()).then((a) => {
      st.access = a;
      if (a.entitled) return flashState();
      const b = $("#dpcs-flash"), dl = $("#dpcs-bin");
      if (dl) dl.remove();
      b.innerHTML = a.logged_in ? "🔒 Buy to unlock" : "🔒 Log in to flash";
      b.onclick = () => { save(); location.href = LOGIN; };
      $("#dpcs-c2").innerHTML = a.logged_in ? "" : '<div class="dpcs-note">The firmware is free for registered customers. Building and checking a configuration works without an account; your answers are kept while you log in.</div>';
    }).catch(() => {});
  }

  // keep the chosen config and the builder answers across a login (this browser only)
  const SKEY = "dpcs-state";
  function save() {
    try { localStorage.setItem(SKEY, JSON.stringify({ t: Date.now(), ans, config: st.config, choice: st.choice, board: st.board && st.board.id, apps: st.apps ? [...st.apps] : null })); } catch (e) {}
  }
  // how far this browser got (flashed, config written), so a reload does not start the steps again
  const PKEY = "dpcs-progress";
  function saveProgress() {
    try { localStorage.setItem(PKEY, JSON.stringify({ t: Date.now(), flashed: !!st.flashed, written: !!st.written, board: st.board && st.board.id })); } catch (e) {}
  }
  function restoreProgress() {
    try {
      const p = JSON.parse(localStorage.getItem(PKEY) || "null");
      if (!p || Date.now() - p.t > 2 * 864e5 || !st.config) return;
      if (p.board && st.board && p.board !== st.board.id) return;
      st.flashed = !!p.flashed;
      st.written = !!p.written;
      stepState();
      if (st.flashed) $("#dpcs-c2").innerHTML = '<div class="dpcs-note ok">Firmware flashed earlier in this browser. Flash again only for a new board or a new firmware.</div>';
      if (st.written) {
        $("#dpcs-s3").classList.add("done");
        $("#dpcs-s3").classList.remove("now");
        $("#dpcs-s4").classList.add("now");
        $("#dpcs-c3").innerHTML = '<div class="dpcs-note ok">config.yaml was written earlier in this browser. Write it again only if you changed it.</div>';
        renderChecks();
      }
    } catch (e) {}
  }
  function restore() {
    try {
      const s = JSON.parse(localStorage.getItem(SKEY) || "null");
      if (!s || Date.now() - s.t > 7 * 864e5) return;
      if (s.ans) ans = s.ans;
      if (s.apps) st.apps = new Set(s.apps);
      if (s.board) { st.board = { id: s.board }; setBoard(s.board, true); }
      if (s.config && s.config.text) {
        st.choice = s.choice;
        $$(".dpcs-choice", mount).forEach((b) => b.setAttribute("aria-pressed", b.dataset.choice === s.choice ? "true" : "false"));
        Promise.resolve(useConfig(s.config.text, s.config.name, s.config.source)).then(restoreProgress, restoreProgress);
      }
    } catch (e) {}
  }

  function stepState() {
    $("#dpcs-s1").classList.toggle("done", !!(st.config && st.result && st.result.ok));
    $("#dpcs-s1").classList.toggle("now", !(st.config && st.result && st.result.ok));
    $("#dpcs-s2").classList.toggle("now", !!(st.config && st.result && st.result.ok) && !st.flashed);
    $("#dpcs-s2").classList.toggle("done", st.flashed);
    $("#dpcs-s3").classList.toggle("now", st.flashed);
    $("#dpcs-write").disabled = !(st.config && hasSerial);
  }

  function choose(c) {
    st.choice = c;
    $$(".dpcs-choice", mount).forEach((b) => b.setAttribute("aria-pressed", b.dataset.choice === c ? "true" : "false"));
    const box = $("#dpcs-c1");
    if (c === "file") { box.innerHTML = ""; $("#dpcs-file").value = ""; $("#dpcs-file").click(); }
    else if (c === "build") { box.innerHTML = ""; openBuilder(); }
    else if (c === "template") showTemplates();
    else if (c === "board") readFromBoard();
  }

  async function onFile(ev) {
    const f = ev.target.files && ev.target.files[0];
    if (!f) return;
    const text = await f.text();
    useConfig(text, f.name, "your file " + f.name);
  }

  async function useConfig(text, name, source) {
    st.config = { text, name: name || "config.yaml", source };
    $("#dpcs-ready").innerHTML = '<div class="dpcs-note">Checking ' + esc(source) + "…</div>";
    let r;
    try { r = await check(text); } catch (e) {
      $("#dpcs-ready").innerHTML = '<div class="dpcs-note err">Could not load the firmware\'s list of settings (' + esc(e.message || e) + "). Reload the page and try again.</div>";
      return;
    }
    st.result = r;
    showResult();
    stepState();
    save();
  }

  function probList(r) {
    if (!r.problems.length) return "";
    return '<ul class="dpcs-probs">' + r.problems.map((p) => '<li class="' + p.level + '"><span class="lv">' + (p.level === "error" ? "ERROR" : p.level === "warn" ? "WARNING" : "NOTE") + (p.line ? '<br><a data-line="' + p.line + '">line ' + p.line + "</a>" : "") + "</span><span>" + esc(p.msg) + "</span></li>").join("") + "</ul>";
  }

  function showResult() {
    const r = st.result, box = $("#dpcs-ready");
    const pill = r.ok ? '<span class="dpcs-pill ok">ready</span>' : '<span class="dpcs-pill err">' + r.errors + " error" + (r.errors > 1 ? "s" : "") + "</span>";
    const w = r.warnings ? ' <span class="dpcs-pill warn">' + r.warnings + " warning" + (r.warnings > 1 ? "s" : "") + "</span>" : "";
    box.innerHTML = '<div class="dpcs-panel"><div class="dpcs-sum">' + pill + w + "<span><b>" + esc(st.config.name) + "</b> from " + esc(st.config.source) + "</span></div>" +
      (r.ok ? '<p style="margin:8px 0 0">Every key is one the firmware knows. ' + (r.warnings ? "Look at the warnings below before you flash." : "Nothing to fix.") + "</p>"
        : '<div class="dpcs-note err">The firmware would report <code>[MSG:ERR: …]</code> at boot and mark this configuration invalid. Fix the errors first.</div>') +
      (/\((FluidNC community|dpCREATOR, not yet tried)\)/.test(st.config.source) ? cautionHtml(/not yet tried/.test(st.config.source) ? { source: "dpcreator" } : null) : "") +
      probList(r) +
      '<div class="dpcs-row"><button type="button" class="dpcs-btn ghost small" id="dpcs-editbtn">Edit</button><button type="button" class="dpcs-btn ghost small" id="dpcs-dl">Download a copy</button>' +
      (st.choice === "build" ? '<button type="button" class="dpcs-btn ghost small" id="dpcs-rebuild">Back to the builder</button>' : "") + "</div>" +
      '<div id="dpcs-editor" class="dpcs-hidden"><textarea class="dpcs-edit" spellcheck="false" aria-label="config.yaml"></textarea><div class="dpcs-row"><button type="button" class="dpcs-btn small" id="dpcs-recheck">Check again</button></div></div>' +
      '<p style="margin:8px 0 0;font-size:12px">Checked against the firmware\'s settings list (' + esc(schemaSrc) + ").</p></div>";
    $("#dpcs-editbtn").onclick = () => openEditor();
    $("#dpcs-dl").onclick = () => saveFile(st.config.name || "config.yaml", st.config.text);
    if ($("#dpcs-rebuild")) $("#dpcs-rebuild").onclick = () => openBuilder();
    $$(".dpcs-probs a[data-line]", box).forEach((a) => (a.onclick = () => openEditor(+a.dataset.line)));
  }

  function openEditor(line) {
    const ed = $("#dpcs-editor");
    ed.classList.remove("dpcs-hidden");
    const ta = $("textarea", ed);
    if (!ta.value) ta.value = st.config.text;
    $("#dpcs-recheck").onclick = () => useConfig(ta.value, st.config.name, st.config.source + " (edited)").then(() => { const e2 = $("#dpcs-editor"); if (e2) { e2.classList.remove("dpcs-hidden"); $("textarea", e2).value = ta.value; } });
    if (line) {
      const lines = ta.value.split("\n");
      let pos = 0;
      for (let i = 0; i < line - 1 && i < lines.length; i++) pos += lines[i].length + 1;
      ta.focus();
      ta.setSelectionRange(pos, pos + (lines[line - 1] || "").length);
      ta.scrollTop = Math.max(0, (line - 4) * 18);
    }
  }

  function saveFile(name, text) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "text/yaml" }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // ------------------------------------------------------------ USB helpers
  function wrap(sp) {
    const reader = sp.readable.getReader();
    const writer = sp.writable.getWriter();
    return {
      sp,
      read: async () => { const { value, done } = await reader.read(); return done ? null : value; },
      write: (b) => writer.write(b),
      close: async () => {
        try { await reader.cancel(); } catch (e) {}
        try { reader.releaseLock(); writer.releaseLock(); } catch (e) {}
        try { await sp.close(); } catch (e) {}
      },
    };
  }
  async function openPort(sp) {
    await sp.open({ baudRate: 115200, bufferSize: 65536 });
    return wrap(sp);
  }
  // A port we may use without asking again: the flasher's, or a granted one with the same USB ids.
  async function findPort(prefer) {
    const ports = await navigator.serial.getPorts();
    if (prefer && ports.includes(prefer)) return prefer;
    const info = prefer && prefer.getInfo ? prefer.getInfo() : null;
    if (info) {
      const same = ports.filter((p) => { const i = p.getInfo(); return i.usbVendorId === info.usbVendorId && i.usbProductId === info.usbProductId; });
      if (same.length === 1) return same[0];
    }
    if (ports.length === 1) return ports[0];
    return null;
  }

  function logger(el) {
    return (line, dir) => {
      const s = document.createElement("span");
      if (dir === "out") s.className = "o";
      else if (/\[MSG:ERR|^error:|Ignored key|Configuration is invalid/i.test(line)) s.className = "e";
      s.textContent = (dir === "out" ? "> " : "") + line + "\n";
      el.appendChild(s);
      while (el.childNodes.length > 600) el.removeChild(el.firstChild);
      el.scrollTop = el.scrollHeight;
    };
  }

  async function startSession(sp, logEl) {
    const port = await openPort(sp);
    const lines = [];
    const log = logEl ? logger(logEl) : () => {};
    const session = window.DPCBoardTools.Session(port, { onLine: (l, dir) => {
      if (dir === "in") { lines.push(l); if (lines.length > 3000) lines.splice(0, 1000); }
      if (st.quietStatus && ((dir === "in" && /^<.*>$/.test(l)) || (dir === "out" && l === "?"))) return;
      if (dir === "out") l = l.replace(/^(\$(?:Sta\/Password|Auth\/Set)=).*$/, "$1********");
      log(l, dir);
    } });
    return { port, session, lines };
  }

  async function waitReady(session, ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const r = await session.cmd("$I", 2500);
      if (r.ok) return r;
      if (session.closed) return null;
      await sleep(700);
    }
    return null;
  }

  // ------------------------------------------------------------ keep the board's config
  async function readFromBoard() {
    const box = $("#dpcs-c1");
    box.innerHTML = '<div class="dpcs-panel"><p style="margin:0 0 6px">Connect the controller by USB and pick its port. The page reads the active config file and checks it.</p><div class="dpcs-row"><button type="button" class="dpcs-btn" id="dpcs-rd">Connect and read</button></div><div class="dpcs-log dpcs-hidden" id="dpcs-rdlog"></div><div id="dpcs-rdmsg"></div></div>';
    $("#dpcs-rd").onclick = async () => {
      const msg = $("#dpcs-rdmsg"), logEl = $("#dpcs-rdlog");
      let sp;
      try { sp = await navigator.serial.requestPort(); } catch (e) { return; }
      logEl.classList.remove("dpcs-hidden");
      let s;
      try {
        s = await startSession(sp, logEl);
        msg.innerHTML = '<div class="dpcs-note">Talking to the board…</div>';
        if (!(await waitReady(s.session, 8000))) throw new Error("The board does not answer. Is FluidNC running on it (not the bootloader)?");
        let name = (await s.session.getSetting("Config/Filename")) || "config.yaml";
        name = name.replace(/^\/?(localfs\/)?/, "");
        const list = await s.session.listFiles("localfs", "/");
        const f = list.files.find((x) => x.name === name);
        if (!f) throw new Error("The board has no " + name + " in its flash.");
        const bytes = await s.session.download("localfs", name, f.size);
        const text = new TextDecoder().decode(bytes);
        msg.innerHTML = '<div class="dpcs-note ok">Read ' + esc(name) + " (" + bytes.length + " bytes) from the board. The USB port is closed again so the flasher can use it.</div>";
        await s.port.close();
        st.dialogPort = sp;
        useConfig(text, "config.yaml", "the board (" + name + ")");
      } catch (e) {
        msg.innerHTML = '<div class="dpcs-note err">' + esc(e.message || e) + "</div>";
        if (s) try { await s.port.close(); } catch (x) {}
      }
    };
  }

  // ------------------------------------------------------------ flash (ESP Web Tools)
  function onFlash() {
    const box = $("#dpcs-c2");
    if (!st.config || !st.result) {
      box.innerHTML = '<div class="dpcs-note warn">No configuration chosen. The board will start with the firmware\'s default config.yaml, which does not match your machine. <a href="#" id="dpcs-flash-anyway">Flash anyway</a></div>';
      $("#dpcs-flash-anyway").onclick = (e) => { e.preventDefault(); box.innerHTML = ""; startFlash(); };
      return;
    }
    if (!st.result.ok) {
      box.innerHTML = '<div class="dpcs-note err">The configuration still has errors (step 1). Fix them first, or <a href="#" id="dpcs-flash-anyway">flash anyway</a> and fix it later.</div>';
      $("#dpcs-flash-anyway").onclick = (e) => { e.preventDefault(); box.innerHTML = ""; startFlash(); };
      return;
    }
    box.innerHTML = "";
    startFlash();
  }
  async function startFlash() {
    await closeSession();   // the flasher needs the USB port
    const b = document.createElement("button");
    b.setAttribute("data-manifest", withFw(mount.dataset.fwManifest || mount.dataset.manifest));
    b.setAttribute("data-name", (st.board && st.board.chip === "esp32" ? "dpCREATOR firmware for ESP32 (WROOM-32)" : mount.dataset.name) || "dpCREATOR controller firmware");
    if (typeof window.dpcFlash === "function") window.dpcFlash(b);
    watchDialog();
  }
  let watching = false;
  function watchDialog() {
    if (watching) return;
    watching = true;
    let dlg = null, finished = false, noted = false;
    const t = setInterval(() => {
      const d = document.querySelector("ewt-install-dialog");
      if (d && d !== dlg) { dlg = d; finished = false; noted = false; }
      if (dlg) {
        if (dlg.port) st.dialogPort = dlg.port;
        // "Erase device" question, or the erase confirmation (boards without Improv are always erased):
        // say what it means for config.yaml
        const sr = dlg.shadowRoot;
        const asking = dlg._state === "ASK_ERASE" || (dlg._state === "INSTALL" && !dlg._installConfirmed && dlg._installErase);
        if (asking && sr && !sr.querySelector(".dpcs-erase")) {
          const host = (sr.querySelector("label.formfield") || {}).parentNode || sr.querySelector('[slot="content"]');
          if (host) {
            const n = document.createElement("div");
            n.className = "dpcs-erase";
            n.style.cssText = "margin:10px 0 0;padding:8px 10px;border-left:3px solid #d9a21b;background:rgba(217,162,27,.12);font-size:14px;line-height:1.4";
            n.textContent = st.config ? "Erasing also wipes config.yaml on the board. That's fine: this page writes your configuration back right after flashing." : "Erasing also wipes config.yaml and every other file on the board. Choose a configuration in step 1 first, so this page can write it back.";
            host.appendChild(n);
          }
        }
        void noted;
        if (dlg._installErase) st.erase = true;
        const s = dlg._installState;
        if (s && s.state === "finished" && !finished) {
          finished = true;
          st.flashed = true;
          saveProgress();
          stepState();
          $("#dpcs-c2").innerHTML = '<div class="dpcs-note ok">Firmware flashed' + (st.erase ? " (device erased)" : "") + ". Close the flasher window" + (st.config ? ": the configuration is written next." : ".") + "</div>";
        }
        if (!document.body.contains(dlg)) {
          const wasFinished = finished;
          dlg = null;
          clearInterval(t);
          watching = false;
          if (wasFinished) {
            if (typeof window.dpcCloseModal === "function" && document.getElementById("dpc-flash-modal")) window.dpcCloseModal("dpc-flash-modal");
            $("#dpcs-s3").scrollIntoView({ behavior: "smooth", block: "start" });
            if (st.config) setTimeout(() => writeBack(true), 700);
          }
        }
      }
    }, 400);
  }

  // ------------------------------------------------------------ write back + boot check
  async function writeBack(auto, opts) {
    opts = opts || {};
    const box = $("#dpcs-c3");
    if (!st.config) { box.innerHTML = '<div class="dpcs-note warn">Choose a configuration in step 1 first.</div>'; return; }
    if (st.result && !st.result.ok) box.innerHTML = '<div class="dpcs-note warn">The configuration has errors (step 1). It is written anyway so you can see the board\'s own messages.</div>';
    else box.innerHTML = "";
    box.insertAdjacentHTML("beforeend", '<div class="dpcs-bar"><div id="dpcs-wbar"></div></div><div id="dpcs-wmsg" class="dpcs-note">Opening the USB port…</div><div class="dpcs-log" id="dpcs-wlog"></div><div id="dpcs-verdict"></div>');
    const msg = (t, cls) => { const m = $("#dpcs-wmsg"); m.className = "dpcs-note" + (cls ? " " + cls : ""); m.innerHTML = t; };
    const bar = (p) => ($("#dpcs-wbar").style.width = Math.round(p * 100) + "%");
    $("#dpcs-write").disabled = true;
    try {
      await closeSession();
      let sp = await findPort(st.sp || st.dialogPort);
      if (!sp) {
        if (opts.configOnly) throw new Error("The page lost the board's USB port. Click Connect over USB in the first-run checks, then try again.");
        if (auto) { msg('Click <b>Write config.yaml to the board</b> and pick the controller\'s port.', "warn"); $("#dpcs-write").disabled = false; return; }
        sp = await navigator.serial.requestPort();
      }
      let s = null;
      for (let i = 0; i < 6 && !s; i++) {
        try { s = await startSession(sp, $("#dpcs-wlog")); } catch (e) { await sleep(800); sp = (await findPort(sp)) || sp; }
      }
      if (!s) throw new Error("Could not open the USB port. Close other programs that use it, then click Write again.");
      msg("Waiting for the board to start…");
      bar(0.1);
      if (!(await waitReady(s.session, 20000))) throw new Error("The board does not answer over USB. Unplug and replug the USB cable, then click Write again.");
      msg("Writing config.yaml…");
      const bytes = new TextEncoder().encode(st.config.text.endsWith("\n") ? st.config.text : st.config.text + "\n");
      await s.session.upload("localfs", "config.yaml", bytes, (p) => bar(0.1 + p * 0.6));
      const fn = await s.session.getSetting("Config/Filename");
      if (fn && fn.replace(/^\/?(localfs\/)?/, "") !== "config.yaml") await s.session.setSetting("Config/Filename", "config.yaml");
      msg("Written (" + bytes.length + " bytes). Restarting the board…");
      bar(0.75);
      let before = s.lines.length;
      s.session.send("$Bye");
      // Native USB disconnects on restart; a USB-UART bridge stays open and shows the boot log.
      await sleep(2500);
      if (s.session.closed) {
        try { await s.port.close(); } catch (e) {}
        s = null;
        for (let i = 0; i < 15 && !s; i++) {
          await sleep(1000);
          const p2 = await findPort(sp);
          if (!p2) continue;
          try { s = await startSession(p2, $("#dpcs-wlog")); sp = p2; before = 0; } catch (e) { s = null; }
        }
        if (!s) throw new Error("The board restarted but the USB port did not come back. Click Write again, or check the boot log in Board tools → Terminal ($SS).");
      } else await sleep(2500);
      msg("Reading the boot log…");
      if (!(await waitReady(s.session, 15000))) throw new Error("The board does not answer after the restart.");
      const ss = await s.session.cmd("$SS", 6000);
      const bootLines = s.lines.slice(before).concat(ss.lines || []);
      bar(1);
      st.session = s.session; st.port = s.port; st.sp = sp; st.lines = s.lines;
      const good = verdict(bootLines);
      if (good) { st.written = true; saveProgress(); }
      if (opts.configOnly) return good;
      if (good && st.apps && st.apps.size) {
        await closeSession();
        await sleep(300);
        box.insertAdjacentHTML("beforeend", '<div id="dpcs-apps-run"></div>');
        await installApps(sp, $("#dpcs-apps-run"));
        if (!netWanted()) {
          // back on the board for the first-run checks
          try { const s2 = await startSession(sp, $("#dpcs-wlog")); if (await waitReady(s2.session, 8000)) { st.session = s2.session; st.port = s2.port; st.lines = s2.lines; } } catch (e) {}
          renderChecks();
        }
      }
      if (good && netWanted()) {
        await closeSession();
        await sleep(300);
        box.insertAdjacentHTML("beforeend", '<div id="dpcs-net-run"></div>');
        await applyNetwork(sp, $("#dpcs-net-run"));
        renderChecks();
      }
      return good;
    } catch (e) {
      if (e && e.name === "NotFoundError") { msg("No port chosen.", "warn"); }
      else msg(esc(e.message || e), "err");
      if (opts.configOnly) throw e;
      return false;
    } finally {
      $("#dpcs-write").disabled = false;
    }
  }
  async function closeSession() {
    if (st.port) { try { await st.port.close(); } catch (e) {} }
    st.port = null; st.session = null;
  }

  function verdict(lines) {
    const errs = lines.filter((l) => /\[MSG:ERR|Ignored key|Configuration is invalid/i.test(l));
    const uniq = errs.filter((l, i) => errs.indexOf(l) === i);
    const cfg = lines.find((l) => /Configuration file:?\s*(\S+)/i.test(l));
    const v = $("#dpcs-verdict");
    $("#dpcs-wmsg").classList.add("dpcs-hidden");
    if (uniq.length) {
      v.innerHTML = '<div class="dpcs-note err"><b>The board rejected part of the configuration.</b> Any of these lines makes the whole config invalid:<ul class="dpcs-probs">' + uniq.map((l) => "<li class=\"error\"><span class=\"lv\">ERR</span><span><code>" + esc(l) + "</code></span></li>").join("") + "</ul>Fix them in step 1 (Edit), then click Write again.</div>";
      $("#dpcs-s3").classList.remove("done");
      return false;
    } else {
      v.innerHTML = '<div class="dpcs-note ok"><b>Configuration loaded.</b> ' + (cfg ? esc(cfg.replace(/^\[MSG:INFO: ?/, "").replace(/\]$/, "")) + ". " : "") + "No <code>ERR</code> lines in the boot log. Now the first-run checks below.</div>";
      $("#dpcs-s3").classList.add("done");
      $("#dpcs-s3").classList.remove("now");
      $("#dpcs-s4").classList.add("now");
      renderChecks();
      return true;
    }
  }

  // ------------------------------------------------------------ first-run checks (brief 2.11)
  function cfgAxes() {
    if (!st.config) return ["x", "y", "z"];
    const t = S.parseConfig(st.config.text);
    const a = S.child(t.root, "axes");
    return a ? a.children.map((c) => c.key).filter((k) => /^[xyzabc]$/.test(k)) : ["x", "y", "z"];
  }
  function cfgVal(path) {
    if (!st.config) return null;
    const n = S.get(S.parseConfig(st.config.text).root, path);
    return n ? n.value : null;
  }
  // axis colours, as on most CNC software: X red, Y green, Z blue
  function axColor(a) { return { x: "#e0564c", y: "#2fb36a", z: "#2b8fe0", a: "#d9a21b", b: "#b48cf0", c: "#4fb4ee" }[a] || "var(--c-acc)"; }
  function renderChecks() {
    const box = $("#dpcs-c4");
    const live = !!st.session;
    const axes = cfgAxes();
    const laser = st.config && /^Laser:/m.test(st.config.text);
    const laserTool = (cfgVal("Laser.tools") || "").split(/\s+/)[0];
    const btn = (id, label, ghost) => live ? '<button type="button" class="dpcs-btn small' + (ghost ? " ghost" : "") + '" id="' + id + '">' + label + "</button>" : "";
    const cal = st.cal || (st.cal = { ax: axes[0] || "x", cmd: 100, mp: "", mn: "" });
    if (!axes.includes(cal.ax)) cal.ax = axes[0] || "x";
    const dirWord = { x: "the tool moves RIGHT", y: "the tool moves AWAY from you (a moving bed comes TOWARD you)", z: "the tool moves UP", a: "the axis turns the positive way" };
    box.innerHTML = (live ? '<div class="dpcs-note ok">Connected over USB: the buttons below send the commands for you. You can also type them in Board tools → Terminal.</div>'
      : '<div class="dpcs-note">' + (hasSerial ? '<button type="button" class="dpcs-btn small" id="dpcs-k-connect">Connect over USB</button> The buttons below then send the commands for you. Or type' : "Type") + ' the commands in Board tools → Terminal (or the WebUI console).<div id="dpcs-k-cmsg"></div></div>') +
      '<ol class="dpcs-checks">' +
      '<li id="dpcs-k1"><b>Boot log: no ERR lines</b><p>Any <code>Ignored key</code> or pin error makes the whole config invalid. Step 3 checks this; by hand: <code>$SS</code>.</p>' + btn("dpcs-k1b", "Read the boot log again", true) + '<div class="k-out"></div></li>' +
      '<li id="dpcs-k2"><b>Switches at rest: no Pn: letters</b><p>Send <code>?</code> with nothing pressed. A letter with nothing pressed = wrong block, open wire, NO switch configured as NC, or the switch not on ' + (st.board && (st.board.id === "r3" || st.board.id === "r2") ? "LIMIT and LIMIT COM" : "its limit input and the isolated ground") + '.</p>' + btn("dpcs-k2b", "Check inputs", true) + '<div class="k-out"></div></li>' +
      '<li id="dpcs-k3"><b>Directions: tool relative to the work</b><p>Unlock with <code>$X</code>, jog each axis +10 mm and watch the <b>tool against the workpiece</b>, not the bed. Wrong way: flip that axis (the page toggles <code>:low</code> on its direction_pin and writes the config again).</p><div class="k-axes">' +
      axes.map((a) => '<div class="dpcs-row" data-ax="' + a + '"><b class="dpcs-axtag" style="--ax:' + axColor(a) + '">' + a.toUpperCase() + "</b>" + (live ? '<button type="button" class="dpcs-btn small ghost" data-jog="' + a + '">Jog ' + a.toUpperCase() + "+10</button>" : "<code>$J=G91 G21 " + a.toUpperCase() + "10 F300</code>") + '<span style="color:var(--c-mute);font-size:13px">expect: ' + (dirWord[a] || "+") + "</span>" + (live ? '<button type="button" class="dpcs-btn small ghost" data-flip="' + a + '">Wrong way: flip ' + a.toUpperCase() + "</button>" : "") + "</div>").join("") + '</div><div class="k-out"></div></li>' +
      '<li id="dpcs-k4"><b>Steps/mm over 100 mm</b><p>Mark the position, jog 100 mm (Z: 10-20 mm) and measure the real distance. Do it both ways if you can: the page uses the average, and a difference between the two shows backlash. New value = current × commanded ÷ measured.</p>' +
      '<div class="dpcs-row dpcs-axpick" role="group" aria-label="Axis">' + axes.map((a) => '<button type="button" class="dpcs-axbtn' + (a === cal.ax ? " on" : "") + '" data-calax="' + a + '" style="--ax:' + axColor(a) + '" aria-pressed="' + (a === cal.ax) + '">' + a.toUpperCase() + "</button>").join("") + "</div>" +
      '<div class="dpcs-row"><label>steps/mm now <input type="number" id="dpcs-cal-spm" step="0.001" min="0" value="' + esc(cal.spm !== "" && cal.spm != null ? cal.spm : (cfgVal("axes." + cal.ax + ".steps_per_mm") || "")) + '" style="width:110px"></label>' +
      (live ? '<button type="button" class="dpcs-btn small ghost" id="dpcs-spm-try">Try it now</button>' : "") + '<button type="button" class="dpcs-btn small" id="dpcs-spm-save">Save to config.yaml</button><span style="font-size:12.5px;color:var(--c-mute)">Type a value to set it by hand, or measure below.</span></div>' +
      '<div class="dpcs-row"><label>commanded <input type="number" id="dpcs-cal-cmd" min="1" value="' + esc(String(cal.cmd)) + '" style="width:80px"> mm</label>' +
      (live ? '<button type="button" class="dpcs-btn small ghost" data-caljog="1">Jog + </button><button type="button" class="dpcs-btn small ghost" data-caljog="-1">Jog − </button>' : "") + "</div>" +
      '<div class="dpcs-row"><label><span class="dpcs-dirtag" style="--ax:' + axColor(cal.ax) + '">+</span> measured <input type="number" id="dpcs-cal-mp" step="0.01" min="0" value="' + esc(cal.mp) + '" style="width:90px"> mm</label>' +
      '<label><span class="dpcs-dirtag" style="--ax:' + axColor(cal.ax) + '">−</span> measured <input type="number" id="dpcs-cal-mn" step="0.01" min="0" value="' + esc(cal.mn) + '" style="width:90px"> mm</label>' +
      '<button type="button" class="dpcs-btn small" id="dpcs-cal-go">Calculate</button></div><div class="k-out"></div></li>' +
      '<li id="dpcs-k5"><b>Press each switch: the right letter lights up</b><p>Live view of the inputs (<code>?</code> → <code>Pn:</code>).</p>' + btn("dpcs-k5b", "Start live view", true) + '<div class="dpcs-pn" id="dpcs-pn">' + ["X", "Y", "Z", "A", "P", "D", "R", "H", "S"].map((c) => '<span data-pn="' + c + '" title="' + ({ P: "probe", D: "door", R: "reset", H: "feed hold", S: "cycle start" }[c] || c + " limit") + '">' + c + "</span>").join("") + '</div><div class="k-out"></div></li>' +
      '<li id="dpcs-k6"><b>First homing</b><p>Hand on the power switch. <code>$H</code> homes Z first, then X/Y. Each axis must move <b>toward</b> its switch; if one goes away from it, stop and check positive_direction.</p>' + btn("dpcs-k6b", "Home ($H)") + '<div class="k-out"></div></li>' +
      '<li id="dpcs-k7"><b>Work zero on the stock</b><p>Jog to the front-left corner of the stock for X0 Y0 and to its top for Z0, then zero each axis there. The WebUI shows Machine (from the switches) and Work (from your zero) side by side; work zero must sit inside the machine travel.</p><div class="dpcs-row">' + btn("dpcs-k7xy", "Zero X and Y here", true) + btn("dpcs-k7z", "Zero Z here", true) + "</div>" + (live ? "" : "<p><code>G10 L20 P1 X0 Y0</code> then <code>G10 L20 P1 Z0</code></p>") + '<div class="k-out"></div></li>' +
      (laser ? '<li id="dpcs-k9"><b>Laser polarity, before connecting the laser</b><p>A reversed output fires the laser at full power while idle. With a meter on the output: <code>M6 T' + esc(laserTool || "0") + "</code>, <code>M3 S0</code> must read off; <code>M3 S" + esc(((cfgVal("Laser.speed_map") || "").match(/(\d+)=100/) || [])[1] || "255") + "</code> must read on; <code>M5</code>. Reversed: add or remove <code>:low</code> on Laser/output_pin.</p>" +
        (live ? '<div class="dpcs-row"><button type="button" class="dpcs-btn small ghost" data-cmds="M6 T' + esc(laserTool || "0") + '|M3 S0">Output OFF test</button><button type="button" class="dpcs-btn small ghost" data-cmds="M3 S' + esc(((cfgVal("Laser.speed_map") || "").match(/(\d+)=100/) || [])[1] || "255") + '">Output ON test</button><button type="button" class="dpcs-btn small" data-cmds="M5">M5 (off)</button></div>' : "") + '<div class="k-out"></div></li>' : "") +
      '<li id="dpcs-k8"><b>Load the job and run</b><p>In the WebUI, open the job and check that the travel warning ("Goes past the travel … by N mm") is gone. If it shows, the zero is wrong: re-zero on the stock, especially after any direction or homing change.</p></li>' +
      "</ol>";
    if (!live) {
      const c = $("#dpcs-k-connect");
      if (c) c.onclick = async () => {
        const m = $("#dpcs-k-cmsg");
        let sp = await findPort(st.sp || st.dialogPort);
        if (!sp) { try { sp = await navigator.serial.requestPort(); } catch (x) { return; } }
        c.disabled = true;
        m.textContent = "Connecting…";
        try {
          await closeSession();
          const s = await startSession(sp, null);
          if (!(await waitReady(s.session, 10000))) {
            const heard = s.lines.filter((l) => l.trim()).slice(-4);
            try { await s.port.close(); } catch (x) {}
            const boot = heard.some((l) => /rst:|Guru Meditation|abort\(\)|Backtrace|ESP-ROM/i.test(l));
            throw new Error((boot ? "The board keeps restarting, so it cannot answer. The config on it probably stops it: set the value back below (it changes the page's copy), then use Write config.yaml in step 6, or flash again with Erase device in step 5." : "The board does not answer over USB. Unplug and replug the USB cable, close other tabs or programs that use the port, then try again.") + (heard.length ? " Last lines from the board: " + heard.join(" | ") : " Nothing came from the board."));
          }
          st.session = s.session; st.port = s.port; st.lines = s.lines; st.sp = sp;
          renderChecks();
        } catch (e) {
          m.textContent = e && e.name === "InvalidStateError" || /Failed to open/i.test(e && e.message || "") ? "Could not open the USB port. Close other programs that use it (another tab, a terminal), then try again." : (e && e.message) || String(e);
          c.disabled = false;
        }
      };
      return;
    }
    const out = (li, html, cls) => { const o = $("#" + li + " .k-out"); o.innerHTML = '<div class="dpcs-note ' + (cls || "") + '">' + html + "</div>"; };
    const mark = (li, ok) => { const el = $("#" + li); el.classList.toggle("pass", ok === true); el.classList.toggle("fail", ok === false); };
    const send = async (c, ms) => st.session.cmd(c, ms || 8000);
    $("#dpcs-k1b").onclick = async () => {
      const r = await send("$SS", 6000);
      const errs = (r.lines || []).filter((l) => /\[MSG:ERR|Ignored key|Configuration is invalid/i.test(l));
      mark("dpcs-k1", !errs.length);
      out("dpcs-k1", errs.length ? errs.map((l) => "<code>" + esc(l) + "</code>").join("<br>") : "No ERR lines.", errs.length ? "err" : "ok");
    };
    // realtime '?' answers with a status report line (<Idle|MPos:..|Pn:XZ>); cmd() skips those, the session's line list keeps them
    async function pins() {
      const before = st.lines.length;
      st.quietStatus = true;
      await st.session.realtime(0x3f);
      let last = null;
      for (let i = 0; i < 10 && !last; i++) { await sleep(60); last = st.lines.slice(before).filter((l) => /^<.*>$/.test(l)).pop() || null; }
      if (!last) return null;
      const pn = (last.match(/\|Pn:([A-Z]+)/) || [])[1] || "";
      const state = (last.match(/^<([A-Za-z]+)/) || [])[1] || "";
      return { pn, state, raw: last };
    }
    $("#dpcs-k2b").onclick = async () => {
      const r = await pins();
      if (!r) return out("dpcs-k2", "No status report came back. Try again.", "warn");
      mark("dpcs-k2", !r.pn);
      out("dpcs-k2", r.pn ? "Active with nothing pressed: <b>" + esc(r.pn.split("").join(", ")) + "</b>. Check that switch: block, wiring between pins 8 and 7, NC vs NO." : "No inputs active. State: " + esc(r.state) + ".", r.pn ? "err" : "ok");
    };
    $$("[data-jog]", box).forEach((b) => (b.onclick = async () => {
      const a = b.dataset.jog.toUpperCase();
      const axi = "XYZABC".indexOf(a);
      const mpos = (raw) => { const m = /MPos:([-\d.,]+)/.exec(raw || ""); return m ? parseFloat(m[1].split(",")[axi]) : NaN; };
      await send("$X", 3000);
      const p0 = await pins();
      const r = await send("$J=G91 G21 " + a + "10 F300", 6000);
      if (!r.ok) {
        const e = String(r.error || "") + " " + (r.lines || []).join(" ");
        const hint = /15|travel/i.test(e) ? " The jog would go past the travel limit (max_travel_mm, soft limits): jog the other way first, or check " + a + "'s homing direction." : /alarm|9\b/i.test(e) ? " The board is in alarm: a limit switch or E-stop is active. Check the inputs (check 2)." : "";
        return out("dpcs-k3", "The board refused the jog: " + esc(e.trim()) + "." + esc(hint), "err");
      }
      out("dpcs-k3", "Jogging " + a + " +10 mm…");
      let p1 = null;
      for (let i = 0; i < 40; i++) { await sleep(250); p1 = await pins(); if (p1 && /^Idle/.test(p1.state)) break; }
      const d = p0 && p1 ? mpos(p1.raw) - mpos(p0.raw) : NaN;
      if (!isNaN(d) && Math.abs(d) < 0.01) return out("dpcs-k3", "The board did not move " + a + " (its position did not change). State: " + esc(p1 ? p1.state : "?") + ". Check the inputs (check 2) for an active switch or E-stop.", "err");
      out("dpcs-k3", "The board moved " + a + " +10 mm" + (isNaN(d) ? "" : " (position " + mpos(p0.raw).toFixed(2) + " → " + mpos(p1.raw).toFixed(2) + ")") + ". Expected: " + (dirWord[b.dataset.jog] || "the + way") + ". If it went the other way, click Wrong way. If the motor did not turn at all, the board sent the steps but they did not reach the motor: check " + a + "'s STEP/DIR wiring to its driver, the driver's power and enable, and its microstep switches.");
    }));
    $$("[data-flip]", box).forEach((b) => (b.onclick = async () => {
      const a = b.dataset.flip;
      const path = "axes." + a + ".motor0.standard_stepper.direction_pin";
      const cur = cfgVal(path);
      if (!cur) return out("dpcs-k3", "No direction_pin for " + a.toUpperCase() + " in the config.", "err");
      const parts = cur.split(":");
      const next = parts.includes("low") ? parts.filter((p) => p !== "low").join(":") : cur + ":low";
      await rewrite(path, next, "dpcs-k3", a.toUpperCase() + " direction flipped (" + cur + " → " + next + "). Homing direction may need the same flip: re-check step 6.");
    }));
    $$("[data-calax]", box).forEach((b) => (b.onclick = () => {
      const was = cal.ax;
      cal.ax = b.dataset.calax;
      if (cal.ax !== was) { cal.mp = ""; cal.mn = ""; cal.spm = ""; if ((cal.ax === "z") !== (was === "z") && (+cal.cmd === 100 || +cal.cmd === 20)) cal.cmd = cal.ax === "z" ? 20 : 100; }
      renderChecks();
    }));
    const keep = (id, k) => { const e = $("#" + id); if (e) e.oninput = () => (cal[k] = e.value); };
    keep("dpcs-cal-cmd", "cmd"); keep("dpcs-cal-mp", "mp"); keep("dpcs-cal-mn", "mn"); keep("dpcs-cal-spm", "spm");
    const spmVal = () => { const v = parseFloat($("#dpcs-cal-spm").value); return v > 0 && v < 1e6 ? Math.round(v * 1000) / 1000 : 0; };
    if ($("#dpcs-spm-try")) $("#dpcs-spm-try").onclick = async () => {
      const a = cal.ax, v = spmVal();
      if (!v) return out("dpcs-k4", "Enter a steps/mm value above 0.", "warn");
      const r = await send("$/axes/" + a + "/steps_per_mm=" + v, 4000);
      out("dpcs-k4", r.ok ? a.toUpperCase() + " set to " + v + " steps/mm until the next restart. Jog and measure, then save it." : "Refused: " + esc(r.error || ""), r.ok ? "ok" : "err");
    };
    $("#dpcs-spm-save").onclick = () => {
      const a = cal.ax, v = spmVal(), cur = cfgVal("axes." + a + ".steps_per_mm");
      if (!v) return out("dpcs-k4", "Enter a steps/mm value above 0.", "warn");
      if (String(v) === String(parseFloat(cur))) return out("dpcs-k4", a.toUpperCase() + " is already " + v + " steps/mm in config.yaml.", "ok");
      if (!live) { const nt = S.setValue(st.config.text, "axes." + a + ".steps_per_mm", String(v)); if (!nt) return out("dpcs-k4", "axes." + a + ".steps_per_mm is not in the config, so the page cannot change it. Edit it in step 1.", "err"); st.config.text = nt; save(); cal.spm = ""; renderChecks(); return out("dpcs-k4", a.toUpperCase() + " steps/mm changed to " + v + " in the page's config.yaml. Write it to the board in step 6.", "ok"); }
      cal.spm = "";
      rewrite("axes." + a + ".steps_per_mm", String(v), "dpcs-k4", a.toUpperCase() + " steps/mm saved as " + v + " (was " + cur + "). Check max_rate in step 1: at more steps/mm the driver may allow less speed.");
    };
    $$("[data-caljog]", box).forEach((b) => (b.onclick = async () => {
      const a = cal.ax.toUpperCase(), sign = +b.dataset.caljog, d = Math.abs(+cal.cmd) || 100;
      await send("$X", 3000);
      const r = await send("$J=G91 G21 " + a + (sign * d) + " F" + (a === "Z" ? 200 : 600), 8000);
      out("dpcs-k4", r.ok ? "Jogging " + a + (sign > 0 ? " +" : " −") + d + " mm. Measure the real distance and enter it in the " + (sign > 0 ? "+" : "−") + " box." : "Refused: " + esc(r.error || ""), r.ok ? "" : "err");
    }));
    $("#dpcs-cal-go").onclick = async () => {
      const a = cal.ax, cmd = Math.abs(+cal.cmd);
      const ms = [cal.mp, cal.mn].map((v) => Math.abs(parseFloat(v))).filter((v) => v > 0);
      const cur = parseFloat(cfgVal("axes." + a + ".steps_per_mm"));
      if (!cur) return out("dpcs-k4", "No steps_per_mm for " + a.toUpperCase() + " in the config.", "err");
      if (!cmd || !ms.length) return out("dpcs-k4", "Enter the commanded distance and at least one measured distance.", "warn");
      const meas = ms.reduce((x, y) => x + y, 0) / ms.length;
      const ratio = cmd / meas;
      const odd = ratio > 1.5 || ratio < 0.67;
      const nv = Math.round(((cur * cmd) / meas) * 1000) / 1000;
      const diff = ms.length === 2 ? Math.abs(ms[0] - ms[1]) : 0;
      cal.spm = String(nv); if ($("#dpcs-cal-spm")) $("#dpcs-cal-spm").value = nv;
      const oddNote = odd ? '<div class="dpcs-note warn">Measured ' + meas.toFixed(2) + " mm for " + cmd + " mm commanded is a big difference. Measure the distance the axis travelled (end minus start), not a position on the screen. If it is right, the motor or driver settings (microsteps, pulley, screw pitch) are wrong: check them in step 1 first.</div>" : "";
      const note = oddNote + (ms.length === 2
        ? (diff > Math.max(0.05, cmd * 0.001) ? '<div class="dpcs-note warn">The + and − moves differ by <b>' + diff.toFixed(2) + " mm</b>. That is backlash or something loose (pulley grub screw, coupler, belt tension, nut). Fix it first: steps/mm cannot correct it.</div>" : '<div class="dpcs-note ok">+ and − agree (' + diff.toFixed(2) + " mm apart).</div>")
        : '<div class="dpcs-note">Measured one way only. Measuring the other way too shows backlash.</div>');
      out("dpcs-k4", '<span class="dpcs-axtag" style="--ax:' + axColor(a) + '">' + a.toUpperCase() + "</span> steps/mm: <b>" + nv + "</b> (was " + cur + ", measured " + meas.toFixed(2) + " mm for " + cmd + " mm). " +
        '<button type="button" class="dpcs-btn small ghost" id="dpcs-cal-try">Try it now (until restart)</button> <button type="button" class="dpcs-btn small" id="dpcs-cal-save">Save to config.yaml</button>' + note);
      $("#dpcs-cal-try").onclick = async () => { const r = await send("$/axes/" + a + "/steps_per_mm=" + nv, 4000); out("dpcs-k4", r.ok ? "Set to " + nv + " until the next restart. Jog and measure again." : "Refused: " + esc(r.error || ""), r.ok ? "ok" : "err"); };
      $("#dpcs-cal-save").onclick = () => { cal.mp = ""; cal.mn = ""; cal.spm = ""; rewrite("axes." + a + ".steps_per_mm", String(nv), "dpcs-k4", a.toUpperCase() + " steps/mm saved as " + nv + ". Check max_rate in step 1: at more steps/mm the driver may allow less speed."); };
    };
    let liveT = null;
    $("#dpcs-k5b").onclick = async () => {
      if (liveT) { clearInterval(liveT); liveT = null; $("#dpcs-k5b").textContent = "Start live view"; return; }
      $("#dpcs-k5b").textContent = "Stop live view";
      const seen = new Set();
      liveT = setInterval(async () => {
        if (!st.session) { clearInterval(liveT); return; }
        const r = await pins();
        if (!r) return;
        $$("#dpcs-pn span").forEach((s) => s.classList.toggle("on", r.pn.includes(s.dataset.pn)));
        r.pn.split("").forEach((c) => seen.add(c));
        out("dpcs-k5", "Seen so far: " + (seen.size ? [...seen].join(", ") : "none"));
      }, 400);
    };
    $("#dpcs-k6b").onclick = async () => {
      out("dpcs-k6", "Homing… stop with the power switch if an axis runs away from its switch.");
      const r = await send("$H", 90000);
      mark("dpcs-k6", r.ok);
      out("dpcs-k6", r.ok ? "Homed. The machine position is now 0 at each switch." : "Homing failed: " + esc(r.error || "") + " " + esc((r.lines || []).filter((l) => /ALARM|ERR/.test(l)).join(" ")), r.ok ? "ok" : "err");
    };
    $("#dpcs-k7xy").onclick = async () => { const r = await send("G10 L20 P1 X0 Y0", 4000); out("dpcs-k7", r.ok ? "X0 Y0 set here (G54)." : "Refused: " + esc(r.error || ""), r.ok ? "ok" : "err"); };
    $("#dpcs-k7z").onclick = async () => { const r = await send("G10 L20 P1 Z0", 4000); out("dpcs-k7", r.ok ? "Z0 set here (G54)." : "Refused: " + esc(r.error || ""), r.ok ? "ok" : "err"); };
    $$("[data-cmds]", box).forEach((b) => (b.onclick = async () => {
      const res = [];
      for (const c of b.dataset.cmds.split("|")) { const r = await send(c, 4000); res.push(c + ": " + (r.ok ? "ok" : r.error)); }
      out("dpcs-k9", esc(res.join(" · ")) + ". Read the meter now.");
    }));
  }

  // change one value, write the file back, restart and re-check
  async function rewrite(path, value, li, okText) {
    if (/\.steps_per_mm$/.test(path) && !(parseFloat(value) > 0)) { const o = $("#" + li + " .k-out"); if (o) o.innerHTML = '<div class="dpcs-note err">steps/mm must be a positive number. Nothing was written.</div>'; return; }
    const nt = S.setValue(st.config.text, path, value);
    if (!nt) { const o = $("#" + li + " .k-out"); if (o) o.innerHTML = '<div class="dpcs-note err">' + esc(path) + " is not in the config, so the page cannot change it. Edit it in step 1.</div>"; return; }
    st.config.text = nt;
    try { st.result = await check(nt); showResult(); } catch (e) { /* the board's own check follows */ }
    save();
    const say = (html, cls) => { const o = $("#" + li + " .k-out"); if (o) o.innerHTML = '<div class="dpcs-note ' + (cls || "") + '">' + html + "</div>"; };
    $$("#dpcs-c4 button").forEach((b) => (b.disabled = true));
    say("Writing the change and restarting the board. This takes about 20 seconds…");
    let good = false, err = "";
    try { good = await writeBack(false, { configOnly: true }); } catch (e) { err = e && e.message ? e.message : String(e); }
    if (!st.session) renderChecks();
    $$("#dpcs-c4 button").forEach((b) => (b.disabled = false));
    if (good) say(esc(okText), "ok");
    else say((err ? esc(err) : "The board did not take the change. See the boot log in step 6.") + " Nothing else was changed.", "err");
  }

  // ------------------------------------------------------------ builder
  const DEF_AX = {
    x: { travel: 300, wantRate: 3000, switchAt: "min" },
    y: { travel: 200, wantRate: 3000, switchAt: "min" },
    z: { travel: 60, wantRate: 1000, switchAt: "max" },
    a: { travel: 360, wantRate: 3000, switchAt: "none", rotary: true },
  };
  function defaults(boardId) {
    const b = S.BOARDS[boardId];
    const usable = ["X", "Y", "Z", "A"].filter((k) => !b.blocks[k].unusable);
    const axes = ["x", "y", "z"].map((ax) => {
      let blk = ax.toUpperCase();
      if (!usable.includes(blk)) blk = usable.find((k) => !["X", "Y", "Z", "A"].slice(0, 3).includes(k) || k === "A") || usable[0];
      return Object.assign({ axis: ax, block: blk, limitBlock: blk, moves: "tool", accel: 100, calc: { motorSteps: 200, micro: 8, drive: "screw", lead: 8 }, spmOverride: "" }, DEF_AX[ax]);
    });
    return {
      board: boardId, machineName: "", type: "router", nAxes: 3, driver: "tb6600", holdIdle: false, switchType: "nc",
      axes, probe: false, controls: {}, spindles: [{ kind: b.outputs.relay && b.outputs.relay.pin !== "" ? "relay" : "pwm", output: b.outputs.relay && b.outputs.relay.pin !== "" ? "relay" : "pwm", spinup: 3000, spindown: 3000, maxRpm: 24000 }],
      pendant: !!b.pendant, network: b.eth && b.eth.cs ? "ethernet" : "wifi", sd: true, sdHz: 4000000, custom: {},
    };
  }
  let screen = 0, lastYaml = "";
  // The builder offers only boards that fit the board picked on the install page (same chip, same firmware).
  function builderBoards() {
    const b = st.board || OWN_BOARDS[0];
    if (b.id === "r3" || b.id === "r2") return ["r3", "r2", "legacy"];
    if (b.configs && b.configs.length) return ["tpl", "generic"];
    return ["generic"];
  }
  function makeAns(id) {
    const b = st.board || OWN_BOARDS[0];
    const a = defaults(id === "tpl" ? "generic" : id);
    a.board = id;
    a.forBoard = b.id;
    if (id === "generic") a.customChip = b.chip || "esp32s3";
    if (id === "tpl") { a.driver = "stepstick"; a.tpl = { idx: 0 }; a.axes = []; a.nAxes = 0; }
    return a;
  }
  function initialAns() {
    const b = st.board || OWN_BOARDS[0];
    const list = builderBoards();
    return makeAns(list.includes(b.id) ? b.id : list[0]);
  }
  function loadTpl() {
    const b = st.board, t = ans.tpl, want = t.idx;
    const c = b.configs[want] || b.configs[0];
    return tplText(c.file).then((text) => {
      if (ans.board !== "tpl" || ans.tpl !== t || t.idx !== want) return;
      const info = tplInfo(text);
      Object.assign(t, { file: c.file, title: c.title, info: { board: info.board, kin: info.kin, i2so: info.i2so } });
      ans.axes = info.axes;
      ans.nAxes = info.axes.length;
      const m = $("#dpcs-modal");
      if (m && !m.hidden) renderScreen();
    }).catch((e) => { t.err = String(e.message || e); const m = $("#dpcs-modal"); if (m && !m.hidden) renderScreen(); });
  }
  // The template with only the values the builder asks for changed; each changed line says what it was.
  function tplYaml() {
    const t = ans.tpl, text = t && t.file && tplCache[t.file];
    if (!text) return "# Loading the board's config…\n";
    const lines = text.replace(/\r\n?/g, "\n").split("\n");
    const root = S.parseConfig(text).root, axN = S.get(root, "axes");
    const fmtN = (n) => (Number.isInteger(n) ? String(n) : String(+n.toFixed(3)));
    const inserts = [];
    const put = (node, key, v) => {
      const c = node && S.child(node, key);
      if (!node || v === "" || v == null || (typeof v === "number" && !isFinite(v))) return;
      const nv = typeof v === "number" ? fmtN(v) : String(v);
      if (c) {
        const old = c.value == null ? "" : String(c.value);
        if (old === nv || (typeof v === "number" && Math.abs(+old - v) < 1e-6)) return;
        const m = /^(\s*[^:#]+:)/.exec(lines[c.line - 1]);
        if (m) lines[c.line - 1] = m[1] + " " + nv + "   # set in the builder (the template had " + (old || "nothing") + ")";
      } else {
        const ind = node.children.length ? node.children[0].indent : node.indent + 2;
        inserts.push([node.line, " ".repeat(ind) + key + ": " + nv + "   # added by the builder"]);
      }
    };
    ans.axes.slice(0, ans.nAxes).forEach((x) => {
      const n = axN && S.get(axN, x.axis);
      if (!n) return;
      put(n, "steps_per_mm", +x.spmOverride || S.stepsPerMm(x.calc));
      put(n, "max_rate_mm_per_min", +x.wantRate);
      put(n, "acceleration_mm_per_sec2", +x.accel);
      put(n, "max_travel_mm", +x.travel);
      const h = S.get(n, "homing");
      if (h && x.homeDir) put(h, "positive_direction", x.homeDir === "max" ? "true" : "false");
    });
    inserts.sort((a, b) => b[0] - a[0]).forEach(([after, l]) => lines.splice(after, 0, l));
    const head = ["# Built with the dpCREATOR builder from the " + (st.board.source === "dpcreator" ? "dpCREATOR starting point" : "FluidNC community template") + " \"" + t.title + "\" (" + t.file.split("/").pop() + ")" + (st.board.source === "dpcreator" ? "." : ","),
      st.board.source === "dpcreator" ? "# not yet tried on this board." : "# github.com/bdring/fluidnc-config-files, GPL-3.0. From a public source, not tested by dpCREATOR:",
      "# check every pin against your board before you connect motors.", ""];
    return head.join("\n") + "\n" + lines.join("\n");
  }
  function SCREENS() {
    if (ans.board === "tpl") return ["tpl", "steps", "travel", "review"];
    const list = ["board"];
    if (ans.board === "generic") list.push("pins");
    list.push("machine", "blocks", "moves", "drivers", "steps", "switches", "controls", "spindles", "extras", "review");
    return list;
  }
  function getP(o, path) { return path.split(".").reduce((x, k) => (x == null ? x : x[k]), o); }
  function setP(o, path, v) {
    const ks = path.split(".");
    let x = o;
    for (let i = 0; i < ks.length - 1; i++) { if (x[ks[i]] == null) x[ks[i]] = /^\d+$/.test(ks[i + 1]) ? [] : {}; x = x[ks[i]]; }
    x[ks[ks.length - 1]] = v;
  }
  function genAnswers() {
    const a = JSON.parse(JSON.stringify(ans));
    a.axes = a.axes.slice(0, a.nAxes);
    a.axes.forEach((x) => {
      const calc = S.stepsPerMm(x.calc);
      x.spm = +x.spmOverride || Math.round(calc * 1000) / 1000;
      x.spmNote = +x.spmOverride ? "measured / set by hand (calculated: " + Math.round(calc * 1000) / 1000 + ")" : null;
      if (!+x.spmOverride) delete x.spmNote;
    });
    a.spindles = (a.spindles || []).filter(Boolean);
    a.mustHome = a.axes.every((x) => x.switchAt !== "none" || x.rotary);
    return a;
  }
  function yamlNow() { try { return ans.board === "tpl" ? tplYaml() : S.generate(genAnswers()); } catch (e) { return "# " + e.message; } }
  const builderChip = () => (ans.board === "tpl" ? (st.board && st.board.chip) || "esp32" : S.BOARDS[ans.board].chip);

  function openBuilder() {
    if (!ans || ans.forBoard !== (st.board && st.board.id) || !builderBoards().includes(ans.board)) { ans = initialAns(); screen = 0; }
    if (ans.board === "tpl" && !(ans.tpl.file && tplCache[ans.tpl.file])) loadTpl();
    let m = $("#dpcs-modal");
    if (!m) {
      m = document.createElement("div");
      m.id = "dpcs-modal";
      m.setAttribute("role", "dialog");
      m.setAttribute("aria-modal", "true");
      m.setAttribute("aria-label", "Build my machine");
      m.innerHTML = '<header class="dpcs-top"><h3>Build my machine<span class="for" data-no-i18n></span></h3><div class="dpcs-prog" aria-hidden="true"></div><button type="button" class="dpcs-btn ghost small yaml-toggle">config.yaml</button><button type="button" class="dpcs-btn ghost small" data-close>Close</button></header>' +
        '<div class="dpcs-main"><section class="dpcs-q" aria-live="polite"></section><aside class="dpcs-yaml" aria-label="config.yaml preview"><div class="hd"><b>config.yaml</b><span class="v"></span></div><pre></pre></aside></div>' +
        '<footer><button type="button" class="dpcs-btn ghost" data-back>Back</button><span class="sp"></span><button type="button" class="dpcs-btn" data-next>Next</button></footer>';
      document.body.appendChild(m);
      m.addEventListener("click", onBuilderClick);
      m.addEventListener("change", onBuilderInput);
      m.addEventListener("input", (e) => { if (e.target.matches("input[type=text],input[type=number]")) onBuilderInput(e, true); });
      m.addEventListener("keydown", (e) => {
        if (e.key === "Escape") closeBuilder();
        if ((e.key === "Enter" || e.key === " ") && e.target.matches(".tgt")) { e.preventDefault(); e.target.dispatchEvent(new MouseEvent("click", { bubbles: true })); }
      });
    }
    document.documentElement.classList.add("dpcs-open");
    $("header .for", m).textContent = st.board && st.board.label ? st.board.label : "";
    m.hidden = false;
    renderScreen();
    $("[data-next]", m).focus();
  }
  function closeBuilder() {
    save();
    const m = $("#dpcs-modal");
    if (m) m.hidden = true;
    document.documentElement.classList.remove("dpcs-open");
  }
  function onBuilderClick(e) {
    const m = $("#dpcs-modal");
    const t = e.target.closest("[data-set],[data-close],[data-back],[data-next],[data-go],.yaml-toggle,[data-use],[data-dl],[data-add],[data-del],[data-tplpick]");
    if (!t) return;
    if (t.matches("[data-close]")) return closeBuilder();
    if (t.matches(".yaml-toggle")) return m.classList.toggle("show-yaml");
    if (t.matches("[data-back]")) { if (screen === 0) return closeBuilder(); screen = Math.max(0, screen - 1); return renderScreen(); }
    if (t.matches("[data-next]")) { screen = Math.min(SCREENS().length - 1, screen + 1); return renderScreen(); }
    if (t.matches("[data-go]")) { screen = +t.dataset.go; return renderScreen(); }
    if (t.matches("[data-use]")) {
      const y = yamlNow();
      closeBuilder();
      useConfig(y, "config.yaml", ans.board === "tpl" ? "the builder, from the " + st.board.label + " template \"" + ans.tpl.title + "\"" + (st.board.source === "dpcreator" ? " (dpCREATOR, not yet tried)" : " (FluidNC community)") : "the builder");
      return;
    }
    if (t.matches("[data-tplpick]")) { closeBuilder(); choose("template"); return; }
    if (t.matches("[data-dl]")) return saveFile("config.yaml", yamlNow());
    if (t.matches("[data-add]")) { addSpindle(t.dataset.add); return renderScreen(); }
    if (t.matches("[data-del]")) { ans.spindles.splice(+t.dataset.del, 1); return renderScreen(); }
    if (t.matches("[data-set]")) {
      let v = t.dataset.val;
      if (v === "true") v = true; else if (v === "false") v = false; else if (/^-?\d+(\.\d+)?$/.test(v)) v = +v;
      if (t.dataset.set === "board") { const name = ans.machineName; ans = makeAns(v); ans.machineName = name; screen = 0; if (v === "tpl") loadTpl(); }
      else setP(ans, t.dataset.set, v);
      afterChange(t.dataset.set);
      renderScreen();
    }
  }
  function onBuilderInput(e, typing) {
    const el = e.target;
    if (!el.dataset || !el.dataset.k) return;
    let v = el.type === "checkbox" ? el.checked : el.value;
    if (el.type === "number" || el.dataset.num) v = el.value === "" ? "" : +el.value;
    setP(ans, el.dataset.k, v);
    afterChange(el.dataset.k);
    if (typing) updateYaml(); else renderScreen();
  }
  function afterChange(path) {
    if (path === "tpl.idx") { ans.tpl = { idx: +ans.tpl.idx }; ans.axes = []; ans.nAxes = 0; loadTpl(); return; }
    if (/^axes\.\d+\.block$/.test(path)) {
      const i = +path.split(".")[1];
      if (!ans.axes[i].limitApart) ans.axes[i].limitBlock = ans.axes[i].block;
    }
    if (/^axes\.\d+\.limitApart$/.test(path)) { const i = +path.split(".")[1]; if (!ans.axes[i].limitApart) ans.axes[i].limitBlock = ans.axes[i].block; }
    if (path === "nAxes" && ans.nAxes === 4 && ans.axes.length < 4) {
      const b = S.BOARDS[ans.board];
      const used = ans.axes.map((x) => x.block);
      const free = ["X", "Y", "Z", "A"].find((k) => !used.includes(k) && !b.blocks[k].unusable) || "A";
      ans.axes.push(Object.assign({ axis: "a", block: free, limitBlock: free, moves: "tool", accel: 100, calc: { motorSteps: 200, micro: 8, drive: "rotary", ratio: 1 }, spmOverride: "" }, DEF_AX.a));
    }
    if (path === "type") {
      const b = S.BOARDS[ans.board];
      const relay = b.outputs.relay && b.outputs.relay.pin !== "" ? "relay" : null;
      const pwmOut = b.outputs.pwm ? "pwm" : null;
      const t = ans.type;
      ans.spindles = [];
      if (t === "router" || t === "router+laser") ans.spindles.push({ kind: relay ? "relay" : "pwm", output: relay || pwmOut, spinup: 3000, spindown: 3000, maxRpm: 24000 });
      if (t === "plasma") ans.spindles.push({ kind: "relay", output: relay || pwmOut, spinup: 0, spindown: 0, maxRpm: 1 });
      if (t === "laser" || t === "router+laser") ans.spindles.push({ kind: "laser", output: pwmOut, low: b.outputs.pwm && b.outputs.pwm.lowDefault, tools: t === "router+laser" ? "2" : "", offset: [0, 0, 0], maxS: 255, pwmHz: 5000 });
    }
  }
  function addSpindle(kind) {
    const b = S.BOARDS[ans.board];
    const used = ans.spindles.map((s) => s.output);
    const want = kind === "relay" ? ["relay", "pwm", "ttl"] : kind === "vfd" ? [null] : ["pwm", "ttl", "relay"];
    const out = want.find((o) => o === null || (b.outputs[o] && !used.includes(o))) || want[0];
    const s = { kind, output: out, spinup: kind === "vfd" ? 5000 : kind === "laser" ? 0 : 3000, spindown: kind === "vfd" ? 5000 : kind === "laser" ? 0 : 3000, maxRpm: 24000 };
    if (kind === "laser") Object.assign(s, { tools: ans.spindles.some((x) => x.kind !== "laser") ? "2" : "", offset: [0, 0, 0], maxS: 255, pwmHz: 5000, low: b.outputs[out] && b.outputs[out].lowDefault });
    if (kind === "vfd") Object.assign(s, { vfd: "Huanyang", modbusId: 1, baud: 9600 });
    ans.spindles.push(s);
  }

  function updateYaml() {
    const m = $("#dpcs-modal");
    const y = yamlNow();
    const pre = $(".dpcs-yaml pre", m);
    const old = lastYaml.split("\n");
    pre.innerHTML = y.split("\n").map((l, i) => {
      const c = l.indexOf(" #") >= 0 && !/^\s*#/.test(l) ? l.indexOf(" #") : (/^\s*#/.test(l) ? 0 : -1);
      const main = c >= 0 ? l.slice(0, c) : l, com = c >= 0 ? l.slice(c) : "";
      const km = /^(\s*)([A-Za-z0-9_]+):(.*)$/.exec(main);
      const body = km ? esc(km[1]) + '<span class="k">' + esc(km[2]) + "</span>:" + esc(km[3]) : esc(main);
      return '<span class="' + (lastYaml && old[i] !== l ? "chg" : "") + '">' + body + (com ? '<span class="c">' + esc(com) + "</span>" : "") + "</span>";
    }).join("\n");
    lastYaml = y;
    const first = $(".chg", pre);
    if (first) { const top = first.offsetTop - pre.clientHeight / 3; if (top > pre.scrollTop + pre.clientHeight - 40 || top < pre.scrollTop) pre.scrollTop = Math.max(0, top); }
    schema().then((sc) => {
      const chip = builderChip();
      const r = S.validate(y, sc, { chip, octal: ans.board === "tpl" ? undefined : S.BOARDS[ans.board].octal, driverHz: S.DRIVERS[ans.driver].hz });
      const v = $(".dpcs-yaml .v", m);
      v.innerHTML = r.ok ? '<span class="dpcs-pill ok">valid</span>' + (r.warnings ? ' <span class="dpcs-pill warn">' + r.warnings + " warning" + (r.warnings > 1 ? "s" : "") + "</span>" : "") : '<span class="dpcs-pill err">' + r.errors + " error" + (r.errors > 1 ? "s" : "") + "</span>";
      const rv = $("#dpcs-review-probs");
      if (rv) rv.innerHTML = r.problems.length ? probList(r) : '<div class="dpcs-note ok">No problems: every key is one the firmware knows, no pin is used twice, every speed is within the driver\'s limit.</div>';
    }).catch(() => {});
  }

  const opt = (path, val, cur, title, sub, dis) => '<button type="button" class="opt" data-set="' + path + '" data-val="' + esc(val) + '" aria-pressed="' + (String(cur) === String(val) ? "true" : "false") + '"' + (dis ? " disabled" : "") + "><b>" + title + "</b>" + (sub ? "<span>" + sub + "</span>" : "") + "</button>";
  const seg = (path, cur, items) => '<div class="seg" role="group">' + items.map(([v, l, dis]) => '<button type="button" data-set="' + path + '" data-val="' + esc(v) + '" aria-pressed="' + (String(cur) === String(v) ? "true" : "false") + '"' + (dis ? " disabled" : "") + ">" + l + "</button>").join("") + "</div>";
  const num = (path, val, label, extra) => '<label class="f">' + label + '<input type="number" data-k="' + path + '" value="' + esc(val == null ? "" : val) + '"' + (extra || "") + "></label>";
  const txt = (path, val, label, extra) => '<label class="f">' + label + '<input type="text" data-k="' + path + '" value="' + esc(val == null ? "" : val) + '"' + (extra || "") + "></label>";
  const chk = (path, val, title, sub, dis) => '<label class="chk"><input type="checkbox" data-k="' + path + '"' + (val ? " checked" : "") + (dis ? " disabled" : "") + "><span><b>" + title + "</b>" + (sub ? "<span>" + sub + "</span>" : "") + "</span></label>";
  const AX = (i) => ans.axes[i].axis.toUpperCase();
  const lockChip = () => { const b = st.board; return b && b.id !== "r3" && b.id !== "r2" ? b.chip : null; };
  // Names differ too much between configs and the catalog ("MKS-DLC32 V2.1", "FluidNC 4X 2209"): only a version
  // written in both ("V2.0" in the config, "v2.1" in the board name) is compared.
  function sameBoard(a, b) {
    const va = /v?(\d+(\.\d+)+)/.exec(String(a).toLowerCase()), vb = /v(\d+(\.\d+)+)/.exec(String(b).toLowerCase());
    return !(va && vb && va[1] !== vb[1]);
  }

  const RENDER = {
    board() {
      const allowed = builderBoards(), pb = st.board || OWN_BOARDS[0];
      const o = (id, title, sub) => (allowed.includes(id) ? opt("board", id, ans.board, title, sub) : "");
      return "<h2>Which controller?</h2><p class=\"lead\">Each board is a table of its terminal blocks and the pins behind them. The rest of the questions follow from it.</p>" +
        (pb.id !== "r3" && pb.id !== "r2" ? '<p class="lead">Board picked on the install page: <b data-no-i18n>' + esc(pb.label) + "</b></p>" : "") + '<div class="opts">' +
        o("r3", "dpCREATOR R3", "ESP32-S3 N16R8, W5500 Ethernet, separate probe input") +
        o("r2", "dpCREATOR R2", "Same pins as the R3; the probe shares the Z limit input") +
        o("legacy", "Legacy v4.0.2 / XYZ50 / XYZ77", "With the ESP32-S3 module swap (pin table from the bring-up)") +
        o("tpl", "Start from this board's ready config", "Pins come from the template; you set the mechanics") +
        o("generic", "Enter the pins myself", "Type the pins from your board's documentation; they are checked as you go") +
        "</div>" +
        (ans.board === "generic" ? '<div class="dpcs-caution"><strong>Use with caution</strong>You enter this board\'s pins yourself. Copy them from the board\'s documentation for your revision: a wrong pin can drive a motor or an output you did not mean to.</div>' : G.board(S.BOARDS[ans.board], {}));
    },
    tpl() {
      const b = st.board, t = ans.tpl, info = t.info;
      const sel = '<label class="f" style="max-width:520px">Ready config<select data-k="tpl.idx" data-num="1">' + b.configs.map((c, i) => '<option value="' + i + '"' + (i === t.idx ? " selected" : "") + ">" + esc(c.title) + (c.errors ? " (" + c.errors + " problem" + (c.errors > 1 ? "s" : "") + " to fix)" : "") + "</option>").join("") + "</select></label>";
      return '<h2>Your board: <span data-no-i18n>' + esc(b.label) + "</span></h2>" +
        '<p class="lead">The pins, drivers and outputs come from a ready config for this board. You set your machine: steps/mm, speeds, travel and the homing side. Everything else in the config stays as it is.</p>' +
        cautionHtml(b) + sel +
        (t.err ? '<div class="dpcs-note err">Could not load the config (' + esc(t.err) + ").</div>"
          : !info ? '<div class="dpcs-note">Loading the config…</div>'
          : '<p style="margin:8px 0 0">Written for: <b data-no-i18n>' + esc(info.board || "?") + "</b></p>" +
            '<p style="margin:2px 0 0">Axes in this config: <b data-no-i18n>' + ans.axes.map((x) => x.axis.toUpperCase()).join(" ") + "</b></p>" +
            (info.board && !sameBoard(info.board, b.label) ? '<div class="dpcs-note warn">This config was written for a different board or revision than the one you picked. Pick another one, or check every pin against your board.</div>' : "") +
            (!/^cartesian$/i.test(info.kin) ? '<div class="dpcs-note warn">Kinematics in this config: <code>' + esc(info.kin) + "</code>. The builder changes only the values per axis; check the kinematics settings in the editor.</div>" : "")) +
        "<h5>Other ways</h5>" +
        '<div class="dpcs-row"><button type="button" class="dpcs-btn ghost small" data-tplpick>Use the config as it is</button>' +
        (info && info.i2so ? "" : '<button type="button" class="dpcs-btn ghost small" data-set="board" data-val="generic">Enter the pins myself</button>') + "</div>" +
        (info && info.i2so ? '<p class="lead" style="margin-top:6px">This board drives its motors through a shift register (I2S output pins, <code>i2so</code>), so its pins can\'t be typed in by hand here: start from its ready config.</p>' : "");
    },
    travel() {
      return "<h2>Travel and homing</h2><p class=\"lead\">How far each axis can move, and at which end its homing switch sits. Directions are the tool relative to the workpiece: +X = tool to the right, +Y = tool away from you, +Z = tool up.</p>" +
        ans.axes.slice(0, ans.nAxes).map((x, i) => '<div class="axcard"><h6>' + AX(i) + "</h6>" +
          '<div class="grid">' + num("axes." + i + ".travel", x.travel, x.axis === "a" || x.axis === "b" || x.axis === "c" ? "Travel (mm or degrees)" : "Travel, mm") + "</div>" +
          (x.homeDir ? '<div class="dpcs-row">homing switch at ' + seg("axes." + i + ".homeDir", x.homeDir, [["min", "the − end"], ["max", "the + end"]]) + "</div>" : '<p class="lead" style="margin:6px 0 0">No homing for this axis in the config.</p>') + "</div>").join("") +
        '<div class="dpcs-note">The config\'s other homing values (machine position after homing, pull-off, speeds) are kept. If you change the switch side, check <code>mpos_mm</code> in the editor: after homing, work zero must lie inside the travel.</div>';
    },
    pins() {
      const c = ans.custom;
      const row = (blk) => '<div class="axcard"><h6>' + blk + ' block</h6><div class="grid">' + txt("custom.blocks." + blk + ".step", (c.blocks || {})[blk] && c.blocks[blk].step, "STEP pin", ' placeholder="gpio.4"') + txt("custom.blocks." + blk + ".dir", (c.blocks || {})[blk] && c.blocks[blk].dir, "DIR pin", ' placeholder="gpio.5"') + txt("custom.blocks." + blk + ".limit", (c.blocks || {})[blk] && c.blocks[blk].limit, "Limit input", ' placeholder="gpio.36"') + "</div></div>";
      return "<h2>Your board's pins</h2><p class=\"lead\">Type the GPIO behind each terminal, like <code>gpio.4</code>. Leave a field empty if the board doesn't have it. The preview on the right checks each pin: used twice, flash or USB pins, input-only pins.</p>" +
        '<div class="axcard"><h6>Chip</h6>' + seg("customChip", ans.customChip || "esp32s3", [["esp32s3", "ESP32-S3", lockChip() && lockChip() !== "esp32s3"], ["esp32", "ESP32 (classic)", lockChip() && lockChip() !== "esp32"]]) + (lockChip() ? '<p class="lead" style="margin:6px 0 0">Set by the board you picked on the install page; the firmware is built for that chip.</p>' : "") + "</div>" +
        ["X", "Y", "Z", "A"].map(row).join("") +
        '<div class="axcard"><h6>Other outputs and inputs</h6><div class="grid">' + txt("custom.enable", c.enable, "Shared stepper enable") + txt("custom.probe", c.probe, "Probe input") + txt("custom.outputs.pwm", (c.outputs || {}).pwm, "PWM output") + txt("custom.outputs.relay", (c.outputs || {}).relay, "Relay output") +
        txt("custom.spi.miso", (c.spi || {}).miso, "SPI MISO") + txt("custom.spi.mosi", (c.spi || {}).mosi, "SPI MOSI") + txt("custom.spi.sck", (c.spi || {}).sck, "SPI SCK") + txt("custom.sd.cs", (c.sd || {}).cs, "SD card CS") + txt("custom.eth.cs", (c.eth || {}).cs, "W5500 CS") +
        txt("custom.controls.safety_door_pin", (c.controls || {}).safety_door_pin, "Door input") + txt("custom.controls.reset_pin", (c.controls || {}).reset_pin, "Reset input") + txt("custom.controls.feed_hold_pin", (c.controls || {}).feed_hold_pin, "Feed hold input") + txt("custom.controls.cycle_start_pin", (c.controls || {}).cycle_start_pin, "Cycle start input") + "</div></div>";
    },
    machine() {
      return "<h2>What kind of machine?</h2><p class=\"lead\">This picks the spindle and laser setup; you can change it later.</p><div class=\"opts\">" +
        opt("type", "router", ans.type, "CNC router", "Spindle or router motor") + opt("type", "laser", ans.type, "Laser", "Diode or CO2 laser on PWM") + opt("type", "router+laser", ans.type, "Router + laser", "Laser next to the spindle, M6 T2 selects it") +
        opt("type", "plotter", ans.type, "Plotter / drag knife", "No spindle") + opt("type", "plasma", ans.type, "Plasma", "Torch on a relay output") + "</div>" +
        "<h5>Axes</h5>" + seg("nAxes", ans.nAxes, [[3, "3 axes: X Y Z"], [4, "4 axes: X Y Z A"]]) +
        '<div class="grid" style="max-width:420px">' + txt("machineName", ans.machineName, "Machine name (for the config name)", ' placeholder="3018"') + "</div>" +
        '<p class="lead" style="margin-top:12px">Cartesian kinematics (CoreXY comes later).</p>';
    },
    blocks() {
      const b = S.BOARDS[ans.board];
      const sel = {}, lims = {};
      ans.axes.slice(0, ans.nAxes).forEach((x) => { sel[x.block] = (sel[x.block] ? sel[x.block] + "+" : "") + x.axis.toUpperCase(); if (x.limitBlock !== x.block) lims[x.limitBlock] = x.axis.toUpperCase(); });
      const bad = Object.entries(b.blocks).filter(([, v]) => v.unusable);
      return "<h2>Which block drives which axis?</h2><p class=\"lead\">Follow the real wiring: blocks can be swapped freely, e.g. Z on the A block. The limit switch of an axis can sit on a different block than its driver (" + (b.terminals === "r3" ? "LIMIT and LIMIT COM of any block" : b.editable ? "any limit input" : "pins 8/7 of any block") + ").</p>" +
        G.board(b.editable ? Object.assign({}, b, { label: "Your board" }) : b, { sel, limits: lims }) +
        (bad.length ? '<div class="dpcs-note warn">' + bad.map(([k, v]) => "<b>" + k + " block:</b> " + esc(v.unusable)).join("<br>") + "</div>" : "") +
        ans.axes.slice(0, ans.nAxes).map((x, i) => '<div class="axcard"><h6>' + AX(i) + " axis</h6>" +
          '<div class="dpcs-row">driver on ' + seg("axes." + i + ".block", x.block, ["X", "Y", "Z", "A"].map((k) => [k, k + " block", !!b.blocks[k].unusable])) + "</div>" +
          chk("axes." + i + ".limitApart", x.limitApart, "The limit switch is on a different block", "") +
          (x.limitApart ? '<div class="dpcs-row">switch on ' + seg("axes." + i + ".limitBlock", x.limitBlock, ["X", "Y", "Z", "A"].map((k) => [k, k + " block"])) + "</div>" : "") + "</div>").join("");
    },
    moves() {
      return "<h2>What moves: the tool or the bed?</h2><p class=\"lead\"><b>Directions are always the tool relative to the workpiece.</b> +X = tool to the right, +Y = tool away from you, +Z = tool up. On a 3018 the <b>bed</b> moves on Y, so for +Y the bed comes <b>toward</b> you. Judging Y by the bed instead of the tool mirrors every job.</p>" +
        G.topView({ bed: ans.axes[1] && ans.axes[1].moves === "bed" }) +
        ans.axes.slice(0, Math.min(2, ans.nAxes)).map((x, i) => '<div class="axcard"><h6>' + AX(i) + " axis</h6>" + G.movesPick("axes." + i + ".moves", x.moves, x.axis === "x") + "</div>").join("") +
        '<p class="lead">Z: the tool always moves (up = +Z). You check each direction on the machine after flashing (first-run step 3).</p>';
    },
    drivers() {
      const d = S.DRIVERS[ans.driver];
      return "<h2>Stepper drivers</h2><p class=\"lead\">The driver type sets the pulse timing and the highest step rate.</p><div class=\"opts\">" +
        Object.entries(S.DRIVERS).map(([k, v]) => opt("driver", k, ans.driver, v.label, "pulse " + v.pulse + " µs, DIR delay " + v.dirDelay + " µs, up to ~" + Math.round(v.hz / 1000) + " kHz")).join("") + "</div>" +
        (ans.driver === "tb6600" ? '<div class="dpcs-note warn">TB6600: with 2 µs pulses it ignores steps (the motors don\'t move). <code>pulse_us: 5</code> and <code>dir_delay_us: 5</code> are set for it.</div>' : "") +
        (S.BOARDS[ans.board].editable ? '<p class="lead">Wire the drivers as your board\'s documentation shows.</p>' : S.BOARDS[ans.board].terminals === "r3" ? "<h5>Wiring</h5><p class=\"lead\">Each axis block gives STEP and DIR at 5 V. STEP 5V goes to PUL+, DIR 5V to DIR+, and the two GND terminals to PUL- and DIR-. Leave ENA unconnected: the driver stays enabled. STEP and DIR only come out while the E-STOP loop is closed.</p>" + G.wiring(d.label, true) : "<h5>Wiring (common anode)</h5><p class=\"lead\">The block outputs are open-collector (ULN2803). PUL+, DIR+ and ENA+ go to +5 V (pins 1/3/5); PUL- to pin 4, DIR- to pin 6, ENA- to pin 2. ENA may stay unconnected: the driver is then always enabled.</p>" + G.wiring(d.label)) +
        chk("holdIdle", ans.holdIdle, "Keep the motors powered when idle", "Holds position (Z won't drop), motors stay warm. Off: they switch off 250 ms after a move.");
    },
    steps() {
      const d = S.DRIVERS[ans.driver];
      return "<h2>Steps per mm</h2><p class=\"lead\"><b>steps/mm = motor steps per turn × microstepping ÷ mm per turn.</b> Microstepping is set with the driver's DIP switches. Lead is how far the nut moves per turn (T8x8 = 8, T8x4 = 4, T8x2 = 2), not the thread pitch.</p>" + G.leadscrew() +
        '<table class="t"><tr><th>Lead</th><th>1/4</th><th>1/8</th><th>1/16</th></tr><tr><td>2 mm</td><td>400</td><td>800</td><td>1600</td></tr><tr><td>4 mm</td><td>200</td><td>400</td><td>800</td></tr><tr><td>8 mm</td><td>100</td><td>200</td><td>400</td></tr></table>' +
        ans.axes.slice(0, ans.nAxes).map((x, i) => {
          const c = x.calc, calc = S.stepsPerMm(c), spm = +x.spmOverride || calc;
          const cap = S.maxRateFor(spm, d.hz, d.pulse, d.dirDelay);
          let hint = "";
          if (cap < (+x.wantRate || 0)) {
            const per = spm / (c.micro || 1);   // steps/mm per microstep setting (works for a measured value too)
            const better = [1, 2, 4, 8, 16, 32].filter((mm) => mm < c.micro).reverse().find((mm) => S.maxRateFor(per * mm, d.hz, d.pulse, d.dirDelay) >= x.wantRate);
            hint = '<div class="dpcs-note warn">At ' + Math.round(spm * 1000) / 1000 + " steps/mm the " + esc(d.label) + " allows only <b>" + cap + " mm/min</b>" + (better ? ". Microstepping 1/" + better + " would allow " + x.wantRate + "." : ".") + " The config uses " + cap + ".</div>";
          }
          return '<div class="axcard"><h6>' + AX(i) + "</h6>" +
            '<div class="grid">' +
            '<label class="f">Motor steps/turn<select data-k="axes.' + i + '.calc.motorSteps" data-num="1"><option' + (c.motorSteps == 200 ? " selected" : "") + ">200</option><option" + (c.motorSteps == 400 ? " selected" : "") + ">400</option></select></label>" +
            '<label class="f">Microstepping<select data-k="axes.' + i + '.calc.micro" data-num="1">' + [1, 2, 4, 8, 16, 32].map((m) => "<option value=\"" + m + "\"" + (c.micro == m ? " selected" : "") + ">1/" + m + "</option>").join("") + "</select></label>" +
            '<label class="f">Drive<select data-k="axes.' + i + '.calc.drive">' + [["screw", "Leadscrew / ballscrew"], ["belt", "Belt"], ["rack", "Rack and pinion"], ["rotary", "Rotary (degrees)"]].map(([v, l]) => '<option value="' + v + '"' + (c.drive === v ? " selected" : "") + ">" + l + "</option>").join("") + "</select></label>" +
            (c.drive === "belt" ? num("axes." + i + ".calc.teeth", c.teeth || 20, "Pulley teeth") + num("axes." + i + ".calc.pitch", c.pitch || 2, "Belt pitch, mm") : c.drive === "rack" ? num("axes." + i + ".calc.pinionDia", c.pinionDia || 20, "Pinion pitch diameter, mm") : c.drive === "rotary" ? num("axes." + i + ".calc.ratio", c.ratio || 1, "Gear ratio") : num("axes." + i + ".calc.lead", c.lead, "Lead, mm per turn", ' step="any"')) +
            "</div>" +
            '<div class="dpcs-row">calculated <span class="res">' + Math.round(calc * 1000) / 1000 + "</span> steps/" + (c.drive === "rotary" ? "degree" : "mm") + "</div>" +
            (x.tplSpm ? '<p style="margin:4px 0 0;font-size:13px">The config had <b>' + x.tplSpm + '</b>. Clear the box below to use the calculated value.</p>' : "") +
            '<div class="grid">' + num("axes." + i + ".spmOverride", x.spmOverride, x.tplSpm ? "Steps/mm used" : "Measured steps/mm (optional)", ' step="any" placeholder="leave empty"') + num("axes." + i + ".wantRate", x.wantRate, "Wanted max speed, mm/min") + num("axes." + i + ".accel", x.accel, "Acceleration, mm/s²") + "</div>" + hint + "</div>";
        }).join("") +
        '<div class="dpcs-note">After flashing you calibrate over 100 mm (first-run step 4): new = current × commanded ÷ measured. On the 3018 the first guess was 200; the measured value was 1600.</div>';
    },
    switches() {
      const xi = ans.axes.findIndex((x) => x.axis === "x"), yi = ans.axes.findIndex((x) => x.axis === "y"), zi = ans.axes.findIndex((x) => x.axis === "z");
      const bedY = yi >= 0 && ans.axes[yi].moves === "bed";
      const rng = ans.axes.slice(0, ans.nAxes).map((x) => ({ axis: x.axis, from: x.switchAt === "none" ? null : 0, to: x.switchAt === "max" ? -(+x.travel || 0) : +x.travel || 0 }));
      return "<h2>Limit switches and homing</h2><p class=\"lead\">Click where each switch is, along the <b>tool's</b> travel." + (bedY ? " Y moves the bed: a switch that trips with the bed at the back means the tool is at the <b>front</b> = Y minimum." : "") + "</p>" +
        G.topView({ bed: bedY, sw: { x: xi >= 0 ? ans.axes[xi].switchAt : "", y: yi >= 0 ? ans.axes[yi].switchAt : "" }, pick: { x: xi >= 0 ? "axes." + xi + ".switchAt" : null, y: yi >= 0 ? "axes." + yi + ".switchAt" : null } }) +
        '<div class="dpcs-row">' + (xi >= 0 ? '<button type="button" class="dpcs-btn ghost small" data-set="axes.' + xi + '.switchAt" data-val="none">No X switch</button>' : "") + (yi >= 0 ? '<button type="button" class="dpcs-btn ghost small" data-set="axes.' + yi + '.switchAt" data-val="none">No Y switch</button>' : "") + "</div>" +
        (zi >= 0 ? G.sideZ({ sw: ans.axes[zi].switchAt, pick: "axes." + zi + ".switchAt" }) + '<div class="dpcs-row"><button type="button" class="dpcs-btn ghost small" data-set="axes.' + zi + '.switchAt" data-val="none">No Z switch</button></div>' : "") +
        "<h5>Switch type</h5>" + seg("switchType", ans.switchType, [["nc", "NC, normally closed (recommended)"], ["no", "NO, normally open"]]) +
        "<h5>Wiring</h5>" + G.limitWiring(S.BOARDS[ans.board].terminals === "r3") +
        "<h5>Travel</h5><div class=\"grid\">" + ans.axes.slice(0, ans.nAxes).map((x, i) => num("axes." + i + ".travel", x.travel, x.axis.toUpperCase() + " travel, mm")).join("") + "</div>" +
        "<h5>Machine coordinates after homing</h5><p class=\"lead\">The switch is machine 0. Work zero (your stock) must be inside these ranges.</p>" + G.ranges(rng) +
        '<div class="dpcs-note">With switches, the config turns on <code>hard_limits</code> (stop at once if a switch trips during a job) and <code>soft_limits</code> (refuse moves outside the travel). Without hard_limits the machine runs through the switches during jobs.</div>';
    },
    controls() {
      const b = S.BOARDS[ans.board];
      const names = { safety_door_pin: ["Safety door switch", "Stops the job when the door opens"], reset_pin: ["Reset / e-stop button", "Soft reset, like Ctrl-X"], feed_hold_pin: ["Feed hold button", "Pauses the job"], cycle_start_pin: ["Cycle start button", "Resumes the job"] };
      const zSw = ans.axes.find((x) => x.axis === "z" && x.switchAt !== "none");
      const probeClash = b.probe && b.probe.sharedWithZ && zSw;
      return "<h2>Buttons, door and probe</h2><p class=\"lead\">Tick only what is connected. Anything not present becomes <code>NO_PIN</code>: an unconnected door input reads \"open\" and gives <code>error:13 Safety door open</code> and <code>ALARM:11</code> at every start.</p>" +
        b.controls.map((c) => { const pin = c.pin || (b.editable ? ((ans.custom.controls || {})[c.key] || "") : null); const n = names[c.key]; return chk("controls." + c.key, ans.controls[c.key], n[0], pin ? n[1] + " · " + esc(pin) : b.editable ? n[1] + " (enter the pin on the pins page)" : "No input for this on the " + esc(b.short) + ".", !pin && !b.editable); }).join("") +
        "<h5>Probe / touch plate</h5>" + chk("probe", ans.probe, "Touch plate or probe", (b.probe && b.probe.pin ? esc(b.probe.where || b.probe.pin) + " · " : "") + "test with ? after flashing: Pn:P appears when it touches", probeClash) +
        (probeClash ? '<div class="dpcs-note warn">On the R2 the probe shares the Z limit input. With a Z switch configured, the probe can\'t be used. No Z switch: remove it on the switches page.</div>' : "");
    },
    spindles() {
      const b = S.BOARDS[ans.board];
      const outs = Object.entries(b.outputs || {}).filter(([, v]) => v.pin !== undefined);
      const names = { relay: "Relay (on/off)", pwm: "PWM spindle", "10v": "0-10 V spindle", vfd: "RS485 VFD", laser: "Laser" };
      const usedBy = {};
      ans.spindles.forEach((s, i) => { if (s.output) (usedBy[s.output] = usedBy[s.output] || []).push(i); });
      return "<h2>Spindle and laser</h2><p class=\"lead\">Several at once is fine, each on its own output: two spindles can't share an output pin. With a router and a laser, <code>M6 T2</code> selects the laser (dpCREATOR firmware) and any other tool the spindle.</p>" +
        ans.spindles.map((s, i) => '<div class="axcard"><h6>' + names[s.kind] + ' <button type="button" class="dpcs-btn ghost small" data-del="' + i + '" style="float:right">Remove</button></h6>' +
          (s.kind !== "vfd" ? '<div class="dpcs-row">output ' + seg("spindles." + i + ".output", s.output, outs.map(([k, v]) => [k, esc(v.label || k)])) + "</div>" + ((usedBy[s.output] || []).length > 1 ? '<div class="dpcs-note err">This output is used by two spindles. Pick another output.</div>' : "") : '<div class="grid"><label class="f">VFD model<select data-k="spindles.' + i + '.vfd">' + ["Huanyang", "H2A", "H100", "YL620", "NowForever", "SiemensV20", "DanfossVLT2800", "DeltaMS300", "FolinnBD600", "MollomG70"].map((v) => "<option" + (s.vfd === v ? " selected" : "") + ">" + v + "</option>").join("") + "</select></label>" + num("spindles." + i + ".modbusId", s.modbusId, "Modbus ID") + num("spindles." + i + ".baud", s.baud, "Baud") + "</div>" + (b.rs485 ? "" : '<div class="dpcs-note warn">This board has no RS485 port.</div>')) +
          (s.kind === "laser" ? chk("spindles." + i + ".low", s.low, "Output is active-low (:low)", "Check with a meter before connecting the laser (first-run step). A reversed laser fires at full power while idle.") + '<div class="grid">' + num("spindles." + i + ".maxS", s.maxS, "S value for full power") + num("spindles." + i + ".pwmHz", s.pwmHz, "PWM frequency, Hz") + (ans.spindles.some((x) => x.kind !== "laser") ? txt("spindles." + i + ".tools", s.tools, "Selected by tool number(s)") : "") + "</div>" +
            (ans.spindles.some((x) => x.kind !== "laser") ? '<p class="lead" style="margin:8px 0 4px">Laser spot relative to the router bit (offset_mm). Measure: engrave a dot with the laser, plunge a V-bit at the same work zero, measure the distance in X and Y.</p><div class="grid">' + [0, 1, 2].map((k) => num("spindles." + i + ".offset." + k, (s.offset || [0, 0, 0])[k], "XYZ"[k] + " offset, mm", ' step="any"')).join("") + "</div>" : "")
            : s.kind === "vfd" || s.kind === "relay" || s.kind === "pwm" || s.kind === "10v" ? '<div class="grid">' + num("spindles." + i + ".spinup", s.spinup, "Spin-up wait, ms") + num("spindles." + i + ".spindown", s.spindown, "Spin-down wait, ms") + num("spindles." + i + ".maxRpm", s.maxRpm, "Max RPM") + "</div>" : "") + "</div>").join("") +
        '<div class="dpcs-row">add: ' + ["relay", "pwm", "10v", "vfd", "laser"].map((k) => '<button type="button" class="dpcs-btn ghost small" data-add="' + k + '"' + (k === "vfd" && !b.rs485 ? " disabled" : "") + ">" + names[k] + "</button>").join("") + "</div>";
    },
    extras() {
      const b = S.BOARDS[ans.board];
      return "<h2>Pendant, network and SD card</h2>" +
        (b.pendant ? chk("pendant", ans.pendant, "SmartTabUI pendant", "On UART1 (" + esc(b.pendant.tx + " / " + b.pendant.rx) + ", 1 000 000 baud)") : '<p class="lead">This board has no pendant port.</p>') +
        "<h5>Network</h5>" + seg("network", ans.network, [["ethernet", "Wired Ethernet (W5500)", !(b.eth && (b.eth.cs || b.editable))], ["wifi", "Wi-Fi"]]) +
        (ans.network === "ethernet" && b.eth && !b.eth.intWired && b.eth.intLater ? '<div class="dpcs-note"><code>int_pin: NO_PIN</code>: the W5500 is polled. Set it to ' + esc(b.eth.intLater) + " only once the INT wire is really connected: a wrong int_pin brings the link up but no packets pass.</div>" : "") +
        "<h5>SD card</h5>" + chk("sd", ans.sd, "SD card slot", "Shares the SPI bus with the W5500") +
        (ans.sd ? seg("sdHz", ans.sdHz, [[4000000, "4 MHz (default)"], [1000000, "1 MHz (long wires)"]]) + '<div class="dpcs-note">If Ethernet stops working when the SD card is read, the card is holding MISO: about 2 kΩ in series in the card\'s MISO fixes it.</div>' : "");
    },
    review() {
      const tpl = ans.board === "tpl";
      return "<h2>Review</h2><p class=\"lead\">" + (tpl ? "Lines the builder changed end with a comment saying what the config had before; the rest is the ready config as published." : "Every line has a comment saying where it came from.") + " The check below uses the firmware's own list of settings.</p>" +
        (tpl ? cautionHtml(st.board) : "") +
        '<div id="dpcs-review-probs"><div class="dpcs-note">Checking…</div></div>' +
        '<div class="dpcs-row"><button type="button" class="dpcs-btn" data-use>Use this config</button><button type="button" class="dpcs-btn ghost" data-dl>Download config.yaml</button></div>' +
        '<p class="lead">Without the flasher: upload it in the WebUI under Files as <code>config.yaml</code>, then send <code>$bye</code>.</p>' +
        "<h5>Jump back</h5><div class=\"dpcs-row\">" + SCREENS().map((s, i) => '<button type="button" class="dpcs-btn ghost small" data-go="' + i + '">' + ({ board: "Board", tpl: "Board", travel: "Travel", pins: "Pins", machine: "Machine", blocks: "Blocks", moves: "What moves", drivers: "Drivers", steps: "Steps/mm", switches: "Switches", controls: "Buttons", spindles: "Spindle", extras: "Network", review: "Review" }[s]) + "</button>").join("") + "</div>";
    },
  };

  function renderScreen() {
    const m = $("#dpcs-modal");
    const list = SCREENS();
    screen = Math.min(screen, list.length - 1);
    if (ans.board === "generic") { if (lockChip()) ans.customChip = lockChip(); S.BOARDS.generic.chip = ans.customChip || "esp32s3"; S.BOARDS.generic.octal = (ans.customChip || "esp32s3") === "esp32s3"; }
    const q = $(".dpcs-q", m);
    const scroll = q.scrollTop, same = q.dataset.s === list[screen];
    q.innerHTML = RENDER[list[screen]]();
    q.dataset.s = list[screen];
    if (same) q.scrollTop = scroll; else q.scrollTop = 0;
    $(".dpcs-prog", m).innerHTML = list.map((_, i) => "<i" + (i <= screen ? ' class="on"' : "") + "></i>").join("");
    const back = $("[data-back]", m);
    back.textContent = screen === 0 ? "Back to the install page" : "Back";
    $("[data-next]", m).disabled = list[screen] === "tpl" && !(ans.tpl.info && ans.axes.length);
    $("[data-next]", m).classList.toggle("dpcs-hidden", screen === list.length - 1);
    $("footer .sp", m).textContent = "Step " + (screen + 1) + " of " + list.length;
    updateYaml();
  }

  // ------------------------------------------------------------ go
  let ans = null;
  render();
  stepState();
  restore();
  schema().catch(() => {});
  window.DPCSetupUI = { openBuilder, useConfig, state: st };
})();
