<?php
/**
 * Modern Customer Account - renders the account dashboard (shop) and the settings page (admin).
 */
require_once(dirname(__FILE__) . '/Service.php');
require_once(dirname(__FILE__) . '/Lang.php');

if (!class_exists('MaUi')) {
class MaUi {
	const VERSION = '1.0.0';

	private static function h($s) {
		return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
	}

	/* ------------------------------------------------ admin */

	public static function writeActions() {
		return array('save_settings', 'add_coupon', 'remove_coupon');
	}

	public static function dispatch(MaService $s, $action, array $in) {
		$s->ensureTables();

		switch ($action) {
			case 'bootstrap':
				return $s->bootstrap();
			case 'save_settings':
				return array('config' => $s->saveConfig($in));
			case 'coupon_search':
				return array('items' => $s->searchCoupons(isset($in['q']) ? $in['q'] : ''));
			case 'customer_search':
				return array('items' => $s->searchCustomers(isset($in['q']) ? $in['q'] : ''));
			case 'add_coupon':
				return array('coupons' => $s->addCoupon($in));
			case 'remove_coupon':
				return array('coupons' => $s->removeCoupon(isset($in['id']) ? (int)$in['id'] : 0));
		}

		throw new Exception('Unknown action: ' . $action);
	}

	public static function input() {
		$raw = file_get_contents('php://input');
		$in = $raw !== '' ? json_decode($raw, true) : array();

		return is_array($in) ? $in : array();
	}

	public static function json($payload) {
		return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_INVALID_UTF8_SUBSTITUTE);
	}

	public static function api(MaService $s, $action, $can) {
		$perm = in_array($action, self::writeActions(), true) ? 'modify' : 'access';

		if (!call_user_func($can, $perm)) {
			return self::json(array('error' => 'Permission denied: your user group needs "' . $perm . '" permission for Modern Customer Account (System > Users > User Groups).'));
		}

		try {
			return self::json(array('ok' => true, 'data' => self::dispatch($s, $action, self::input())));
		} catch (Exception $e) {
			return self::json(array('error' => $e->getMessage()));
		} catch (Error $e) {
			return self::json(array('error' => 'Server error: ' . $e->getMessage()));
		}
	}

	public static function page($api_url, $oc_major, array $links) {
		$boot = array('api' => $api_url, 'oc' => (int)$oc_major, 'version' => self::VERSION, 'links' => $links);
		$dir = dirname(__FILE__) . '/ui/';

		return '<div id="mca-admin" class="mcaa"><div class="mcaa-loading">Loading…</div></div>'
			. '<style>' . file_get_contents($dir . 'admin.css') . '</style>'
			. '<script>window.MCA_ADMIN=' . json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . ';</script>'
			. '<script>' . file_get_contents($dir . 'admin.js') . '</script>';
	}

	/* ------------------------------------------------ shop: placing the dashboard in the account page */

	/**
	 * Swaps what is inside <div id="content"> of the rendered account page for the dashboard, keeping the theme's
	 * header, footer, breadcrumb and columns. Returns the page unchanged if the content block is not found.
	 */
	public static function place($html, $inner) {
		if (!preg_match('/<div\b[^>]*\bid\s*=\s*["\']content["\'][^>]*>/i', $html, $m, PREG_OFFSET_CAPTURE)) {
			return $html;
		}

		$start = $m[0][1] + strlen($m[0][0]);
		$depth = 1;
		$pos = $start;

		while ($depth > 0 && preg_match('/<(\/?)div\b[^>]*>/i', $html, $t, PREG_OFFSET_CAPTURE, $pos)) {
			$depth += $t[1][0] === '/' ? -1 : 1;
			$pos = $t[0][1] + strlen($t[0][0]);

			if ($depth === 0) {
				return substr($html, 0, $start) . $inner . substr($html, $t[0][1]);
			}
		}

		return $html;
	}

	/* ------------------------------------------------ shop: the dashboard */

	private static function date($ymd, $months) {
		if (!$ymd || $ymd === '0000-00-00') {
			return '';
		}

		$t = strtotime($ymd);

		return $months ? date('j', $t) . ' ' . $months[(int)date('n', $t) - 1] . ' ' . date('Y', $t) : date('d.m.Y', $t);
	}

	private static function couponWhat(array $c, array $L, $money) {
		if ($c['shipping'] && $c['discount'] <= 0) {
			$what = $L['free_delivery'];
		} else {
			$v = $c['type'] === 'P' ? rtrim(rtrim(number_format($c['discount'], 2, '.', ''), '0'), '.') . '%' : call_user_func($money, $c['discount']);
			$what = sprintf($L['off'], $v) . ($c['shipping'] ? ' + ' . mb_strtolower($L['free_delivery'], 'UTF-8') : '');
		}

		return $what . ($c['total'] > 0 ? sprintf($L['over'], call_user_func($money, $c['total'])) : '');
	}

	private static function icon($theme, $found) {
		$fills = array('coin' => array('#F2C14E', '#A87410'), 'egg' => array('#F4A9C0', '#B5527A'), 'gift' => array('#E05555', '#962828'), 'pumpkin' => array('#F08A24', '#A4520B'), 'heart' => array('#E8507A', '#A3214A'));
		$f = isset($fills[$theme]) ? $fills[$theme] : $fills['coin'];
		$fill = $found ? $f[0] : 'none';
		$stroke = $found ? $f[1] : '#9AA5B4';
		$dash = $found ? '' : ' stroke-dasharray="3 3"';

		switch ($theme) {
			case 'egg':
				$shape = '<path d="M12 3c3.6 0 6.5 5.2 6.5 9.6 0 4.2-2.9 7.4-6.5 7.4s-6.5-3.2-6.5-7.4C5.5 8.2 8.4 3 12 3z" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.6"' . $dash . '/>';
				break;
			case 'gift':
				$shape = '<rect x="4" y="9" width="16" height="11" rx="1.5" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.6"' . $dash . '/><path d="M12 9v11M4 13h16M12 9c-2-4-6-3-5 0M12 9c2-4 6-3 5 0" fill="none" stroke="' . $stroke . '" stroke-width="1.4"/>';
				break;
			case 'heart':
				$shape = '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.6"' . $dash . '/>';
				break;
			case 'pumpkin':
				$shape = '<ellipse cx="12" cy="13.5" rx="8" ry="6.5" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.6"' . $dash . '/><path d="M12 7V4.5M12 7c-2 2-2 11 0 13M12 7c2 2 2 11 0 13" fill="none" stroke="' . $stroke . '" stroke-width="1.3"/>';
				break;
			default:
				$shape = '<circle cx="12" cy="12" r="9" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.6"' . $dash . '/><path d="M9.5 9.5h4a1.6 1.6 0 0 1 0 3.2h-3a1.6 1.6 0 0 0 0 3.2h4M12 8v1.5M12 16v1.5" fill="none" stroke="' . ($found ? $f[1] : '#B6BFCB') . '" stroke-width="1.5" stroke-linecap="round"/>';
		}

		return '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true">' . $shape . '</svg>';
	}

	/**
	 * $d: MaService::dashboard(). $links: overview, order, return, wishlist, address, address_add, download, reward, edit,
	 * password, newsletter, transaction, subscription, payment_method, affiliate, logout, home. $fmt: money(amount in the
	 * shop's default currency), language (code). Empty links are left out.
	 */
	public static function render(array $d, array $links, array $cfg, array $fmt) {
		$L = MaLang::get($fmt['language']);
		$months = MaLang::months($fmt['language']);
		$money = $fmt['money'];
		$sec = $cfg['sections'];
		$h = function ($s) { return MaUi::h($s); };
		$link = function ($k) use ($links) { return isset($links[$k]) && $links[$k] ? $links[$k] : ''; };
		$name = $d['firstname'] !== '' ? $d['firstname'] : $d['lastname'];
		$hunt = $sec['hunt'] && !empty($d['hunt']) && empty($d['hunt']['guest']) ? $d['hunt'] : null;
		$coupons = $d['coupons'];
		$activeCoupons = count(array_filter($coupons, function ($c) { return $c['active']; }));

		$o = '<div id="mca" class="mca" style="--mca-accent:' . $h($cfg['accent']) . '">';
		$o .= '<style>' . file_get_contents(dirname(__FILE__) . '/ui/account.css') . '</style>';
		$o .= '<div class="mca-wrap">';

		// Side menu
		if ($cfg['menu']) {
			$nav = array(
				array('overview', $L['nav_overview'], '', true),
				array('order', $L['nav_orders'], $d['order_count'] ?: ''),
				array('return', $L['nav_returns'], $d['returns_open'] ?: ''),
				array('wishlist', $L['nav_wishlist'], $d['wishlist'] ?: ''),
				array('address', $L['nav_addresses'], $d['address_count'] ?: ''),
				array('download', $L['nav_downloads'], ''),
				array('subscription', $L['nav_subscriptions'], $d['subscriptions'] ?: '', false, $d['subscriptions'] > 0),
				array('reward', $L['nav_reward'], $d['reward_on'] ? number_format($d['points'], 0, '.', ',') : ''),
				array('#mca-coupons', $L['nav_coupons'], $activeCoupons ?: ''),
				array('#mca-hunt', $hunt ? $hunt['name'] : '', $hunt && empty($hunt['won']) ? (int)$hunt['found'] . '/' . (int)$hunt['goal'] : ''),
				array('transaction', $L['nav_transactions'], '', false, $d['transactions'] > 0),
				array('edit', $L['nav_details'], ''),
				array('password', $L['nav_password'], ''),
				array('newsletter', $L['nav_newsletter'], $d['newsletter'] ? $L['news_on'] : $L['news_off'])
			);
			$o .= '<nav class="mca-nav" aria-label="' . $h($L['title']) . '"><div class="mca-who"><div class="mca-avatar" aria-hidden="true">' . $h(mb_strtoupper(mb_substr($d['firstname'], 0, 1, 'UTF-8') . mb_substr($d['lastname'], 0, 1, 'UTF-8'), 'UTF-8')) . '</div><div><div class="mca-who-name">' . $h(trim($d['firstname'] . ' ' . $d['lastname'])) . '</div>';
			$o .= $d['since'] ? '<div class="mca-muted mca-small">' . $h(sprintf($L['since'], substr($d['since'], 0, 4))) . '</div>' : '';
			$o .= '</div></div>';

			foreach ($nav as $n) {
				if (isset($n[4]) && !$n[4]) {
					continue;
				}

				if ($n[0] === '#mca-coupons' && !$sec['coupons']) {
					continue;
				}

				if ($n[0] === '#mca-hunt' && !$hunt) {
					continue;
				}

				$href = $n[0][0] === '#' ? $n[0] : ($n[0] === 'overview' ? '#mca' : $link($n[0]));

				if ($href === '' || ($n[0] === 'reward' && !$d['reward_on'])) {
					continue;
				}

				$o .= '<a class="mca-nav-a' . (!empty($n[3]) ? ' mca-on' : '') . '" href="' . $h($href) . '"' . (!empty($n[3]) ? ' aria-current="page"' : '') . '><span>' . $h($n[1]) . '</span><span class="mca-count">' . $h($n[2]) . '</span></a>';
			}

			$o .= $link('logout') ? '<a class="mca-nav-a mca-logout" href="' . $h($link('logout')) . '">' . $h($L['nav_logout']) . '</a>' : '';
			$o .= '</nav>';
		}

		$o .= '<div class="mca-main">';

		// Greeting
		if ($sec['greeting']) {
			$thanks = $d['order_count'] > 1 ? sprintf($L['thanks_n'], $d['order_count']) : ($d['order_count'] === 1 ? $L['thanks_1'] : $L['thanks_0']);
			$o .= '<div class="mca-head"><h1 class="mca-h1" data-mca-greet="' . $h(json_encode(array($L['morning'], $L['afternoon'], $L['evening'], $name))) . '">' . $h(sprintf($L['hello'], $name)) . '</h1>';
			$o .= '<p class="mca-muted">' . $h($thanks) . ($d['since'] && !$cfg['menu'] ? ' ' . $h(sprintf($L['since'], substr($d['since'], 0, 4))) . '.' : '') . '</p></div>';
		} else {
			$o .= '<div class="mca-head"><h1 class="mca-h1">' . $h($L['title']) . '</h1><p class="mca-muted">' . $h($L['sub']) . '</p></div>';
		}

		// Tiles
		if ($sec['tiles']) {
			$tiles = array();
			$tiles[] = array($L['tile_way'], (string)$d['on_way'], $d['track'] ? sprintf($L['tile_way_link'], $d['track']['id']) : $L['tile_way_none'], $d['track'] ? '#mca-track' : $link('order'));

			if ($d['reward_on']) {
				$tiles[] = array($L['tile_points'], number_format($d['points'], 0, '.', ','), $L['tile_points_link'], $link('reward'));
			} else {
				$tiles[] = array($L['tile_orders'], (string)$d['order_count'], $L['tile_orders_link'], $link('order'));
			}

			$tiles[] = array($L['tile_wish'], (string)$d['wishlist'], $d['wishlist_sale'] ? sprintf($L['tile_wish_sale'], $d['wishlist_sale']) : $L['tile_wish_link'], $link('wishlist'));
			$tiles[] = array($L['tile_returns'], (string)$d['returns_open'], $d['returns_open'] ? $d['return_status'] : $L['tile_returns_none'], $link('return'));
			$o .= '<div class="mca-tiles">';

			foreach ($tiles as $t) {
				$o .= '<a class="mca-tile" href="' . $h($t[3] ?: '#mca') . '"><span class="mca-muted mca-small">' . $h($t[0]) . '</span><span class="mca-big">' . $h($t[1]) . '</span><span class="mca-tile-link">' . $h($t[2]) . '</span></a>';
			}

			$o .= '</div>';
		}

		// Order on its way
		if ($sec['track'] && $d['track']) {
			$tr = $d['track'];
			$steps = array('placed', 'preparing', 'shipped', 'delivered');
			$at = array_search($tr['kind'], $steps, true);
			$o .= '<section class="mca-card" id="mca-track" aria-labelledby="mca-track-h"><div class="mca-row"><h2 class="mca-h2" id="mca-track-h">' . $h(sprintf($L['track_' . $tr['kind']], $tr['id'])) . '</h2>';
			$o .= '<a class="mca-link" href="' . $h($tr['href']) . '">' . $h($L['order_details']) . '</a></div>';
			$o .= '<ol class="mca-steps">';

			foreach ($steps as $i => $s) {
				$on = $i <= $at;
				$o .= '<li class="mca-step' . ($on ? ' mca-step-on' : '') . ($i === $at ? ' mca-step-now' : '') . '"' . ($i === $at ? ' aria-current="step"' : '') . '><span class="mca-step-bar"></span><span class="mca-step-label">' . $h($L['step_' . $s]) . '</span><span class="mca-muted mca-small">' . $h(isset($tr['when'][$s]) ? self::date($tr['when'][$s], $months) : ($on ? '' : $L['step_soon'])) . '</span></li>';
			}

			$o .= '</ol><div class="mca-muted mca-small">' . $h(implode(' · ', $tr['items'])) . '</div></section>';
		}

		// Coupons and the hunt
		if (($sec['coupons']) || $hunt) {
			$o .= '<div class="mca-two">';

			if ($sec['coupons']) {
				$o .= '<section class="mca-card" id="mca-coupons" aria-labelledby="mca-cpn-h"><h2 class="mca-h2" id="mca-cpn-h">' . $h($L['coupons']) . '</h2>';

				if (!$coupons) {
					$o .= '<p class="mca-muted mca-empty">' . $h($L['no_coupons']) . '</p>';
				}

				foreach ($coupons as $c) {
					$src = !$c['active'] ? ($c['used'] ? $L['src_used'] : $L['src_expired']) : ($c['label'] !== '' ? $c['label'] : $L['src_' . ($c['source'] === 'used' ? 'shop' : $c['source'])]);
					$note = $c['used'] && !$c['active'] ? sprintf($L['used_on'], $c['used']['order_id'], self::date($c['used']['date'], $months)) : ($c['until'] ? sprintf($L['valid_until'], self::date($c['until'], $months)) : $L['no_end']);
					$o .= '<div class="mca-coupon' . ($c['active'] ? '' : ' mca-coupon-old') . '"><div class="mca-coupon-body"><div class="mca-coupon-top"><span class="mca-code">' . $h($c['code']) . '</span><span class="mca-tag mca-tag-' . $h($c['active'] ? $c['source'] : 'old') . '">' . $h($src) . '</span></div>';
					$o .= '<div class="mca-strong">' . $h(self::couponWhat($c, $L, $money)) . '</div><div class="mca-muted mca-small">' . $h($note) . '</div></div>';
					$o .= $c['active'] ? '<button type="button" class="mca-btn mca-btn-line" data-mca-copy="' . $h($c['code']) . '" data-mca-done="' . $h($L['copied']) . '">' . $h($L['copy']) . '</button>' : '';
					$o .= '</div>';
				}

				$o .= '</section>';
			}

			if ($hunt) {
				$goal = max(1, (int)$hunt['goal']);
				$found = min($goal, (int)(isset($hunt['found']) ? $hunt['found'] : 0));
				$words = isset($hunt['words']) ? $hunt['words'] : array('coin', 'coins', 'gold coin');
				$noun = strtolower(substr($fmt['language'], 0, 2)) === 'en' ? $words[min(1, count($words) - 1)] . ' ' : '';
				$o .= '<section class="mca-card" id="mca-hunt" aria-labelledby="mca-hunt-h"><div class="mca-row"><h2 class="mca-h2" id="mca-hunt-h">' . $h($hunt['name']) . '</h2><span class="mca-muted mca-small">' . $h(sprintf($L['hunt_ends'], self::date($hunt['ends'], $months))) . '</span></div>';

				if (!empty($hunt['won'])) {
					$o .= '<p class="mca-strong">' . $h(sprintf($L['hunt_won'], $hunt['won']['code'])) . '</p>';
				} elseif (!empty($hunt['sold_out'])) {
					$o .= '<p>' . $h($L['hunt_sold']) . '</p>';
				} else {
					$o .= '<div class="mca-hunt-count"><span class="mca-big">' . $h(sprintf($L['hunt_of'], $found, $goal)) . '</span> <span class="mca-muted">' . $h($noun . $L['hunt_found']) . '</span></div>';
					$o .= '<ol class="mca-coins" aria-label="' . $h(sprintf($L['hunt_of'], $found, $goal) . ' ' . $L['hunt_found']) . '">';

					for ($i = 0; $i < $goal && $i < 12; $i++) {
						$o .= '<li class="mca-coin' . ($i < $found ? ' mca-coin-on' : '') . '">' . self::icon($hunt['theme'], $i < $found) . '</li>';
					}

					$o .= '</ol><div class="mca-bar"><span style="width:' . round(100 * $found / $goal) . '%"></span></div>';
					$next = null;

					foreach (isset($hunt['hints']) ? $hunt['hints'] : array() as $hint) {
						if (empty($hint['found'])) {
							$next = $hint;
							break;
						}
					}

					if ($next) {
						$txt = !empty($next['name']) ? sprintf($L['hunt_on'], $next['name']) : (!empty($next['where']) ? sprintf($L['hunt_in'], $next['where']) : $L['hunt_page']);
						$txt .= !empty($next['price']) && empty($next['name']) ? sprintf($L['hunt_price'], preg_replace('/^priced\s+/', '', $next['price'])) : '';
						$o .= '<div class="mca-hint"><b>' . $h($L['hunt_hint']) . '</b> ' . $h($txt) . '</div>';
					} elseif (isset($hunt['hints'])) {
						$o .= '<div class="mca-hint">' . $h($L['hunt_today']) . '</div>';
					}

					$o .= '<p class="mca-small">' . $h(sprintf($L['hunt_win'], $goal, $hunt['prize'])) . ' ' . $h($L['hunt_appear']) . '</p>';
					$o .= $link('home') ? '<a class="mca-btn mca-btn-fill" href="' . $h($link('home')) . '">' . $h($L['hunt_go']) . '</a>' : '';
				}

				$o .= '</section>';
			}

			$o .= '</div>';
		}

		// Recent orders
		if ($sec['orders']) {
			$o .= '<section class="mca-card" aria-labelledby="mca-ord-h"><div class="mca-row"><h2 class="mca-h2" id="mca-ord-h">' . $h($L['orders']) . '</h2>' . ($link('order') ? '<a class="mca-link" href="' . $h($link('order')) . '">' . $h($L['all_orders']) . '</a>' : '') . '</div>';

			if (!$d['orders']) {
				$o .= '<p class="mca-muted mca-empty">' . $h($L['no_orders']) . ' ' . ($link('home') ? '<a class="mca-link" href="' . $h($link('home')) . '">' . $h($L['shop_now']) . '</a>' : '') . '</p>';
			} else {
				$o .= '<div class="mca-table-box"><table class="mca-table"><thead><tr><th scope="col">' . $h($L['col_order']) . '</th><th scope="col">' . $h($L['col_date']) . '</th><th scope="col">' . $h($L['col_items']) . '</th><th scope="col">' . $h($L['col_total']) . '</th><th scope="col">' . $h($L['col_status']) . '</th><th scope="col"><span class="mca-sr">' . $h($L['col_actions']) . '</span></th></tr></thead><tbody>';

				foreach ($d['orders'] as $r) {
					$names = array_map(function ($i) { return $i['name'] . ($i['qty'] > 1 ? ' ×' . $i['qty'] : ''); }, array_slice($r['items'], 0, 2));
					$more = count($r['items']) - 2;
					$again = '';

					if ($r['kind'] === 'delivered' && !empty($r['items'])) {
						foreach ($d['again'] as $a) {
							if ($a['product_id'] === $r['items'][0]['product_id']) {
								$again = $a['href'];
							}
						}
					}

					$o .= '<tr><td class="mca-strong">#' . (int)$r['id'] . '</td><td class="mca-nowrap">' . $h(self::date($r['date'], $months)) . '</td><td>' . $h(implode(', ', $names)) . ($more > 0 ? ' <span class="mca-muted">' . $h(sprintf($L['more'], $more)) . '</span>' : '') . '</td>';
					$o .= '<td class="mca-strong mca-nowrap">' . $h($r['total']) . '</td><td><span class="mca-chip mca-chip-' . $h($r['kind']) . '">' . $h($r['status']) . '</span></td>';
					$o .= '<td class="mca-actions"><a class="mca-link" href="' . $h($r['href']) . '">' . $h($L['details']) . '</a>' . ($again ? '<a class="mca-link" href="' . $h($again) . '">' . $h($L['buy_again']) . '</a>' : '') . '</td></tr>';
				}

				$o .= '</tbody></table></div>';
			}

			$o .= '</section>';
		}

		// Addresses and the checklist
		if ($sec['addresses'] || $sec['checklist']) {
			$o .= '<div class="mca-two">';

			if ($sec['addresses']) {
				$o .= '<section class="mca-card" aria-labelledby="mca-adr-h"><div class="mca-row"><h2 class="mca-h2" id="mca-adr-h">' . $h($L['addresses']) . '</h2>' . ($link('address') ? '<a class="mca-link" href="' . $h($link('address')) . '">' . $h($d['addresses'] ? $L['manage'] : $L['add_address']) . '</a>' : '') . '</div>';

				if (!$d['addresses']) {
					$o .= '<p class="mca-muted mca-empty">' . $h($L['no_address']) . '</p>';
				} else {
					$o .= '<div class="mca-addresses">';

					foreach ($d['addresses'] as $a) {
						$o .= '<div class="mca-address' . ($a['default'] ? ' mca-address-def' : '') . '">' . ($a['default'] ? '<span class="mca-tag mca-tag-gift">' . $h($L['default']) . '</span>' : '') . '<div>' . implode('<br>', array_map(function ($l) { return MaUi::h($l); }, $a['lines'])) . '</div></div>';
					}

					$o .= '</div>';
				}

				$o .= '</section>';
			}

			if ($sec['checklist']) {
				$checks = array(
					array($L['chk_email'], $d['email'] !== '', $link('edit')),
					array($L['chk_phone'], trim($d['telephone']) !== '', $link('edit')),
					array($L['chk_address'], $d['address_count'] > 0, $link('address')),
					array($L['chk_news'], $d['newsletter'], $link('newsletter'))
				);
				$done = count(array_filter($checks, function ($c) { return $c[1]; }));
				$pct = (int)round(100 * $done / count($checks));
				$o .= '<section class="mca-card" aria-labelledby="mca-chk-h"><h2 class="mca-h2" id="mca-chk-h">' . $h(sprintf($L['complete'], $pct)) . '</h2><div class="mca-bar"><span style="width:' . $pct . '%"></span></div><ul class="mca-checks">';

				foreach ($checks as $c) {
					$o .= '<li class="mca-check' . ($c[1] ? ' mca-check-on' : '') . '"><span class="mca-tick" aria-hidden="true">' . ($c[1] ? '✓' : '') . '</span><span class="mca-grow">' . $h($c[0]) . '<span class="mca-sr"> ' . $h($c[1] ? $L['done'] : '') . '</span></span>' . (!$c[1] && $c[2] ? '<a class="mca-link" href="' . $h($c[2]) . '">' . $h($L['add']) . '</a>' : '') . '</li>';
				}

				$o .= '</ul></section>';
			}

			$o .= '</div>';
		}

		// Buy again
		if ($sec['again'] && $d['again']) {
			$o .= '<section aria-labelledby="mca-again-h"><h2 class="mca-h2 mca-h2-out" id="mca-again-h">' . $h($L['again']) . '</h2><div class="mca-again">';

			foreach ($d['again'] as $a) {
				$o .= '<a class="mca-product" href="' . $h($a['href']) . '"><span class="mca-product-img">' . ($a['image'] ? '<img src="' . $h($a['image']) . '" alt="" loading="lazy">' : '') . '</span><span class="mca-product-body"><span class="mca-strong">' . $h($a['name']) . '</span>';
				$o .= '<span class="mca-muted mca-small">' . $h($a['times'] > 1 ? sprintf($L['bought_n'], $a['times']) : sprintf($L['bought_1'], self::date($a['last'], $months))) . '</span>';
				$o .= '<span class="mca-product-foot"><span class="mca-strong">' . $h($a['price']) . '</span><span class="mca-tile-link">' . $h($L['view']) . '</span></span></span></a>';
			}

			$o .= '</div></section>';
		}

		$o .= '</div></div>';
		$o .= '<script>' . file_get_contents(dirname(__FILE__) . '/ui/account.js') . '</script>';
		$o .= '</div>';

		return $o;
	}
}
}
