<?php
/**
 * Modern Customer Account - shop texts. English is the base; a shop language without its own set falls back to it,
 * and any single missing text falls back to the English one.
 */
if (!class_exists('MaLang')) {
class MaLang {
	public static function sets() {
		return array(
			'en' => array(
				'title' => 'My account', 'sub' => 'Everything about your account in one place.',
				'hello' => 'Hello, %s', 'morning' => 'Good morning, %s', 'afternoon' => 'Good afternoon, %s', 'evening' => 'Good evening, %s',
				'since' => 'Customer since %s', 'thanks_n' => 'Thank you for your %d orders with us.', 'thanks_1' => 'Thank you for your first order with us.', 'thanks_0' => 'Welcome! We are glad you are here.',
				'nav_overview' => 'Overview', 'nav_orders' => 'Orders', 'nav_returns' => 'Returns', 'nav_wishlist' => 'Wishlist', 'nav_addresses' => 'Addresses', 'nav_downloads' => 'Downloads',
				'nav_reward' => 'Reward points', 'nav_coupons' => 'Coupons', 'nav_details' => 'Personal details', 'nav_password' => 'Password', 'nav_newsletter' => 'Newsletter',
				'nav_transactions' => 'Transactions', 'nav_subscriptions' => 'Subscriptions', 'nav_payment' => 'Payment methods', 'nav_affiliate' => 'Affiliate', 'nav_logout' => 'Log out', 'news_on' => 'On', 'news_off' => 'Off',
				'tile_way' => 'On the way', 'tile_way_link' => 'Track order #%d', 'tile_way_none' => 'Nothing on the way', 'tile_points' => 'Reward points', 'tile_points_link' => 'See history',
				'tile_wish' => 'Wishlist', 'tile_wish_sale' => '%d on sale now', 'tile_wish_link' => 'See wishlist', 'tile_returns' => 'Open returns', 'tile_returns_none' => 'No open returns',
				'tile_orders' => 'Orders', 'tile_orders_link' => 'See all orders',
				'track_placed' => 'We have received your order #%d', 'track_preparing' => 'Your order #%d is being prepared', 'track_shipped' => 'Your order #%d is on its way',
				'step_placed' => 'Order placed', 'step_preparing' => 'Being prepared', 'step_shipped' => 'Shipped', 'step_delivered' => 'Delivered', 'step_soon' => 'Coming soon', 'order_details' => 'Order details',
				'coupons' => 'Your coupons', 'copy' => 'Copy code', 'copied' => 'Copied', 'src_hunt' => 'Hunt prize', 'src_gift' => 'Gift for you', 'src_shop' => 'Offer', 'src_used' => 'Used', 'src_expired' => 'Expired',
				'off' => '%s off', 'free_delivery' => 'Free delivery', 'over' => ' on orders over %s', 'valid_until' => 'Valid until %s', 'no_end' => 'No end date', 'used_on' => 'Used on order #%d, %s',
				'no_coupons' => 'No coupons right now. Coupons you win or receive from us will appear here.',
				'hunt_ends' => 'Ends %s', 'hunt_found' => 'found', 'hunt_of' => '%d of %d', 'hunt_hint' => 'Next hint:', 'hunt_in' => 'one is hiding on a product in %s', 'hunt_price' => ', priced %s', 'hunt_on' => 'one is hiding on %s',
				'hunt_page' => 'one is hiding on a product page', 'hunt_today' => 'You found all of today\'s. New hiding places tomorrow!', 'hunt_win' => 'Find all %d to win %s.', 'hunt_appear' => 'Your prize code will appear in Your coupons.',
				'hunt_go' => 'Continue the hunt', 'hunt_won' => 'You found them all! Your prize: %s.', 'hunt_sold' => 'All prizes have been won. Thank you for playing!',
				'orders' => 'Recent orders', 'all_orders' => 'All orders', 'col_order' => 'Order', 'col_date' => 'Date', 'col_items' => 'Items', 'col_total' => 'Total', 'col_status' => 'Status', 'col_actions' => 'Actions',
				'details' => 'Details', 'buy_again' => 'Buy again', 'more' => '+%d more', 'no_orders' => 'You have no orders yet.', 'shop_now' => 'Start shopping',
				'addresses' => 'Addresses', 'default' => 'Default', 'manage' => 'Manage', 'add_address' => 'Add an address', 'no_address' => 'No address saved yet. Saving one makes checkout faster.',
				'complete' => 'Your account is %d%% complete', 'chk_email' => 'Email address', 'chk_phone' => 'Phone number for the courier', 'chk_address' => 'Delivery address saved', 'chk_news' => 'Newsletter with offers', 'add' => 'Add', 'done' => 'Done',
				'again' => 'Buy again', 'bought_n' => 'Bought %d times', 'bought_1' => 'Bought once, %s', 'view' => 'View product'
			),
			'lv' => array(
				'title' => 'Mans konts', 'sub' => 'Viss par jūsu kontu vienuviet.',
				'hello' => 'Sveiki, %s', 'morning' => 'Labrīt, %s', 'afternoon' => 'Labdien, %s', 'evening' => 'Labvakar, %s',
				'since' => 'Klients kopš %s', 'thanks_n' => 'Paldies par jūsu %d pasūtījumiem!', 'thanks_1' => 'Paldies par jūsu pirmo pasūtījumu!', 'thanks_0' => 'Laipni lūdzam! Priecājamies, ka esat šeit.',
				'nav_overview' => 'Pārskats', 'nav_orders' => 'Pasūtījumi', 'nav_returns' => 'Atgriešana', 'nav_wishlist' => 'Vēlmju saraksts', 'nav_addresses' => 'Adreses', 'nav_downloads' => 'Lejupielādes',
				'nav_reward' => 'Bonusa punkti', 'nav_coupons' => 'Kuponi', 'nav_details' => 'Personas dati', 'nav_password' => 'Parole', 'nav_newsletter' => 'Jaunumi e-pastā',
				'nav_transactions' => 'Darījumi', 'nav_subscriptions' => 'Abonementi', 'nav_payment' => 'Maksājumu veidi', 'nav_affiliate' => 'Partneriem', 'nav_logout' => 'Iziet', 'news_on' => 'Ieslēgts', 'news_off' => 'Izslēgts',
				'tile_way' => 'Ceļā', 'tile_way_link' => 'Sekot pasūtījumam #%d', 'tile_way_none' => 'Nekas nav ceļā', 'tile_points' => 'Bonusa punkti', 'tile_points_link' => 'Skatīt vēsturi',
				'tile_wish' => 'Vēlmju saraksts', 'tile_wish_sale' => '%d ar atlaidi', 'tile_wish_link' => 'Skatīt sarakstu', 'tile_returns' => 'Atvērtās atgriešanas', 'tile_returns_none' => 'Nav atvērtu atgriešanu',
				'tile_orders' => 'Pasūtījumi', 'tile_orders_link' => 'Visi pasūtījumi',
				'track_placed' => 'Esam saņēmuši jūsu pasūtījumu #%d', 'track_preparing' => 'Jūsu pasūtījums #%d tiek sagatavots', 'track_shipped' => 'Jūsu pasūtījums #%d ir ceļā',
				'step_placed' => 'Pasūtīts', 'step_preparing' => 'Tiek sagatavots', 'step_shipped' => 'Nosūtīts', 'step_delivered' => 'Piegādāts', 'step_soon' => 'Drīzumā', 'order_details' => 'Pasūtījuma informācija',
				'coupons' => 'Jūsu kuponi', 'copy' => 'Kopēt kodu', 'copied' => 'Nokopēts', 'src_hunt' => 'Medību balva', 'src_gift' => 'Dāvana jums', 'src_shop' => 'Piedāvājums', 'src_used' => 'Izmantots', 'src_expired' => 'Beidzies',
				'off' => '%s atlaide', 'free_delivery' => 'Bezmaksas piegāde', 'over' => ' pasūtījumiem virs %s', 'valid_until' => 'Derīgs līdz %s', 'no_end' => 'Bez termiņa', 'used_on' => 'Izmantots pasūtījumā #%d, %s',
				'no_coupons' => 'Pašlaik kuponu nav. Šeit parādīsies kuponi, ko laimēsiet vai saņemsiet no mums.',
				'hunt_ends' => 'Beidzas %s', 'hunt_found' => 'atrasti', 'hunt_of' => '%d no %d', 'hunt_hint' => 'Nākamais mājiens:', 'hunt_in' => 'viens slēpjas pie preces kategorijā %s', 'hunt_price' => ', cena %s', 'hunt_on' => 'viens slēpjas pie preces %s',
				'hunt_page' => 'viens slēpjas kādā preces lapā', 'hunt_today' => 'Šodienas visi atrasti. Rīt jaunas slēptuves!', 'hunt_win' => 'Atrodiet visus %d un laimējiet: %s.', 'hunt_appear' => 'Balvas kods parādīsies sadaļā "Jūsu kuponi".',
				'hunt_go' => 'Turpināt medības', 'hunt_won' => 'Jūs atradāt visus! Jūsu balva: %s.', 'hunt_sold' => 'Visas balvas ir laimētas. Paldies, ka piedalījāties!',
				'orders' => 'Pēdējie pasūtījumi', 'all_orders' => 'Visi pasūtījumi', 'col_order' => 'Pasūtījums', 'col_date' => 'Datums', 'col_items' => 'Preces', 'col_total' => 'Summa', 'col_status' => 'Statuss', 'col_actions' => 'Darbības',
				'details' => 'Sīkāk', 'buy_again' => 'Pirkt vēlreiz', 'more' => 'un vēl %d', 'no_orders' => 'Jums vēl nav pasūtījumu.', 'shop_now' => 'Sākt iepirkties',
				'addresses' => 'Adreses', 'default' => 'Galvenā', 'manage' => 'Pārvaldīt', 'add_address' => 'Pievienot adresi', 'no_address' => 'Adrese vēl nav saglabāta. Ar to pasūtīt ir ātrāk.',
				'complete' => 'Jūsu konts ir aizpildīts par %d%%', 'chk_email' => 'E-pasta adrese', 'chk_phone' => 'Tālrunis kurjeram', 'chk_address' => 'Saglabāta piegādes adrese', 'chk_news' => 'Jaunumi un piedāvājumi', 'add' => 'Pievienot', 'done' => 'Gatavs',
				'again' => 'Pirkt vēlreiz', 'bought_n' => 'Pirkts %d reizes', 'bought_1' => 'Pirkts vienreiz, %s', 'view' => 'Skatīt preci'
			),
			'ru' => array(
				'title' => 'Мой аккаунт', 'sub' => 'Всё о вашем аккаунте в одном месте.',
				'hello' => 'Здравствуйте, %s', 'morning' => 'Доброе утро, %s', 'afternoon' => 'Добрый день, %s', 'evening' => 'Добрый вечер, %s',
				'since' => 'Покупатель с %s', 'thanks_n' => 'Спасибо за ваши заказы: %d!', 'thanks_1' => 'Спасибо за ваш первый заказ!', 'thanks_0' => 'Добро пожаловать! Мы рады вам.',
				'nav_overview' => 'Обзор', 'nav_orders' => 'Заказы', 'nav_returns' => 'Возвраты', 'nav_wishlist' => 'Избранное', 'nav_addresses' => 'Адреса', 'nav_downloads' => 'Загрузки',
				'nav_reward' => 'Бонусные баллы', 'nav_coupons' => 'Купоны', 'nav_details' => 'Личные данные', 'nav_password' => 'Пароль', 'nav_newsletter' => 'Рассылка',
				'nav_transactions' => 'Транзакции', 'nav_subscriptions' => 'Подписки', 'nav_payment' => 'Способы оплаты', 'nav_affiliate' => 'Партнёрам', 'nav_logout' => 'Выйти', 'news_on' => 'Вкл.', 'news_off' => 'Выкл.',
				'tile_way' => 'В пути', 'tile_way_link' => 'Отследить заказ #%d', 'tile_way_none' => 'Ничего не в пути', 'tile_points' => 'Бонусные баллы', 'tile_points_link' => 'История',
				'tile_wish' => 'Избранное', 'tile_wish_sale' => 'Со скидкой: %d', 'tile_wish_link' => 'Открыть', 'tile_returns' => 'Открытые возвраты', 'tile_returns_none' => 'Нет открытых возвратов',
				'tile_orders' => 'Заказы', 'tile_orders_link' => 'Все заказы',
				'track_placed' => 'Мы получили ваш заказ #%d', 'track_preparing' => 'Ваш заказ #%d собирается', 'track_shipped' => 'Ваш заказ #%d в пути',
				'step_placed' => 'Заказ оформлен', 'step_preparing' => 'Собирается', 'step_shipped' => 'Отправлен', 'step_delivered' => 'Доставлен', 'step_soon' => 'Скоро', 'order_details' => 'Детали заказа',
				'coupons' => 'Ваши купоны', 'copy' => 'Копировать', 'copied' => 'Скопировано', 'src_hunt' => 'Приз охоты', 'src_gift' => 'Подарок вам', 'src_shop' => 'Предложение', 'src_used' => 'Использован', 'src_expired' => 'Истёк',
				'off' => 'Скидка %s', 'free_delivery' => 'Бесплатная доставка', 'over' => ' на заказы от %s', 'valid_until' => 'Действует до %s', 'no_end' => 'Без срока', 'used_on' => 'Использован в заказе #%d, %s',
				'no_coupons' => 'Сейчас купонов нет. Здесь появятся купоны, которые вы выиграете или получите от нас.',
				'hunt_ends' => 'До %s', 'hunt_found' => 'найдено', 'hunt_of' => '%d из %d', 'hunt_hint' => 'Подсказка:', 'hunt_in' => 'одна спрятана у товара в разделе %s', 'hunt_price' => ', цена %s', 'hunt_on' => 'одна спрятана у товара %s',
				'hunt_page' => 'одна спрятана на странице товара', 'hunt_today' => 'Все на сегодня найдены. Завтра новые тайники!', 'hunt_win' => 'Найдите все %d и выиграйте: %s.', 'hunt_appear' => 'Код приза появится в разделе «Ваши купоны».',
				'hunt_go' => 'Продолжить охоту', 'hunt_won' => 'Вы нашли все! Ваш приз: %s.', 'hunt_sold' => 'Все призы разыграны. Спасибо за участие!',
				'orders' => 'Последние заказы', 'all_orders' => 'Все заказы', 'col_order' => 'Заказ', 'col_date' => 'Дата', 'col_items' => 'Товары', 'col_total' => 'Сумма', 'col_status' => 'Статус', 'col_actions' => 'Действия',
				'details' => 'Подробнее', 'buy_again' => 'Купить снова', 'more' => 'и ещё %d', 'no_orders' => 'У вас пока нет заказов.', 'shop_now' => 'За покупками',
				'addresses' => 'Адреса', 'default' => 'Основной', 'manage' => 'Изменить', 'add_address' => 'Добавить адрес', 'no_address' => 'Адрес ещё не сохранён. С ним оформлять заказ быстрее.',
				'complete' => 'Аккаунт заполнен на %d%%', 'chk_email' => 'Адрес e-mail', 'chk_phone' => 'Телефон для курьера', 'chk_address' => 'Сохранён адрес доставки', 'chk_news' => 'Рассылка с предложениями', 'add' => 'Добавить', 'done' => 'Готово',
				'again' => 'Купить снова', 'bought_n' => 'Куплено %d раз', 'bought_1' => 'Куплено один раз, %s', 'view' => 'К товару'
			),
			'de' => array(
				'title' => 'Mein Konto', 'sub' => 'Alles zu Ihrem Konto an einem Ort.',
				'hello' => 'Hallo, %s', 'morning' => 'Guten Morgen, %s', 'afternoon' => 'Guten Tag, %s', 'evening' => 'Guten Abend, %s',
				'since' => 'Kunde seit %s', 'thanks_n' => 'Danke für Ihre %d Bestellungen bei uns!', 'thanks_1' => 'Danke für Ihre erste Bestellung!', 'thanks_0' => 'Willkommen! Schön, dass Sie da sind.',
				'nav_overview' => 'Übersicht', 'nav_orders' => 'Bestellungen', 'nav_returns' => 'Retouren', 'nav_wishlist' => 'Wunschliste', 'nav_addresses' => 'Adressen', 'nav_downloads' => 'Downloads',
				'nav_reward' => 'Bonuspunkte', 'nav_coupons' => 'Gutscheine', 'nav_details' => 'Persönliche Daten', 'nav_password' => 'Passwort', 'nav_newsletter' => 'Newsletter',
				'nav_transactions' => 'Transaktionen', 'nav_subscriptions' => 'Abonnements', 'nav_payment' => 'Zahlungsarten', 'nav_affiliate' => 'Partnerprogramm', 'nav_logout' => 'Abmelden', 'news_on' => 'An', 'news_off' => 'Aus',
				'tile_way' => 'Unterwegs', 'tile_way_link' => 'Bestellung #%d verfolgen', 'tile_way_none' => 'Nichts unterwegs', 'tile_points' => 'Bonuspunkte', 'tile_points_link' => 'Verlauf ansehen',
				'tile_wish' => 'Wunschliste', 'tile_wish_sale' => '%d im Angebot', 'tile_wish_link' => 'Wunschliste ansehen', 'tile_returns' => 'Offene Retouren', 'tile_returns_none' => 'Keine offenen Retouren',
				'tile_orders' => 'Bestellungen', 'tile_orders_link' => 'Alle Bestellungen',
				'track_placed' => 'Wir haben Ihre Bestellung #%d erhalten', 'track_preparing' => 'Ihre Bestellung #%d wird vorbereitet', 'track_shipped' => 'Ihre Bestellung #%d ist unterwegs',
				'step_placed' => 'Bestellt', 'step_preparing' => 'In Vorbereitung', 'step_shipped' => 'Versendet', 'step_delivered' => 'Zugestellt', 'step_soon' => 'Demnächst', 'order_details' => 'Bestelldetails',
				'coupons' => 'Ihre Gutscheine', 'copy' => 'Code kopieren', 'copied' => 'Kopiert', 'src_hunt' => 'Schatzsuche-Preis', 'src_gift' => 'Geschenk für Sie', 'src_shop' => 'Angebot', 'src_used' => 'Eingelöst', 'src_expired' => 'Abgelaufen',
				'off' => '%s Rabatt', 'free_delivery' => 'Kostenloser Versand', 'over' => ' ab %s Bestellwert', 'valid_until' => 'Gültig bis %s', 'no_end' => 'Unbefristet', 'used_on' => 'Eingelöst bei Bestellung #%d, %s',
				'no_coupons' => 'Zurzeit keine Gutscheine. Gewonnene oder geschenkte Gutscheine erscheinen hier.',
				'hunt_ends' => 'Endet am %s', 'hunt_found' => 'gefunden', 'hunt_of' => '%d von %d', 'hunt_hint' => 'Nächster Hinweis:', 'hunt_in' => 'eines versteckt sich bei einem Produkt in %s', 'hunt_price' => ', Preis %s', 'hunt_on' => 'eines versteckt sich bei %s',
				'hunt_page' => 'eines versteckt sich auf einer Produktseite', 'hunt_today' => 'Alle von heute gefunden. Morgen gibt es neue Verstecke!', 'hunt_win' => 'Finden Sie alle %d und gewinnen Sie: %s.', 'hunt_appear' => 'Ihr Gewinncode erscheint unter „Ihre Gutscheine“.',
				'hunt_go' => 'Weitersuchen', 'hunt_won' => 'Sie haben alle gefunden! Ihr Preis: %s.', 'hunt_sold' => 'Alle Preise sind vergeben. Danke fürs Mitspielen!',
				'orders' => 'Letzte Bestellungen', 'all_orders' => 'Alle Bestellungen', 'col_order' => 'Bestellung', 'col_date' => 'Datum', 'col_items' => 'Artikel', 'col_total' => 'Summe', 'col_status' => 'Status', 'col_actions' => 'Aktionen',
				'details' => 'Details', 'buy_again' => 'Erneut kaufen', 'more' => '+%d weitere', 'no_orders' => 'Sie haben noch keine Bestellungen.', 'shop_now' => 'Jetzt einkaufen',
				'addresses' => 'Adressen', 'default' => 'Standard', 'manage' => 'Verwalten', 'add_address' => 'Adresse hinzufügen', 'no_address' => 'Noch keine Adresse gespeichert. Damit geht die Bestellung schneller.',
				'complete' => 'Ihr Konto ist zu %d%% vollständig', 'chk_email' => 'E-Mail-Adresse', 'chk_phone' => 'Telefonnummer für den Kurier', 'chk_address' => 'Lieferadresse gespeichert', 'chk_news' => 'Newsletter mit Angeboten', 'add' => 'Hinzufügen', 'done' => 'Erledigt',
				'again' => 'Erneut kaufen', 'bought_n' => '%d-mal gekauft', 'bought_1' => 'Einmal gekauft, %s', 'view' => 'Zum Produkt'
			)
		);
	}

	public static function get($code) {
		$sets = self::sets();
		$k = strtolower(substr((string)$code, 0, 2));
		$base = $sets['en'];

		return isset($sets[$k]) ? array_merge($base, $sets[$k]) : $base;
	}

	public static function months($code) {
		return strtolower(substr((string)$code, 0, 2)) === 'en' ? array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec') : null;
	}
}
}
