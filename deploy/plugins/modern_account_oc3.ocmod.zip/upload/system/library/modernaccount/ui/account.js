/* Modern Customer Account: the greeting by the customer's own clock, and copying coupon codes. */
(function () {
  var root = document.getElementById('mca');
  if (!root) return;

  var g = root.querySelector('[data-mca-greet]');
  if (g) {
    try {
      var t = JSON.parse(g.getAttribute('data-mca-greet'));
      var hr = new Date().getHours();
      var pick = hr >= 5 && hr < 12 ? t[0] : (hr >= 12 && hr < 18 ? t[1] : t[2]);
      if (t[3]) g.textContent = pick.replace('%s', t[3]);
    } catch (e) {}
  }

  function copied(btn, code) {
    var was = btn.textContent;
    btn.textContent = btn.getAttribute('data-mca-done') || 'Copied';
    btn.setAttribute('aria-live', 'polite');
    setTimeout(function () { btn.textContent = was; }, 1800);
  }

  root.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('[data-mca-copy]') : null;
    if (!btn) return;
    var code = btn.getAttribute('data-mca-copy');
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(code).then(function () { copied(btn, code); }, function () { fallback(); });
    } else {
      fallback();
    }
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = code; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (x) {}
      document.body.removeChild(ta);
      copied(btn, code);
    }
  });
})();
