/* Modern Customer Account - admin settings page. */
(function () {
	var B = window.MCA_ADMIN || {};
	var root = document.getElementById('mca-admin');
	if (!root) return;
	var S = {config: null, statuses: [], rstatuses: [], coupons: [], hunt: false, pickCoupon: null, pickCustomer: null};

	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; });
	}

	function api(action, body) {
		return fetch(B.api + (B.api.indexOf('?') < 0 ? '?' : '&') + 'action=' + action, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})})
			.then(function (r) { return r.text(); })
			.then(function (t) {
				var j;
				try { j = JSON.parse(t); } catch (e) { throw new Error('The server answered with something unexpected. Reload the page and try again.'); }
				if (j.error) throw new Error(j.error);
				return j.data;
			});
	}

	var SECTIONS = [
		['greeting', 'Personal greeting', 'Good morning / evening by the customer\'s clock, and a thank-you for their orders.'],
		['tiles', 'Overview tiles', 'On the way, reward points (or orders), wishlist with items on sale, open returns.'],
		['track', 'Order tracker', 'The newest order in progress as placed → prepared → shipped → delivered.'],
		['coupons', 'Your coupons', 'Treasure Hunt prizes, gifts and offers you choose below, with a copy button. Used ones are shown greyed.'],
		['hunt', 'Treasure Hunt progress', 'Coins found, the next hint and the prize, while a hunt runs. Needs the Treasure Hunt extension.'],
		['orders', 'Recent orders', 'Coloured status labels, details and buy-again links.'],
		['addresses', 'Addresses', 'The default address first.'],
		['checklist', 'Account checklist', 'Email, phone, address and newsletter, with links to add what is missing.'],
		['again', 'Buy again', 'What the customer orders most, still for sale, with price and picture.']
	];
	var SWATCHES = ['#2448C8', '#1F5E4A', '#B5462B', '#6B3FA0', '#0F766E', '#1D2329'];

	function multi(name, list, chosen) {
		return '<div class="mcaa-multi">' + list.map(function (s) {
			var on = chosen.indexOf(s.id) >= 0;
			return '<label class="mcaa-pill' + (on ? ' on' : '') + '"><input type="checkbox" data-multi="' + name + '" value="' + s.id + '"' + (on ? ' checked' : '') + '> ' + esc(s.name) + '</label>';
		}).join('') + '</div>';
	}

	function render() {
		var c = S.config;
		var h = '';
		h += '<div class="mcaa-card"><div class="mcaa-head"><div><h3>Modern Customer Account</h3><div class="mcaa-muted">Replaces the content of the shop\'s My Account page with a dashboard. Your theme\'s header, footer and menus stay. Version ' + esc(B.version) + '</div></div>';
		h += '<div><button type="button" class="mcaa-btn pri" id="mcaa-save">Save settings</button><span class="mcaa-status" id="mcaa-st"></span></div></div>';
		h += '<div class="mcaa-grid">';
		h += '<label class="ck"><input type="checkbox" data-k="status"' + (c.status ? ' checked' : '') + '><span><b>Show the dashboard</b><em>Off: customers see the shop\'s original account page.</em></span></label>';
		h += '<label class="ck"><input type="checkbox" data-k="menu"' + (c.menu ? ' checked' : '') + '><span><b>Side menu</b><em>All account pages with counts. Turn off if your theme has its own account menu.</em></span></label>';
		h += '<label class="ck"><input type="checkbox" data-k="hide_columns"' + (c.hide_columns ? ' checked' : '') + '><span><b>Full width on the account page</b><em>Hides the left and right columns (like the Account module) on this one page, so the dashboard has room.</em></span></label>';
		h += '<div class="f"><span>Accent colour</span><div class="mcaa-color"><input type="color" id="mcaa-accent" value="' + esc(c.accent) + '"><input type="text" id="mcaa-accent-t" value="' + esc(c.accent) + '" style="width:110px"><div class="mcaa-swatches">' + SWATCHES.map(function (s) { return '<button type="button" class="mcaa-sw" data-sw="' + s + '" style="background:' + s + '" aria-label="Use ' + s + '"></button>'; }).join('') + '</div></div><em>Use your shop\'s button colour. Links, buttons and progress bars use it.</em></div>';
		h += '</div></div>';

		h += '<div class="mcaa-card"><h3>Sections</h3><div class="mcaa-muted" style="margin-bottom:12px">Each section shows only when the customer has something in it.</div><div class="mcaa-grid">';
		SECTIONS.forEach(function (s) {
			h += '<label class="ck"><input type="checkbox" data-sec="' + s[0] + '"' + (c.sections[s[0]] ? ' checked' : '') + '><span><b>' + esc(s[1]) + '</b><em>' + esc(s[2]) + (s[0] === 'hunt' && !S.hunt ? ' (Treasure Hunt is not installed.)' : '') + '</em></span></label>';
		});
		h += '</div></div>';

		h += '<div class="mcaa-card"><h3>Order statuses</h3><div class="mcaa-muted" style="margin-bottom:12px">"Delivered" and "in progress" come from your settings (System › Settings › Option: Processing / Complete order status). Here you only say which statuses mean the parcel has left.</div>';
		h += '<div class="f" style="margin-bottom:14px"><span>Shipped statuses</span>' + multi('shipped', S.statuses, c.shipped) + '</div>';
		h += '<div class="f" style="margin-bottom:14px"><span>Return statuses that close a return</span>' + multi('return_done', S.rstatuses, c.return_done) + '<em>Returns in any other status count as open.</em></div>';
		h += '<label class="f" style="max-width:220px"><span>Recent orders shown</span><input type="number" min="3" max="10" id="mcaa-orders" value="' + esc(c.orders_shown) + '"></label>';
		h += '</div>';

		h += '<div class="mcaa-card"><div class="mcaa-head"><div><h3>Coupons on the account page</h3><div class="mcaa-muted">Show a coupon to every customer, or give one to a single customer as a personal gift. Treasure Hunt prizes appear by themselves.</div></div>';
		h += B.links && B.links.coupons ? '<a class="mcaa-btn" href="' + esc(B.links.coupons) + '" target="_blank" rel="noopener">Create a coupon ›</a>' : '';
		h += '</div>';
		if (!S.coupons.length) {
			h += '<p class="mcaa-muted">No coupons chosen yet.</p>';
		} else {
			h += '<table class="mcaa-t"><thead><tr><th>Code</th><th>Coupon</th><th>Shown to</th><th>Label</th><th>Valid until</th><th></th></tr></thead><tbody>';
			S.coupons.forEach(function (x) {
				h += '<tr><td class="mono">' + esc(x.code || '(deleted)') + '</td><td>' + esc(x.name) + (x.status ? '' : ' <span class="mcaa-muted small">(disabled)</span>') + '</td><td>' + (x.customer_id ? esc(x.customer) : '<b>Every customer</b>') + '</td><td>' + esc(x.label || '—') + '</td><td>' + esc(x.until || 'No end date') + '</td>';
				h += '<td style="text-align:right"><button type="button" class="mcaa-btn sm danger" data-rm="' + x.id + '">Remove</button></td></tr>';
			});
			h += '</tbody></table>';
		}
		h += '<div class="mcaa-add">';
		h += '<div class="f mcaa-pick"><span>Coupon</span>' + (S.pickCoupon ? '<span class="mcaa-chosen"><span class="mono">' + esc(S.pickCoupon.code) + '</span> ' + esc(S.pickCoupon.name) + '<button type="button" data-clear="coupon" aria-label="Clear">×</button></span>' : '<input type="text" id="mcaa-cq" placeholder="Search by code or name" autocomplete="off"><div class="mcaa-list" id="mcaa-cl" hidden></div>') + '</div>';
		h += '<div class="f mcaa-pick"><span>Customer</span>' + (S.pickCustomer ? '<span class="mcaa-chosen">' + esc(S.pickCustomer.name) + ' &lt;' + esc(S.pickCustomer.email) + '&gt;<button type="button" data-clear="customer" aria-label="Clear">×</button></span>' : '<input type="text" id="mcaa-uq" placeholder="Empty = every customer" autocomplete="off"><div class="mcaa-list" id="mcaa-ul" hidden></div>') + '</div>';
		h += '<label class="f"><span>Label <span class="mcaa-muted">(optional)</span></span><input type="text" id="mcaa-label" maxlength="64" placeholder="e.g. Birthday gift, Winter sale"></label>';
		h += '<div><button type="button" class="mcaa-btn pri" id="mcaa-add">Show this coupon</button><span class="mcaa-status" id="mcaa-ast"></span></div>';
		h += '</div>';
		h += '<p class="mcaa-note" style="margin:14px 0 0">Tip: for a personal gift, create the coupon with "Customer login" on and "Uses per customer" 1, then give it to the customer here.</p>';
		h += '</div>';
		root.innerHTML = h;
		bind();
	}

	function status(id, text, ok) {
		var el = document.getElementById(id);
		if (!el) return;
		el.textContent = text;
		el.className = 'mcaa-status ' + (ok ? 'ok' : 'bad');
		if (ok) setTimeout(function () { if (el.textContent === text) el.textContent = ''; }, 2500);
	}

	function collect() {
		var c = {status: 0, menu: 0, hide_columns: 0, sections: {}, shipped: [], return_done: []};
		root.querySelectorAll('[data-k]').forEach(function (i) { c[i.getAttribute('data-k')] = i.checked ? 1 : 0; });
		root.querySelectorAll('[data-sec]').forEach(function (i) { c.sections[i.getAttribute('data-sec')] = i.checked ? 1 : 0; });
		root.querySelectorAll('[data-multi]').forEach(function (i) { if (i.checked) c[i.getAttribute('data-multi')].push(+i.value); });
		c.accent = document.getElementById('mcaa-accent-t').value.trim();
		c.orders_shown = +document.getElementById('mcaa-orders').value || 5;
		return c;
	}

	function picker(inputId, listId, action, label, onPick) {
		var input = document.getElementById(inputId), list = document.getElementById(listId), timer = null, items = [];
		if (!input) return;
		function show() {
			api(action, {q: input.value}).then(function (d) {
				items = d.items || [];
				list.innerHTML = items.length ? items.map(function (x, i) { return '<button type="button" data-i="' + i + '">' + label(x) + '</button>'; }).join('') : '<div style="padding:8px 10px" class="mcaa-muted">Nothing found</div>';
				list.hidden = false;
			}).catch(function () {});
		}
		input.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(show, 250); });
		input.addEventListener('focus', function () { if (action === 'coupon_search') show(); });
		list.addEventListener('mousedown', function (e) {
			var b = e.target.closest('button[data-i]');
			if (b) { e.preventDefault(); onPick(items[+b.getAttribute('data-i')]); }
		});
		input.addEventListener('blur', function () { setTimeout(function () { list.hidden = true; }, 150); });
	}

	function bind() {
		var accent = document.getElementById('mcaa-accent'), accentT = document.getElementById('mcaa-accent-t');
		accent.addEventListener('input', function () { accentT.value = accent.value.toUpperCase(); });
		accentT.addEventListener('input', function () { if (/^#[0-9a-f]{6}$/i.test(accentT.value)) accent.value = accentT.value; });
		root.querySelectorAll('[data-sw]').forEach(function (b) { b.addEventListener('click', function () { accent.value = b.getAttribute('data-sw'); accentT.value = b.getAttribute('data-sw'); }); });
		root.querySelectorAll('[data-multi]').forEach(function (i) { i.addEventListener('change', function () { i.parentNode.classList.toggle('on', i.checked); }); });

		document.getElementById('mcaa-save').addEventListener('click', function () {
			var c = collect();
			if (!/^#[0-9a-f]{6}$/i.test(c.accent)) { status('mcaa-st', 'The colour must look like #2448C8.', false); return; }
			api('save_settings', c).then(function (d) { S.config = d.config; status('mcaa-st', 'Saved', true); }).catch(function (e) { status('mcaa-st', e.message, false); });
		});

		picker('mcaa-cq', 'mcaa-cl', 'coupon_search', function (x) { return '<span class="mono">' + esc(x.code) + '</span> ' + esc(x.name) + (x.until && x.until !== '0000-00-00' ? ' <span class="mcaa-muted small">until ' + esc(x.until) + '</span>' : ''); }, function (x) { keep(); S.pickCoupon = x; render(); restore(); });
		picker('mcaa-uq', 'mcaa-ul', 'customer_search', function (x) { return esc(x.name) + ' <span class="mcaa-muted">&lt;' + esc(x.email) + '&gt;</span>'; }, function (x) { keep(); S.pickCustomer = x; render(); restore(); });
		root.querySelectorAll('[data-clear]').forEach(function (b) { b.addEventListener('click', function () { keep(); if (b.getAttribute('data-clear') === 'coupon') S.pickCoupon = null; else S.pickCustomer = null; render(); restore(); }); });

		document.getElementById('mcaa-add').addEventListener('click', function () {
			if (!S.pickCoupon) { status('mcaa-ast', 'Choose a coupon first.', false); return; }
			api('add_coupon', {coupon_id: S.pickCoupon.id, customer_id: S.pickCustomer ? S.pickCustomer.id : 0, label: document.getElementById('mcaa-label').value}).then(function (d) {
				keep(); S.coupons = d.coupons; S.pickCoupon = null; S.pickCustomer = null; S.keepLabel = ''; render(); restore(); status('mcaa-ast', 'Added', true);
			}).catch(function (e) { status('mcaa-ast', e.message, false); });
		});
		root.querySelectorAll('[data-rm]').forEach(function (b) {
			b.addEventListener('click', function () {
				api('remove_coupon', {id: +b.getAttribute('data-rm')}).then(function (d) { keep(); S.coupons = d.coupons; render(); restore(); }).catch(function (e) { alert(e.message); });
			});
		});
	}

	// Unsaved settings survive the coupon picker re-rendering the page.
	function keep() {
		S.config = Object.assign({}, S.config, collect());
		var l = document.getElementById('mcaa-label');
		S.keepLabel = l ? l.value : '';
	}

	function restore() {
		var l = document.getElementById('mcaa-label');
		if (l && S.keepLabel) l.value = S.keepLabel;
	}

	api('bootstrap').then(function (d) {
		S.config = d.config; S.statuses = d.statuses; S.rstatuses = d.return_statuses; S.coupons = d.coupons; S.hunt = d.hunt;
		render();
	}).catch(function (e) { root.innerHTML = '<div class="mcaa-card" style="color:#B0362E">' + esc(e.message) + '</div>'; });
})();
