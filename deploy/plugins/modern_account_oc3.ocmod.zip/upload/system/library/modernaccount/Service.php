<?php
/**
 * Modern Customer Account - shared core for OpenCart 3.0.x and 4.0.x / 4.1.x.
 * Reads what OpenCart already stores about a customer (orders, status history, reward points, addresses, wishlist,
 * returns, coupons) and turns it into the data the account dashboard shows. Version differences stay in here;
 * the OpenCart adapters pass links, money and image formatting in as callables.
 */
if (!class_exists('MaService')) {
class MaService {
	private $db;
	private $p;
	private $oc;
	private $config = null;

	public function __construct($db, $prefix, $oc_major) {
		$this->db = $db;
		$this->p = $prefix;
		$this->oc = (int)$oc_major;
	}

	private function e($s) {
		return $this->db->escape((string)$s);
	}

	private function t($name) {
		return '`' . $this->p . 'modern_account_' . $name . '`';
	}

	private function o($name) {
		return '`' . $this->p . $name . '`';
	}

	private function hasTable($name) {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e($this->p . $name) . "'")->num_rows;
	}

	private function hasColumn($table, $col) {
		return (bool)$this->db->query("SHOW COLUMNS FROM " . $this->o($table) . " LIKE '" . $this->e($col) . "'")->num_rows;
	}

	/* ------------------------------------------------ install and settings */

	public function install() {
		$this->ensureTables();
	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS " . $this->t('config'));
		$this->db->query("DROP TABLE IF EXISTS " . $this->t('coupon'));
	}

	public function ensureTables() {
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('config') . " (
			`k` VARCHAR(64) NOT NULL,
			`v` MEDIUMTEXT NOT NULL,
			PRIMARY KEY (`k`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('coupon') . " (
			`id` INT(11) NOT NULL AUTO_INCREMENT,
			`coupon_id` INT(11) NOT NULL,
			`customer_id` INT(11) NOT NULL DEFAULT '0',
			`label` VARCHAR(64) NOT NULL DEFAULT '',
			`date_added` DATETIME NOT NULL,
			PRIMARY KEY (`id`),
			KEY `customer` (`customer_id`),
			KEY `coupon` (`coupon_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	public static function defaults() {
		return array(
			'status'      => 1,
			'accent'      => '#2448C8',
			'menu'        => 1,
			'hide_columns'=> 1,
			'sections'    => array('greeting' => 1, 'tiles' => 1, 'track' => 1, 'coupons' => 1, 'hunt' => 1, 'orders' => 1, 'addresses' => 1, 'checklist' => 1, 'again' => 1),
			'shipped'     => array(3),
			'return_done' => array(3),
			'orders_shown'=> 5
		);
	}

	public function getConfig() {
		if ($this->config !== null) {
			return $this->config;
		}

		$c = self::defaults();

		try {
			foreach ($this->db->query("SELECT k, v FROM " . $this->t('config'))->rows as $r) {
				$v = json_decode($r['v'], true);

				if ($v !== null && array_key_exists($r['k'], $c)) {
					$c[$r['k']] = is_array($c[$r['k']]) && is_array($v) && $r['k'] === 'sections' ? array_merge($c['sections'], $v) : $v;
				}
			}
		} catch (\Throwable $e) {
		}

		return $this->config = $c;
	}

	public function saveConfig(array $in) {
		$d = self::defaults();
		$c = $this->getConfig();

		foreach (array('status', 'menu', 'hide_columns') as $k) {
			if (isset($in[$k])) {
				$c[$k] = $in[$k] ? 1 : 0;
			}
		}

		if (isset($in['accent']) && preg_match('/^#[0-9a-fA-F]{6}$/', (string)$in['accent'])) {
			$c['accent'] = strtoupper($in['accent']);
		}

		if (isset($in['sections']) && is_array($in['sections'])) {
			foreach ($d['sections'] as $k => $v) {
				$c['sections'][$k] = !empty($in['sections'][$k]) ? 1 : 0;
			}
		}

		foreach (array('shipped', 'return_done') as $k) {
			if (isset($in[$k]) && is_array($in[$k])) {
				$c[$k] = array_values(array_unique(array_filter(array_map('intval', $in[$k]))));
			}
		}

		if (isset($in['orders_shown'])) {
			$c['orders_shown'] = max(3, min(10, (int)$in['orders_shown']));
		}

		foreach ($c as $k => $v) {
			$this->db->query("REPLACE INTO " . $this->t('config') . " SET k = '" . $this->e($k) . "', v = '" . $this->e(json_encode($v)) . "'");
		}

		$this->config = null;

		return $this->getConfig();
	}

	private function setting($key, $default = null) {
		$q = $this->db->query("SELECT value, serialized FROM " . $this->o('setting') . " WHERE store_id = '0' AND `key` = '" . $this->e($key) . "'");

		if (!$q->num_rows) {
			return $default;
		}

		if ($q->row['serialized'] || substr((string)$q->row['value'], 0, 1) === '[') {
			$v = json_decode($q->row['value'], true);

			return $v === null ? $default : $v;
		}

		return $q->row['value'];
	}

	/* ------------------------------------------------ order statuses */

	public function statuses($language_id) {
		return array_map(function ($r) { return array('id' => (int)$r['order_status_id'], 'name' => html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8')); },
			$this->db->query("SELECT order_status_id, name FROM " . $this->o('order_status') . " WHERE language_id = '" . (int)$language_id . "' ORDER BY name")->rows);
	}

	public function returnStatuses($language_id) {
		return array_map(function ($r) { return array('id' => (int)$r['return_status_id'], 'name' => html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8')); },
			$this->db->query("SELECT return_status_id, name FROM " . $this->o('return_status') . " WHERE language_id = '" . (int)$language_id . "' ORDER BY name")->rows);
	}

	/** How an order status reads on the dashboard: placed, preparing, shipped, delivered or closed (cancelled, refunded...). */
	public function kinds() {
		$c = $this->getConfig();
		$processing = array_map('intval', (array)$this->setting('config_processing_status', array()));
		$complete = array_map('intval', (array)$this->setting('config_complete_status', array()));
		$first = (int)$this->setting('config_order_status_id', 1);
		$shipped = array_map('intval', $c['shipped']);

		return function ($sid) use ($processing, $complete, $first, $shipped) {
			$sid = (int)$sid;

			if (in_array($sid, $shipped, true)) {
				return 'shipped';
			}

			if (in_array($sid, $complete, true)) {
				return 'delivered';
			}

			if (in_array($sid, $processing, true)) {
				return $sid === $first ? 'placed' : 'preparing';
			}

			return $sid === $first ? 'placed' : 'closed';
		};
	}

	/* ------------------------------------------------ the dashboard */

	/**
	 * Everything the account page shows for one customer.
	 * $ctx: customer_id, language_id, money(callable amount, currency_code, currency_value), link(route, args),
	 * order_link(order_id), product(product_id) -> array|null (name, image, price, href), hunt (array|null).
	 */
	public function dashboard(array $ctx) {
		$cid = (int)$ctx['customer_id'];
		$lid = (int)$ctx['language_id'];
		$c = $this->getConfig();
		$kind = $this->kinds();
		$money = $ctx['money'];

		$cu = $this->db->query("SELECT * FROM " . $this->o('customer') . " WHERE customer_id = '" . $cid . "'")->row;
		$d = array(
			'firstname'  => html_entity_decode((string)(isset($cu['firstname']) ? $cu['firstname'] : ''), ENT_QUOTES, 'UTF-8'),
			'lastname'   => html_entity_decode((string)(isset($cu['lastname']) ? $cu['lastname'] : ''), ENT_QUOTES, 'UTF-8'),
			'since'      => !empty($cu['date_added']) ? substr($cu['date_added'], 0, 10) : '',
			'email'      => (string)(isset($cu['email']) ? $cu['email'] : ''),
			'telephone'  => (string)(isset($cu['telephone']) ? $cu['telephone'] : ''),
			'newsletter' => !empty($cu['newsletter'])
		);

		$names = array();

		foreach ($this->db->query("SELECT order_status_id, name FROM " . $this->o('order_status') . " WHERE language_id = '" . $lid . "'")->rows as $r) {
			$names[(int)$r['order_status_id']] = html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8');
		}

		// Orders
		$d['order_count'] = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->o('order') . " WHERE customer_id = '" . $cid . "' AND order_status_id > '0'")->row['n'];
		$rows = $this->db->query("SELECT order_id, order_status_id, date_added, total, currency_code, currency_value FROM " . $this->o('order') . " WHERE customer_id = '" . $cid . "' AND order_status_id > '0' ORDER BY date_added DESC, order_id DESC LIMIT " . (int)$c['orders_shown'])->rows;
		$d['orders'] = array();
		$d['on_way'] = 0;

		foreach ($rows as $r) {
			$items = $this->db->query("SELECT product_id, name, quantity FROM " . $this->o('order_product') . " WHERE order_id = '" . (int)$r['order_id'] . "' ORDER BY order_product_id")->rows;
			$k = $kind($r['order_status_id']);
			$d['orders'][] = array(
				'id'       => (int)$r['order_id'],
				'date'     => substr($r['date_added'], 0, 10),
				'items'    => array_map(function ($i) { return array('name' => html_entity_decode((string)$i['name'], ENT_QUOTES, 'UTF-8'), 'qty' => (int)$i['quantity'], 'product_id' => (int)$i['product_id']); }, $items),
				'total'    => call_user_func($money, (float)$r['total'], $r['currency_code'], (float)$r['currency_value']),
				'status'   => isset($names[(int)$r['order_status_id']]) ? $names[(int)$r['order_status_id']] : '',
				'kind'     => $k,
				'href'     => call_user_func($ctx['order_link'], (int)$r['order_id'])
			);
		}

		// The order on its way: the newest order not delivered or closed, from the last 60 days.
		$d['track'] = null;
		$recent = $this->db->query("SELECT order_id, order_status_id, date_added FROM " . $this->o('order') . " WHERE customer_id = '" . $cid . "' AND order_status_id > '0' AND date_added > DATE_SUB(NOW(), INTERVAL 60 DAY) ORDER BY date_added DESC, order_id DESC LIMIT 10")->rows;

		foreach ($recent as $r) {
			$k = $kind($r['order_status_id']);

			if (in_array($k, array('placed', 'preparing', 'shipped'), true)) {
				$d['on_way']++;

				if (!$d['track']) {
					$hist = $this->db->query("SELECT order_status_id, date_added FROM " . $this->o('order_history') . " WHERE order_id = '" . (int)$r['order_id'] . "' ORDER BY date_added, order_history_id")->rows;
					$when = array('placed' => substr($r['date_added'], 0, 10));

					foreach ($hist as $h) {
						$hk = $kind($h['order_status_id']);

						if (in_array($hk, array('preparing', 'shipped', 'delivered'), true) && !isset($when[$hk])) {
							$when[$hk] = substr($h['date_added'], 0, 10);
						}
					}

					$items = $this->db->query("SELECT name, quantity FROM " . $this->o('order_product') . " WHERE order_id = '" . (int)$r['order_id'] . "' ORDER BY order_product_id LIMIT 4")->rows;
					$d['track'] = array(
						'id'     => (int)$r['order_id'],
						'kind'   => $k,
						'status' => isset($names[(int)$r['order_status_id']]) ? $names[(int)$r['order_status_id']] : '',
						'when'   => $when,
						'items'  => array_map(function ($i) { return html_entity_decode((string)$i['name'], ENT_QUOTES, 'UTF-8') . ((int)$i['quantity'] > 1 ? ' ×' . (int)$i['quantity'] : ''); }, $items),
						'href'   => call_user_func($ctx['order_link'], (int)$r['order_id'])
					);
				}
			}
		}

		// Reward points
		$d['reward_on'] = (bool)$this->setting('total_reward_status', 0);
		$d['points'] = $this->hasTable('customer_reward') ? (int)$this->db->query("SELECT COALESCE(SUM(points), 0) n FROM " . $this->o('customer_reward') . " WHERE customer_id = '" . $cid . "'")->row['n'] : 0;

		// Wishlist, and how many of those are on special today
		$d['wishlist'] = 0;
		$d['wishlist_sale'] = 0;

		if ($this->hasTable('customer_wishlist')) {
			$d['wishlist'] = (int)$this->db->query("SELECT COUNT(DISTINCT product_id) n FROM " . $this->o('customer_wishlist') . " WHERE customer_id = '" . $cid . "'")->row['n'];

			if ($d['wishlist']) {
				// OpenCart 4.1 keeps specials in product_discount (special = 1); earlier versions in product_special.
				$sp = $this->hasTable('product_special') ? $this->o('product_special') . " ps ON ps.product_id = w.product_id" : $this->o('product_discount') . " ps ON ps.product_id = w.product_id AND ps.special = '1'";
				$d['wishlist_sale'] = (int)$this->db->query("SELECT COUNT(DISTINCT w.product_id) n FROM " . $this->o('customer_wishlist') . " w JOIN " . $sp . "
					WHERE w.customer_id = '" . $cid . "' AND (ps.date_start = '0000-00-00' OR ps.date_start IS NULL OR ps.date_start <= CURDATE()) AND (ps.date_end = '0000-00-00' OR ps.date_end IS NULL OR ps.date_end >= CURDATE())")->row['n'];
			}
		}

		// Returns still open
		$done = array_map('intval', $c['return_done']);
		$d['returns_open'] = 0;
		$d['return_status'] = '';

		if ($this->hasTable('return')) {
			$q = $this->db->query("SELECT r.return_status_id, rs.name FROM " . $this->o('return') . " r LEFT JOIN " . $this->o('return_status') . " rs ON rs.return_status_id = r.return_status_id AND rs.language_id = '" . $lid . "'
				WHERE r.customer_id = '" . $cid . "'" . ($done ? " AND r.return_status_id NOT IN (" . implode(',', $done) . ")" : '') . " ORDER BY r.date_added DESC");
			$d['returns_open'] = $q->num_rows;
			$d['return_status'] = $q->num_rows ? html_entity_decode((string)$q->row['name'], ENT_QUOTES, 'UTF-8') : '';
		}

		// Addresses, the default one first
		$def = 0;

		if ($this->hasColumn('address', 'default')) {
			$q = $this->db->query("SELECT address_id FROM " . $this->o('address') . " WHERE customer_id = '" . $cid . "' AND `default` = '1' LIMIT 1");
			$def = $q->num_rows ? (int)$q->row['address_id'] : 0;
		} elseif (isset($cu['address_id'])) {
			$def = (int)$cu['address_id'];
		}

		$d['addresses'] = array();
		$ad = $this->db->query("SELECT a.* FROM " . $this->o('address') . " a WHERE a.customer_id = '" . $cid . "' ORDER BY (a.address_id = '" . $def . "') DESC, a.address_id")->rows;
		$d['address_count'] = count($ad);

		foreach (array_slice($ad, 0, 2) as $a) {
			$lines = array_filter(array(trim($a['firstname'] . ' ' . $a['lastname']), $a['company'], $a['address_1'], $a['address_2'], trim($a['postcode'] . ' ' . $a['city'])));
			$d['addresses'][] = array('lines' => array_values(array_map(function ($l) { return html_entity_decode((string)$l, ENT_QUOTES, 'UTF-8'); }, $lines)), 'default' => (int)$a['address_id'] === $def || count($ad) === 1);
		}

		// Coupons: the customer's own (prizes, gifts), coupons the shop shows to everyone, and the ones already used.
		$d['coupons'] = $this->coupons($cid, $ctx);

		// Buy again: what this customer orders most, still for sale
		$d['again'] = array();

		if (!empty($ctx['product'])) {
			$top = $this->db->query("SELECT op.product_id, COUNT(DISTINCT op.order_id) n, MAX(o.date_added) last FROM " . $this->o('order_product') . " op JOIN " . $this->o('order') . " o ON o.order_id = op.order_id
				WHERE o.customer_id = '" . $cid . "' AND o.order_status_id > '0' GROUP BY op.product_id ORDER BY n DESC, last DESC LIMIT 12")->rows;

			foreach ($top as $t) {
				$p = call_user_func($ctx['product'], (int)$t['product_id']);

				if ($p) {
					$d['again'][] = $p + array('times' => (int)$t['n'], 'last' => substr($t['last'], 0, 10));
				}

				if (count($d['again']) >= 4) {
					break;
				}
			}
		}

		// Transactions and subscriptions get a menu entry only when the customer has some.
		$d['transactions'] = $this->hasTable('customer_transaction') ? (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->o('customer_transaction') . " WHERE customer_id = '" . $cid . "'")->row['n'] : 0;
		$d['subscriptions'] = 0;

		if ($this->hasTable('subscription') && $this->hasColumn('subscription', 'customer_id')) {
			$d['subscriptions'] = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->o('subscription') . " WHERE customer_id = '" . $cid . "'")->row['n'];
		} elseif ($this->hasTable('order_recurring')) {
			$d['subscriptions'] = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->o('order_recurring') . " r JOIN " . $this->o('order') . " o ON o.order_id = r.order_id WHERE o.customer_id = '" . $cid . "'")->row['n'];
		}

		$d['hunt'] = isset($ctx['hunt']) ? $ctx['hunt'] : null;

		return $d;
	}

	/** Coupons for the account page, active first. */
	public function coupons($cid, array $ctx) {
		$out = array();
		$seen = array();
		$used = array();

		foreach ($this->db->query("SELECT coupon_id, COUNT(*) n, MAX(order_id) order_id, MAX(date_added) d FROM " . $this->o('coupon_history') . " WHERE customer_id = '" . (int)$cid . "' GROUP BY coupon_id")->rows as $r) {
			$used[(int)$r['coupon_id']] = $r;
		}

		$add = function ($row, $label, $source) use (&$out, &$seen, $used) {
			$id = (int)$row['coupon_id'];

			if (isset($seen[$id])) {
				return;
			}

			$seen[$id] = 1;
			$u = isset($used[$id]) ? $used[$id] : null;
			$expired = $row['date_end'] && $row['date_end'] !== '0000-00-00' && $row['date_end'] < date('Y-m-d');
			$usedUp = $u && (int)$row['uses_customer'] > 0 && (int)$u['n'] >= (int)$row['uses_customer'];

			if ($expired && !$u) {
				return;
			}

			$out[] = array(
				'code'     => (string)$row['code'],
				'label'    => $label,
				'source'   => $source,
				'type'     => (string)$row['type'],
				'discount' => (float)$row['discount'],
				'shipping' => (int)$row['shipping'],
				'total'    => (float)$row['total'],
				'until'    => $row['date_end'] && $row['date_end'] !== '0000-00-00' ? $row['date_end'] : '',
				'active'   => !$expired && !$usedUp && (int)$row['status'] === 1,
				'used'     => $u ? array('order_id' => (int)$u['order_id'], 'date' => substr($u['d'], 0, 10)) : null
			);
		};

		if ($this->hasTable('treasure_hunt_prize')) {
			foreach ($this->db->query("SELECT c.*, p.date_end AS prize_end FROM " . $this->o('treasure_hunt_prize') . " p JOIN " . $this->o('coupon') . " c ON c.coupon_id = p.coupon_id WHERE p.customer_id = '" . (int)$cid . "' ORDER BY p.date_added DESC")->rows as $r) {
				$add($r, '', 'hunt');
			}
		}

		foreach ($this->db->query("SELECT c.*, m.label, m.customer_id AS for_customer FROM " . $this->t('coupon') . " m JOIN " . $this->o('coupon') . " c ON c.coupon_id = m.coupon_id
			WHERE m.customer_id IN ('0', '" . (int)$cid . "') AND c.status = '1' AND (c.date_start = '0000-00-00' OR c.date_start <= CURDATE()) ORDER BY m.customer_id DESC, m.id DESC")->rows as $r) {
			$add($r, html_entity_decode((string)$r['label'], ENT_QUOTES, 'UTF-8'), (int)$r['for_customer'] ? 'gift' : 'shop');
		}

		// Other coupons this customer used at checkout, newest first, as history.
		if ($used) {
			$ids = array_diff(array_keys($used), array_keys($seen));

			if ($ids) {
				foreach ($this->db->query("SELECT * FROM " . $this->o('coupon') . " WHERE coupon_id IN (" . implode(',', array_map('intval', $ids)) . ")")->rows as $r) {
					$add($r, '', 'used');
				}
			}
		}

		usort($out, function ($a, $b) {
			if ($a['active'] !== $b['active']) {
				return $a['active'] ? -1 : 1;
			}

			return strcmp($b['until'] . ($b['used'] ? $b['used']['date'] : ''), $a['until'] . ($a['used'] ? $a['used']['date'] : ''));
		});
		$active = array_values(array_filter($out, function ($x) { return $x['active']; }));
		$old = array_slice(array_values(array_filter($out, function ($x) { return !$x['active']; })), 0, 2);

		return array_merge(array_slice($active, 0, 6), $old);
	}

	/* ------------------------------------------------ admin: coupons shown on the account page */

	public function shownCoupons() {
		// Coupons deleted in Marketing > Coupons leave the list too.
		$this->db->query("DELETE m FROM " . $this->t('coupon') . " m LEFT JOIN " . $this->o('coupon') . " c ON c.coupon_id = m.coupon_id WHERE c.coupon_id IS NULL");
		$rows = $this->db->query("SELECT m.id, m.coupon_id, m.customer_id, m.label, c.code, c.name, c.date_end, c.status, cu.firstname, cu.lastname, cu.email FROM " . $this->t('coupon') . " m
			LEFT JOIN " . $this->o('coupon') . " c ON c.coupon_id = m.coupon_id LEFT JOIN " . $this->o('customer') . " cu ON cu.customer_id = m.customer_id ORDER BY m.id DESC")->rows;

		return array_map(function ($r) {
			return array(
				'id' => (int)$r['id'], 'coupon_id' => (int)$r['coupon_id'], 'code' => (string)$r['code'], 'name' => html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8'),
				'until' => $r['date_end'] && $r['date_end'] !== '0000-00-00' ? $r['date_end'] : '', 'status' => (int)$r['status'], 'label' => html_entity_decode((string)$r['label'], ENT_QUOTES, 'UTF-8'),
				'customer_id' => (int)$r['customer_id'], 'customer' => (int)$r['customer_id'] ? trim(html_entity_decode($r['firstname'] . ' ' . $r['lastname'], ENT_QUOTES, 'UTF-8')) . ' <' . $r['email'] . '>' : ''
			);
		}, $rows);
	}

	public function searchCoupons($q) {
		$q = trim((string)$q);
		$rows = $this->db->query("SELECT coupon_id, code, name, date_end FROM " . $this->o('coupon') . ($q !== '' ? " WHERE code LIKE '%" . $this->e($q) . "%' OR name LIKE '%" . $this->e($q) . "%'" : '') . " ORDER BY coupon_id DESC LIMIT 15")->rows;

		return array_map(function ($r) { return array('id' => (int)$r['coupon_id'], 'code' => (string)$r['code'], 'name' => html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8'), 'until' => $r['date_end']); }, $rows);
	}

	public function searchCustomers($q) {
		$q = trim((string)$q);

		if (mb_strlen($q) < 2) {
			return array();
		}

		$rows = $this->db->query("SELECT customer_id, firstname, lastname, email FROM " . $this->o('customer') . " WHERE email LIKE '%" . $this->e($q) . "%' OR CONCAT(firstname, ' ', lastname) LIKE '%" . $this->e($q) . "%' ORDER BY customer_id DESC LIMIT 15")->rows;

		return array_map(function ($r) { return array('id' => (int)$r['customer_id'], 'name' => trim(html_entity_decode($r['firstname'] . ' ' . $r['lastname'], ENT_QUOTES, 'UTF-8')), 'email' => (string)$r['email']); }, $rows);
	}

	public function addCoupon(array $in) {
		$coupon_id = isset($in['coupon_id']) ? (int)$in['coupon_id'] : 0;
		$customer_id = isset($in['customer_id']) ? (int)$in['customer_id'] : 0;
		$label = isset($in['label']) ? mb_substr(trim((string)$in['label']), 0, 64) : '';

		if (!$coupon_id || !$this->db->query("SELECT coupon_id FROM " . $this->o('coupon') . " WHERE coupon_id = '" . $coupon_id . "'")->num_rows) {
			throw new Exception('Choose a coupon first.');
		}

		if ($customer_id && !$this->db->query("SELECT customer_id FROM " . $this->o('customer') . " WHERE customer_id = '" . $customer_id . "'")->num_rows) {
			throw new Exception('That customer was not found.');
		}

		$this->db->query("DELETE FROM " . $this->t('coupon') . " WHERE coupon_id = '" . $coupon_id . "' AND customer_id = '" . $customer_id . "'");
		$this->db->query("INSERT INTO " . $this->t('coupon') . " SET coupon_id = '" . $coupon_id . "', customer_id = '" . $customer_id . "', label = '" . $this->e($label) . "', date_added = NOW()");

		return $this->shownCoupons();
	}

	public function removeCoupon($id) {
		$this->db->query("DELETE FROM " . $this->t('coupon') . " WHERE id = '" . (int)$id . "'");

		return $this->shownCoupons();
	}

	public function languageId() {
		$code = $this->setting('config_admin_language', 'en-gb');
		$q = $this->db->query("SELECT language_id FROM " . $this->o('language') . " WHERE code = '" . $this->e($code) . "'");

		return $q->num_rows ? (int)$q->row['language_id'] : 1;
	}

	public function bootstrap() {
		$lid = $this->languageId();

		return array(
			'config'          => $this->getConfig(),
			'statuses'        => $this->statuses($lid),
			'return_statuses' => $this->returnStatuses($lid),
			'coupons'         => $this->shownCoupons(),
			'hunt'            => $this->hasTable('treasure_hunt_campaign')
		);
	}
}
}
