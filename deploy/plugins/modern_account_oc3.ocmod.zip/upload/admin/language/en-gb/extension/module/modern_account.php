<?php
$_['heading_title'] = 'Modern Customer Account';
$_['text_home']     = 'Home';
