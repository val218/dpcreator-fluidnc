<?php
/**
 * Modern Customer Account for OpenCart 3.0.x - thin adapter around the shared core in system/library/modernaccount.
 * No core or theme files are modified: the account page is changed with OpenCart events.
 */
class ControllerExtensionModuleModernAccount extends Controller {
	const ROUTE = 'extension/module/modern_account';
	const CODE = 'modern_account';

	private function core() {
		require_once(DIR_SYSTEM . 'library/modernaccount/Service.php');
		require_once(DIR_SYSTEM . 'library/modernaccount/Ui.php');

		return new MaService($this->db, DB_PREFIX, 3);
	}

	public function index() {
		$this->load->language(self::ROUTE);
		$this->document->setTitle($this->language->get('heading_title'));
		$t = 'user_token=' . $this->session->data['user_token'];

		$data['heading_title'] = $this->language->get('heading_title');
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $t, true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link(self::ROUTE, $t, true))
		);
		$this->core()->ensureTables();
		$this->ensureEvents();
		$api = html_entity_decode($this->url->link(self::ROUTE . '/api', $t, true), ENT_QUOTES, 'UTF-8');
		$data['body'] = MaUi::page($api, 3, array('coupons' => html_entity_decode($this->url->link('marketing/coupon', $t, true), ENT_QUOTES, 'UTF-8')));
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	public function api() {
		$service = $this->core();
		$user = $this->user;
		$action = isset($this->request->get['action']) ? preg_replace('/[^a-z_]/', '', $this->request->get['action']) : '';
		$json = MaUi::api($service, $action, function ($perm) use ($user) {
			return $user->hasPermission($perm, ControllerExtensionModuleModernAccount::ROUTE);
		});

		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput($json);
	}

	private function events() {
		return array(
			array('admin/view/common/column_left/before', self::ROUTE . '/eventMenu'),
			array('catalog/view/account/account/before', self::ROUTE . '/eventColumns'),
			array('catalog/view/account/account/after', self::ROUTE . '/eventPage')
		);
	}

	public function install() {
		$this->core()->install();
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `key` = 'module_modern_account_status'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = '0', `code` = 'module_modern_account', `key` = 'module_modern_account_status', `value` = '1', serialized = '0'");
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);

		foreach ($this->events() as $e) {
			$this->model_setting_event->addEvent(self::CODE, $e[0], $e[1]);
		}
	}

	private function ensureEvents() {
		$have = array_column($this->db->query("SELECT `trigger` FROM `" . DB_PREFIX . "event` WHERE `code` = '" . self::CODE . "'")->rows, 'trigger');
		$this->load->model('setting/event');

		foreach ($this->events() as $e) {
			if (!in_array($e[0], $have, true)) {
				$this->model_setting_event->addEvent(self::CODE, $e[0], $e[1]);
			}
		}
	}

	public function uninstall() {
		$this->core()->uninstall();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
	}

	public function eventMenu(&$route, &$data) {
		if (empty($data['menus']) || !$this->user->hasPermission('access', self::ROUTE)) {
			return;
		}

		$item = array('name' => 'Modern Customer Account', 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true), 'children' => array());

		foreach (array('menu-customer', 'menu-design') as $want) {
			foreach ($data['menus'] as &$menu) {
				if (isset($menu['id']) && $menu['id'] === $want) {
					$menu['children'][] = $item;

					return;
				}
			}

			unset($menu);
		}

		$data['menus'][] = array('id' => 'menu-modern-account', 'icon' => 'fa-user', 'name' => 'Modern Customer Account', 'href' => $item['href'], 'children' => array());
	}
}
