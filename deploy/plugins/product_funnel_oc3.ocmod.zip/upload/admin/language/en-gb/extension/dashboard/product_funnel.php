<?php
$_['heading_title']    = 'Product Funnel: drop-off flags';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: you have modified the Product Funnel dashboard widget!';
$_['text_edit']        = 'Edit Product Funnel dashboard widget';
$_['entry_width']      = 'Width';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify the Product Funnel dashboard widget!';
