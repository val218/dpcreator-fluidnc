<?php
$_['heading_title'] = 'Product Funnel: where shoppers drop off, product by product';
$_['text_menu']     = 'Product Funnel';
$_['text_home']     = 'Home';
