<?php
/**
 * Product Funnel for OpenCart 3.0.x - thin adapter around the shared core in system/library/productfunnel.
 * No core or theme files are modified: the shop side is hooked in with OpenCart events.
 */
class ControllerExtensionModuleProductFunnel extends Controller {
	const ROUTE = 'extension/module/product_funnel';
	const DASH = 'extension/dashboard/product_funnel';
	const CODE = 'product_funnel';

	private function core() {
		require_once(DIR_SYSTEM . 'library/productfunnel/Service.php');
		require_once(DIR_SYSTEM . 'library/productfunnel/Ui.php');

		return new PfnService($this->db, DB_PREFIX, 3);
	}

	public function index() {
		$this->load->language(self::ROUTE);
		$this->document->setTitle($this->language->get('heading_title'));
		$t = 'user_token=' . $this->session->data['user_token'];

		$data['heading_title'] = $this->language->get('heading_title');
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $t, true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link(self::ROUTE, $t, true))
		);
		$this->core()->ensureTables();
		$this->ensureEvents();
		$links = array('product' => html_entity_decode($this->url->link('catalog/product/edit', $t . '&product_id=PFNID', true), ENT_QUOTES, 'UTF-8'));
		$api = html_entity_decode($this->url->link(self::ROUTE . '/api', $t, true), ENT_QUOTES, 'UTF-8');
		$data['body'] = PfnUi::page($api, 3, $links);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	public function api() {
		$service = $this->core();
		$user = $this->user;
		$action = isset($this->request->get['action']) ? preg_replace('/[^a-z_]/', '', $this->request->get['action']) : '';
		$json = PfnUi::api($service, $action, function ($perm) use ($user) {
			return $user->hasPermission($perm, ControllerExtensionModuleProductFunnel::ROUTE);
		});

		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput($json);
	}

	private function events() {
		return array(
			array('admin/view/common/column_left/before', self::ROUTE . '/eventMenu'),
			array('catalog/controller/product/product/before', self::ROUTE . '/eventRaw'),
			array('catalog/view/product/product/after', self::ROUTE . '/eventScript'),
			array('catalog/controller/checkout/cart/add/after', self::ROUTE . '/eventAdded'),
			array('catalog/controller/checkout/cart/remove/before', self::ROUTE . '/eventRemove')
		);
	}

	public function install() {
		$this->core()->install();
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `key` = 'module_product_funnel_status'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = '0', `code` = 'module_product_funnel', `key` = 'module_product_funnel_status', `value` = '1', serialized = '0'");

		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);

		foreach ($this->events() as $e) {
			$this->model_setting_event->addEvent(self::CODE, $e[0], $e[1]);
		}

		$this->installWidget();
	}

	/** Also switch on the dashboard widget, so the flags show on the admin home page straight away. */
	private function installWidget() {
		try {
			$have = $this->db->query("SELECT extension_id FROM `" . DB_PREFIX . "extension` WHERE `type` = 'dashboard' AND `code` = 'product_funnel'");

			if (!$have->num_rows) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "extension` SET `type` = 'dashboard', `code` = 'product_funnel'");
			}

			$this->load->model('user/user_group');
			$gid = (int)$this->user->getGroupId();

			foreach (array('access', 'modify') as $type) {
				$this->model_user_user_group->removePermission($gid, $type, self::DASH);
				$this->model_user_user_group->addPermission($gid, $type, self::DASH);
			}

			if (!$this->db->query("SELECT setting_id FROM `" . DB_PREFIX . "setting` WHERE store_id = '0' AND `key` = 'dashboard_product_funnel_width'")->num_rows) {
				$this->load->model('setting/setting');
				$this->model_setting_setting->editSetting('dashboard_product_funnel', array('dashboard_product_funnel_width' => 6, 'dashboard_product_funnel_status' => 1, 'dashboard_product_funnel_sort_order' => 3));
			}
		} catch (Exception $e) {
		}
	}

	private function ensureEvents() {
		$have = array_column($this->db->query("SELECT `trigger` FROM `" . DB_PREFIX . "event` WHERE `code` = '" . self::CODE . "'")->rows, 'trigger');
		$this->load->model('setting/event');

		foreach ($this->events() as $e) {
			if (!in_array($e[0], $have, true)) {
				$this->model_setting_event->addEvent(self::CODE, $e[0], $e[1]);
			}
		}
	}

	public function uninstall() {
		$this->core()->uninstall();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
		$this->db->query("DELETE FROM `" . DB_PREFIX . "extension` WHERE `type` = 'dashboard' AND `code` = 'product_funnel'");
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'dashboard_product_funnel'");
	}

	public function eventMenu(&$route, &$data) {
		// The shop owner's own visits are not counted: mark this browser for the shop side.
		if (!headers_sent() && !isset($this->request->cookie['pfn_staff'])) {
			if (PHP_VERSION_ID >= 70300) {
				setcookie('pfn_staff', '1', array('expires' => time() + 86400 * 365, 'path' => '/', 'samesite' => 'Lax', 'httponly' => true));
			} else {
				setcookie('pfn_staff', '1', time() + 86400 * 365, '/; samesite=Lax', '', false, true);
			}
		}

		if (empty($data['menus']) || !$this->user->hasPermission('access', self::ROUTE)) {
			return;
		}

		$item = array('name' => 'Product Funnel', 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true), 'children' => array());

		foreach (array('menu-report', 'menu-marketing') as $want) {
			foreach ($data['menus'] as &$menu) {
				if (isset($menu['id']) && $menu['id'] === $want) {
					$menu['children'][] = $item;

					return;
				}
			}

			unset($menu);
		}

		$data['menus'][] = array('id' => 'menu-product-funnel', 'icon' => 'fa-filter', 'name' => 'Product Funnel', 'href' => $item['href'], 'children' => array());
	}
}
