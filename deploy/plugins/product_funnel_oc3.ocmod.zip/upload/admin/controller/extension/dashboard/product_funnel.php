<?php
/**
 * Product Funnel dashboard widget for OpenCart 3.0.x: the top drop-off flags.
 */
class ControllerExtensionDashboardProductFunnel extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/product_funnel');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');

		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
			$this->model_setting_setting->editSetting('dashboard_product_funnel', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/product_funnel', 'user_token=' . $this->session->data['user_token'], true))
		);
		$data['action'] = $this->url->link('extension/dashboard/product_funnel', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		foreach (array('width' => 6, 'status' => 1, 'sort_order' => 3) as $key => $default) {
			$name = 'dashboard_product_funnel_' . $key;

			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}

		$data['columns'] = range(3, 12);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/dashboard/product_funnel_form', $data));
	}

	public function install() {
		$this->load->model('setting/setting');

		if ((string)$this->config->get('dashboard_product_funnel_width') === '') {
			$this->model_setting_setting->editSetting('dashboard_product_funnel', array('dashboard_product_funnel_width' => 6, 'dashboard_product_funnel_status' => 1, 'dashboard_product_funnel_sort_order' => 3));
		}
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/product_funnel')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function dashboard() {
		require_once(DIR_SYSTEM . 'library/productfunnel/Service.php');
		require_once(DIR_SYSTEM . 'library/productfunnel/Ui.php');

		try {
			$s = new PfnService($this->db, DB_PREFIX, 3);
			$page = html_entity_decode($this->url->link('extension/module/product_funnel', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');

			return PfnUi::widget($s, $page, $page . '&pfn_product=PFNID', 3);
		} catch (Exception $e) {
			return '';
		}
	}
}
