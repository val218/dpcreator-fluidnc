/* Product Funnel - product page script. Sends nothing until the visitor moves, scrolls, touches or types; then one
   "view", and on leaving the active seconds and how far they read. No cookies, no IDs, no third parties. */
(function () {
	try {
		var C = window.PFN;
		if (!C || !C.u || !C.p || window.__pfnOn || navigator.webdriver) return;
		window.__pfnOn = 1;

		var viewSent = 0, lastAct = 0, active = 0, sentTime = 0, leaves = 0, flags = {}, sent = {}, seenAt = 0;

		function post(d) {
			try {
				var f = new FormData();
				d.p = C.p;
				for (var k in d) f.append(k, d[k]);
				if (navigator.sendBeacon && navigator.sendBeacon(C.u, f)) return;
				fetch(C.u, {method: 'POST', body: f, credentials: 'same-origin', keepalive: true}).catch(function () {});
			} catch (e) {}
		}

		function q(sel) {
			try {
				var list = document.querySelectorAll(sel || '');
				for (var i = 0; i < list.length; i++) if (list[i].textContent.replace(/\s+/g, '').length > 20 || list[i].querySelector('img,table')) return list[i];
				return list[0] || null;
			} catch (e) { return null; }
		}

		function shown(el) {
			if (!el) return null;
			var r = el.getBoundingClientRect();
			return r.height > 0 && r.width > 0 ? r : null;
		}

		var desc = q(C.sd);

		function look() {
			var h = window.innerHeight || document.documentElement.clientHeight, r;
			r = shown(desc);
			if (r) {
				if (r.top < h * 0.85 && r.bottom > 0 && !flags.d) { flags.d = 1; seenAt = active; }
				// Read to the end: the end of the description came into view and they spent a few seconds since it appeared.
				if (flags.d && r.bottom <= h + 8 && active - seenAt >= 5) flags.r = 1;
			}
			r = shown(q(C.ss));
			if (r && r.top < h * 0.85 && r.bottom > 0 && scrolled) flags.s = 1;
			r = shown(q(C.sr));
			if (r && r.top < h * 0.85 && r.bottom > 0 && scrolled) flags.w = 1;
		}

		var scrolled = 0;

		function act(e) {
			lastAct = Date.now();
			if (e && (e.type === 'scroll' || e.type === 'wheel' || e.type === 'touchmove')) scrolled = 1;
			if (!viewSent) { viewSent = 1; post({e: 'v'}); }
		}

		['mousemove', 'pointerdown', 'touchstart', 'touchmove', 'keydown', 'wheel', 'scroll'].forEach(function (n) {
			addEventListener(n, act, {capture: true, passive: true});
		});

		// Tabs and photos opened by a click.
		document.addEventListener('click', function (e) {
			var a = e.target && e.target.closest ? e.target.closest('a,button,img') : null;
			if (!a) return;
			var href = (a.getAttribute('href') || a.getAttribute('data-bs-target') || a.getAttribute('data-target') || '').toLowerCase();
			if (/specification|attribute/.test(href)) flags.s = 1;
			if (/review/.test(href)) flags.w = 1;
			if (/\.(jpe?g|png|webp|gif|avif)(\?|$)/.test(href) || a.closest('.thumbnails,.image-additional,.product-gallery,[class*="gallery"],[class*="thumb"],[data-bs-toggle="lightbox"],.magnific-popup')) flags.g = 1;
			for (var k in flags) if (!sent[k]) { setTimeout(flush, 300); break; }
		}, true);

		// Active time: a visible tab with a move, scroll, touch or key in the last 30 seconds.
		setInterval(function () {
			if (!viewSent || document.visibilityState !== 'visible' || Date.now() - lastAct > 30000) return;
			active++;
			if (active % 2 === 0) look();
			// Every 15 active seconds, so the time is not lost when a phone closes the tab without a goodbye.
			if (active - sentTime >= 15) flush();
		}, 1000);

		function flush() {
			if (!viewSent) return;
			look();
			var d = {e: 'l', t: Math.min(1800, active - sentTime), f: leaves ? 0 : 1};
			var any = 0;
			for (var k in flags) if (!sent[k]) { d[k] = 1; sent[k] = 1; any = 1; }
			if (leaves && !d.t && !any) return;
			sentTime = active;
			leaves++;
			post(d);
		}

		document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
		addEventListener('pagehide', flush);
	} catch (e) {}
})();
