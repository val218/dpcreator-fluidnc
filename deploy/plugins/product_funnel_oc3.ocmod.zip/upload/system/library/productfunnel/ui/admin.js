/* Product Funnel - admin page */
(function () {
	'use strict';
	var B = window.PFN_ADMIN || {};
	var root = document.getElementById('pfn-root');
	if (!root) return;

	var S = {tab: 'flags', days: 30, report: null, cfg: null, defaults: null, sort: 'visitors', dir: -1, search: '', detail: null, filter: ''};

	function esc(s) {
		return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
			return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c];
		});
	}

	function api(action, body) {
		var url = B.api + (B.api.indexOf('?') < 0 ? '?' : '&') + 'action=' + encodeURIComponent(action);
		return fetch(url, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})})
			.then(function (r) { return r.text(); })
			.then(function (t) {
				var j;
				try { j = JSON.parse(t); } catch (e) { throw new Error('The server answered with something that is not JSON: ' + t.replace(/<[^>]+>/g, ' ').slice(0, 200)); }
				if (j.error) throw new Error(j.error);
				return j.data;
			});
	}

	function toast(msg, bad) {
		var t = document.createElement('div');
		t.className = 'pfn-toast' + (bad ? ' bad' : '');
		t.textContent = msg;
		root.appendChild(t);
		setTimeout(function () { t.remove(); }, bad ? 6000 : 2600);
	}

	function n(v) { return v === null || v === undefined ? '–' : Number(v).toLocaleString(); }
	function p(v) { return v === null || v === undefined ? '–' : (v >= 10 || v === Math.round(v) ? Math.round(v) : v.toFixed(1)) + '%'; }
	function secs(v) {
		if (v === null || v === undefined) return '–';
		return v < 60 ? v + ' s' : Math.floor(v / 60) + ' min ' + (v % 60 ? (v % 60) + ' s' : '');
	}
	function money(v) {
		var c = S.report && S.report.currency || {left: '', right: '', decimals: 2};
		return c.left + Number(v || 0).toFixed(c.decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + c.right;
	}
	function editLink(id) { return B.links && B.links.product ? B.links.product.replace('PFNID', id) : '#'; }

	var TYPES = {
		first_look: ['Leave at first sight', 'bad'],
		doubt: ['Interested, but in doubt', 'bad'],
		low_add: ['Few add to cart', 'warn'],
		cart_drop: ['Added, then dropped', 'bad'],
		hidden_gem: ['Hard to find', 'good']
	};

	/* ---------------------------------------------- frame */

	function frame(body) {
		var tabs = [['flags', 'Flags' + (S.report && S.report.flags.length ? ' <span class="n">' + S.report.flags.filter(function (f) { return f.level !== 'good'; }).length + '</span>' : '')], ['products', 'Products'], ['settings', 'Settings']];
		var h = '<div class="pfn-top"><div class="tabs">';
		tabs.forEach(function (t) { h += '<button data-tab="' + t[0] + '" class="' + (S.tab === t[0] && !S.detail ? 'on' : '') + '">' + t[1] + '</button>'; });
		h += '</div>';
		if (S.tab !== 'settings' || S.detail) {
			h += '<div class="period">';
			[7, 30, 90].forEach(function (d) { h += '<button data-days="' + d + '" class="' + (S.days === d ? 'on' : '') + '">' + d + ' days</button>'; });
			h += '</div>';
		}
		root.innerHTML = h + '</div><div class="pfn-body">' + body + '</div>';
	}

	function render() {
		if (S.detail) return renderDetail();
		if (S.tab === 'settings') return renderSettings();
		if (!S.report) { frame('<div class="pfn-loading">Loading…</div>'); return; }
		if (S.tab === 'products') return renderProducts();
		renderFlags();
	}

	/* ---------------------------------------------- overview + flags */

	function change(now, before) {
		if (now === null || before === null || before === undefined || !S.report.prev.visitors) return '';
		var d = now - before;
		if (Math.abs(d) < 0.05) return '';
		return '<i class="' + (d > 0 ? 'up' : 'down') + '">' + (d > 0 ? '▲' : '▼') + ' ' + Math.abs(d).toFixed(1) + ' pts</i>';
	}

	function overview() {
		var b = S.report.base, pv = S.report.prev;
		var steps = [
			['Real visitors', b.visitors, null, 'People on product pages, each counted once per product a day. Bots, the shop staff and scripts are left out.'],
			['Saw the description', b.desc_seen, b.seen_rate, 'Scrolled down to the description (share of product views).'],
			['Added to cart', b.add_visitors, b.add_rate, 'Visitors who added the product to the cart.'],
			['Started checkout', b.checkouts, b.visitors ? Math.min(100, 100 * b.checkouts / b.visitors) : null, 'Orders created with the product, paid or not (unfinished ones are "missing orders").'],
			['Bought', b.orders, b.buy_rate, 'Orders with the product in a processing or complete status.']
		];
		var max = Math.max(1, b.visitors);
		var h = '<div class="pfn-card"><div class="funnel">';
		steps.forEach(function (s, i) {
			var w = Math.max(2, Math.min(100, 100 * (s[1] || 0) / max));
			var prevRate = [null, pv.seen_rate, pv.add_rate, pv.visitors ? 100 * pv.checkouts / pv.visitors : null, pv.buy_rate][i];
			h += '<div class="step" title="' + esc(s[3]) + '"><div class="lbl">' + s[0] + '</div><div class="bar"><i style="width:' + w + '%"></i></div>'
				+ '<div class="val"><b>' + n(s[1]) + '</b>' + (s[2] !== null ? ' <span>' + p(s[2]) + '</span>' + change(s[2], prevRate) : '') + '</div></div>';
		});
		h += '</div>';
		var bots = b.raw > b.views ? Math.round(100 * (b.raw - b.views) / b.raw) : null;
		h += '<div class="facts">';
		h += '<div><b>' + secs(b.avg_time) + '</b><span>average active time on a product page</span></div>';
		h += '<div><b>' + money(b.revenue) + '</b><span>sales of these products</span></div>';
		if (bots !== null && b.raw >= 20) h += '<div><b>' + bots + '%</b><span>of product page requests were bots or scripts: ' + n(b.raw) + ' requests, ' + n(b.views) + ' by people. OpenCart\'s own "Products Viewed" report counts them all.</span></div>';
		if (b.hunt_visitors) h += '<div><b>' + n(b.hunt_visitors) + '</b><span>visits by Treasure Hunt players, counted apart and left out of the funnel (' + n(b.hunt_adds) + ' of their add-to-carts).</span></div>';
		h += '</div></div>';
		return h;
	}

	function flagCard(f, inDetail) {
		var h = '<div class="flag ' + f.level + '"><div class="fh"><span class="pill ' + f.level + '">' + esc(f.title) + '</span>'
			+ (inDetail ? '' : '<button class="pfn-btn sm" data-open="' + f.product_id + '">Product details</button>'
			+ '<a class="pfn-btn sm" target="_blank" href="' + esc(editLink(f.product_id)) + '">Edit product</a>') + '</div>'
			+ '<p>' + esc(f.text) + '</p>';
		if (f.fixes && f.fixes.length) {
			h += '<div class="fixes"><b>' + (f.level === 'good' ? 'Do this' : 'Fix') + '</b><ul>';
			f.fixes.forEach(function (x) { h += '<li>' + esc(x) + '</li>'; });
			h += '</ul></div>';
		}
		return h + '</div>';
	}

	function renderFlags() {
		var r = S.report;
		var h = overview();
		var counts = {};
		r.flags.forEach(function (f) { counts[f.type] = (counts[f.type] || 0) + 1; });
		h += '<div class="pfn-filters"><button data-filter="" class="' + (!S.filter ? 'on' : '') + '">All ' + r.flags.length + '</button>';
		Object.keys(TYPES).forEach(function (k) {
			if (counts[k]) h += '<button data-filter="' + k + '" class="' + (S.filter === k ? 'on' : '') + '"><i class="dot ' + TYPES[k][1] + '"></i>' + TYPES[k][0] + ' ' + counts[k] + '</button>';
		});
		h += '</div>';
		var list = r.flags.filter(function (f) { return !S.filter || f.type === S.filter; });
		if (!list.length) {
			h += '<div class="pfn-card empty">';
			if (!r.base.visitors) {
				h += '<h4>Counting has started</h4><p>Product Funnel counts people from now on' + (r.tracking ? '' : ' <b>once you switch counting on in Settings</b>') + '. Flags appear once a product has ' + r.min_visitors + ' real visitors in the period (change it in Settings). Orders are already counted from your order history.</p>';
			} else {
				h += '<h4>No drop-off patterns found</h4><p>No product with at least ' + r.min_visitors + ' real visitors in the last ' + r.days + ' days falls clearly below the shop average. Check again when more visitors have come, or lower the minimum in Settings.</p>';
			}
			h += '</div>';
		}
		list.forEach(function (f) { h += flagCard(f); });
		if (r.unseen) h += '<p class="muted note">' + n(r.unseen) + ' enabled products had no real visitors in the last ' + r.days + ' days. If they matter, link to them from the menu, the home page or related products.</p>';
		frame(h);
	}

	/* ---------------------------------------------- products table */

	var COLS = [
		['name', 'Product', 0],
		['visitors', 'Real visitors', 1],
		['avg_time', 'Active time', 1],
		['read_rate', 'Read description', 1],
		['add_rate', 'Add to cart', 1],
		['removes', 'Removed', 1],
		['checkouts', 'Checkouts', 1],
		['orders', 'Orders', 1],
		['buy_rate', 'Conversion', 1],
		['revenue', 'Sales', 1]
	];

	function renderProducts() {
		var r = S.report, b = r.base;
		var q = S.search.toLowerCase();
		var rows = r.products.filter(function (x) { return !q || (x.name + ' ' + x.model).toLowerCase().indexOf(q) >= 0; });
		rows.sort(function (a, c) {
			var x = a[S.sort], y = c[S.sort];
			if (S.sort === 'name') return S.dir * String(x).localeCompare(String(y));
			x = x === null ? -1 : x; y = y === null ? -1 : y;
			return S.dir * (x - y);
		});
		var h = '<div class="pfn-row"><input type="text" id="pfn-search" placeholder="Find a product" value="' + esc(S.search) + '"><span class="muted">' + rows.length + ' products with visitors or orders in the last ' + r.days + ' days</span></div>';
		h += '<div class="pfn-card flush"><div class="scroll"><table class="pfn-table"><thead><tr>';
		COLS.forEach(function (c) { h += '<th data-sort="' + c[0] + '" class="' + (c[2] ? 'num' : '') + (S.sort === c[0] ? ' on' : '') + '">' + c[1] + (S.sort === c[0] ? (S.dir < 0 ? ' ↓' : ' ↑') : '') + '</th>'; });
		h += '</tr></thead><tbody>';
		h += '<tr class="avg"><td>Shop average</td><td class="num">' + n(b.visitors) + '</td><td class="num">' + secs(b.avg_time) + '</td><td class="num">' + p(b.read_rate) + '</td><td class="num">' + p(b.add_rate) + '</td><td class="num">' + n(b.removes) + '</td><td class="num">' + n(b.checkouts) + '</td><td class="num">' + n(b.orders) + '</td><td class="num">' + p(b.buy_rate) + '</td><td class="num">' + money(b.revenue) + '</td></tr>';
		rows.slice(0, 500).forEach(function (x) {
			var low = b.add_rate && x.add_rate !== null && x.visitors >= r.min_visitors && x.add_rate < 0.6 * b.add_rate;
			h += '<tr data-open="' + x.product_id + '"><td><b>' + esc(x.name) + '</b>' + (x.status ? '' : ' <span class="pill">disabled</span>') + '<div class="tags">';
			x.flags.forEach(function (t) { if (TYPES[t]) h += '<span class="pill ' + TYPES[t][1] + '">' + TYPES[t][0] + '</span>'; });
			h += '</div></td><td class="num">' + n(x.visitors) + '</td><td class="num">' + secs(x.avg_time) + '</td><td class="num">' + p(x.read_rate) + '</td><td class="num' + (low ? ' bad' : '') + '">' + p(x.add_rate) + '</td><td class="num">' + n(x.removes) + '</td><td class="num">' + n(x.checkouts) + '</td><td class="num">' + n(x.orders) + '</td><td class="num">' + p(x.buy_rate) + '</td><td class="num">' + money(x.revenue) + '</td></tr>';
		});
		if (!rows.length) h += '<tr><td colspan="10" class="muted">No products yet.</td></tr>';
		h += '</tbody></table></div></div>';
		frame(h);
		var s = document.getElementById('pfn-search');
		if (s) {
			s.addEventListener('input', function () { S.search = s.value; var pos = s.selectionStart; renderProducts(); var t = document.getElementById('pfn-search'); t.focus(); t.setSelectionRange(pos, pos); });
		}
	}

	/* ---------------------------------------------- product detail */

	function chart(daily) {
		var W = 960, H = 140, pad = 26, max = 1;
		daily.forEach(function (d) { max = Math.max(max, d.visitors, d.adds); });
		var bw = (W - pad) / daily.length;
		var svg = '<svg viewBox="0 0 ' + W + ' ' + (H + 24) + '" class="chart" role="img" aria-label="Real visitors and add to cart per day">';
		svg += '<text x="0" y="10" class="ax">' + max + '</text><line x1="' + pad + '" x2="' + W + '" y1="' + H + '" y2="' + H + '" class="base"/>';
		daily.forEach(function (d, i) {
			var x = pad + i * bw, hv = (H - 14) * d.visitors / max, ha = (H - 14) * d.adds / max;
			svg += '<rect x="' + (x + bw * 0.12) + '" y="' + (H - hv) + '" width="' + Math.max(1, bw * 0.76) + '" height="' + hv + '" class="v"><title>' + d.day + ': ' + d.visitors + ' visitors, ' + d.adds + ' added to cart, ' + d.orders + ' orders</title></rect>';
			if (ha) svg += '<rect x="' + (x + bw * 0.3) + '" y="' + (H - ha) + '" width="' + Math.max(1, bw * 0.4) + '" height="' + ha + '" class="a"/>';
			if (d.orders) svg += '<circle cx="' + (x + bw / 2) + '" cy="' + (H + 8) + '" r="3" class="o"/>';
		});
		var step = Math.max(1, Math.ceil(daily.length / 6));
		daily.forEach(function (d, i) { if (i % step === 0) svg += '<text x="' + (pad + i * bw + 2) + '" y="' + (H + 22) + '" class="ax">' + d.day.slice(5) + '</text>'; });
		return svg + '</svg><div class="legend"><span><i class="v"></i>Real visitors</span><span><i class="a"></i>Added to cart</span><span><i class="o"></i>Day with an order</span></div>';
	}

	function compare(label, val, avg, fmt, help) {
		var w1 = val === null ? 0 : Math.min(100, val), w2 = avg === null ? 0 : Math.min(100, avg);
		return '<div class="cmp" title="' + esc(help || '') + '"><div class="lbl">' + label + '</div><div class="bars"><div class="b1"><i style="width:' + w1 + '%"></i></div><div class="b2"><i style="width:' + w2 + '%"></i></div></div>'
			+ '<div class="val"><b>' + fmt(val) + '</b><span>shop ' + fmt(avg) + '</span></div></div>';
	}

	function renderDetail() {
		var d = S.detail;
		if (d.loading) { frame('<div class="pfn-loading">Loading…</div>'); return; }
		var pr = d.product, r = d.row, b = d.base;
		var h = '<div class="pfn-row"><button class="pfn-btn" data-back="1">← Back</button><h3 class="grow">' + esc(pr.name) + '</h3><a class="pfn-btn" target="_blank" href="' + esc(editLink(pr.product_id)) + '">Edit product</a></div>';
		d.flags.forEach(function (f) { h += flagCard(f, true); });
		h += '<div class="two"><div class="pfn-card"><h4>Funnel, last ' + d.days + ' days</h4>';
		h += '<div class="kpis"><div><b>' + n(r.visitors) + '</b><span>real visitors</span></div><div><b>' + secs(r.avg_time) + '</b><span>active time (shop ' + secs(b.avg_time) + ')</span></div><div><b>' + n(r.orders) + '</b><span>orders, ' + money(r.revenue) + '</span></div></div>';
		h += compare('Saw the description', r.seen_rate, b.seen_rate, p, 'Scrolled down to the description.');
		h += compare('Read it to the end', r.read_rate, b.read_rate, p, 'Reached the end of the description and stayed a few seconds.');
		h += compare('Opened specifications', r.views ? 100 * r.specs / r.views : null, b.views ? 100 * b.specs / b.views : null, p);
		h += compare('Looked at reviews', r.views ? 100 * r.reviews / r.views : null, b.views ? 100 * b.reviews / b.views : null, p);
		h += compare('Opened photos', r.views ? 100 * r.photos / r.views : null, b.views ? 100 * b.photos / b.views : null, p);
		h += compare('Added to cart', r.add_rate, b.add_rate, p);
		h += compare('Removed from cart', r.remove_rate, b.remove_rate, p, 'Share of add-to-carts that were removed again.');
		h += compare('Bought', r.buy_rate, b.buy_rate, p, 'Orders as a share of real visitors.');
		if (r.raw > r.views && r.raw >= 10) h += '<p class="muted small">' + n(r.raw) + ' requests for this page, ' + n(r.views) + ' by people. The rest were search engines, AI crawlers and other bots.</p>';
		h += '</div><div class="pfn-card"><h4>Product page check</h4>';
		d.checks.forEach(function (c) { h += '<div class="chk"><i class="dot ' + c.level + '">' + (c.level === 'ok' ? '✓' : '!') + '</i><span>' + esc(c.text) + '</span></div>'; });
		h += '</div></div>';
		h += '<div class="pfn-card"><h4>Day by day</h4>' + chart(d.daily) + '</div>';
		frame(h);
	}

	function openProduct(id) {
		S.detail = {loading: true, id: id};
		render();
		window.scrollTo(0, Math.max(0, root.getBoundingClientRect().top + window.scrollY - 60));
		api('product', {product_id: id, days: S.days}).then(function (d) { S.detail = d; render(); }).catch(function (e) { S.detail = null; render(); toast(e.message, true); });
	}

	/* ---------------------------------------------- settings */

	function renderSettings() {
		var c = S.cfg || {}, d = S.defaults || {};
		var h = '<div class="two"><div class="pfn-card"><h4>Counting</h4>'
			+ '<label class="ck"><input type="checkbox" id="s-tracking"' + (c.tracking ? ' checked' : '') + '> Count visitors on product pages</label>'
			+ '<label class="ck"><input type="checkbox" id="s-dnt"' + (c.honour_dnt ? ' checked' : '') + '> Skip browsers that send Do Not Track or Global Privacy Control</label>'
			+ '<label class="f"><span>Flag a product once it has this many real visitors in the period</span><input type="number" min="5" max="5000" id="s-min" value="' + esc(c.min_visitors) + '"></label>'
			+ '<label class="f"><span>Period shown first</span><select id="s-period">' + [7, 30, 90].map(function (x) { return '<option value="' + x + '"' + (+c.period === x ? ' selected' : '') + '>Last ' + x + ' days</option>'; }).join('') + '</select></label>'
			+ '<label class="f"><span>Keep daily counts for (days)</span><input type="number" min="30" max="1100" id="s-keep" value="' + esc(c.keep_days) + '"></label>'
			+ '</div><div class="pfn-card"><h4>Theme</h4><p class="muted small">Where the product page shows the description, specifications and reviews (CSS selectors, comma separated). The defaults fit the standard theme and most others.</p>'
			+ '<label class="f"><span>Description</span><input type="text" id="s-desc" value="' + esc(c.sel_desc) + '"></label>'
			+ '<label class="f"><span>Specifications</span><input type="text" id="s-specs" value="' + esc(c.sel_specs) + '"></label>'
			+ '<label class="f"><span>Reviews</span><input type="text" id="s-reviews" value="' + esc(c.sel_reviews) + '"></label>'
			+ '<button class="pfn-btn sm" id="s-reset">Use the defaults</button></div></div>'
			+ '<div class="pfn-row"><button class="pfn-btn pri" id="s-save">Save settings</button></div>'
			+ '<div class="pfn-card"><h4>Privacy</h4><p class="small">Product Funnel stores only counts per product per day: how many people looked, how long, how far they read, how many added to cart. '
			+ 'No IP address, browser name, location or customer is stored, and it sets no cookie of its own on shoppers. To count each person once, a salted hash of the shop\'s own session is kept for two days and then deleted. '
			+ 'The product page script sends data only to your shop. Nothing goes to a third party, so there is no outside service to list in your cookie banner.</p>'
			+ '<p class="small">Your own visits are not counted: opening the shop admin marks this browser as staff.</p>'
			+ '<button class="pfn-btn danger" id="s-clear">Delete all counted data</button></div>'
			+ '<p class="muted small">Product Funnel ' + esc(B.version) + (S.since ? ' · counting since ' + esc(S.since) : '') + '</p>';
		frame(h);
		document.getElementById('s-reset').onclick = function () {
			document.getElementById('s-desc').value = d.sel_desc;
			document.getElementById('s-specs').value = d.sel_specs;
			document.getElementById('s-reviews').value = d.sel_reviews;
		};
		document.getElementById('s-save').onclick = function () {
			var body = {
				tracking: document.getElementById('s-tracking').checked ? 1 : 0,
				honour_dnt: document.getElementById('s-dnt').checked ? 1 : 0,
				min_visitors: +document.getElementById('s-min').value,
				period: +document.getElementById('s-period').value,
				keep_days: +document.getElementById('s-keep').value,
				sel_desc: document.getElementById('s-desc').value,
				sel_specs: document.getElementById('s-specs').value,
				sel_reviews: document.getElementById('s-reviews').value
			};
			api('save_settings', body).then(function (d) { S.cfg = d.config; S.report = null; toast('Settings saved'); render(); load(); }).catch(function (e) { toast(e.message, true); });
		};
		document.getElementById('s-clear').onclick = function () {
			var b = this;
			if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = 'Click again to delete everything'; return; }
			api('clear_all').then(function () { toast('All counted data deleted'); S.report = null; S.since = null; load(); render(); }).catch(function (e) { toast(e.message, true); });
		};
	}

	/* ---------------------------------------------- events */

	root.addEventListener('click', function (e) {
		var t = e.target.closest('[data-tab],[data-days],[data-open],[data-back],[data-sort],[data-filter]');
		if (!t || t.tagName === 'A') return;
		if (t.dataset.tab) { S.tab = t.dataset.tab; S.detail = null; render(); return; }
		if (t.dataset.days) {
			S.days = +t.dataset.days;
			if (S.detail) { openProduct(S.detail.product ? S.detail.product.product_id : S.detail.id); }
			S.report = null; load(); if (!S.detail) render();
			return;
		}
		if (t.dataset.open) { openProduct(+t.dataset.open); return; }
		if (t.dataset.back) { S.detail = null; render(); return; }
		if (t.dataset.sort) {
			if (S.sort === t.dataset.sort) S.dir = -S.dir; else { S.sort = t.dataset.sort; S.dir = t.dataset.sort === 'name' ? 1 : -1; }
			renderProducts(); return;
		}
		if (t.hasAttribute('data-filter')) { S.filter = t.dataset.filter; renderFlags(); }
	});

	function load() {
		return api('report', {days: S.days}).then(function (r) { S.report = r; if (!S.detail && S.tab !== 'settings') render(); else if (!S.detail) render(); })
			.catch(function (e) { frame('<div class="pfn-card empty bad">' + esc(e.message) + '</div>'); });
	}

	api('bootstrap').then(function (b) {
		S.cfg = b.config; S.defaults = b.defaults; S.since = b.since; S.days = +b.config.period || 30;
		var m = /[?&]pfn_product=(\d+)/.exec(location.search);
		load().then(function () { if (m) openProduct(+m[1]); });
		render();
	}).catch(function (e) { root.innerHTML = '<div class="pfn-card empty bad">' + esc(e.message) + '</div>'; });
})();
