<?php
/**
 * Product Funnel - admin API, admin page and the product page script.
 */
require_once(dirname(__FILE__) . '/Service.php');

if (!class_exists('PfnUi')) {
class PfnUi {
	const VERSION = '1.0.1';

	public static function writeActions() {
		return array('save_settings', 'clear_all');
	}

	public static function dispatch(PfnService $s, $action, array $in) {
		$s->ensureTables();

		switch ($action) {
			case 'bootstrap':
				return $s->bootstrap();
			case 'report':
				return $s->report($in);
			case 'product':
				return $s->product($in);
			case 'save_settings':
				return array('config' => $s->saveConfig($in));
			case 'clear_all':
				$s->clearAll();

				return array('cleared' => 1);
		}

		throw new Exception('Unknown action: ' . $action);
	}

	public static function input() {
		$raw = file_get_contents('php://input');
		$in = $raw !== '' ? json_decode($raw, true) : array();

		return is_array($in) ? $in : array();
	}

	public static function json($payload) {
		return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_INVALID_UTF8_SUBSTITUTE);
	}

	public static function api(PfnService $s, $action, $can) {
		$perm = in_array($action, self::writeActions(), true) ? 'modify' : 'access';

		if (!call_user_func($can, $perm)) {
			return self::json(array('error' => 'Permission denied: your user group needs "' . $perm . '" permission for Product Funnel (System > Users > User Groups).'));
		}

		try {
			return self::json(array('ok' => true, 'data' => self::dispatch($s, $action, self::input())));
		} catch (Exception $e) {
			return self::json(array('error' => $e->getMessage()));
		} catch (Error $e) {
			return self::json(array('error' => 'Server error: ' . $e->getMessage()));
		}
	}

	/** $links: product (edit link with PFNID), orders, settings. */
	public static function page($api_url, $oc_major, array $links) {
		$boot = array('api' => $api_url, 'oc' => (int)$oc_major, 'version' => self::VERSION, 'links' => $links);
		$dir = dirname(__FILE__) . '/ui/';

		return '<div id="pfn-root" class="pfn"><div class="pfn-loading">Loading…</div></div>'
			. '<style>' . file_get_contents($dir . 'admin.css') . '</style>'
			. '<script>window.PFN_ADMIN=' . json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . ';</script>'
			. '<script>' . file_get_contents($dir . 'admin.js') . '</script>';
	}

	/** The product page script, appended to the product template's output. */
	public static function script(array $cfg) {
		return '<script>window.PFN=' . json_encode($cfg, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>'
			. '<script>' . file_get_contents(dirname(__FILE__) . '/ui/track.js') . '</script>';
	}

	/** Before </body> when the template has it, else at the end. */
	public static function inject($html, $script) {
		$pos = strripos($html, '</body>');

		return $pos === false ? $html . $script : substr($html, 0, $pos) . $script . substr($html, $pos);
	}

	/** Small summary for the OpenCart admin dashboard widget: the top flags. */
	public static function widget(PfnService $s, $page_url, $product_url, $oc_major) {
		$s->ensureTables();
		$r = $s->report(array('days' => 30));
		$e = function ($t) { return htmlspecialchars((string)$t, ENT_QUOTES, 'UTF-8'); };
		$card = $oc_major >= 4 ? 'card mb-3' : 'panel panel-default';
		$head = $oc_major >= 4 ? 'card-header' : 'panel-heading';
		$bodyc = $oc_major >= 4 ? 'card-body' : 'panel-body';
		$h = '<div class="' . $card . '"><div class="' . $head . '">' . ($oc_major >= 4 ? '<i class="fa-solid fa-filter"></i>' : '<h3 class="panel-title"><i class="fa fa-filter"></i>') . ' Product Funnel: last 30 days' . ($oc_major >= 4 ? '' : '</h3>') . '</div><div class="' . $bodyc . '" style="font-size:13px;line-height:1.45">';
		$h .= '<div style="display:flex;gap:18px;flex-wrap:wrap;margin-bottom:10px">';

		foreach (array(array($r['base']['visitors'], 'real visitors on product pages'), array($r['base']['add_rate'] !== null ? $r['base']['add_rate'] . '%' : '-', 'add to cart'), array($r['base']['orders'], 'orders')) as $k) {
			$h .= '<div><b style="font-size:20px;display:block">' . $e($k[0]) . '</b><span style="color:#6c757d">' . $e($k[1]) . '</span></div>';
		}

		$h .= '</div>';
		$flags = array_slice($r['flags'], 0, 4);

		if (!$flags) {
			$h .= '<p style="color:#6c757d;margin:0">' . ($r['base']['visitors'] ? 'No problems found in the last 30 days.' : 'Counting has started. The first flags appear once products have ' . (int)$r['min_visitors'] . ' real visitors.') . '</p>';
		}

		foreach ($flags as $f) {
			$c = $f['level'] === 'good' ? '#2d7a4b' : ($f['level'] === 'bad' ? '#b0362e' : '#9a6a12');
			$h .= '<div style="border-left:3px solid ' . $c . ';padding:4px 0 4px 10px;margin:0 0 8px"><b style="color:' . $c . '">' . $e($f['title']) . '</b><br>' . $e($f['text'])
				. ' <a href="' . $e(str_replace('PFNID', (string)(int)$f['product_id'], $product_url)) . '">Details</a></div>';
		}

		return $h . '<a href="' . $e($page_url) . '">Open Product Funnel</a></div></div>';
	}
}
}
