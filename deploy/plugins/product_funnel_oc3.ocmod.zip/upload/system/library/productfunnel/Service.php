<?php
/**
 * Product Funnel for OpenCart - per-product counts of real (human) visitors: views, active time on the page,
 * how far they read, add to cart / remove, and checkouts and purchases from the shop's own orders.
 * Everything is stored as anonymous daily counts per product. No IP address, browser name or cookie of its own is
 * stored; a hashed session marker (to count each visitor once) is deleted after two days.
 * Framework-free: the OpenCart 3 / 4 adapters pass in the DB object.
 */
if (!class_exists('PfnService')) {
class PfnService {
	const CONFIG_CODE = 'module_product_funnel';
	const CONFIG_KEY = 'module_product_funnel_config';
	const STAFF_COOKIE = 'pfn_staff';

	const BOTS = '~(googlebot|google-inspectiontool|googleother|google-extended|adsbot-google|mediapartners-google|storebot-google|feedfetcher-google|bingbot|bingpreview|msnbot|adidxbot|yandex|baiduspider|duckduckbot|duckassistbot|applebot|slurp|facebookexternalhit|facebookcatalog|meta-externalagent|meta-externalfetcher|twitterbot|linkedinbot|pinterest|whatsapp|telegrambot|discordbot|slackbot|skypeuripreview|redditbot|embedly|ahrefs|semrush|mj12bot|dotbot|rogerbot|petalbot|bytespider|gptbot|chatgpt-user|oai-searchbot|claudebot|claude-user|claude-searchbot|anthropic|perplexity|youbot|cohere|diffbot|ccbot|amazonbot|dataforseo|serpstat|seznambot|sogou|exabot|qwantify|ia_archiver|archive\.org|uptimerobot|pingdom|statuscake|site24x7|betteruptime|crawler|spider|scraper|bot[/;\s)]|\bbot$|curl/|wget/|python|go-http-client|java/|okhttp|axios|node-fetch|undici|httpclient|libwww|guzzle|scrapy|headlesschrome|phantomjs|puppeteer|playwright|selenium|lighthouse|pagespeed|gtmetrix)~i';

	/** A browser session that opens more product pages than this in a day is a scraper, not a shopper. */
	const MAX_VIEWS = 120;

	private $db;
	private $p;
	private $oc;
	private $config;
	private $cols = array();

	public function __construct($db, $prefix, $oc_major) {
		$this->db = $db;
		$this->p = $prefix;
		$this->oc = (int)$oc_major;
	}

	private function e($s) {
		return $this->db->escape((string)$s);
	}

	private function t($name) {
		return '`' . $this->p . 'product_funnel_' . $name . '`';
	}

	private function o($name) {
		return '`' . $this->p . $name . '`';
	}

	public function oc() {
		return $this->oc;
	}

	/* ------------------------------------------------ settings */

	public static function defaults() {
		return array(
			'tracking'     => 1,
			'min_visitors' => 30,   // a product needs this many real visitors in the period before it gets a flag
			'period'       => 30,   // days shown by default
			'honour_dnt'   => 0,    // skip browsers that send Do Not Track / Global Privacy Control
			'keep_days'    => 400,  // daily counts are kept this long
			'sel_desc'     => '#tab-description, #description, .product-description, [itemprop="description"]',
			'sel_specs'    => '#tab-specification, #tab-attribute, #specification, .product-attributes',
			'sel_reviews'  => '#tab-review, #reviews, #review',
			'salt'         => ''
		);
	}

	public function getConfig() {
		if ($this->config !== null) {
			return $this->config;
		}

		$cfg = self::defaults();
		$q = $this->db->query("SELECT `value` FROM " . $this->o('setting') . " WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "' LIMIT 1");

		if ($q->num_rows) {
			$saved = json_decode($q->row['value'], true);

			if (is_array($saved)) {
				$cfg = array_merge($cfg, array_intersect_key($saved, $cfg));
			}
		}

		return $this->config = $cfg;
	}

	/** Settings without the internal salt, for the admin page. */
	public function publicConfig() {
		$c = $this->getConfig();
		unset($c['salt']);

		return $c;
	}

	public function saveConfig(array $in) {
		$cfg = $this->getConfig();
		$d = self::defaults();

		foreach (array('tracking', 'honour_dnt') as $k) {
			if (array_key_exists($k, $in)) {
				$cfg[$k] = !empty($in[$k]) ? 1 : 0;
			}
		}

		if (isset($in['min_visitors'])) {
			$cfg['min_visitors'] = max(5, min(5000, (int)$in['min_visitors']));
		}

		if (isset($in['period'])) {
			$cfg['period'] = in_array((int)$in['period'], array(7, 30, 90), true) ? (int)$in['period'] : $d['period'];
		}

		if (isset($in['keep_days'])) {
			$cfg['keep_days'] = max(30, min(1100, (int)$in['keep_days']));
		}

		foreach (array('sel_desc', 'sel_specs', 'sel_reviews') as $k) {
			if (isset($in[$k])) {
				$v = trim(preg_replace('/[\r\n<>{}]+/', ' ', (string)$in[$k]));
				$cfg[$k] = $v !== '' ? substr($v, 0, 400) : $d[$k];
			}
		}

		if ($cfg['salt'] === '') {
			$cfg['salt'] = bin2hex(function_exists('random_bytes') ? random_bytes(16) : uniqid('', true));
		}

		$this->db->query("DELETE FROM " . $this->o('setting') . " WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "'");
		$this->db->query("INSERT INTO " . $this->o('setting') . " SET store_id = '0', `code` = '" . self::CONFIG_CODE . "', `key` = '" . self::CONFIG_KEY . "', `value` = '" . $this->e(json_encode($cfg)) . "', serialized = '0'");
		$this->config = $cfg;

		return $this->publicConfig();
	}

	/* ------------------------------------------------ install */

	public function install() {
		$this->ensureTables();
		$this->saveConfig(array());
	}

	public function uninstall() {
		$this->db->query("DELETE FROM " . $this->o('setting') . " WHERE `code` = '" . self::CONFIG_CODE . "'");
		$this->db->query("DROP TABLE IF EXISTS " . $this->t('sess'));
		$this->db->query("DROP TABLE IF EXISTS " . $this->t('seen'));
		// Daily counts stay, so a reinstall keeps the history; "Delete all data" in Settings removes them.
	}

	public function ensureTables() {
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('day') . " (
			`product_id` INT(11) NOT NULL,
			`day` DATE NOT NULL,
			`raw` INT(11) NOT NULL DEFAULT 0,
			`views` INT(11) NOT NULL DEFAULT 0,
			`visitors` INT(11) NOT NULL DEFAULT 0,
			`time_sum` INT(11) NOT NULL DEFAULT 0,
			`time_n` INT(11) NOT NULL DEFAULT 0,
			`desc_seen` INT(11) NOT NULL DEFAULT 0,
			`desc_read` INT(11) NOT NULL DEFAULT 0,
			`specs` INT(11) NOT NULL DEFAULT 0,
			`reviews` INT(11) NOT NULL DEFAULT 0,
			`photos` INT(11) NOT NULL DEFAULT 0,
			`adds` INT(11) NOT NULL DEFAULT 0,
			`add_visitors` INT(11) NOT NULL DEFAULT 0,
			`removes` INT(11) NOT NULL DEFAULT 0,
			`hunt_visitors` INT(11) NOT NULL DEFAULT 0,
			`hunt_adds` INT(11) NOT NULL DEFAULT 0,
			PRIMARY KEY (`product_id`, `day`),
			KEY `day` (`day`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		// 1.0.1: visits by customers playing a Treasure Hunt are counted apart.
		foreach (array('hunt_visitors', 'hunt_adds') as $col) {
			if (!$this->db->query("SHOW COLUMNS FROM " . $this->t('day') . " LIKE '" . $col . "'")->num_rows) {
				$this->db->query("ALTER TABLE " . $this->t('day') . " ADD `" . $col . "` INT(11) NOT NULL DEFAULT 0");
			}
		}

		// Short-lived: a salted hash of the shop session, so one person is counted once. Deleted after two days.
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('sess') . " (
			`sid` CHAR(40) NOT NULL,
			`human` TINYINT(1) NOT NULL DEFAULT 0,
			`bot` TINYINT(1) NOT NULL DEFAULT 0,
			`views` INT(11) NOT NULL DEFAULT 0,
			`created` DATETIME NOT NULL,
			PRIMARY KEY (`sid`),
			KEY `created` (`created`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('seen') . " (
			`sid` CHAR(40) NOT NULL,
			`product_id` INT(11) NOT NULL,
			`viewed` TINYINT(1) NOT NULL DEFAULT 0,
			`added` TINYINT(1) NOT NULL DEFAULT 0,
			`created` DATETIME NOT NULL,
			PRIMARY KEY (`sid`, `product_id`),
			KEY `created` (`created`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	public function ready() {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->e($this->p . 'product_funnel_seen') . "'")->num_rows;
	}

	/* ------------------------------------------------ shop side */

	public static function isBot($ua) {
		$ua = trim((string)$ua);

		return $ua === '' || strlen($ua) < 25 || (bool)preg_match(self::BOTS, $ua) || stripos($ua, 'mozilla/') === false;
	}

	/**
	 * Should this request be counted at all? $r: ua, staff (the shop admin's own browser), dnt.
	 */
	public function countable(array $r) {
		$cfg = $this->getConfig();

		if (!$cfg['tracking'] || !empty($r['staff']) || self::isBot(isset($r['ua']) ? $r['ua'] : '')) {
			return false;
		}

		return !($cfg['honour_dnt'] && !empty($r['dnt']));
	}

	private function sid($session_id) {
		$cfg = $this->getConfig();

		return sha1($cfg['salt'] . '|' . (string)$session_id);
	}

	private function bump($product_id, array $add) {
		$product_id = (int)$product_id;

		if ($product_id <= 0 || !$add) {
			return;
		}

		$cols = array();
		$vals = array();
		$sets = array();

		foreach ($add as $k => $v) {
			$k = preg_replace('/[^a-z_]/', '', $k);
			$cols[] = '`' . $k . '`';
			$vals[] = (int)$v;
			$sets[] = '`' . $k . '` = `' . $k . '` + ' . (int)$v;
		}

		$this->db->query("INSERT INTO " . $this->t('day') . " (`product_id`, `day`, " . implode(', ', $cols) . ") VALUES ('" . $product_id . "', CURDATE(), " . implode(', ', $vals) . ") ON DUPLICATE KEY UPDATE " . implode(', ', $sets));
	}

	private function session($sid) {
		$q = $this->db->query("SELECT * FROM " . $this->t('sess') . " WHERE sid = '" . $this->e($sid) . "'");

		if ($q->num_rows) {
			return $q->row;
		}

		$this->db->query("INSERT IGNORE INTO " . $this->t('sess') . " SET sid = '" . $this->e($sid) . "', created = NOW()");

		if (mt_rand(1, 50) === 1) {
			$this->cleanup();
		}

		return array('sid' => $sid, 'human' => 0, 'bot' => 0, 'views' => 0);
	}

	private function productExists($product_id) {
		return (bool)$this->db->query("SELECT product_id FROM " . $this->o('product') . " WHERE product_id = '" . (int)$product_id . "' AND status = '1'")->num_rows;
	}

	/** Every request for a product page, people and bots alike: what OpenCart's own report counts. */
	public function raw($product_id) {
		if ($this->getConfig()['tracking']) {
			$this->bump($product_id, array('raw' => 1));
		}
	}

	/**
	 * From the product page script, sent only after the visitor moved, scrolled, touched or typed.
	 * e = v (view) or l (leave, with active seconds and how far they read).
	 */
	public function beacon($session_id, array $in, array $r) {
		if (!$this->countable($r) || (string)$session_id === '') {
			return 'skip';
		}

		$pid = isset($in['p']) ? (int)$in['p'] : 0;
		$e = isset($in['e']) ? (string)$in['e'] : '';

		if ($pid <= 0 || !in_array($e, array('v', 'l'), true) || !$this->productExists($pid)) {
			return 'skip';
		}

		$sid = $this->sid($session_id);
		$s = $this->session($sid);

		if ($s['bot']) {
			return 'bot';
		}

		$seen = $this->db->query("SELECT viewed FROM " . $this->t('seen') . " WHERE sid = '" . $this->e($sid) . "' AND product_id = '" . $pid . "'");

		// Customers playing a Treasure Hunt browse to find icons, not to buy: count them apart, once per product.
		if (!empty($r['hunt'])) {
			if ($e === 'v' && (!$seen->num_rows || !(int)$seen->row['viewed'])) {
				$this->db->query("INSERT INTO " . $this->t('seen') . " SET sid = '" . $this->e($sid) . "', product_id = '" . $pid . "', viewed = 1, created = NOW() ON DUPLICATE KEY UPDATE viewed = 1");
				$this->bump($pid, array('hunt_visitors' => 1));
			}

			return 'hunt';
		}

		if ($e === 'v') {
			if ((int)$s['views'] + 1 > self::MAX_VIEWS) {
				$this->db->query("UPDATE " . $this->t('sess') . " SET bot = 1 WHERE sid = '" . $this->e($sid) . "'");

				return 'bot';
			}

			$this->db->query("UPDATE " . $this->t('sess') . " SET human = 1, views = views + 1 WHERE sid = '" . $this->e($sid) . "'");
			$add = array('views' => 1);

			if (!$seen->num_rows || !(int)$seen->row['viewed']) {
				$add['visitors'] = 1;
				$this->db->query("INSERT INTO " . $this->t('seen') . " SET sid = '" . $this->e($sid) . "', product_id = '" . $pid . "', viewed = 1, created = NOW() ON DUPLICATE KEY UPDATE viewed = 1");
			}

			$this->bump($pid, $add);

			return 'view';
		}

		// Leave: only for a view that was counted.
		if (!$seen->num_rows || !(int)$seen->row['viewed']) {
			return 'skip';
		}

		$add = array();
		$t = isset($in['t']) ? max(0, min(1800, (int)$in['t'])) : 0;

		if ($t > 0) {
			$add['time_sum'] = $t;
		}

		if (!empty($in['f'])) {
			$add['time_n'] = 1;
		}

		foreach (array('d' => 'desc_seen', 'r' => 'desc_read', 's' => 'specs', 'w' => 'reviews', 'g' => 'photos') as $k => $col) {
			if (!empty($in[$k])) {
				$add[$col] = 1;
			}
		}

		$this->bump($pid, $add);

		return 'leave';
	}

	/** After OpenCart's add-to-cart answered with success. $xhr: sent by the page's own script. */
	public function added($session_id, $product_id, $xhr, array $r) {
		if (!$this->countable($r) || (string)$session_id === '' || (int)$product_id <= 0) {
			return 'skip';
		}

		$sid = $this->sid($session_id);
		$s = $this->session($sid);

		if ($s['bot'] || (!$s['human'] && !$xhr)) {
			return 'skip';
		}

		$pid = (int)$product_id;

		if (!empty($r['hunt'])) {
			$this->bump($pid, array('hunt_adds' => 1));

			return 'hunt';
		}

		$seen = $this->db->query("SELECT added FROM " . $this->t('seen') . " WHERE sid = '" . $this->e($sid) . "' AND product_id = '" . $pid . "'");
		$add = array('adds' => 1);

		if (!$seen->num_rows || !(int)$seen->row['added']) {
			$add['add_visitors'] = 1;
			$this->db->query("INSERT INTO " . $this->t('seen') . " SET sid = '" . $this->e($sid) . "', product_id = '" . $pid . "', added = 1, created = NOW() ON DUPLICATE KEY UPDATE added = 1");
		}

		$this->bump($pid, $add);

		return 'add';
	}

	/** Before OpenCart removes a cart line: which product it was. */
	public function removing($session_id, $cart_id, array $r) {
		if (!$this->countable($r) || (int)$cart_id <= 0) {
			return 'skip';
		}

		$q = $this->db->query("SELECT product_id FROM " . $this->o('cart') . " WHERE cart_id = '" . (int)$cart_id . "' AND session_id = '" . $this->e($session_id) . "'");

		if (!$q->num_rows) {
			return 'skip';
		}

		$this->bump((int)$q->row['product_id'], array('removes' => 1));

		return 'remove';
	}

	public function cleanup() {
		$this->db->query("DELETE FROM " . $this->t('sess') . " WHERE created < DATE_SUB(NOW(), INTERVAL 2 DAY)");
		$this->db->query("DELETE FROM " . $this->t('seen') . " WHERE created < DATE_SUB(NOW(), INTERVAL 2 DAY)");
		$keep = (int)$this->getConfig()['keep_days'];
		$this->db->query("DELETE FROM " . $this->t('day') . " WHERE `day` < DATE_SUB(CURDATE(), INTERVAL " . max(30, $keep) . " DAY)");
	}

	public function clearAll() {
		foreach (array('day', 'sess', 'seen') as $t) {
			$this->db->query("TRUNCATE TABLE " . $this->t($t));
		}
	}

	/** Settings for the product page script. */
	public function pageConfig($product_id, $url) {
		$c = $this->getConfig();

		return array('u' => $url, 'p' => (int)$product_id, 'sd' => $c['sel_desc'], 'ss' => $c['sel_specs'], 'sr' => $c['sel_reviews']);
	}

	/* ------------------------------------------------ report */

	private function hasColumn($table, $col) {
		$key = $table . '.' . $col;

		if (!isset($this->cols[$key])) {
			$this->cols[$key] = (bool)$this->db->query("SHOW COLUMNS FROM " . $this->o($table) . " LIKE '" . $this->e($col) . "'")->num_rows;
		}

		return $this->cols[$key];
	}

	private function setting($key) {
		$q = $this->db->query("SELECT `value`, serialized FROM " . $this->o('setting') . " WHERE store_id = '0' AND `key` = '" . $this->e($key) . "' LIMIT 1");

		if (!$q->num_rows) {
			return null;
		}

		$v = $q->row['value'];

		if ((int)$q->row['serialized']) {
			$j = json_decode($v, true);

			return $j !== null ? $j : @unserialize($v);
		}

		return $v;
	}

	/** Order statuses that count as a sale: the shop's "processing" and "complete" statuses. */
	public function paidStatuses() {
		$ids = array();

		foreach (array('config_processing_status', 'config_complete_status') as $k) {
			$v = $this->setting($k);

			foreach ((array)$v as $id) {
				if ((int)$id > 0) {
					$ids[] = (int)$id;
				}
			}
		}

		return $ids ? array_values(array_unique($ids)) : array(2, 3, 5, 15);
	}

	public function languageId() {
		$code = (string)$this->setting('config_language');

		if ($this->oc >= 4 && $code === '') {
			$code = (string)$this->setting('config_language_admin');
		}

		$q = $this->db->query("SELECT language_id FROM " . $this->o('language') . " WHERE code = '" . $this->e($code) . "' LIMIT 1");

		if ($q->num_rows) {
			return (int)$q->row['language_id'];
		}

		$q = $this->db->query("SELECT language_id FROM " . $this->o('language') . " ORDER BY status DESC, sort_order, language_id LIMIT 1");

		return $q->num_rows ? (int)$q->row['language_id'] : 1;
	}

	public function currency() {
		$code = (string)$this->setting('config_currency');
		$q = $this->db->query("SELECT * FROM " . $this->o('currency') . " WHERE code = '" . $this->e($code) . "' LIMIT 1");

		if (!$q->num_rows) {
			return array('code' => $code, 'left' => '', 'right' => ' ' . $code, 'decimals' => 2);
		}

		return array('code' => $code, 'left' => (string)$q->row['symbol_left'], 'right' => (string)$q->row['symbol_right'], 'decimals' => (int)$q->row['decimal_place']);
	}

	private static function range($days, $offset = 0) {
		$days = max(1, (int)$days);
		$end = date('Y-m-d', strtotime('-' . (int)$offset . ' days'));
		$start = date('Y-m-d', strtotime($end . ' -' . ($days - 1) . ' days'));

		return array($start, $end);
	}

	/** Counts per product for the period, from the daily table and from the orders. */
	public function rows($days, $offset = 0, $product_id = 0) {
		list($from, $to) = self::range($days, $offset);
		$where = "d.`day` BETWEEN '" . $from . "' AND '" . $to . "'" . ($product_id ? " AND d.product_id = '" . (int)$product_id . "'" : '');
		$q = $this->db->query("SELECT d.product_id, SUM(d.raw) raw, SUM(d.views) views, SUM(d.visitors) visitors, SUM(d.time_sum) time_sum, SUM(d.time_n) time_n,
			SUM(d.desc_seen) desc_seen, SUM(d.desc_read) desc_read, SUM(d.specs) specs, SUM(d.reviews) reviews, SUM(d.photos) photos,
			SUM(d.adds) adds, SUM(d.add_visitors) add_visitors, SUM(d.removes) removes, SUM(d.hunt_visitors) hunt_visitors, SUM(d.hunt_adds) hunt_adds
			FROM " . $this->t('day') . " d WHERE " . $where . " GROUP BY d.product_id");
		$rows = array();

		foreach ($q->rows as $r) {
			$id = (int)$r['product_id'];
			$rows[$id] = array_map('intval', $r) + array('checkouts' => 0, 'orders' => 0, 'units' => 0, 'revenue' => 0.0);
		}

		$paid = implode(',', $this->paidStatuses());
		$q = $this->db->query("SELECT op.product_id, COUNT(DISTINCT o.order_id) checkouts,
			COUNT(DISTINCT CASE WHEN o.order_status_id IN (" . $paid . ") THEN o.order_id END) orders,
			SUM(CASE WHEN o.order_status_id IN (" . $paid . ") THEN op.quantity ELSE 0 END) units,
			SUM(CASE WHEN o.order_status_id IN (" . $paid . ") THEN op.total ELSE 0 END) revenue
			FROM " . $this->o('order_product') . " op JOIN " . $this->o('order') . " o ON o.order_id = op.order_id
			WHERE o.date_added >= '" . $from . " 00:00:00' AND o.date_added <= '" . $to . " 23:59:59'" . ($product_id ? " AND op.product_id = '" . (int)$product_id . "'" : '') . "
			GROUP BY op.product_id");

		foreach ($q->rows as $r) {
			$id = (int)$r['product_id'];

			if (!isset($rows[$id])) {
				$rows[$id] = array('product_id' => $id, 'raw' => 0, 'views' => 0, 'visitors' => 0, 'time_sum' => 0, 'time_n' => 0, 'desc_seen' => 0, 'desc_read' => 0, 'specs' => 0, 'reviews' => 0, 'photos' => 0, 'adds' => 0, 'add_visitors' => 0, 'removes' => 0, 'hunt_visitors' => 0, 'hunt_adds' => 0);
			}

			$rows[$id]['checkouts'] = (int)$r['checkouts'];
			$rows[$id]['orders'] = (int)$r['orders'];
			$rows[$id]['units'] = (int)$r['units'];
			$rows[$id]['revenue'] = round((float)$r['revenue'], 2);
		}

		foreach ($rows as &$r) {
			$r = self::derive($r);
		}

		return $rows;
	}

	private static function pct($a, $b) {
		return $b > 0 ? round(100 * $a / $b, 1) : null;
	}

	private static function derive(array $r) {
		$v = max($r['visitors'], 0);
		$r['avg_time'] = $r['time_n'] > 0 ? (int)round($r['time_sum'] / $r['time_n']) : null;
		$r['seen_rate'] = self::pct($r['desc_seen'], $r['views']);
		$r['read_rate'] = self::pct($r['desc_read'], $r['views']);
		$r['add_rate'] = self::pct(min($r['add_visitors'], $v), $v);
		$r['buy_rate'] = self::pct(min($r['orders'], $v), $v);
		$r['remove_rate'] = self::pct($r['removes'], $r['adds']);

		return $r;
	}

	/** Whole-shop rates, weighted by visitors: the yardstick each product is compared with. */
	private static function baseline(array $rows) {
		$t = array('visitors' => 0, 'views' => 0, 'raw' => 0, 'time_sum' => 0, 'time_n' => 0, 'desc_seen' => 0, 'desc_read' => 0, 'add_visitors' => 0, 'adds' => 0, 'removes' => 0, 'checkouts' => 0, 'orders' => 0, 'units' => 0, 'revenue' => 0.0, 'specs' => 0, 'reviews' => 0, 'photos' => 0, 'hunt_visitors' => 0, 'hunt_adds' => 0);
		$vis = array();

		foreach ($rows as $r) {
			foreach ($t as $k => $v) {
				$t[$k] += $r[$k];
			}

			if ($r['visitors'] > 0) {
				$vis[] = $r['visitors'];
			}
		}

		sort($vis);
		$t['revenue'] = round($t['revenue'], 2);
		$t = self::derive($t);
		$t['median_visitors'] = $vis ? $vis[(int)floor((count($vis) - 1) / 2)] : 0;
		$t['products'] = count($vis);

		return $t;
	}

	/* ------------------------------------------------ product facts for the checks */

	public function facts(array $ids) {
		$ids = array_values(array_filter(array_map('intval', $ids)));

		if (!$ids) {
			return array();
		}

		$in = implode(',', $ids);
		$lang = $this->languageId();
		$out = array();
		$q = $this->db->query("SELECT p.product_id, p.model, p.price, p.image, p.quantity, p.status, p.weight, p.length, p.width, p.height, p.shipping, pd.name, pd.description
			FROM " . $this->o('product') . " p LEFT JOIN " . $this->o('product_description') . " pd ON pd.product_id = p.product_id AND pd.language_id = '" . $lang . "'
			WHERE p.product_id IN (" . $in . ")");

		foreach ($q->rows as $r) {
			$text = trim(preg_replace('/\s+/u', ' ', strip_tags(html_entity_decode((string)$r['description'], ENT_QUOTES, 'UTF-8'))));
			$out[(int)$r['product_id']] = array(
				'product_id' => (int)$r['product_id'],
				'name'       => html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8') ?: ('#' . $r['product_id']),
				'model'      => (string)$r['model'],
				'price'      => round((float)$r['price'], 2),
				'special'    => null,
				'status'     => (int)$r['status'],
				'quantity'   => (int)$r['quantity'],
				'photos'     => $r['image'] !== '' && $r['image'] !== null ? 1 : 0,
				'words'      => $text === '' ? 0 : count(preg_split('/\s+/u', $text)),
				'shipping_text' => (bool)preg_match('/(shipping|delivery|dispatch|ships in|lieferung|versand|piegād|доставк|dostaw|livraison|envío|consegna)/iu', $text),
				'size_text'  => (bool)preg_match('/(\d\s?(mm|cm|m|in|inch|"|kg|g|lb|ml|l)\b|dimension|size|weight|measure|compatib|fits)/iu', $text),
				'weight'     => (float)$r['weight'] > 0,
				'dimensions' => (float)$r['length'] > 0 && (float)$r['width'] > 0 && (float)$r['height'] > 0,
				'needs_shipping' => (int)$r['shipping'] === 1,
				'attributes' => 0,
				'reviews'    => 0,
				'rating'     => null,
				'category_id' => 0,
				'category'   => '',
				'category_median' => null,
				'category_count' => 0
			);
		}

		foreach ($this->db->query("SELECT product_id, COUNT(*) n FROM " . $this->o('product_image') . " WHERE product_id IN (" . $in . ") GROUP BY product_id")->rows as $r) {
			if (isset($out[(int)$r['product_id']])) {
				$out[(int)$r['product_id']]['photos'] += (int)$r['n'];
			}
		}

		foreach ($this->db->query("SELECT product_id, COUNT(DISTINCT attribute_id) n FROM " . $this->o('product_attribute') . " WHERE product_id IN (" . $in . ") GROUP BY product_id")->rows as $r) {
			if (isset($out[(int)$r['product_id']])) {
				$out[(int)$r['product_id']]['attributes'] = (int)$r['n'];
			}
		}

		foreach ($this->db->query("SELECT product_id, COUNT(*) n, AVG(rating) r FROM " . $this->o('review') . " WHERE status = '1' AND product_id IN (" . $in . ") GROUP BY product_id")->rows as $r) {
			if (isset($out[(int)$r['product_id']])) {
				$out[(int)$r['product_id']]['reviews'] = (int)$r['n'];
				$out[(int)$r['product_id']]['rating'] = round((float)$r['r'], 1);
			}
		}

		// OpenCart 4.1 keeps specials in product_discount (special = 1, with a percentage / subtract / fixed type).
		$active = "(x.date_start = '0000-00-00' OR x.date_start IS NULL OR x.date_start <= CURDATE()) AND (x.date_end = '0000-00-00' OR x.date_end IS NULL OR x.date_end >= CURDATE())";

		if ($this->db->query("SHOW TABLES LIKE '" . $this->e($this->p . 'product_special') . "'")->num_rows) {
			$special = "SELECT x.product_id, MIN(x.price) price FROM " . $this->o('product_special') . " x WHERE x.product_id IN (" . $in . ") AND " . $active . " GROUP BY x.product_id";
		} else {
			$special = "SELECT x.product_id, MIN(CASE WHEN x.`type` = 'P' THEN p.price - p.price * x.price / 100 WHEN x.`type` = 'S' THEN p.price - x.price ELSE x.price END) price
				FROM " . $this->o('product_discount') . " x JOIN " . $this->o('product') . " p ON p.product_id = x.product_id
				WHERE x.special = '1' AND x.quantity <= 1 AND x.product_id IN (" . $in . ") AND " . $active . " GROUP BY x.product_id";
		}

		foreach ($this->db->query($special)->rows as $r) {
			if (isset($out[(int)$r['product_id']])) {
				$out[(int)$r['product_id']]['special'] = round((float)$r['price'], 2);
			}
		}

		// The deepest category of each product, and the median price of the other enabled products in it.
		$cats = array();
		$q = $this->db->query("SELECT p2c.product_id, p2c.category_id, cd.name, (SELECT COUNT(*) FROM " . $this->o('category_path') . " cp WHERE cp.category_id = p2c.category_id) depth
			FROM " . $this->o('product_to_category') . " p2c LEFT JOIN " . $this->o('category_description') . " cd ON cd.category_id = p2c.category_id AND cd.language_id = '" . $lang . "'
			WHERE p2c.product_id IN (" . $in . ") ORDER BY depth DESC");

		foreach ($q->rows as $r) {
			$pid = (int)$r['product_id'];

			if (isset($out[$pid]) && !$out[$pid]['category_id']) {
				$out[$pid]['category_id'] = (int)$r['category_id'];
				$out[$pid]['category'] = html_entity_decode((string)$r['name'], ENT_QUOTES, 'UTF-8');
				$cats[(int)$r['category_id']] = true;
			}
		}

		$prices = array();

		if ($cats) {
			$q = $this->db->query("SELECT p2c.category_id, p.product_id, p.price FROM " . $this->o('product_to_category') . " p2c JOIN " . $this->o('product') . " p ON p.product_id = p2c.product_id
				WHERE p.status = '1' AND p.price > 0 AND p2c.category_id IN (" . implode(',', array_keys($cats)) . ")");

			foreach ($q->rows as $r) {
				$prices[(int)$r['category_id']][(int)$r['product_id']] = (float)$r['price'];
			}
		}

		foreach ($out as $pid => &$f) {
			if ($f['category_id'] && !empty($prices[$f['category_id']])) {
				$list = $prices[$f['category_id']];
				unset($list[$pid]);

				if (count($list) >= 3) {
					$list = array_values($list);
					sort($list);
					$n = count($list);
					$f['category_median'] = round($n % 2 ? $list[($n - 1) / 2] : ($list[$n / 2 - 1] + $list[$n / 2]) / 2, 2);
					$f['category_count'] = $n;
				}
			}
		}

		return $out;
	}

	/** Plain checks of the product page itself; used by the flags and the product view. */
	public static function checks(array $f, array $cur) {
		$out = array();
		$price = $f['special'] !== null && $f['special'] < $f['price'] ? $f['special'] : $f['price'];
		$m = function ($v) use ($cur) {
			return $cur['left'] . number_format((float)$v, $cur['decimals'], '.', ',') . $cur['right'];
		};

		if ($f['photos'] <= 1) {
			$out[] = array('photos', 'bad', $f['photos'] ? 'Only 1 photo. Add 4 to 6: front, back, close-up of the material or details, in use, and next to something for scale.' : 'No photo.');
		} elseif ($f['photos'] < 4) {
			$out[] = array('photos', 'warn', $f['photos'] . ' photos. Shops with 4 to 6 per product sell more: add close-ups, the product in use and one that shows its size.');
		} else {
			$out[] = array('photos', 'ok', $f['photos'] . ' photos.');
		}

		if ($f['category_median'] !== null && $price > 0) {
			$diff = round(100 * ($price - $f['category_median']) / $f['category_median']);

			if ($diff >= 20) {
				$out[] = array('price', 'bad', 'Price ' . $m($price) . ' is ' . $diff . '% above the middle price of its category "' . $f['category'] . '" (' . $m($f['category_median']) . '). Say on the page why it costs more, or test a lower price or a bundle.');
			} elseif ($diff <= -35) {
				$out[] = array('price', 'warn', 'Price ' . $m($price) . ' is ' . abs($diff) . '% below the middle price of its category (' . $m($f['category_median']) . '). A very low price can look like low quality: explain it (sale, end of line).');
			} else {
				$out[] = array('price', 'ok', 'Price ' . $m($price) . ' is close to the middle of its category (' . $m($f['category_median']) . ').');
			}
		}

		if ($f['words'] < 60) {
			$out[] = array('description', 'bad', 'The description has only ' . $f['words'] . ' words. Write what it is, who it is for, what it is made of, sizes, and what is in the box.');
		} elseif ($f['words'] < 150) {
			$out[] = array('description', 'warn', 'The description has ' . $f['words'] . ' words. Add the details people ask about: materials, sizes, care, what is in the box.');
		} else {
			$out[] = array('description', 'ok', 'The description has ' . $f['words'] . ' words.');
		}

		if (!$f['attributes'] && !$f['size_text']) {
			$out[] = array('specs', 'bad', 'No specifications: no attributes and no sizes or measurements in the text. Add them as attributes so they show in the Specification tab.');
		} elseif (!$f['attributes']) {
			$out[] = array('specs', 'warn', 'No attributes. Put sizes, materials and compatibility in attributes too, so they are easy to find and compare.');
		} else {
			$out[] = array('specs', 'ok', $f['attributes'] . ' specification lines.');
		}

		if (!$f['reviews']) {
			$out[] = array('reviews', 'warn', 'No reviews yet. Ask recent buyers for one (an email a week after delivery works well).');
		} elseif ($f['rating'] !== null && $f['rating'] < 3.5) {
			$out[] = array('reviews', 'bad', $f['reviews'] . ' reviews, average ' . $f['rating'] . ' stars. Read them: they name the problem, then answer them on the page.');
		} else {
			$out[] = array('reviews', 'ok', $f['reviews'] . ' reviews, average ' . $f['rating'] . ' stars.');
		}

		if ($f['needs_shipping']) {
			if (!$f['shipping_text']) {
				$out[] = array('shipping', 'warn', 'The page does not mention delivery. Say how much it costs and when it arrives, near the price.');
			}

			if (!$f['weight']) {
				$out[] = array('weight', 'warn', 'No weight is set, so weight-based shipping cannot be estimated before checkout.');
			}
		}

		if ($f['quantity'] <= 0) {
			$out[] = array('stock', 'warn', 'Out of stock (quantity ' . $f['quantity'] . '). If it can still be ordered, say when it will ship.');
		}

		return $out;
	}

	/* ------------------------------------------------ flags */

	/**
	 * The drop-off patterns, in plain words. Each flag: product_id, type, level, title, text, fixes[], impact.
	 */
	public static function flags(array $rows, array $base, array $facts, array $cfg, array $cur) {
		$min = max(5, (int)$cfg['min_visitors']);
		$shopAdd = $base['add_rate'] !== null ? $base['add_rate'] : 0;
		$shopTime = $base['avg_time'] !== null ? $base['avg_time'] : 0;
		$medV = max(1, (int)$base['median_visitors']);
		$flags = array();

		foreach ($rows as $pid => $r) {
			if (!isset($facts[$pid])) {
				continue;
			}

			$f = $facts[$pid];
			$name = $f['name'];
			$V = $r['visitors'];
			$A = $r['add_rate'] !== null ? $r['add_rate'] : 0;
			$T = $r['avg_time'];
			$R = $r['read_rate'] !== null ? $r['read_rate'] : 0;
			$checks = array();

			foreach (self::checks($f, $cur) as $c) {
				$checks[$c[0]] = $c;
			}

			$fix = function (array $keys) use ($checks) {
				$out = array();

				foreach ($keys as $k) {
					if (isset($checks[$k]) && $checks[$k][1] !== 'ok') {
						$out[] = $checks[$k][2];
					}
				}

				return $out;
			};

			$lowAdd = $shopAdd > 0 ? $A < 0.6 * $shopAdd : $A < 2;

			// 1 + 2: plenty of visitors, few add to cart
			if ($V >= $min && $lowAdd && $r['time_n'] >= 5 && $T !== null) {
				$short = $T < max(20, 0.7 * $shopTime);
				$long = $T >= max(45, 1.3 * $shopTime);
				$lost = (int)round($V * max(0, $shopAdd - $A) / 100);

				if ($short) {
					$fixes = $fix(array('price', 'photos'));

					if (!$fixes) {
						$fixes[] = 'Look at the page as a first-time visitor on a phone: is the price clear, is the main photo sharp and does it show the product well, is the Add to cart button visible without scrolling?';
					}

					$flags[] = array('product_id' => $pid, 'type' => 'first_look', 'level' => 'bad', 'title' => 'Leave at first sight',
						'text' => $name . ': ' . $V . ' real visitors, ' . self::fmt($A) . '% add to cart (shop average ' . self::fmt($shopAdd) . '%). They leave after ' . $T . ' s' . ($r['seen_rate'] !== null && $r['seen_rate'] < 50 ? ' and only ' . self::fmt($r['seen_rate']) . '% scroll down to the description' : '') . ', so the price or the photos put them off.',
						'fixes' => $fixes, 'impact' => $lost);
				} elseif ($long || $R >= 40) {
					$fixes = $fix(array('specs', 'reviews', 'shipping', 'weight', 'description'));

					if (!$fixes) {
						$fixes[] = 'Add an FAQ to the description with the questions customers email you about this product (size, fit, compatibility, delivery time).';
					}

					$flags[] = array('product_id' => $pid, 'type' => 'doubt', 'level' => 'bad', 'title' => 'Interested, but in doubt',
						'text' => $name . ': ' . $V . ' real visitors spend ' . $T . ' s on the page' . ($R > 0 ? ' and ' . self::fmt($R) . '% read the description to the end' : '') . ', but only ' . self::fmt($A) . '% add it to the cart. They want it but something is missing: specs, compatibility, reviews or the shipping cost.',
						'fixes' => $fixes, 'impact' => $lost);
				} else {
					$fixes = $fix(array('price', 'photos', 'specs', 'reviews', 'shipping', 'description'));
					$flags[] = array('product_id' => $pid, 'type' => 'low_add', 'level' => 'warn', 'title' => 'Few add to cart',
						'text' => $name . ': ' . $V . ' real visitors, ' . self::fmt($A) . '% add to cart (shop average ' . self::fmt($shopAdd) . '%). Visitors spend ' . $T . ' s on the page, about the shop average, so check the price and the page against similar products.',
						'fixes' => $fixes ?: array('Compare price, photos and delivery with the same product at two competitors.'), 'impact' => $lost);
				}
			}

			// 3: added, then removed or never bought, compared with the shop as a whole (most carts are abandoned everywhere)
			$adders = $r['add_visitors'];

			if ($adders >= 8) {
				$bought = min($r['orders'], $adders);
				$keep = $bought / $adders;
				$rem = $r['adds'] > 0 ? $r['removes'] / $r['adds'] : 0;
				$shopKeep = $base['add_visitors'] > 0 ? min(1, $base['orders'] / $base['add_visitors']) : 0;
				$shopRem = $base['adds'] > 0 ? $base['removes'] / $base['adds'] : 0;
				// Only when enough sales were expected for "none" or "few" to mean something (at least 3 at the shop's rate).
				$expected = $adders * $shopKeep;
				$badKeep = $expected >= 3 && $bought < 0.5 * $expected;
				$badRem = $r['removes'] >= 5 && $rem >= max(0.25, 2 * $shopRem);

				if ($badKeep || $badRem) {
					$fixes = $fix(array('shipping', 'weight', 'stock'));
					$fixes[] = 'Show the delivery cost and delivery time on the product page and in the cart, not only at checkout. A free-delivery threshold helps too.';

					if ($r['checkouts'] > $r['orders']) {
						$fixes[] = ($r['checkouts'] - $r['orders']) . ' checkouts with this product were never paid: look at them in Sales > Orders > Missing Orders and test the payment methods.';
					}

					$flags[] = array('product_id' => $pid, 'type' => 'cart_drop', 'level' => 'bad', 'title' => 'Added, then dropped',
						'text' => $name . ': ' . $adders . ' visitors added it to the cart, ' . ($r['removes'] ? $r['removes'] . ' removed it again' : 'nobody removed it') . ', and ' . $bought . ' bought it' . ($shopKeep > 0 ? ' (' . self::fmt(100 * $keep) . '% of those who added it; shop average ' . self::fmt(100 * $shopKeep) . '%)' : '') . '. Shoppers back out late, which usually means the shipping cost or delivery time shows up too late.',
						'fixes' => $fixes, 'impact' => $adders - $bought);
				}
			}

			// 4: hard to find, but converts
			if ($V >= 5 && $V <= 0.5 * $medV && $adders >= 3 && $shopAdd > 0 && $A >= 1.5 * $shopAdd) {
				$flags[] = array('product_id' => $pid, 'type' => 'hidden_gem', 'level' => 'good', 'title' => 'Good product, hard to find',
					'text' => $name . ': only ' . $V . ' real visitors, but ' . self::fmt($A) . '% add it to the cart, ' . self::fmt($A / $shopAdd) . '× the shop average. People like it once they find it, so promote it.',
					'fixes' => array('Feature it on the home page (Featured module) and move it to the top of its category (sort order).', 'Link to it from the descriptions of similar, more visited products and set it as a related product.', 'Put it in the next newsletter or social post.'),
					'impact' => (int)round(($medV - $V) * $A / 100));
			}
		}

		$order = array('bad' => 0, 'warn' => 1, 'good' => 2);
		usort($flags, function ($a, $b) use ($order) {
			if ($order[$a['level']] !== $order[$b['level']]) {
				return $order[$a['level']] - $order[$b['level']];
			}

			return $b['impact'] - $a['impact'];
		});

		return $flags;
	}

	private static function fmt($n) {
		$n = (float)$n;

		return $n >= 10 || $n == (int)$n ? (string)(int)round($n) : number_format($n, 1, '.', '');
	}

	/* ------------------------------------------------ admin data */

	public function report(array $in) {
		$cfg = $this->getConfig();
		$days = isset($in['days']) && in_array((int)$in['days'], array(7, 30, 90), true) ? (int)$in['days'] : (int)$cfg['period'];
		$rows = $this->rows($days);
		$prev = $this->rows($days, $days);
		$base = self::baseline($rows);
		$pbase = self::baseline($prev);
		$facts = $this->facts(array_keys($rows));
		$cur = $this->currency();
		$flags = self::flags($rows, $base, $facts, $cfg, $cur);

		$byProduct = array();

		foreach ($flags as $f) {
			$byProduct[$f['product_id']][] = $f['type'];
		}

		$list = array();

		foreach ($rows as $pid => $r) {
			if (!isset($facts[$pid])) {
				continue;
			}

			$r['name'] = $facts[$pid]['name'];
			$r['model'] = $facts[$pid]['model'];
			$r['status'] = $facts[$pid]['status'];
			$r['flags'] = isset($byProduct[$pid]) ? $byProduct[$pid] : array();
			$list[] = $r;
		}

		usort($list, function ($a, $b) {
			return $b['visitors'] - $a['visitors'] ?: $b['orders'] - $a['orders'];
		});

		foreach ($flags as &$f) {
			$f['name'] = $facts[$f['product_id']]['name'];
		}

		unset($f);

		$unseen = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->o('product') . " p WHERE p.status = '1'" . ($rows ? " AND p.product_id NOT IN (" . implode(',', array_map('intval', array_keys(array_filter($rows, function ($r) { return $r['visitors'] > 0; })) ?: array(0))) . ")" : ''))->row['n'];

		return array('days' => $days, 'range' => self::range($days), 'base' => $base, 'prev' => $pbase, 'flags' => $flags, 'products' => $list, 'unseen' => $unseen, 'currency' => $cur,
			'min_visitors' => (int)$cfg['min_visitors'], 'tracking' => (int)$cfg['tracking'], 'since' => $this->since());
	}

	public function since() {
		$q = $this->db->query("SELECT MIN(`day`) d FROM " . $this->t('day'));

		return $q->num_rows && $q->row['d'] ? $q->row['d'] : null;
	}

	public function product(array $in) {
		$pid = isset($in['product_id']) ? (int)$in['product_id'] : 0;
		$cfg = $this->getConfig();
		$days = isset($in['days']) && in_array((int)$in['days'], array(7, 30, 90), true) ? (int)$in['days'] : (int)$cfg['period'];
		$facts = $this->facts(array($pid));

		if (!isset($facts[$pid])) {
			throw new Exception('Product not found.');
		}

		$all = $this->rows($days);
		$base = self::baseline($all);
		$row = isset($all[$pid]) ? $all[$pid] : self::derive(array('product_id' => $pid, 'raw' => 0, 'views' => 0, 'visitors' => 0, 'time_sum' => 0, 'time_n' => 0, 'desc_seen' => 0, 'desc_read' => 0, 'specs' => 0, 'reviews' => 0, 'photos' => 0, 'adds' => 0, 'add_visitors' => 0, 'removes' => 0, 'hunt_visitors' => 0, 'hunt_adds' => 0, 'checkouts' => 0, 'orders' => 0, 'units' => 0, 'revenue' => 0.0));
		$cur = $this->currency();
		$flags = array_values(array_filter(self::flags($all, $base, $facts, $cfg, $cur), function ($f) use ($pid) { return $f['product_id'] === $pid; }));

		list($from, $to) = self::range($days);
		$daily = array();

		for ($d = strtotime($from); $d <= strtotime($to); $d += 86400) {
			$daily[date('Y-m-d', $d)] = array('day' => date('Y-m-d', $d), 'visitors' => 0, 'adds' => 0, 'orders' => 0, 'raw' => 0);
		}

		foreach ($this->db->query("SELECT `day`, visitors, add_visitors, raw FROM " . $this->t('day') . " WHERE product_id = '" . $pid . "' AND `day` BETWEEN '" . $from . "' AND '" . $to . "'")->rows as $r) {
			if (isset($daily[$r['day']])) {
				$daily[$r['day']]['visitors'] = (int)$r['visitors'];
				$daily[$r['day']]['adds'] = (int)$r['add_visitors'];
				$daily[$r['day']]['raw'] = (int)$r['raw'];
			}
		}

		$paid = implode(',', $this->paidStatuses());

		foreach ($this->db->query("SELECT DATE(o.date_added) d, COUNT(DISTINCT o.order_id) n FROM " . $this->o('order_product') . " op JOIN " . $this->o('order') . " o ON o.order_id = op.order_id
			WHERE op.product_id = '" . $pid . "' AND o.order_status_id IN (" . $paid . ") AND o.date_added >= '" . $from . " 00:00:00' GROUP BY DATE(o.date_added)")->rows as $r) {
			if (isset($daily[$r['d']])) {
				$daily[$r['d']]['orders'] = (int)$r['n'];
			}
		}

		$checks = array_map(function ($c) { return array('key' => $c[0], 'level' => $c[1], 'text' => $c[2]); }, self::checks($facts[$pid], $cur));

		return array('days' => $days, 'product' => $facts[$pid], 'row' => $row, 'base' => $base, 'flags' => $flags, 'checks' => $checks, 'daily' => array_values($daily), 'currency' => $cur);
	}

	public function bootstrap() {
		return array('config' => $this->publicConfig(), 'defaults' => array_diff_key(self::defaults(), array('salt' => 1)), 'since' => $this->since(), 'oc' => $this->oc);
	}
}
}
