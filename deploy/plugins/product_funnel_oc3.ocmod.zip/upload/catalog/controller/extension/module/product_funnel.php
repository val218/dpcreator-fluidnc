<?php
/**
 * Product Funnel for OpenCart 3.0.x - shop side: counts product page requests, adds the product page script,
 * and counts add to cart / remove from cart. Hooked in with OpenCart events, so no theme or core file is changed.
 * Never breaks a page: every hook gives up quietly on an error.
 */
class ControllerExtensionModuleProductFunnel extends Controller {
	private static $service = null;

	private function core() {
		if (!self::$service) {
			require_once(DIR_SYSTEM . 'library/productfunnel/Service.php');
			require_once(DIR_SYSTEM . 'library/productfunnel/Ui.php');
			self::$service = new PfnService($this->db, DB_PREFIX, 3);
		}

		return self::$service;
	}

	private function server($k) {
		return isset($this->request->server[$k]) ? html_entity_decode((string)$this->request->server[$k], ENT_QUOTES, 'UTF-8') : '';
	}

	private function who() {
		return array(
			'ua'    => $this->server('HTTP_USER_AGENT'),
			'staff' => isset($this->request->cookie['pfn_staff']),
			'hunt'  => !empty($this->session->data['th_hunting']),
			'dnt'   => $this->server('HTTP_DNT') === '1' || $this->server('HTTP_SEC_GPC') === '1'
		);
	}

	private function quiet($fn) {
		set_error_handler(function () { return true; });

		try {
			$fn();
		} catch (\Throwable $e) {
		} finally {
			restore_error_handler();
		}
	}

	public function eventRaw(&$route, &$args) {
		$self = $this;
		$this->quiet(function () use ($self) {
			if ($self->server('REQUEST_METHOD') === 'GET' && !empty($self->request->get['product_id']) && empty($self->request->cookie['pfn_staff'])) {
				$self->core()->raw((int)$self->request->get['product_id']);
			}
		});
	}

	public function eventScript(&$route, &$data, &$output) {
		$self = $this;
		$this->quiet(function () use ($self, &$data, &$output) {
			$pid = isset($data['product_id']) ? (int)$data['product_id'] : (isset($self->request->get['product_id']) ? (int)$self->request->get['product_id'] : 0);

			if (!$pid || !is_string($output) || !$self->core()->getConfig()['tracking']) {
				return;
			}

			$url = html_entity_decode($self->url->link('extension/module/product_funnel/beacon', '', true), ENT_QUOTES, 'UTF-8');
			$output = PfnUi::inject($output, PfnUi::script($self->core()->pageConfig($pid, $url)));
		});
	}

	public function eventAdded(&$route, &$args, &$output) {
		$self = $this;
		$this->quiet(function () use ($self) {
			$json = json_decode((string)$self->response->getOutput(), true);

			if (!is_array($json) || empty($json['success']) || empty($self->request->post['product_id'])) {
				return;
			}

			$xhr = strtolower($self->server('HTTP_X_REQUESTED_WITH')) === 'xmlhttprequest' || $self->server('HTTP_SEC_FETCH_MODE') === 'cors';
			$self->core()->added($self->session->getId(), (int)$self->request->post['product_id'], $xhr, $self->who());
		});
	}

	public function eventRemove(&$route, &$args) {
		$self = $this;
		$this->quiet(function () use ($self) {
			$key = isset($self->request->post['key']) ? $self->request->post['key'] : 0;
			$self->core()->removing($self->session->getId(), (int)$key, $self->who());
		});
	}

	public function beacon() {
		$self = $this;
		$this->quiet(function () use ($self) {
			if ($self->server('REQUEST_METHOD') === 'POST') {
				$self->core()->beacon($self->session->getId(), $self->request->post, $self->who());
			}
		});

		$this->response->addHeader('Content-Type: text/plain; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->addHeader('X-Robots-Tag: noindex');
		$this->response->setOutput('ok');
	}
}
