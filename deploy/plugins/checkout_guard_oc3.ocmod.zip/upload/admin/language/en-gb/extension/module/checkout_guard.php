<?php
$_['heading_title'] = 'Checkout Guard: stop card-testing bots at checkout';
$_['text_menu']     = 'Checkout Guard';
$_['text_home']     = 'Home';
