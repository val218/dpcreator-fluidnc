<?php
/**
 * Checkout Guard for OpenCart 3.0.x - thin adapter around the shared core in system/library/checkoutguard.
 * No core or theme files are modified: the shop side is hooked in with OpenCart events.
 */
class ControllerExtensionModuleCheckoutGuard extends Controller {
	const ROUTE = 'extension/module/checkout_guard';
	const CODE = 'checkout_guard';

	private function core() {
		require_once(DIR_SYSTEM . 'library/checkoutguard/Service.php');
		require_once(DIR_SYSTEM . 'library/checkoutguard/Ui.php');

		return new CgService($this->db, DB_PREFIX, 3);
	}

	public function index() {
		$this->load->language(self::ROUTE);
		$this->document->setTitle($this->language->get('heading_title'));
		$t = 'user_token=' . $this->session->data['user_token'];

		$data['heading_title'] = $this->language->get('heading_title');
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', $t, true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link(self::ROUTE, $t, true))
		);
		$this->core()->ensureTables();
		$this->ensureEvents();
		$api = html_entity_decode($this->url->link(self::ROUTE . '/api', $t, true), ENT_QUOTES, 'UTF-8');
		$data['body'] = CgUi::page($api, 3, array('orders' => html_entity_decode($this->url->link('sale/order', $t, true), ENT_QUOTES, 'UTF-8')));
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	public function api() {
		$service = $this->core();
		$user = $this->user;
		$action = isset($this->request->get['action']) ? preg_replace('/[^a-z_]/', '', $this->request->get['action']) : '';
		$json = CgUi::api($service, $action, function ($perm) use ($user) {
			return $user->hasPermission($perm, ControllerExtensionModuleCheckoutGuard::ROUTE);
		});

		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput($json);
	}

	private function events() {
		return array(
			array('admin/view/common/column_left/before', self::ROUTE . '/eventMenu'),
			array('catalog/controller/extension/payment/*/before', self::ROUTE . '/eventBefore'),
			array('catalog/controller/extension/payment/*/after', self::ROUTE . '/eventAfter'),
			array('catalog/view/common/footer/after', self::ROUTE . '/eventScript')
		);
	}

	public function install() {
		$this->core()->install();
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `key` = 'module_checkout_guard_status'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = '0', `code` = 'module_checkout_guard', `key` = 'module_checkout_guard_status', `value` = '1', serialized = '0'");
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);

		foreach ($this->events() as $e) {
			$this->model_setting_event->addEvent(self::CODE, $e[0], $e[1]);
		}
	}

	private function ensureEvents() {
		$have = array_column($this->db->query("SELECT `trigger` FROM `" . DB_PREFIX . "event` WHERE `code` = '" . self::CODE . "'")->rows, 'trigger');
		$this->load->model('setting/event');

		foreach ($this->events() as $e) {
			if (!in_array($e[0], $have, true)) {
				$this->model_setting_event->addEvent(self::CODE, $e[0], $e[1]);
			}
		}
	}

	public function uninstall() {
		$this->core()->uninstall();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
	}

	public function eventMenu(&$route, &$data) {
		if (empty($data['menus']) || !$this->user->hasPermission('access', self::ROUTE)) {
			return;
		}

		$item = array('name' => 'Checkout Guard', 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true), 'children' => array());

		foreach (array('menu-system', 'menu-report') as $want) {
			foreach ($data['menus'] as &$menu) {
				if (isset($menu['id']) && $menu['id'] === $want) {
					$menu['children'][] = $item;

					return;
				}
			}

			unset($menu);
		}

		$data['menus'][] = array('id' => 'menu-checkout-guard', 'icon' => 'fa-shield', 'name' => 'Checkout Guard', 'href' => $item['href'], 'children' => array());
	}
}
