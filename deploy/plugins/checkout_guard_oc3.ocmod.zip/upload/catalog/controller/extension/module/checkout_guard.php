<?php
/**
 * Checkout Guard for OpenCart 3.0.x - shop side: checks every payment request (any payment extension) before it
 * runs, counts declined cards after it, and adds the small browser check script. Never breaks a page.
 */
class ControllerExtensionModuleCheckoutGuard extends Controller {
	private static $service = null;
	private static $ctx = null;
	private static $script = false;

	private function core() {
		if (!self::$service) {
			require_once(DIR_SYSTEM . 'library/checkoutguard/Service.php');
			require_once(DIR_SYSTEM . 'library/checkoutguard/Ui.php');
			self::$service = new CgService($this->db, DB_PREFIX, 3);
		}

		return self::$service;
	}

	private function server($k) {
		return isset($this->request->server[$k]) ? html_entity_decode((string)$this->request->server[$k], ENT_QUOTES, 'UTF-8') : '';
	}

	private function isMain($route) {
		return isset($this->request->get['route']) && (string)$this->request->get['route'] === (string)$route;
	}

	private function email() {
		if ($this->customer->isLogged()) {
			return (string)$this->customer->getEmail();
		}

		foreach (array(array('guest', 'email'), array('payment_address', 'email')) as $k) {
			if (!empty($this->session->data[$k[0]][$k[1]])) {
				return (string)$this->session->data[$k[0]][$k[1]];
			}
		}

		return isset($this->request->post['email']) ? (string)$this->request->post['email'] : '';
	}

	private function ctx($route) {
		$server = array();

		foreach (array('REMOTE_ADDR', 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR') as $k) {
			$server[$k] = $this->server($k);
		}

		$sid = $this->session->getId();

		return array(
			'ip'          => $this->core()->ip($server),
			'sess'        => $this->core()->sessionKey($sid),
			'email'       => $this->email(),
			'customer_id' => (int)$this->customer->getId(),
			'ua'          => $this->server('HTTP_USER_AGENT'),
			'bin'         => CgService::bin($this->request->post),
			'gateway'     => CgService::gateway($route),
			'challenge'   => $this->core()->challengeOk($sid, isset($this->request->cookie['cg_ok']) ? $this->request->cookie['cg_ok'] : '')
		);
	}

	/** catalog/controller/extension/payment/{any}/before */
	public function eventBefore(&$route, &$args) {
		set_error_handler(function () { return true; });

		try {
			if ($this->server('REQUEST_METHOD') !== 'POST' || !$this->isMain($route) || !$this->core()->watched($route)) {
				return null;
			}

			self::$ctx = $this->ctx($route);
			$block = $this->core()->check(self::$ctx);

			if ($block) {
				self::$ctx = null;
				$this->response->addHeader('Content-Type: application/json; charset=utf-8');
				$this->response->addHeader('Cache-Control: no-store');
				$this->response->setOutput(CgUi::blocked($block[1]));

				// Anything but null stops OpenCart 3 from running the payment controller.
				return true;
			}
		} catch (\Throwable $e) {
		} finally {
			restore_error_handler();
		}

		return null;
	}

	/** catalog/controller/extension/payment/{any}/after */
	public function eventAfter(&$route, &$args, &$output) {
		set_error_handler(function () { return true; });

		try {
			if (!self::$ctx || !$this->isMain($route)) {
				return null;
			}

			$ctx = self::$ctx;
			self::$ctx = null;
			$answer = is_string($output) && $output !== '' ? $output : (string)$this->response->getOutput();
			$alert = $this->core()->result($ctx, $answer);

			if ($alert) {
				$this->alert($alert);
			}
		} catch (\Throwable $e) {
		} finally {
			restore_error_handler();
		}

		return null;
	}

	private function alert($a) {
		try {
			if (!$this->config->get('config_mail_engine')) {
				return;
			}

			$cfg = $this->core()->getConfig();
			$to = $cfg['alert_email'] ? $cfg['alert_email'] : (string)$this->config->get('config_email');
			$shop = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
			$admin = (defined('HTTP_SERVER') ? HTTP_SERVER : '') . 'admin/';
			$m = CgUi::alertMail($a, $shop, $admin);
			$mail = new Mail($this->config->get('config_mail_engine'));
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			$mail->setTo($to);
			$mail->setFrom($this->config->get('config_email'));
			$mail->setSender($shop);
			$mail->setSubject($m['subject']);
			$mail->setHtml($m['html']);
			$mail->setText($m['text']);
			$mail->send();
		} catch (\Throwable $e) {
		}
	}

	/** catalog/view/common/footer/after: the browser check. */
	public function eventScript(&$route, &$data, &$output) {
		set_error_handler(function () { return true; });

		try {
			if (self::$script || !is_string($output) || !$this->core()->getConfig()['enabled']) {
				return null;
			}

			self::$script = true;
			$output = CgUi::inject($output, CgUi::script($this->core()->challengeToken($this->session->getId())));
		} catch (\Throwable $e) {
		} finally {
			restore_error_handler();
		}

		return null;
	}
}
