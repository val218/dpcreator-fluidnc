/* Checkout Guard - browser check: sets a short-lived cookie only after a person moves, touches, scrolls or types. */
(function(){try{var T=window.CG_T;if(!T||window.__cgOn||navigator.webdriver)return;window.__cgOn=1;
var ev=['mousemove','pointerdown','touchstart','keydown','wheel','scroll'],done=0;
function ok(){if(done)return;done=1;ev.forEach(function(e){removeEventListener(e,ok,true);});setTimeout(function(){document.cookie='cg_ok='+T+';path=/;max-age=86400;SameSite=Lax'+(location.protocol==='https:'?';Secure':'');},600);}
ev.forEach(function(e){addEventListener(e,ok,{capture:true,passive:true});});}catch(e){}})();
