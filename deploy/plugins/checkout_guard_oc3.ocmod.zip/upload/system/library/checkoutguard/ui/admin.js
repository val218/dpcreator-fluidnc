/* Checkout Guard - admin page */
(function () {
	'use strict';
	var B = window.CG_ADMIN || {}, root = document.getElementById('cg-root');
	if (!root) return;
	var S = {tab: 'overview', boot: null, ov: null, cfg: null, log: null, kind: 'block', q: '', page: 1};

	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
	function api(action, body) {
		return fetch(B.api + (B.api.indexOf('?') < 0 ? '?' : '&') + 'action=' + action, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})})
			.then(function (r) { return r.text(); }).then(function (t) {
				var j; try { j = JSON.parse(t); } catch (e) { throw new Error('The server answered with something that is not JSON: ' + t.replace(/<[^>]+>/g, ' ').slice(0, 200)); }
				if (j.error) throw new Error(j.error); return j.data;
			});
	}
	function toast(m, bad) { var t = document.createElement('div'); t.className = 'cg-toast' + (bad ? ' bad' : ''); t.textContent = m; root.appendChild(t); setTimeout(function () { t.remove(); }, bad ? 6000 : 2600); }
	function n(v) { return Number(v || 0).toLocaleString(); }

	function frame(body) {
		var h = '<div class="cg-tabs">';
		[['overview', 'Overview'], ['log', 'Log'], ['settings', 'Settings']].forEach(function (t) { h += '<button data-tab="' + t[0] + '" class="' + (S.tab === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; });
		root.innerHTML = h + '</div>' + body;
	}

	function renderOverview() {
		var o = S.ov, c = S.cfg, h = '';
		if (!o.enabled) h += '<div class="cg-banner off"><b>Checkout Guard is off.</b> Payments are not checked. Switch it on in Settings.</div>';
		else if (o.attack) h += '<div class="cg-banner bad"><div class="grow"><b>Under attack mode is on' + (o.attack_until ? ' until ' + esc(o.attack_until.slice(11)) : '') + '.</b> ' + (c.attack_action === 'login' ? 'Guests must log in to pay.' : 'Every payment needs a real browser that passes the check.') + '</div><button class="cg-btn" data-attack="0">Turn off</button></div>';
		else h += '<div class="cg-banner ok"><div class="grow"><b>Checkout is protected.</b> ' + (c.attack_mode === 'auto' ? 'Under attack mode switches on by itself when ' + c.attack_declines + ' cards are declined within 10 minutes.' : (c.attack_mode === 'off' ? 'Under attack mode will not switch on by itself.' : '')) + '</div><button class="cg-btn" data-attack="1">Under attack: turn on for ' + c.attack_minutes + ' min</button></div>';
		var d = o.day, w = o.week;
		h += '<div class="cg-kpis">' + [[d.attempt + d.decline, 'payment attempts today', 'last 24 hours'], [d.decline, 'cards declined', 'last 24 hours'], [d.block, 'attempts blocked', 'last 24 hours'], [o.unpaid_day, 'unfinished orders', 'last 24 hours, "missing orders"'], [w.block, 'blocked this week', '']].map(function (k) { return '<div class="cg-card"><b>' + n(k[0]) + '</b><span>' + k[1] + '</span>' + (k[2] ? '<em>' + k[2] + '</em>' : '') + '</div>'; }).join('') + '</div>';
		var max = 1;
		o.hours.forEach(function (x) { max = Math.max(max, x.attempt + x.decline + x.block); });
		h += '<div class="cg-card"><h4>Last 24 hours</h4><div class="cg-bars">';
		o.hours.forEach(function (x) {
			var tot = x.attempt + x.decline + x.block;
			h += '<div title="' + x.h + ':00 · ' + x.attempt + ' attempts, ' + x.decline + ' declined, ' + x.block + ' blocked"><span class="stack" style="height:' + (100 * tot / max) + '%"><i class="b" style="flex:' + x.block + '"></i><i class="d" style="flex:' + x.decline + '"></i><i class="a" style="flex:' + x.attempt + '"></i></span><small>' + x.h + '</small></div>';
		});
		h += '</div><div class="cg-legend"><span><i class="a"></i>Attempts</span><span><i class="d"></i>Declined</span><span><i class="b"></i>Blocked</span></div></div>';
		h += '<div class="cg-two"><div class="cg-card"><h4>Why attempts were blocked (7 days)</h4>' + (o.reasons.length ? '<table class="cg-t">' + o.reasons.map(function (r) { return '<tr><td>' + esc(r.text) + '</td><td class="num">' + n(r.n) + '</td></tr>'; }).join('') + '</table>' : '<p class="muted">Nothing blocked. Quiet is good.</p>') + '</div>';
		h += '<div class="cg-card"><h4>Most declines and blocks (7 days)</h4>' + (o.top.length ? '<table class="cg-t"><tr><th>IP</th><th class="num">Declined</th><th class="num">Blocked</th><th></th></tr>' + o.top.map(function (t) {
			return '<tr><td><span class="mono">' + esc(t.ip) + '</span>' + (t.host ? '<div class="muted small">' + esc(t.host) + (+t.dc ? ' · data centre' : '') + '</div>' : '') + '</td><td class="num">' + n(t.declines) + '</td><td class="num">' + n(t.blocks) + '</td><td class="acts">'
				+ (+t.denied ? '<button class="cg-btn sm" data-list="deny" data-remove="1" data-value="' + esc(t.ip) + '">Unblock</button>' : '<button class="cg-btn sm danger" data-list="deny" data-value="' + esc(t.ip) + '">Block</button>')
				+ (+t.allowed ? '<button class="cg-btn sm" data-list="allow" data-remove="1" data-value="' + esc(t.ip) + '">Remove allow</button>' : '<button class="cg-btn sm" data-list="allow" data-value="' + esc(t.ip) + '">Allow</button>') + '</td></tr>';
		}).join('') + '</table>' : '<p class="muted">No declined cards.</p>') + '</div></div>';
		h += '<p class="muted small">Checkout Guard stops card testing that goes through your checkout. Bots can also call Stripe or PayPal directly with your public key: for that, use Stripe Radar or your provider\'s own protection.</p>';
		frame(h);
	}

	function renderLog() {
		var L = S.log, h = '<div class="cg-row"><div class="cg-seg">';
		[['block', 'Blocked'], ['decline', 'Declined'], ['attempt', 'Attempts'], ['', 'All']].forEach(function (k) { h += '<button data-kind="' + k[0] + '" class="' + (S.kind === k[0] ? 'on' : '') + '">' + k[1] + '</button>'; });
		h += '</div><input type="text" id="cg-q" placeholder="IP, email, card BIN or gateway" value="' + esc(S.q) + '"><span class="muted">' + (L ? n(L.total) + ' entries' : '') + '</span></div>';
		if (!L) { frame(h + '<div class="cg-loading">Loading…</div>'); return; }
		h += '<div class="cg-card flush"><table class="cg-t"><tr><th>When</th><th>What</th><th>IP</th><th>Email</th><th>Card BIN</th><th>Payment</th><th></th></tr>';
		L.rows.forEach(function (r) {
			h += '<tr class="' + r.kind + '"><td class="nowrap">' + esc(r.created.slice(5, 16)) + '</td><td><span class="pill ' + r.kind + '">' + (r.kind === 'block' ? 'Blocked' : r.kind === 'decline' ? 'Declined' : 'Attempt') + '</span> ' + esc(r.text) + '</td><td class="mono">' + esc(r.ip) + '</td><td>' + esc(r.email) + '</td><td class="mono">' + esc(r.bin) + '</td><td>' + esc(r.gateway) + '</td><td>' + (r.ip && r.kind !== 'attempt' ? '<button class="cg-btn sm" data-list="allow" data-value="' + esc(r.ip) + '">Allow IP</button>' : '') + '</td></tr>';
		});
		if (!L.rows.length) h += '<tr><td colspan="7" class="muted">Nothing here.</td></tr>';
		h += '</table></div>';
		if (L.total > L.per) h += '<div class="cg-row end"><button class="cg-btn sm" data-page="' + (L.page - 1) + '"' + (L.page <= 1 ? ' disabled' : '') + '>‹</button><span class="muted">' + L.page + ' / ' + Math.ceil(L.total / L.per) + '</span><button class="cg-btn sm" data-page="' + (L.page + 1) + '"' + (L.page * L.per >= L.total ? ' disabled' : '') + '>›</button></div>';
		frame(h);
		var q = document.getElementById('cg-q'), tm;
		q.oninput = function () { clearTimeout(tm); tm = setTimeout(function () { S.q = q.value; S.page = 1; loadLog(true); }, 300); };
	}

	function loadLog(keepFocus) {
		api('events', {kind: S.kind, q: S.q, page: S.page}).then(function (r) {
			S.log = r; renderLog();
			if (keepFocus) { var q = document.getElementById('cg-q'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }
		}).catch(function (e) { toast(e.message, true); });
	}

	function num(id, label, help) { return '<label class="f"><span>' + label + '</span><input type="number" id="s-' + id + '" value="' + esc(S.cfg[id]) + '">' + (help ? '<em>' + help + '</em>' : '') + '</label>'; }

	function renderSettings() {
		var c = S.cfg;
		var h = '<div class="cg-two"><div>'
			+ '<div class="cg-card"><h4>Protection</h4><label class="ck"><input type="checkbox" id="s-enabled"' + (c.enabled ? ' checked' : '') + '> Check payments at checkout</label>'
			+ '<label class="ck"><input type="checkbox" id="s-block_bots"' + (c.block_bots ? ' checked' : '') + '> Block bots and scripts at payment</label>'
			+ '<label class="ck"><input type="checkbox" id="s-challenge_dc"' + (c.challenge_dc ? ' checked' : '') + '> Visitors from data-centre networks must pass the browser check <em>A person with a normal browser passes without noticing. Most card-testing scripts run on rented servers.</em></label></div>'
			+ '<div class="cg-card"><h4>Limits</h4><div class="cg-grid">' + num('ip_declines', 'Declined cards per IP', 'within the block time') + num('session_declines', 'Declined cards per visit', '') + num('email_declines', 'Declined cards per email', '') + num('bin_sessions', 'Visitors declined on one card range (BIN)', 'only gateways that send the card through your shop')
			+ num('ip_attempts', 'Payment attempts per IP', 'in 10 minutes') + num('session_attempts', 'Payment attempts per visit', 'in 10 minutes') + num('block_minutes', 'Block time (minutes)', 'how long the decline limits look back') + '</div>'
			+ '<p class="muted small">The defaults let a real customer retry a declined card two or three times without being blocked.</p></div></div><div>'
			+ '<div class="cg-card"><h4>Under attack mode</h4><label class="f"><span>Switch on</span><select id="s-attack_mode"><option value="auto"' + (c.attack_mode === 'auto' ? ' selected' : '') + '>By itself, on a spike of declined cards</option><option value="on"' + (c.attack_mode === 'on' ? ' selected' : '') + '>Always on</option><option value="off"' + (c.attack_mode === 'off' ? ' selected' : '') + '>Never</option></select></label>'
			+ '<div class="cg-grid">' + num('attack_declines', 'Declined cards in 10 minutes', 'across the whole shop') + num('attack_minutes', 'Stay on for (minutes)', '') + '</div>'
			+ '<label class="f"><span>While under attack</span><select id="s-attack_action"><option value="challenge"' + (c.attack_action === 'challenge' ? ' selected' : '') + '>Every payment needs the browser check</option><option value="login"' + (c.attack_action === 'login' ? ' selected' : '') + '>Guests must log in to pay</option></select></label>'
			+ '<label class="f"><span>Alert email</span><input type="text" id="s-alert_email" value="' + esc(c.alert_email) + '" placeholder="the shop email"><em>Sent when under attack mode switches on, at most once an hour.</em></label></div>'
			+ '<div class="cg-card"><h4>Lists</h4><label class="f"><span>Never limit (IPs, ranges, emails)</span><textarea id="s-allow" rows="3" placeholder="203.0.113.7&#10;10.0.0.0/8&#10;office@example.com">' + esc(c.allow) + '</textarea></label>'
			+ '<label class="f"><span>Always block at payment (IPs, ranges)</span><textarea id="s-deny" rows="3">' + esc(c.deny) + '</textarea></label></div>'
			+ '<div class="cg-card"><h4>Advanced</h4><label class="f"><span>Visitor IP comes from</span><select id="s-ip_header"><option value=""' + (!c.ip_header ? ' selected' : '') + '>The connection (default)</option><option value="cf"' + (c.ip_header === 'cf' ? ' selected' : '') + '>Cloudflare (CF-Connecting-IP)</option><option value="xff"' + (c.ip_header === 'xff' ? ' selected' : '') + '>Load balancer (X-Forwarded-For)</option></select><em>Only change this if your shop is behind Cloudflare or a load balancer. Otherwise every visitor looks like the same IP.</em></label>'
			+ '<label class="f"><span>Payment calls never checked</span><input type="text" id="s-skip_methods" value="' + esc(c.skip_methods) + '"><em>Calls the payment provider makes to your shop (webhooks, callbacks).</em></label>'
			+ num('keep_days', 'Keep the log for (days)', '') + '</div></div></div>'
			+ '<div class="cg-row"><button class="cg-btn pri" id="s-save">Save settings</button><button class="cg-btn danger" id="s-clear">Delete the log</button></div>'
			+ '<p class="muted small">Checkout Guard ' + esc(B.version) + '. It works on the payment requests that go through your shop, for any payment extension, and never changes core files.</p>';
		frame(h);
		document.getElementById('s-save').onclick = function () {
			var body = {};
			['enabled', 'block_bots', 'challenge_dc'].forEach(function (k) { body[k] = document.getElementById('s-' + k).checked ? 1 : 0; });
			['ip_declines', 'session_declines', 'email_declines', 'bin_sessions', 'ip_attempts', 'session_attempts', 'block_minutes', 'attack_declines', 'attack_minutes', 'keep_days'].forEach(function (k) { body[k] = +document.getElementById('s-' + k).value; });
			['attack_mode', 'attack_action', 'alert_email', 'allow', 'deny', 'ip_header', 'skip_methods'].forEach(function (k) { body[k] = document.getElementById('s-' + k).value; });
			api('save_settings', body).then(function (r) { S.cfg = r.config; S.ov = r.overview; toast('Settings saved'); renderSettings(); }).catch(function (e) { toast(e.message, true); });
		};
		document.getElementById('s-clear').onclick = function () {
			if (this.dataset.sure !== '1') { this.dataset.sure = '1'; this.textContent = 'Click again to delete'; return; }
			api('clear_all').then(function (o) { S.ov = o; toast('Log deleted'); }).catch(function (e) { toast(e.message, true); });
		};
	}

	function render() { if (S.tab === 'log') { if (!S.log) loadLog(); renderLog(); } else if (S.tab === 'settings') renderSettings(); else renderOverview(); }

	root.addEventListener('click', function (e) {
		var t = e.target.closest('button');
		if (!t) return;
		var d = t.dataset;
		if (d.tab) { S.tab = d.tab; if (d.tab === 'overview') api('overview').then(function (o) { S.ov = o; render(); }); render(); }
		else if (d.attack !== undefined) api('attack', {on: +d.attack}).then(function (o) { S.ov = o; toast(+d.attack ? 'Under attack mode is on' : 'Under attack mode is off'); renderOverview(); }).catch(function (x) { toast(x.message, true); });
		else if (d.kind !== undefined) { S.kind = d.kind; S.page = 1; loadLog(); }
		else if (d.page) { S.page = +d.page; loadLog(); }
		else if (d.list) api('list_edit', {list: d.list, value: d.value, remove: d.remove ? 1 : 0}).then(function (r) { S.ov = r.overview; S.cfg = r.config; toast(d.remove ? 'Removed' : (d.list === 'allow' ? d.value + ' will never be limited' : d.value + ' is blocked at payment')); render(); }).catch(function (x) { toast(x.message, true); });
	});

	api('bootstrap').then(function (b) { S.boot = b; S.cfg = b.config; S.ov = b.overview; render(); }).catch(function (e) { root.innerHTML = '<div class="cg-card bad">' + esc(e.message) + '</div>'; });
	setInterval(function () { if (S.tab === 'overview' && document.visibilityState === 'visible') api('overview').then(function (o) { S.ov = o; renderOverview(); }).catch(function () {}); }, 60000);
})();
