<?php
/**
 * Checkout Guard - admin API, admin page, the browser check script and the owner alert email.
 */
require_once(dirname(__FILE__) . '/Service.php');

if (!class_exists('CgUi')) {
class CgUi {
	const VERSION = '1.0.0';

	public static function writeActions() {
		return array('save_settings', 'attack', 'list_edit', 'clear_all');
	}

	public static function dispatch(CgService $s, $action, array $in) {
		$s->ensureTables();

		switch ($action) {
			case 'bootstrap':
				return $s->bootstrap();
			case 'overview':
				return $s->overview();
			case 'events':
				return $s->events($in);
			case 'save_settings':
				return array('config' => $s->saveConfig($in), 'overview' => $s->overview());
			case 'attack':
				return $s->attack($in);
			case 'list_edit':
				$o = $s->listEdit($in);

				return array('overview' => $o, 'config' => $s->publicConfig());
			case 'clear_all':
				$s->clearAll();

				return $s->overview();
		}

		throw new Exception('Unknown action: ' . $action);
	}

	public static function input() {
		$raw = file_get_contents('php://input');
		$in = $raw !== '' ? json_decode($raw, true) : array();

		return is_array($in) ? $in : array();
	}

	public static function json($payload) {
		return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_INVALID_UTF8_SUBSTITUTE);
	}

	public static function api(CgService $s, $action, $can) {
		$perm = in_array($action, self::writeActions(), true) ? 'modify' : 'access';

		if (!call_user_func($can, $perm)) {
			return self::json(array('error' => 'Permission denied: your user group needs "' . $perm . '" permission for Checkout Guard (System > Users > User Groups).'));
		}

		try {
			return self::json(array('ok' => true, 'data' => self::dispatch($s, $action, self::input())));
		} catch (Exception $e) {
			return self::json(array('error' => $e->getMessage()));
		} catch (Error $e) {
			return self::json(array('error' => 'Server error: ' . $e->getMessage()));
		}
	}

	public static function page($api_url, $oc_major, array $links) {
		$boot = array('api' => $api_url, 'oc' => (int)$oc_major, 'version' => self::VERSION, 'links' => $links);
		$dir = dirname(__FILE__) . '/ui/';

		return '<div id="cg-root" class="cg"><div class="cg-loading">Loading…</div></div>'
			. '<style>' . file_get_contents($dir . 'admin.css') . '</style>'
			. '<script>window.CG_ADMIN=' . json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . ';</script>'
			. '<script>' . file_get_contents($dir . 'admin.js') . '</script>';
	}

	public static function script($token) {
		return '<script>window.CG_T=' . json_encode((string)$token) . ';</script><script>' . file_get_contents(dirname(__FILE__) . '/ui/check.js') . '</script>';
	}

	public static function inject($html, $script) {
		$pos = strripos($html, '</body>');

		return $pos === false ? $html . $script : substr($html, 0, $pos) . $script . substr($html, $pos);
	}

	/** JSON answer for a blocked payment request: most payment extensions show "error" to the shopper. */
	public static function blocked($message) {
		return json_encode(array('error' => $message, 'error_warning' => $message, 'checkout_guard' => 1), JSON_UNESCAPED_UNICODE);
	}

	public static function alertMail(array $a, $shop, $admin_url) {
		$e = function ($t) { return htmlspecialchars((string)$t, ENT_QUOTES, 'UTF-8'); };
		$subject = 'Checkout Guard: possible card-testing attack on ' . $shop;
		$how = $a['action'] === 'login' ? 'guests must now log in to pay' : 'every payment now needs a real browser that passes the check';
		$html = '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.5;color:#1d2329;max-width:560px">'
			. '<p><b>' . (int)$a['declines'] . ' cards were declined in the last 10 minutes</b> at ' . $e($shop) . '. That is the usual sign of card testing: bots trying stolen card numbers.</p>'
			. '<p>Checkout Guard switched the shop to <b>under attack</b> mode until ' . $e($a['until']) . ': ' . $e($how) . '. Repeat offenders are blocked automatically.</p>'
			. '<p>What to do now:</p><ul><li>Look at the log to see where the attempts come from.</li><li>If you use Stripe, check Radar in your Stripe dashboard: bots can also call Stripe directly.</li><li>Tell your payment provider if the attack goes on: it protects your account standing.</li></ul>'
			. '<p><a href="' . $e($admin_url) . '">Open Checkout Guard</a></p></div>';

		return array('subject' => $subject, 'html' => $html, 'text' => strip_tags(str_replace(array('</p>', '</li>'), "\n", $html)));
	}
}
}
