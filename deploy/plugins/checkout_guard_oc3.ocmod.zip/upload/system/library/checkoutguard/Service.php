<?php
/**
 * Checkout Guard for OpenCart - stops card-testing bots at the checkout: limits payment attempts and declined cards
 * per IP, session, email and card BIN, blocks bots, challenges data-centre visitors, switches to "under attack" mode
 * on a spike of declines and emails the owner. Framework-free: the OpenCart 3 / 4 adapters pass in the DB object.
 */
if (!class_exists('CgService')) {
class CgService {
	const CONFIG_CODE = 'module_checkout_guard';
	const CONFIG_KEY = 'module_checkout_guard_config';

	const BOTS = '~(googlebot|bingbot|yandex|baiduspider|duckduckbot|applebot|slurp|facebookexternalhit|twitterbot|linkedinbot|ahrefs|semrush|mj12bot|dotbot|petalbot|bytespider|gptbot|claudebot|ccbot|amazonbot|crawler|spider|scraper|bot[/;\s)]|\bbot$|curl/|wget/|python|go-http-client|java/|okhttp|axios|node-fetch|undici|httpclient|libwww|guzzle|scrapy|headlesschrome|phantomjs|puppeteer|playwright|selenium|postman|insomnia)~i';
	const CLOUD = '~(amazonaws|compute\.internal|googleusercontent|cloudfront|azure|hetzner|your-server\.de|ovh|kimsufi|digitalocean|linode|akamai|contabo|vultr|choopa|scaleway|online\.net|leaseweb|hostinger|oraclecloud|alibaba|aliyun|tencent|m247|datacamp|cdn77|\bvps|dedicated|colocation|servers?\.com|hosting|cloud)~i';

	/** Payment routes that gateways call server to server, never checked. */
	const SKIP_METHODS = 'callback, webhook, notify, ipn, cron, return, status, response, success, failure, fail, cancel, acs, three, threedreturn, confirm3d, complete';

	const REASONS = array(
		'bot'          => 'Browser is a bot or script',
		'rate_ip'      => 'Too many payment attempts from this IP',
		'rate_session' => 'Too many payment attempts in this visit',
		'declines_ip'  => 'Too many declined cards from this IP',
		'declines_session' => 'Too many declined cards in this visit',
		'declines_email'   => 'Too many declined cards for this email',
		'declines_bin' => 'Card testing on this card range (BIN) from several visitors',
		'attack_login' => 'Under attack: guests must log in to pay',
		'attack_challenge' => 'Under attack: browser did not pass the check',
		'datacenter'   => 'Data-centre network and browser did not pass the check',
		'blocked_ip'   => 'IP is on your block list'
	);

	private $db;
	private $p;
	private $oc;
	private $config;

	public function __construct($db, $prefix, $oc_major) {
		$this->db = $db;
		$this->p = $prefix;
		$this->oc = (int)$oc_major;
	}

	private function e($s) {
		return $this->db->escape((string)$s);
	}

	private function t($name) {
		return '`' . $this->p . 'checkout_guard_' . $name . '`';
	}

	private function o($name) {
		return '`' . $this->p . $name . '`';
	}

	/* ------------------------------------------------ settings */

	public static function defaults() {
		return array(
			'enabled'          => 1,
			'ip_attempts'      => 12,   // payment attempts per IP in 10 minutes
			'session_attempts' => 8,    // per visit in 10 minutes
			'ip_declines'      => 5,    // declined cards per IP in 60 minutes
			'session_declines' => 4,
			'email_declines'   => 4,
			'bin_sessions'     => 4,    // different visitors with a declined card on the same BIN in 60 minutes
			'block_minutes'    => 60,
			'block_bots'       => 1,
			'challenge_dc'     => 1,    // data-centre networks must pass the browser check
			'attack_mode'      => 'auto', // off / on / auto
			'attack_action'    => 'challenge', // challenge / login
			'attack_declines'  => 15,   // declines in the whole shop in 10 minutes that switch on "under attack"
			'attack_minutes'   => 60,
			'alert_email'      => '',
			'ip_header'        => '',   // '' / cf / xff
			'skip_methods'     => self::SKIP_METHODS,
			'allow'            => '',   // IPs and emails never limited, one per line
			'deny'             => '',   // IPs always blocked at payment
			'keep_days'        => 30,
			'secret'           => '',
			'attack_until'     => 0,
			'alerted'          => 0
		);
	}

	public function getConfig() {
		if ($this->config !== null) {
			return $this->config;
		}

		$cfg = self::defaults();
		$q = $this->db->query("SELECT `value` FROM " . $this->o('setting') . " WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "' LIMIT 1");

		if ($q->num_rows) {
			$saved = json_decode($q->row['value'], true);

			if (is_array($saved)) {
				$cfg = array_merge($cfg, array_intersect_key($saved, $cfg));
			}
		}

		return $this->config = $cfg;
	}

	private function store(array $cfg) {
		$this->db->query("DELETE FROM " . $this->o('setting') . " WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "'");
		$this->db->query("INSERT INTO " . $this->o('setting') . " SET store_id = '0', `code` = '" . self::CONFIG_CODE . "', `key` = '" . self::CONFIG_KEY . "', `value` = '" . $this->e(json_encode($cfg)) . "', serialized = '0'");
		$this->config = $cfg;
	}

	public function publicConfig() {
		$c = $this->getConfig();
		unset($c['secret'], $c['alerted']);

		return $c;
	}

	public function saveConfig(array $in) {
		$cfg = $this->getConfig();
		$d = self::defaults();

		foreach (array('enabled', 'block_bots', 'challenge_dc') as $k) {
			if (array_key_exists($k, $in)) {
				$cfg[$k] = !empty($in[$k]) ? 1 : 0;
			}
		}

		$ranges = array('ip_attempts' => array(2, 500), 'session_attempts' => array(2, 500), 'ip_declines' => array(1, 100), 'session_declines' => array(1, 100), 'email_declines' => array(1, 100),
			'bin_sessions' => array(2, 100), 'block_minutes' => array(5, 1440), 'attack_declines' => array(3, 1000), 'attack_minutes' => array(10, 1440), 'keep_days' => array(7, 365));

		foreach ($ranges as $k => $r) {
			if (isset($in[$k])) {
				$cfg[$k] = max($r[0], min($r[1], (int)$in[$k]));
			}
		}

		if (isset($in['attack_mode']) && in_array($in['attack_mode'], array('off', 'on', 'auto'), true)) {
			$cfg['attack_mode'] = $in['attack_mode'];

			if ($in['attack_mode'] !== 'auto') {
				$cfg['attack_until'] = 0;
			}
		}

		if (isset($in['attack_action'])) {
			$cfg['attack_action'] = $in['attack_action'] === 'login' ? 'login' : 'challenge';
		}

		if (isset($in['ip_header'])) {
			$cfg['ip_header'] = in_array($in['ip_header'], array('cf', 'xff'), true) ? $in['ip_header'] : '';
		}

		if (isset($in['alert_email'])) {
			$em = trim((string)$in['alert_email']);

			if ($em !== '' && !filter_var($em, FILTER_VALIDATE_EMAIL)) {
				throw new Exception('"' . $em . '" is not an email address.');
			}

			$cfg['alert_email'] = $em;
		}

		foreach (array('allow', 'deny') as $k) {
			if (isset($in[$k])) {
				$lines = array();

				foreach (preg_split('/[\s,;]+/', (string)$in[$k]) as $l) {
					$l = strtolower(trim($l));

					if ($l === '') {
						continue;
					}

					if (!filter_var($l, FILTER_VALIDATE_EMAIL) && !preg_match('~^[0-9a-f:.*]+(/\d{1,3})?$~', $l)) {
						throw new Exception('"' . $l . '" is not an IP address, range (10.0.0.0/8, 192.168.*) or email.');
					}

					$lines[] = $l;
				}

				$cfg[$k] = implode("\n", array_unique($lines));
			}
		}

		if (isset($in['skip_methods'])) {
			$words = array_filter(array_map('trim', preg_split('/[\s,;]+/', strtolower((string)$in['skip_methods']))));
			$cfg['skip_methods'] = $words ? implode(', ', array_unique($words)) : $d['skip_methods'];
		}

		if ($cfg['secret'] === '') {
			$cfg['secret'] = bin2hex(function_exists('random_bytes') ? random_bytes(20) : uniqid('', true) . mt_rand());
		}

		$this->store($cfg);

		return $this->publicConfig();
	}

	/* ------------------------------------------------ install */

	public function install() {
		$this->ensureTables();
		$this->saveConfig(array());
	}

	public function uninstall() {
		$this->db->query("DELETE FROM " . $this->o('setting') . " WHERE `code` = '" . self::CONFIG_CODE . "'");
		$this->db->query("DROP TABLE IF EXISTS " . $this->t('event'));
		$this->db->query("DROP TABLE IF EXISTS " . $this->t('ip'));
	}

	public function ensureTables() {
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('event') . " (
			`event_id` INT(11) NOT NULL AUTO_INCREMENT,
			`kind` VARCHAR(10) NOT NULL,
			`reason` VARCHAR(24) NOT NULL DEFAULT '',
			`ip` VARCHAR(45) NOT NULL DEFAULT '',
			`sess` CHAR(16) NOT NULL DEFAULT '',
			`email` VARCHAR(96) NOT NULL DEFAULT '',
			`bin` CHAR(6) NOT NULL DEFAULT '',
			`gateway` VARCHAR(64) NOT NULL DEFAULT '',
			`message` VARCHAR(255) NOT NULL DEFAULT '',
			`created` DATETIME NOT NULL,
			PRIMARY KEY (`event_id`),
			KEY `created` (`created`, `kind`),
			KEY `ip` (`ip`, `created`),
			KEY `sess` (`sess`, `created`),
			KEY `email` (`email`, `created`),
			KEY `bin` (`bin`, `created`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
		// Network name of visitors who reached the payment step, kept a day, to spot data-centre traffic.
		$this->db->query("CREATE TABLE IF NOT EXISTS " . $this->t('ip') . " (
			`ip` VARCHAR(45) NOT NULL,
			`host` VARCHAR(255) NOT NULL DEFAULT '',
			`dc` TINYINT(1) NOT NULL DEFAULT 0,
			`checked` DATETIME NOT NULL,
			PRIMARY KEY (`ip`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	/* ------------------------------------------------ request helpers */

	/** The visitor's IP, from a trusted proxy header when the shop runs behind Cloudflare or a load balancer. */
	public function ip(array $server) {
		$cfg = $this->getConfig();
		$ip = isset($server['REMOTE_ADDR']) ? (string)$server['REMOTE_ADDR'] : '';

		if ($cfg['ip_header'] === 'cf' && !empty($server['HTTP_CF_CONNECTING_IP'])) {
			$ip = (string)$server['HTTP_CF_CONNECTING_IP'];
		} elseif ($cfg['ip_header'] === 'xff' && !empty($server['HTTP_X_FORWARDED_FOR'])) {
			$ip = trim(explode(',', (string)$server['HTTP_X_FORWARDED_FOR'])[0]);
		}

		return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
	}

	public static function isBot($ua) {
		$ua = trim((string)$ua);

		return $ua === '' || strlen($ua) < 25 || stripos($ua, 'mozilla/') === false || (bool)preg_match(self::BOTS, $ua);
	}

	public static function ipMatches($ip, $rule) {
		$rule = trim($rule);

		if ($rule === '' || $ip === '') {
			return false;
		}

		if (strpos($rule, '*') !== false) {
			return (bool)preg_match('/^' . str_replace('\*', '.*', preg_quote($rule, '/')) . '$/i', $ip);
		}

		if (strpos($rule, '/') !== false) {
			list($net, $bits) = explode('/', $rule, 2);
			$a = @inet_pton($ip);
			$b = @inet_pton($net);

			if ($a === false || $b === false || strlen($a) !== strlen($b)) {
				return false;
			}

			$bits = (int)$bits;
			$bytes = intdiv($bits, 8);
			$rest = $bits % 8;

			if (substr($a, 0, $bytes) !== substr($b, 0, $bytes)) {
				return false;
			}

			if ($rest) {
				$mask = chr((0xff << (8 - $rest)) & 0xff);

				return (ord($a[$bytes]) & ord($mask)) === (ord($b[$bytes]) & ord($mask));
			}

			return true;
		}

		return strcasecmp($ip, $rule) === 0;
	}

	private function listed($key, $ip, $email) {
		foreach (preg_split('/\s+/', (string)$this->getConfig()[$key]) as $rule) {
			if ($rule === '') {
				continue;
			}

			if (strpos($rule, '@') !== false ? ($email !== '' && strcasecmp($rule, $email) === 0) : self::ipMatches($ip, $rule)) {
				return true;
			}
		}

		return false;
	}

	public function sessionKey($session_id) {
		return substr(hash_hmac('sha256', 's|' . $session_id, $this->secret()), 0, 16);
	}

	private function secret() {
		$c = $this->getConfig();

		if ($c['secret'] === '') {
			$this->saveConfig(array());
			$c = $this->getConfig();
		}

		return $c['secret'];
	}

	/** The browser check: the page script sets this cookie only after someone moved, touched or typed. */
	public function challengeToken($session_id) {
		return substr(hash_hmac('sha256', 'c|' . $session_id . '|' . date('Y-m-d'), $this->secret()), 0, 24);
	}

	public function challengeOk($session_id, $cookie) {
		$c = (string)$cookie;

		return $c !== '' && (hash_equals($this->challengeToken($session_id), $c) || hash_equals(substr(hash_hmac('sha256', 'c|' . $session_id . '|' . date('Y-m-d', time() - 86400), $this->secret()), 0, 24), $c));
	}

	/** Should this payment route be checked? Not the gateway's own server-to-server calls. */
	public function watched($route) {
		$m = strtolower((string)preg_replace('~^.*[./|]~', '', (string)$route));
		$skip = array_filter(array_map('trim', explode(',', (string)$this->getConfig()['skip_methods'])));

		return $m === '' || !in_array($m, $skip, true);
	}

	public static function gateway($route) {
		if (preg_match('~payment/([a-z0-9_]+)~i', (string)$route, $m)) {
			return $m[1];
		}

		return (string)$route;
	}

	public static function bin($post) {
		foreach (array('cc_number', 'card_number', 'cardnumber', 'card_num', 'ccnum') as $k) {
			if (isset($post[$k])) {
				$n = preg_replace('/\D/', '', (string)$post[$k]);

				if (strlen($n) >= 12) {
					return substr($n, 0, 6);
				}
			}
		}

		return '';
	}

	/** Data-centre network? (reverse DNS, remembered for a day) */
	public function datacenter($ip) {
		if ($ip === '' || preg_match('/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1$|fc|fd)/i', $ip)) {
			return false;
		}

		$q = $this->db->query("SELECT dc FROM " . $this->t('ip') . " WHERE ip = '" . $this->e($ip) . "' AND checked > DATE_SUB(NOW(), INTERVAL 1 DAY)");

		if ($q->num_rows) {
			return (bool)$q->row['dc'];
		}

		$host = function_exists('gethostbyaddr') ? (string)@gethostbyaddr($ip) : '';
		$host = $host === $ip ? '' : strtolower($host);
		$dc = $host !== '' && preg_match(self::CLOUD, $host) ? 1 : 0;
		$this->db->query("REPLACE INTO " . $this->t('ip') . " SET ip = '" . $this->e($ip) . "', host = '" . $this->e(substr($host, 0, 255)) . "', dc = '" . $dc . "', checked = NOW()");

		return (bool)$dc;
	}

	/* ------------------------------------------------ the check */

	private function log($kind, $reason, array $ctx, $message = '') {
		$this->db->query("INSERT INTO " . $this->t('event') . " SET kind = '" . $this->e($kind) . "', reason = '" . $this->e($reason) . "', ip = '" . $this->e($ctx['ip']) . "', sess = '" . $this->e($ctx['sess']) . "',
			email = '" . $this->e(substr(strtolower((string)$ctx['email']), 0, 96)) . "', bin = '" . $this->e($ctx['bin']) . "', gateway = '" . $this->e(substr((string)$ctx['gateway'], 0, 64)) . "',
			message = '" . $this->e(mb_substr(trim(strip_tags((string)$message)), 0, 255)) . "', created = NOW()");

		if (mt_rand(1, 100) === 1) {
			$this->cleanup();
		}
	}

	private function count($kind, $field, $value, $minutes, $distinct = '') {
		if ($value === '') {
			return 0;
		}

		$what = $distinct !== '' ? 'COUNT(DISTINCT ' . $distinct . ')' : 'COUNT(*)';

		return (int)$this->db->query("SELECT " . $what . " n FROM " . $this->t('event') . " WHERE `" . $field . "` = '" . $this->e($value) . "' AND kind IN ('" . implode("','", (array)$kind) . "') AND created > DATE_SUB(NOW(), INTERVAL " . (int)$minutes . " MINUTE)")->row['n'];
	}

	public function underAttack() {
		$c = $this->getConfig();

		return $c['attack_mode'] === 'on' || ($c['attack_mode'] === 'auto' && (int)$c['attack_until'] > time());
	}

	/**
	 * Before a payment request. $ctx: ip, sess, email, customer_id, ua, bin, gateway, challenge (bool).
	 * Returns null to let it through, or array(reason, message for the shopper).
	 */
	public function check(array $ctx) {
		$cfg = $this->getConfig();

		if (!$cfg['enabled']) {
			return null;
		}

		$email = strtolower((string)$ctx['email']);

		if ($this->listed('allow', $ctx['ip'], $email)) {
			$this->log('attempt', 'allowed', $ctx);

			return null;
		}

		$m = (int)$cfg['block_minutes'];
		$reason = '';

		if ($this->listed('deny', $ctx['ip'], $email)) {
			$reason = 'blocked_ip';
		} elseif ($cfg['block_bots'] && self::isBot($ctx['ua'])) {
			$reason = 'bot';
		} elseif ($this->count('decline', 'ip', $ctx['ip'], $m) >= $cfg['ip_declines']) {
			$reason = 'declines_ip';
		} elseif ($this->count('decline', 'sess', $ctx['sess'], $m) >= $cfg['session_declines']) {
			$reason = 'declines_session';
		} elseif ($email !== '' && $this->count('decline', 'email', $email, $m) >= $cfg['email_declines']) {
			$reason = 'declines_email';
		} elseif ($ctx['bin'] !== '' && $this->count('decline', 'bin', $ctx['bin'], $m, 'sess') >= $cfg['bin_sessions']) {
			$reason = 'declines_bin';
		} elseif ($this->count(array('attempt', 'decline'), 'ip', $ctx['ip'], 10) >= $cfg['ip_attempts']) {
			$reason = 'rate_ip';
		} elseif ($this->count(array('attempt', 'decline'), 'sess', $ctx['sess'], 10) >= $cfg['session_attempts']) {
			$reason = 'rate_session';
		} elseif ($this->underAttack() && $cfg['attack_action'] === 'login' && (int)$ctx['customer_id'] <= 0) {
			$reason = 'attack_login';
		} elseif ($this->underAttack() && $cfg['attack_action'] === 'challenge' && empty($ctx['challenge'])) {
			$reason = 'attack_challenge';
		} elseif ($cfg['challenge_dc'] && empty($ctx['challenge']) && $this->datacenter($ctx['ip'])) {
			$reason = 'datacenter';
		}

		if ($reason === '') {
			$this->log('attempt', '', $ctx);

			return null;
		}

		$this->log('block', $reason, $ctx);

		return array($reason, self::shopperMessage($reason));
	}

	public static function shopperMessage($reason) {
		if ($reason === 'attack_login') {
			return 'For your security, please log in or create an account to pay. We are seeing unusual activity at checkout right now.';
		}

		if ($reason === 'attack_challenge' || $reason === 'datacenter') {
			return 'For your security, please reload the page, then try again. If you use a VPN, turning it off for a moment can help.';
		}

		return 'For your security, payments from your connection are paused for a while after several unsuccessful attempts. Please try again later or contact us.';
	}

	/**
	 * After a payment request: was the card declined? $output: what the gateway answered (usually JSON).
	 * Returns an alert to email the owner, when the shop just switched to "under attack".
	 */
	public function result(array $ctx, $output) {
		$cfg = $this->getConfig();

		if (!$cfg['enabled']) {
			return null;
		}

		$error = self::declineMessage($output);

		if ($error === null) {
			return null;
		}

		$this->log('decline', '', $ctx, $error);

		// A spike of declines across the whole shop: switch on "under attack".
		$n = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->t('event') . " WHERE kind = 'decline' AND created > DATE_SUB(NOW(), INTERVAL 10 MINUTE)")->row['n'];

		if ($cfg['attack_mode'] === 'auto' && $n >= $cfg['attack_declines'] && (int)$cfg['attack_until'] <= time()) {
			$cfg['attack_until'] = time() + 60 * (int)$cfg['attack_minutes'];
			$send = (int)$cfg['alerted'] < time() - 3600;

			if ($send) {
				$cfg['alerted'] = time();
			}

			$this->store($cfg);

			return $send ? array('declines' => $n, 'until' => date('H:i', $cfg['attack_until']), 'action' => $cfg['attack_action']) : null;
		}

		return null;
	}

	/** The gateway's error, when the answer is JSON with an error (how OpenCart payment extensions report a decline). */
	public static function declineMessage($output) {
		$s = trim((string)$output);

		if ($s === '' || ($s[0] !== '{' && $s[0] !== '[')) {
			return null;
		}

		$j = json_decode($s, true);

		if (!is_array($j)) {
			return null;
		}

		foreach (array('error', 'errors', 'error_warning', 'decline') as $k) {
			if (!empty($j[$k])) {
				$v = $j[$k];

				if (is_array($v)) {
					$v = implode(' ', array_filter(array_map(function ($x) { return is_scalar($x) ? (string)$x : ''; }, $v)));
				}

				return trim((string)$v) !== '' ? (string)$v : 'Declined';
			}
		}

		return null;
	}

	public function cleanup() {
		$keep = max(7, (int)$this->getConfig()['keep_days']);
		$this->db->query("DELETE FROM " . $this->t('event') . " WHERE created < DATE_SUB(NOW(), INTERVAL " . $keep . " DAY)");
		$this->db->query("DELETE FROM " . $this->t('ip') . " WHERE checked < DATE_SUB(NOW(), INTERVAL 2 DAY)");
	}

	/* ------------------------------------------------ admin */

	public function attack(array $in) {
		$cfg = $this->getConfig();
		$on = !empty($in['on']);

		if ($on) {
			$cfg['attack_until'] = time() + 60 * max(10, (int)(isset($in['minutes']) ? $in['minutes'] : $cfg['attack_minutes']));

			if ($cfg['attack_mode'] === 'off') {
				$cfg['attack_mode'] = 'auto';
			}
		} else {
			$cfg['attack_until'] = 0;

			if ($cfg['attack_mode'] === 'on') {
				$cfg['attack_mode'] = 'auto';
			}
		}

		$this->store($cfg);

		return $this->overview();
	}

	public function overview() {
		$cfg = $this->getConfig();
		$sum = function ($hours) {
			$out = array('attempt' => 0, 'decline' => 0, 'block' => 0);

			foreach ($this->db->query("SELECT kind, COUNT(*) n FROM " . $this->t('event') . " WHERE created > DATE_SUB(NOW(), INTERVAL " . (int)$hours . " HOUR) GROUP BY kind")->rows as $r) {
				$out[$r['kind']] = (int)$r['n'];
			}

			return $out;
		};
		$hours = array();

		for ($i = 23; $i >= 0; $i--) {
			$hours[date('Y-m-d H', time() - $i * 3600)] = array('h' => date('H', time() - $i * 3600), 'attempt' => 0, 'decline' => 0, 'block' => 0);
		}

		foreach ($this->db->query("SELECT DATE_FORMAT(created, '%Y-%m-%d %H') h, kind, COUNT(*) n FROM " . $this->t('event') . " WHERE created > DATE_SUB(NOW(), INTERVAL 24 HOUR) GROUP BY h, kind")->rows as $r) {
			if (isset($hours[$r['h']])) {
				$hours[$r['h']][$r['kind']] = (int)$r['n'];
			}
		}

		$reasons = array();

		foreach ($this->db->query("SELECT reason, COUNT(*) n FROM " . $this->t('event') . " WHERE kind = 'block' AND created > DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY reason ORDER BY n DESC")->rows as $r) {
			$reasons[] = array('reason' => $r['reason'], 'text' => isset(self::REASONS[$r['reason']]) ? self::REASONS[$r['reason']] : $r['reason'], 'n' => (int)$r['n']);
		}

		$top = $this->db->query("SELECT ip, COUNT(*) n, SUM(kind = 'decline') declines, SUM(kind = 'block') blocks, MAX(created) last FROM " . $this->t('event') . "
			WHERE created > DATE_SUB(NOW(), INTERVAL 7 DAY) AND kind IN ('decline', 'block') GROUP BY ip ORDER BY n DESC LIMIT 10")->rows;

		foreach ($top as &$t) {
			$h = $this->db->query("SELECT host, dc FROM " . $this->t('ip') . " WHERE ip = '" . $this->e($t['ip']) . "'");
			$t['host'] = $h->num_rows ? $h->row['host'] : '';
			$t['dc'] = $h->num_rows ? (int)$h->row['dc'] : 0;
			$t['allowed'] = $this->listed('allow', $t['ip'], '') ? 1 : 0;
			$t['denied'] = $this->listed('deny', $t['ip'], '') ? 1 : 0;
		}

		$unpaid = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->o('order') . " WHERE order_status_id = '0' AND date_added > DATE_SUB(NOW(), INTERVAL 24 HOUR)")->row['n'];

		return array('day' => $sum(24), 'week' => $sum(24 * 7), 'hours' => array_values($hours), 'reasons' => $reasons, 'top' => $top,
			'attack' => $this->underAttack() ? 1 : 0, 'attack_until' => (int)$cfg['attack_until'] > time() ? date('Y-m-d H:i', (int)$cfg['attack_until']) : '', 'attack_mode' => $cfg['attack_mode'],
			'enabled' => (int)$cfg['enabled'], 'unpaid_day' => $unpaid, 'now' => date('Y-m-d H:i'));
	}

	public function events(array $in) {
		$where = array('1');
		$kind = isset($in['kind']) ? (string)$in['kind'] : '';

		if (in_array($kind, array('attempt', 'decline', 'block'), true)) {
			$where[] = "kind = '" . $kind . "'";
		}

		if (!empty($in['q'])) {
			$q = $this->e(trim((string)$in['q']));
			$where[] = "(ip LIKE '%" . $q . "%' OR email LIKE '%" . $q . "%' OR bin LIKE '" . $q . "%' OR gateway LIKE '%" . $q . "%')";
		}

		$page = max(1, isset($in['page']) ? (int)$in['page'] : 1);
		$per = 50;
		$total = (int)$this->db->query("SELECT COUNT(*) n FROM " . $this->t('event') . " WHERE " . implode(' AND ', $where))->row['n'];
		$rows = $this->db->query("SELECT * FROM " . $this->t('event') . " WHERE " . implode(' AND ', $where) . " ORDER BY event_id DESC LIMIT " . (($page - 1) * $per) . ", " . $per)->rows;

		foreach ($rows as &$r) {
			$r['text'] = $r['kind'] === 'block' ? (isset(self::REASONS[$r['reason']]) ? self::REASONS[$r['reason']] : $r['reason']) : ($r['kind'] === 'decline' ? 'Card declined' . ($r['message'] !== '' ? ': ' . $r['message'] : '') : ($r['reason'] === 'allowed' ? 'Payment attempt (on your allow list)' : 'Payment attempt'));
		}

		return array('rows' => $rows, 'total' => $total, 'page' => $page, 'per' => $per);
	}

	/** Add to or remove from the allow / block list. */
	public function listEdit(array $in) {
		$cfg = $this->getConfig();
		$list = isset($in['list']) && $in['list'] === 'deny' ? 'deny' : 'allow';
		$value = strtolower(trim((string)(isset($in['value']) ? $in['value'] : '')));
		$lines = array_filter(preg_split('/\s+/', (string)$cfg[$list]));

		if (!empty($in['remove'])) {
			$lines = array_diff($lines, array($value));
		} else {
			$lines[] = $value;
		}

		$this->saveConfig(array($list => implode("\n", array_unique($lines))));

		return $this->overview();
	}

	public function clearAll() {
		$this->db->query("TRUNCATE TABLE " . $this->t('event'));
		$this->db->query("TRUNCATE TABLE " . $this->t('ip'));
	}

	public function bootstrap() {
		return array('config' => $this->publicConfig(), 'defaults' => array_diff_key(self::defaults(), array('secret' => 1, 'alerted' => 1, 'attack_until' => 1)), 'overview' => $this->overview(), 'reasons' => self::REASONS);
	}
}
}
