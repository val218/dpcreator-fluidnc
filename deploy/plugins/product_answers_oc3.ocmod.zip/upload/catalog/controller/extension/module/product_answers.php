<?php
/**
 * Product Answers for OpenCart 3.0.x - shop side: adds the question box and answers questions.
 * Hooked in with an OpenCart event, so no theme or core file is changed.
 */
class ControllerExtensionModuleProductAnswers extends Controller {
	private static $done = false;

	private function core() {
		require_once(DIR_SYSTEM . 'library/productanswers/Service.php');
		require_once(DIR_SYSTEM . 'library/productanswers/Ui.php');

		return new PanService($this->db, DB_PREFIX, 3);
	}

	private function link($route, $args = '') {
		return html_entity_decode($this->url->link($route, $args, true), ENT_QUOTES, 'UTF-8');
	}

	private function productId() {
		$route = isset($this->request->get['route']) ? (string)$this->request->get['route'] : '';

		return $route === 'product/product' && isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
	}

	/** catalog/view/common/footer/after */
	public function eventWidget(&$route, &$data, &$output) {
		try {
			if (self::$done || !is_string($output) || !empty($this->request->server['HTTP_X_REQUESTED_WITH'])) {
				return;
			}

			$core = $this->core();
			$cfg = $core->getConfig();
			$pid = $this->productId();

			if (!$cfg['widget'] || ($cfg['pages'] === 'product' && !$pid)) {
				return;
			}

			self::$done = true;
			$texts = $core->texts((int)$this->config->get('config_language_id'), (string)$this->config->get('config_language'));
			$output = PanUi::inject($output, PanUi::widget($cfg, $texts, $this->link('extension/module/product_answers/ask'), $pid));
		} catch (\Throwable $e) {
			// Never break a shop page.
		}
	}

	/** Answers one question (POST q, product_id). */
	public function ask() {
		$json = array();

		try {
			$core = $this->core();
			$ip = isset($this->request->server['REMOTE_ADDR']) ? $this->request->server['REMOTE_ADDR'] : '';

			if (($this->request->server['REQUEST_METHOD'] ?? '') !== 'POST') {
				$json = array('error' => 'POST only');
			} elseif (!$core->allow($ip)) {
				$json = array('error' => 'Too many questions in a minute. Please wait a moment.');
			} else {
				$q = isset($this->request->post['q']) ? html_entity_decode((string)$this->request->post['q'], ENT_QUOTES, 'UTF-8') : '';
				$pid = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;
				$json = PanUi::publicAnswer($core->answer($q, $this->context($core, $pid)));
			}
		} catch (\Throwable $e) {
			error_log('Product Answers: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
			$json = array('error' => 'Sorry, something went wrong. Please try again.');
		}

		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->addHeader('X-Robots-Tag: noindex');
		$this->response->setOutput(json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
	}

	private function context(PanService $core, $pid) {
		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$lang = (int)$this->config->get('config_language_id');
		$code = (string)$this->config->get('config_language');
		$texts = $core->texts($lang, $code);
		$cur = isset($this->session->data['currency']) ? $this->session->data['currency'] : $this->config->get('config_currency');
		$hide = $this->config->get('config_customer_price') && !$this->customer->isLogged();
		$self = $this;

		$helpers = array(
			'price' => function ($amount, $tax_class_id) use ($self, $cur, $hide) {
				if ($hide) {
					return array(0, '');
				}

				$v = $self->tax->calculate($amount, $tax_class_id, $self->config->get('config_tax'));

				return array($self->currency->convert($v, $self->config->get('config_currency'), $cur), $self->currency->format($v, $cur));
			},
			'thumb' => function ($image) use ($self) {
				$w = 100;

				return $self->model_tool_image->resize($image && is_file(DIR_IMAGE . $image) ? $image : 'placeholder.png', $w, $w);
			},
			'href' => function ($id) use ($self) {
				return $self->link('product/product', 'product_id=' . (int)$id);
			},
			'stock' => function ($p) use ($self, $texts) {
				if ((int)$p['quantity'] <= 0) {
					return html_entity_decode((string)$p['stock_status'], ENT_QUOTES, 'UTF-8');
				}

				return $self->config->get('config_stock_display') ? (int)$p['quantity'] . ' · ' . $texts['in_stock'] : $texts['in_stock'];
			}
		);

		return array(
			'lang' => $lang,
			'code' => $code,
			'store_id' => (int)$this->config->get('config_store_id'),
			'product_id' => $pid,
			'nolog' => !empty($this->request->post['test']),
			'currency_value' => $this->currency->getValue($cur),
			'card' => function ($id) use ($self, $helpers) {
				return PanUi::card($self->model_catalog_product->getProduct((int)$id), $helpers);
			},
			'money' => function ($amount) use ($self, $cur) {
				return $self->currency->format($amount, $cur, 1);
			},
			'info_href' => function ($id) use ($self) {
				return $self->link('information/information', 'information_id=' . (int)$id);
			},
			'contact_href' => $this->link('information/contact')
		);
	}
}
