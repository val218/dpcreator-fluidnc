<?php
/**
 * Product Answers for OpenCart - answers shoppers' questions from the shop's own data:
 * products, attributes, options, prices, stock, information pages and the owner's own answers.
 * No AI service, no API key: a word index in the shop database and plain rules.
 * Framework-free: the OpenCart 3 / 4 adapters pass in the DB object and small helpers.
 */
if (!class_exists('PanService')) {
class PanService {
	const CONFIG_CODE = 'module_product_answers';
	const CONFIG_KEY = 'module_product_answers_config';

	private $db;
	private $p;
	private $oc;
	private $ctx;
	private $config;
	private $nolog = false;

	public function __construct($db, $prefix, $oc_major, array $ctx = array()) {
		$this->db = $db;
		$this->p = $prefix;
		$this->oc = (int)$oc_major;
		$this->ctx = $ctx;
	}

	private function e($s) {
		return $this->db->escape((string)$s);
	}

	private function t($name) {
		return '`' . $this->p . 'product_answers_' . $name . '`';
	}

	private function o($name) {
		return '`' . $this->p . $name . '`';
	}

	private function q($sql) {
		return $this->db->query($sql);
	}

	private static function now() {
		return date('Y-m-d H:i:s');
	}

	/* ------------------------------------------------ install */

	public function install() {
		$this->ensureTables();
	}

	public function ensureTables() {
		$this->q("CREATE TABLE IF NOT EXISTS " . $this->t('term') . " (
			`lang` INT NOT NULL, `term` VARCHAR(48) NOT NULL, `doc` CHAR(1) NOT NULL, `id` INT NOT NULL, `w` FLOAT NOT NULL,
			PRIMARY KEY (`lang`, `term`, `doc`, `id`), KEY `doc` (`doc`, `id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin");
		$this->q("CREATE TABLE IF NOT EXISTS " . $this->t('doc') . " (
			`doc` CHAR(1) NOT NULL, `id` INT NOT NULL, `lang` INT NOT NULL, `title` VARCHAR(255) NOT NULL DEFAULT '', `updated` DATETIME NOT NULL,
			PRIMARY KEY (`doc`, `id`, `lang`), KEY `lang` (`lang`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
		$this->q("CREATE TABLE IF NOT EXISTS " . $this->t('faq') . " (
			`faq_id` INT NOT NULL AUTO_INCREMENT, `lang` INT NOT NULL DEFAULT 0, `question` VARCHAR(255) NOT NULL, `keywords` VARCHAR(500) NOT NULL DEFAULT '',
			`answer` TEXT NOT NULL, `link` VARCHAR(500) NOT NULL DEFAULT '', `status` TINYINT NOT NULL DEFAULT 1, `asked` INT NOT NULL DEFAULT 0, `updated` DATETIME NOT NULL,
			PRIMARY KEY (`faq_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
		$this->q("CREATE TABLE IF NOT EXISTS " . $this->t('log') . " (
			`log_id` INT NOT NULL AUTO_INCREMENT, `q` VARCHAR(300) NOT NULL, `lang` INT NOT NULL, `product_id` INT NOT NULL DEFAULT 0,
			`answered` TINYINT NOT NULL, `kind` VARCHAR(12) NOT NULL, `top` VARCHAR(255) NOT NULL DEFAULT '', `created` DATETIME NOT NULL,
			PRIMARY KEY (`log_id`), KEY `created` (`created`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
		$this->q("CREATE TABLE IF NOT EXISTS " . $this->t('rate') . " (
			`k` CHAR(40) NOT NULL, `minute` INT NOT NULL, `n` INT NOT NULL, PRIMARY KEY (`k`, `minute`)
		) ENGINE=InnoDB DEFAULT CHARSET=ascii");
	}

	public function uninstall() {
		foreach (array('term', 'doc', 'faq', 'log', 'rate') as $t) {
			$this->q("DROP TABLE IF EXISTS " . $this->t($t));
		}

		$this->q("DELETE FROM `" . $this->p . "setting` WHERE `code` = '" . self::CONFIG_CODE . "'");
	}

	/* ------------------------------------------------ settings */

	public static function defaults() {
		return array(
			'widget'       => 1,        // show the question box on the shop
			'pages'        => 'all',    // all | product
			'position'     => 'right',  // right | left
			'colour'       => '#1F6FB8',
			'max_products' => 4,
			'log'          => 1,        // keep the questions so the owner can see what people ask
			'log_days'     => 90,
			'synonyms'     => '',       // one group per line: quiet, noise, silent
			'texts'        => array(),  // language_id => array(key => text)
			'indexed'      => '',       // when the whole index was last built
			'checked'      => 0         // last time the shop side looked for changed products
		);
	}

	public function getConfig() {
		if ($this->config !== null) {
			return $this->config;
		}

		$cfg = self::defaults();
		$q = $this->q("SELECT `value` FROM `" . $this->p . "setting` WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "' LIMIT 1");

		if ($q->num_rows) {
			$saved = json_decode($q->row['value'], true);

			if (is_array($saved)) {
				$cfg = array_merge($cfg, array_intersect_key($saved, $cfg));
			}
		}

		if (!is_array($cfg['texts'])) {
			$cfg['texts'] = array();
		}

		return $this->config = $cfg;
	}

	private function writeConfig(array $cfg) {
		$this->q("DELETE FROM `" . $this->p . "setting` WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "'");
		$this->q("INSERT INTO `" . $this->p . "setting` SET store_id = '0', `code` = '" . self::CONFIG_CODE . "', `key` = '" . self::CONFIG_KEY . "', `value` = '" . $this->e(json_encode($cfg, JSON_UNESCAPED_UNICODE)) . "', serialized = '0'");
		$this->config = $cfg;
	}

	public function saveConfig(array $in) {
		$cfg = $this->getConfig();

		foreach (array('widget', 'log') as $k) {
			if (array_key_exists($k, $in)) {
				$cfg[$k] = !empty($in[$k]) ? 1 : 0;
			}
		}

		if (isset($in['pages'])) {
			$cfg['pages'] = $in['pages'] === 'product' ? 'product' : 'all';
		}

		if (isset($in['position'])) {
			$cfg['position'] = $in['position'] === 'left' ? 'left' : 'right';
		}

		if (isset($in['colour']) && preg_match('/^#[0-9a-fA-F]{6}$/', $in['colour'])) {
			$cfg['colour'] = strtoupper($in['colour']);
		}

		if (isset($in['max_products'])) {
			$cfg['max_products'] = max(1, min(8, (int)$in['max_products']));
		}

		if (isset($in['log_days'])) {
			$cfg['log_days'] = max(7, min(730, (int)$in['log_days']));
		}

		if (isset($in['synonyms'])) {
			$cfg['synonyms'] = mb_substr(str_replace("\r", '', (string)$in['synonyms']), 0, 20000);
		}

		if (isset($in['texts']) && is_array($in['texts'])) {
			$keys = array_keys(self::textDefaults('en'));
			$texts = array();

			foreach ($in['texts'] as $lang => $set) {
				if (!is_array($set)) {
					continue;
				}

				foreach ($keys as $k) {
					if (isset($set[$k]) && trim((string)$set[$k]) !== '') {
						$texts[(int)$lang][$k] = mb_substr(trim((string)$set[$k]), 0, $k === 'examples' ? 600 : 300);
					}
				}
			}

			$cfg['texts'] = $texts;
		}

		$this->writeConfig($cfg);

		return $this->settingsView();
	}

	/* ------------------------------------------------ words for each language */

	public static function textDefaults($code) {
		$all = array(
			'en' => array(
				'weight' => 'Weight', 'size' => 'Size (L × W × H)', 'model' => 'Model',
				'button' => 'Ask a question', 'product_button' => 'Ask about this product', 'title' => 'Ask about our products',
				'greeting' => 'Hi! Ask me about our products, prices, stock, delivery or returns.', 'placeholder' => 'Type your question…', 'send' => 'Ask',
				'not_found' => 'Sorry, I could not find an answer to that in our shop information. I can only answer questions about our products and shop.',
				'contact' => 'Ask us directly', 'products' => 'These products match your question:', 'facts' => 'From the details of {name}:',
				'no_fact' => 'I could not find that in the details of {name}.', 'in_stock' => 'In stock', 'price' => 'Price', 'cheapest' => 'Cheapest first:',
				'under' => 'Products up to {price}:', 'over' => 'Products from {price}:', 'view' => 'View', 'more' => 'Read more',
				'examples' => 'Do you deliver abroad? | What is your cheapest product? | How can I return an item?'
			),
			'lv' => array(
				'weight' => 'Svars', 'size' => 'Izmēri (G × P × A)', 'model' => 'Modelis',
				'button' => 'Uzdot jautājumu', 'product_button' => 'Jautāt par šo preci', 'title' => 'Jautājiet par mūsu precēm',
				'greeting' => 'Sveiki! Jautājiet par mūsu precēm, cenām, pieejamību, piegādi vai atgriešanu.', 'placeholder' => 'Ierakstiet jautājumu…', 'send' => 'Jautāt',
				'not_found' => 'Diemžēl veikala informācijā neatradu atbildi. Varu atbildēt tikai uz jautājumiem par mūsu precēm un veikalu.',
				'contact' => 'Jautājiet mums', 'products' => 'Jūsu jautājumam atbilst šīs preces:', 'facts' => 'No preces {name} apraksta:',
				'no_fact' => 'Preces {name} aprakstā to neatradu.', 'in_stock' => 'Ir noliktavā', 'price' => 'Cena', 'cheapest' => 'Lētākās vispirms:',
				'under' => 'Preces līdz {price}:', 'over' => 'Preces no {price}:', 'view' => 'Skatīt', 'more' => 'Lasīt vairāk',
				'examples' => 'Vai piegādājat uz ārzemēm? | Kura ir lētākā prece? | Kā atgriezt preci?'
			),
			'de' => array(
				'weight' => 'Gewicht', 'size' => 'Maße (L × B × H)', 'model' => 'Modell',
				'button' => 'Frage stellen', 'product_button' => 'Frage zu diesem Produkt', 'title' => 'Fragen zu unseren Produkten',
				'greeting' => 'Hallo! Fragen Sie nach unseren Produkten, Preisen, Verfügbarkeit, Versand oder Rückgabe.', 'placeholder' => 'Ihre Frage…', 'send' => 'Fragen',
				'not_found' => 'Leider habe ich dazu keine Antwort in unseren Shop-Informationen gefunden. Ich beantworte nur Fragen zu unseren Produkten und unserem Shop.',
				'contact' => 'Fragen Sie uns direkt', 'products' => 'Diese Produkte passen zu Ihrer Frage:', 'facts' => 'Aus den Angaben zu {name}:',
				'no_fact' => 'Das habe ich in den Angaben zu {name} nicht gefunden.', 'in_stock' => 'Auf Lager', 'price' => 'Preis', 'cheapest' => 'Günstigste zuerst:',
				'under' => 'Produkte bis {price}:', 'over' => 'Produkte ab {price}:', 'view' => 'Ansehen', 'more' => 'Mehr lesen',
				'examples' => 'Liefern Sie ins Ausland? | Was ist Ihr günstigstes Produkt? | Wie kann ich etwas zurückgeben?'
			),
			'ru' => array(
				'weight' => 'Вес', 'size' => 'Размеры (Д × Ш × В)', 'model' => 'Модель',
				'button' => 'Задать вопрос', 'product_button' => 'Вопрос об этом товаре', 'title' => 'Вопросы о наших товарах',
				'greeting' => 'Здравствуйте! Спросите о товарах, ценах, наличии, доставке или возврате.', 'placeholder' => 'Ваш вопрос…', 'send' => 'Спросить',
				'not_found' => 'К сожалению, я не нашёл ответа в информации магазина. Я отвечаю только на вопросы о наших товарах и магазине.',
				'contact' => 'Спросить нас', 'products' => 'Вашему вопросу соответствуют эти товары:', 'facts' => 'Из описания товара {name}:',
				'no_fact' => 'В описании товара {name} я этого не нашёл.', 'in_stock' => 'В наличии', 'price' => 'Цена', 'cheapest' => 'Сначала дешёвые:',
				'under' => 'Товары до {price}:', 'over' => 'Товары от {price}:', 'view' => 'Открыть', 'more' => 'Подробнее',
				'examples' => 'Доставляете за границу? | Какой самый дешёвый товар? | Как вернуть товар?'
			),
			'es' => array(
				'weight' => 'Peso', 'size' => 'Medidas (L × A × H)', 'model' => 'Modelo',
				'button' => 'Hacer una pregunta', 'product_button' => 'Preguntar por este producto', 'title' => 'Pregunte por nuestros productos',
				'greeting' => '¡Hola! Pregúnteme por productos, precios, disponibilidad, envíos o devoluciones.', 'placeholder' => 'Escriba su pregunta…', 'send' => 'Preguntar',
				'not_found' => 'Lo siento, no encontré una respuesta en la información de la tienda. Solo respondo preguntas sobre nuestros productos y la tienda.',
				'contact' => 'Pregúntenos directamente', 'products' => 'Estos productos coinciden con su pregunta:', 'facts' => 'De los detalles de {name}:',
				'no_fact' => 'No encontré eso en los detalles de {name}.', 'in_stock' => 'En stock', 'price' => 'Precio', 'cheapest' => 'Más baratos primero:',
				'under' => 'Productos hasta {price}:', 'over' => 'Productos desde {price}:', 'view' => 'Ver', 'more' => 'Leer más',
				'examples' => '¿Envían al extranjero? | ¿Cuál es su producto más barato? | ¿Cómo devuelvo un artículo?'
			),
			'fr' => array(
				'weight' => 'Poids', 'size' => 'Dimensions (L × l × H)', 'model' => 'Modèle',
				'button' => 'Poser une question', 'product_button' => 'Question sur ce produit', 'title' => 'Questions sur nos produits',
				'greeting' => 'Bonjour ! Posez vos questions sur nos produits, prix, stock, livraison ou retours.', 'placeholder' => 'Votre question…', 'send' => 'Demander',
				'not_found' => 'Désolé, je n’ai pas trouvé de réponse dans les informations de la boutique. Je réponds seulement aux questions sur nos produits et la boutique.',
				'contact' => 'Nous contacter', 'products' => 'Ces produits correspondent à votre question :', 'facts' => 'D’après la fiche de {name} :',
				'no_fact' => 'Je n’ai pas trouvé cela dans la fiche de {name}.', 'in_stock' => 'En stock', 'price' => 'Prix', 'cheapest' => 'Les moins chers d’abord :',
				'under' => 'Produits jusqu’à {price} :', 'over' => 'Produits à partir de {price} :', 'view' => 'Voir', 'more' => 'Lire la suite',
				'examples' => 'Livrez-vous à l’étranger ? | Quel est votre produit le moins cher ? | Comment retourner un article ?'
			)
		);

		$code = strtolower(substr((string)$code, 0, 2));

		return isset($all[$code]) ? $all[$code] : $all['en'];
	}

	/** Shop-side words for one language: built-in defaults overlaid with the owner's own. */
	public function texts($lang_id, $code) {
		$cfg = $this->getConfig();
		$t = self::textDefaults($code);

		if (isset($cfg['texts'][$lang_id]) && is_array($cfg['texts'][$lang_id])) {
			$t = array_merge($t, $cfg['texts'][$lang_id]);
		}

		return $t;
	}

	/** Words that only carry the shape of a question, never the subject. */
	private static function stopwords() {
		static $s = null;

		if ($s === null) {
			$s = array_flip(preg_split('/\s+/u', trim('
				a an the and or but if of to in on at by for with from as is are was were be been being am do does did done have has had having
				i me my we our us you your he she it its they them their this that these those there here what which who whom whose when where why how
				can could would should will shall may might must not no yes please thanks thank hi hello hey any some anything something
				get got about into than then so too very also just only again more most much many all each every both either neither
				tell know want need like looking look find show give let
				product products item items thing things one ones stuff something anything goods article articles shop store
				prece preces preci precēm produkts produkti produktu lieta lietas veikals veikalā
				produkt produkte produkten artikel ware waren sache
				товар товары товаров вещь продукт магазин
				producto productos artículo artículos produit produits article
				ir ar un vai par uz no kā kas kur kad cik man mums jums jūs es mēs tas tā šis šī to ka lai bet arī vēl tikai vai jums ir lūdzu paldies sveiki
				der die das und oder ist sind ein eine einen einem einer zu im in am an auf mit für von wie was wo wann ich sie wir es haben hat gibt bitte danke
				и в во на с со по к у о об от до за из для не ли это этот эта как что где когда какой какая какие есть ли вы мы я у вас пожалуйста спасибо
				el la los las un una y o de del en con por para que es son hay como cuál cual dónde donde cuándo usted
				le les des du et ou en au aux avec pour par que qui est sont il elle vous nous je quel quelle comment où
			')));
		}

		return $s;
	}

	/** Question words that say what kind of answer is wanted (several languages). */
	private static function intents() {
		return array(
			'price'    => '~\b(price|prices|cost|costs|how much|expensive|cena|cenas|cenu|maksā|cik maksā|preis|preise|kostet|kosten|цена|цены|стоит|сколько стоит|precio|cuesta|prix|coûte)\b~iu',
			'stock'    => '~\b(in stock|stock|available|availability|have you got|do you have|noliktavā|pieejams|pieejama|pieejami|ir pieejams|lager|lieferbar|verfügbar|наличии|наличие|disponible|en stock)\b~iu',
			'cheapest' => '~\b(cheapest|lowest price|least expensive|budget|lētāk\w*|vislēt\w*|günstigst\w*|billigst\w*|дешевле всего|самый дешёвый|самый дешевый|самые дешёвые|más barat\w*|moins cher\w*)\b~iu',
			'dearest'  => '~\b(most expensive|priciest|highest price|best|premium|dārgāk\w*|teuerst\w*|самый дорогой|más car\w*|plus cher\w*)\b~iu',
			'under'    => '~\b(under|below|less than|cheaper than|max|maximum|up to|no more than|līdz|zem|mazāk par|lētāk par|unter|bis|weniger als|до|дешевле|меньше|hasta|menos de|moins de|jusqu\'?à)\b\s*(?:[€$£]|eur\b|euro\b|usd\b|gbp\b)?\s*\d~iu',
			'over'     => '~\b(over|above|more than|at least|virs|vairāk par|über|mehr als|ab|от|дороже|больше|más de|plus de)\b\s*(?:[€$£]|eur\b|euro\b|usd\b|gbp\b)?\s*\d~iu',
			'weight'   => '~\b(weight|weigh|weighs|heavy|how heavy|svars|sver|gewicht|wiegt|вес|весит|peso|pesa|poids|pèse)\b~iu',
			'size'     => '~\b(size|sizes|dimension|dimensions|measurements|how big|how large|how long|how wide|how tall|izmērs|izmēri|izmēru|größe|maße|abmessungen|размер|размеры|габариты|tamaño|medidas|taille|dimensions)\b~iu',
			'options'  => '~\b(colou?rs?|sizes|variants?|options?|versions?|which colou?r|krāsa|krāsas|krāsās|izmēri|varianti|farben?|größen|varianten|цвета?|цвет|размеры|варианты|colores|tallas|couleurs?|tailles)\b~iu',
			'model'    => '~\b(model|sku|part number|code|modelis|artikuls|modell|artikelnummer|модель|артикул|modelo|référence)\b~iu'
		);
	}

	/** Built-in groups of words that mean the same thing in a shop. The owner can add more. */
	private static function builtInSynonyms() {
		return array(
			'ship shipping shipped delivery deliver delivers delivered postage courier dispatch send sending',
			'return returns returning refund refunds exchange money back',
			'pay paying payment payments paypal card invoice bank transfer',
			'size sizes dimension dimensions measurements width height length depth',
			'weight weigh weighs heavy kg mass',
			'colour colours color colors',
			'warranty guarantee guaranteed',
			'quiet noise noisy silent loud db decibel',
			'waterproof water resistant ip65 ip66 ip67 ip68 rain',
			'battery batteries rechargeable charge charging',
			'wifi wi fi wireless wlan',
			'phone mobile smartphone',
			'cheap cheapest inexpensive affordable budget',
			'gift present',
			'piegāde piegādi piegādājat piegādājam sūtīšana sūtījums kurjers',
			'atgriešana atgriezt atgriezšana apmaiņa',
			'apmaksa apmaksāt maksāt maksājums',
			'versand liefern lieferung versenden',
			'rückgabe zurückgeben umtausch erstattung',
			'доставка доставляете доставить отправка курьер',
			'возврат вернуть обмен'
		);
	}

	/* ------------------------------------------------ words */

	private static function lower($s) {
		return function_exists('mb_strtolower') ? mb_strtolower((string)$s, 'UTF-8') : strtolower((string)$s);
	}

	private static function len($s) {
		return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s);
	}

	private static function sub($s, $from, $n = null) {
		return function_exists('mb_substr') ? mb_substr($s, $from, $n, 'UTF-8') : substr($s, $from, $n === null ? strlen($s) : $n);
	}

	public static function plain($html) {
		$s = html_entity_decode((string)$html, ENT_QUOTES, 'UTF-8');
		$s = preg_replace('~<(script|style)\b[^>]*>.*?</\1>~is', ' ', $s);
		$s = preg_replace('~<(br|/p|/div|/li|/h[1-6]|/tr)\b[^>]*>~i', "\n", $s);
		$s = strip_tags($s);
		$s = html_entity_decode($s, ENT_QUOTES, 'UTF-8');
		$s = preg_replace("~[ \t\x{00A0}]+~u", ' ', $s);
		$s = preg_replace("~\s*\n\s*~", "\n", $s);

		return trim((string)$s);
	}

	/** Words of a text: lower case, letters and digits; "ESP32-S3" also gives "esp32s3". */
	public static function words($text, $keepStop = false) {
		$text = self::lower(html_entity_decode((string)$text, ENT_QUOTES, 'UTF-8'));
		$out = array();

		if (preg_match_all('~[\p{L}\p{N}]+(?:[-_./][\p{L}\p{N}]+)+~u', $text, $m)) {
			foreach ($m[0] as $joined) {
				$out[] = preg_replace('~[-_./]~', '', $joined);
			}
		}

		foreach (preg_split('~[^\p{L}\p{N}]+~u', $text, -1, PREG_SPLIT_NO_EMPTY) as $w) {
			$out[] = $w;
		}

		$stop = self::stopwords();
		$res = array();

		foreach ($out as $w) {
			$l = self::len($w);

			if ($l > 40 || ($l < 2 && !ctype_digit($w))) {
				continue;
			}

			if (!$keepStop && isset($stop[$w])) {
				continue;
			}

			$res[] = $w;
		}

		return $res;
	}

	/* ------------------------------------------------ index */

	private function languages() {
		$rows = $this->q("SELECT language_id, code FROM " . $this->o('language') . " ORDER BY sort_order, language_id")->rows;
		$out = array();

		foreach ($rows as $r) {
			$out[(int)$r['language_id']] = $r['code'];
		}

		return $out;
	}

	private function saveDoc($doc, $id, $lang, $title, array $fields) {
		$weights = array();

		foreach ($fields as $f) {
			list($text, $w) = $f;
			$counts = array_count_values(self::words($text));

			foreach ($counts as $term => $n) {
				$term = self::sub($term, 0, 48);
				$weights[$term] = (isset($weights[$term]) ? $weights[$term] : 0) + $w * (1 + log($n));
			}
		}

		$this->q("DELETE FROM " . $this->t('term') . " WHERE `doc` = '" . $this->e($doc) . "' AND `id` = '" . (int)$id . "' AND `lang` = '" . (int)$lang . "'");
		$this->q("REPLACE INTO " . $this->t('doc') . " SET `doc` = '" . $this->e($doc) . "', `id` = '" . (int)$id . "', `lang` = '" . (int)$lang . "', `title` = '" . $this->e(self::sub((string)$title, 0, 255)) . "', `updated` = '" . self::now() . "'");

		$values = array();

		foreach ($weights as $term => $w) {
			$values[] = "('" . (int)$lang . "', '" . $this->e($term) . "', '" . $this->e($doc) . "', '" . (int)$id . "', '" . round(min($w, 60), 3) . "')";

			if (count($values) >= 400) {
				$this->q("INSERT IGNORE INTO " . $this->t('term') . " (`lang`, `term`, `doc`, `id`, `w`) VALUES " . implode(',', $values));
				$values = array();
			}
		}

		if ($values) {
			$this->q("INSERT IGNORE INTO " . $this->t('term') . " (`lang`, `term`, `doc`, `id`, `w`) VALUES " . implode(',', $values));
		}
	}

	public function removeDoc($doc, $id) {
		$this->q("DELETE FROM " . $this->t('term') . " WHERE `doc` = '" . $this->e($doc) . "' AND `id` = '" . (int)$id . "'");
		$this->q("DELETE FROM " . $this->t('doc') . " WHERE `doc` = '" . $this->e($doc) . "' AND `id` = '" . (int)$id . "'");
	}

	private $tables = array();

	private function hasTable($name) {
		if (!isset($this->tables[$name])) {
			$this->tables[$name] = $this->q("SHOW TABLES LIKE '" . $this->e($this->p . $name) . "'")->num_rows > 0;
		}

		return $this->tables[$name];
	}

	public function indexProduct($product_id) {
		$product_id = (int)$product_id;
		$p = $this->q("SELECT p.*, m.name AS manufacturer FROM " . $this->o('product') . " p LEFT JOIN " . $this->o('manufacturer') . " m ON (m.manufacturer_id = p.manufacturer_id) WHERE p.product_id = '" . $product_id . "'");

		if (!$p->num_rows) {
			$this->removeDoc('p', $product_id);

			return false;
		}

		$p = $p->row;
		$descs = $this->q("SELECT * FROM " . $this->o('product_description') . " WHERE product_id = '" . $product_id . "'")->rows;
		$codes = (string)$p['model'];

		foreach (array('sku', 'mpn', 'upc', 'ean', 'jan', 'isbn') as $k) {
			if (isset($p[$k])) {
				$codes .= ' ' . $p[$k];
			}
		}

		// OpenCart 4.1.0.4+ keeps SKU, EAN and the like in their own table.
		if (!isset($p['sku']) && $this->hasTable('product_code')) {
			foreach ($this->q("SELECT `value` FROM " . $this->o('product_code') . " WHERE product_id = '" . $product_id . "'")->rows as $c) {
				$codes .= ' ' . $c['value'];
			}
		}

		$codes = trim($codes);

		foreach ($descs as $d) {
			$lang = (int)$d['language_id'];
			$cats = $this->q("SELECT GROUP_CONCAT(cd.name SEPARATOR ' ') AS n FROM " . $this->o('product_to_category') . " pc JOIN " . $this->o('category_description') . " cd ON (cd.category_id = pc.category_id AND cd.language_id = '" . $lang . "') WHERE pc.product_id = '" . $product_id . "'")->row['n'];
			$attrs = $this->q("SELECT ad.name, pa.text FROM " . $this->o('product_attribute') . " pa JOIN " . $this->o('attribute_description') . " ad ON (ad.attribute_id = pa.attribute_id AND ad.language_id = '" . $lang . "') WHERE pa.product_id = '" . $product_id . "' AND pa.language_id = '" . $lang . "'")->rows;
			$opts = $this->q("SELECT od.name, GROUP_CONCAT(ovd.name SEPARATOR ' ') AS vals FROM " . $this->o('product_option') . " po JOIN " . $this->o('option_description') . " od ON (od.option_id = po.option_id AND od.language_id = '" . $lang . "') LEFT JOIN " . $this->o('product_option_value') . " pov ON (pov.product_option_id = po.product_option_id) LEFT JOIN " . $this->o('option_value_description') . " ovd ON (ovd.option_value_id = pov.option_value_id AND ovd.language_id = '" . $lang . "') WHERE po.product_id = '" . $product_id . "' GROUP BY po.product_option_id")->rows;

			$attrText = '';

			foreach ($attrs as $a) {
				$attrText .= ' ' . $a['name'] . ' ' . $a['text'];
			}

			$optText = '';

			foreach ($opts as $o) {
				$optText .= ' ' . $o['name'] . ' ' . $o['vals'];
			}

			$this->saveDoc('p', $product_id, $lang, $d['name'], array(
				array($d['name'], 6),
				array($codes, 6),
				array($p['manufacturer'], 3),
				array($d['tag'], 3),
				array((string)$cats, 2.5),
				array($attrText, 2),
				array($optText, 1.5),
				array($d['meta_keyword'] . ' ' . $d['meta_title'], 1),
				array(self::plain($d['description']), 1)
			));
		}

		return true;
	}

	public function indexInformation($information_id) {
		$information_id = (int)$information_id;
		$rows = $this->q("SELECT i.status, d.* FROM " . $this->o('information') . " i JOIN " . $this->o('information_description') . " d ON (d.information_id = i.information_id) WHERE i.information_id = '" . $information_id . "'")->rows;
		$this->removeDoc('i', $information_id);

		foreach ($rows as $r) {
			if (!(int)$r['status']) {
				continue;
			}

			$this->saveDoc('i', $information_id, (int)$r['language_id'], $r['title'], array(
				array($r['title'], 5),
				array(isset($r['meta_keyword']) ? $r['meta_keyword'] : '', 1),
				array(self::plain($r['description']), 1)
			));
		}
	}

	public function indexFaq($faq_id) {
		$q = $this->q("SELECT * FROM " . $this->t('faq') . " WHERE faq_id = '" . (int)$faq_id . "'");
		$this->removeDoc('f', $faq_id);

		if (!$q->num_rows || !(int)$q->row['status']) {
			return;
		}

		$f = $q->row;
		$langs = (int)$f['lang'] ? array((int)$f['lang']) : array_keys($this->languages());

		foreach ($langs as $lang) {
			$this->saveDoc('f', (int)$f['faq_id'], $lang, $f['question'], array(
				array($f['question'], 5),
				array($f['keywords'], 5),
				array(self::plain($f['answer']), 1)
			));
		}
	}

	/** Builds the index in steps, so a big catalogue never hits the PHP time limit. */
	public function rebuild(array $in) {
		$step = isset($in['step']) ? (string)$in['step'] : 'start';
		$offset = isset($in['offset']) ? (int)$in['offset'] : 0;
		$batch = 150;
		$total = (int)$this->q("SELECT COUNT(*) AS n FROM " . $this->o('product'))->row['n'];

		if ($step === 'start') {
			$this->q("TRUNCATE TABLE " . $this->t('term'));
			$this->q("TRUNCATE TABLE " . $this->t('doc'));

			foreach ($this->q("SELECT information_id FROM " . $this->o('information'))->rows as $r) {
				$this->indexInformation($r['information_id']);
			}

			foreach ($this->q("SELECT faq_id FROM " . $this->t('faq'))->rows as $r) {
				$this->indexFaq($r['faq_id']);
			}

			return array('step' => 'products', 'offset' => 0, 'total' => $total, 'done' => false);
		}

		$ids = $this->q("SELECT product_id FROM " . $this->o('product') . " ORDER BY product_id LIMIT " . (int)$offset . ", " . $batch)->rows;

		foreach ($ids as $r) {
			$this->indexProduct($r['product_id']);
		}

		$offset += count($ids);

		if (count($ids) < $batch) {
			$cfg = $this->getConfig();
			$cfg['indexed'] = self::now();
			$cfg['checked'] = time();
			$this->writeConfig($cfg);

			return array('step' => 'done', 'offset' => $offset, 'total' => $total, 'done' => true, 'index' => $this->indexStatus());
		}

		return array('step' => 'products', 'offset' => $offset, 'total' => $total, 'done' => false);
	}

	/**
	 * Picks up products changed outside the admin forms (imports, other extensions):
	 * at most once every 10 minutes, at most 100 products at a time.
	 */
	public function refreshChanged() {
		$cfg = $this->getConfig();

		if (!$cfg['indexed'] || time() - (int)$cfg['checked'] < 600) {
			return 0;
		}

		$since = date('Y-m-d H:i:s', max(0, (int)$cfg['checked'] - 60));
		$cfg['checked'] = time();
		$this->writeConfig($cfg);
		$rows = $this->q("SELECT product_id FROM " . $this->o('product') . " WHERE date_modified >= '" . $this->e($since) . "' OR date_added >= '" . $this->e($since) . "' LIMIT 100")->rows;

		foreach ($rows as $r) {
			$this->indexProduct($r['product_id']);
		}

		return count($rows);
	}

	public function indexStatus() {
		$cfg = $this->getConfig();
		$n = $this->q("SELECT `doc`, COUNT(DISTINCT id) AS n FROM " . $this->t('doc') . " GROUP BY `doc`")->rows;
		$c = array('p' => 0, 'i' => 0, 'f' => 0);

		foreach ($n as $r) {
			$c[$r['doc']] = (int)$r['n'];
		}

		$behind = 0;

		if ($cfg['indexed']) {
			$behind = (int)$this->q("SELECT COUNT(*) AS n FROM " . $this->o('product') . " WHERE date_modified > '" . $this->e($cfg['indexed']) . "' OR date_added > '" . $this->e($cfg['indexed']) . "'")->row['n'];
		}

		return array(
			'products' => $c['p'], 'pages' => $c['i'], 'answers' => $c['f'],
			'all_products' => (int)$this->q("SELECT COUNT(*) AS n FROM " . $this->o('product'))->row['n'],
			'built' => $cfg['indexed'], 'behind' => $behind
		);
	}

	/* ------------------------------------------------ asking */

	private function synonymMap() {
		$cfg = $this->getConfig();
		$groups = array_merge(self::builtInSynonyms(), preg_split('~\n~', (string)$cfg['synonyms']));
		$map = array();

		foreach ($groups as $g) {
			$words = array_values(array_unique(self::words(str_replace(array(',', ';', '='), ' ', $g), true)));

			foreach ($words as $w) {
				foreach ($words as $o) {
					if ($o !== $w) {
						$map[$w][$o] = true;
					}
				}
			}
		}

		return $map;
	}

	/** Letters to compare for "same word, different ending" (boards / board, piegādi / piegāde). */
	private static function stemPrefix($w) {
		$l = self::len($w);

		if ($l < 5 || preg_match('~\d~', $w)) {
			return '';
		}

		return self::sub($w, 0, max(4, $l - 2));
	}

	/**
	 * Finds the documents that match the question words.
	 * Returns array(key => array(doc, id, score, covered)) where covered = share of question words found.
	 */
	private function search(array $tokens, $lang, array &$used) {
		if (!$tokens) {
			return array();
		}

		$syn = $this->synonymMap();
		$want = array();   // term => array(token index => factor)
		$prefixes = array();

		foreach ($tokens as $i => $t) {
			$want[$t][$i] = 1.0;

			if (isset($syn[$t])) {
				foreach (array_keys($syn[$t]) as $s) {
					if (!isset($want[$s][$i])) {
						$want[$s][$i] = 0.8;
					}
				}
			}

			$pre = self::stemPrefix($t);

			if ($pre !== '') {
				$prefixes[] = array($pre, $i, self::len($t));
			}
		}

		$where = array("`term` IN ('" . implode("','", array_map(array($this, 'e'), array_keys($want))) . "')");

		foreach ($prefixes as $pr) {
			$where[] = "(`term` LIKE '" . $this->e(addcslashes($pr[0], '%_\\')) . "%' AND CHAR_LENGTH(`term`) <= " . ($pr[2] + 3) . ")";
		}

		$rows = $this->q("SELECT `term`, `doc`, `id`, `w` FROM " . $this->t('term') . " WHERE `lang` = '" . (int)$lang . "' AND (" . implode(' OR ', $where) . ") LIMIT 30000")->rows;

		// Words with no match at all: try a one- or two-letter typo against the shop's own words.
		$found = array();

		foreach ($rows as $r) {
			$found[$r['term']] = true;
		}

		foreach ($tokens as $i => $t) {
			$hit = isset($found[$t]);

			if (!$hit) {
				foreach ($want as $term => $tok) {
					if (isset($tok[$i]) && isset($found[$term])) {
						$hit = true;
						break;
					}
				}
			}

			if (!$hit) {
				foreach ($prefixes as $pr) {
					if ($pr[1] === $i) {
						foreach (array_keys($found) as $term) {
							if (strpos($term, $pr[0]) === 0) {
								$hit = true;
								break 2;
							}
						}
					}
				}
			}

			$l = self::len($t);

			if ($hit || $l < 4 || preg_match('~\d~', $t)) {
				continue;
			}

			$cands = $this->q("SELECT DISTINCT `term` FROM " . $this->t('term') . " WHERE `lang` = '" . (int)$lang . "' AND `term` LIKE '" . $this->e(addcslashes(self::sub($t, 0, 1), '%_\\')) . "%' AND CHAR_LENGTH(`term`) BETWEEN " . ($l - 2) . " AND " . ($l + 2) . " LIMIT 3000")->rows;
			$best = '';
			$bestD = $l >= 6 ? 3 : 2;   // allow 1 wrong letter in short words, 2 in longer ones

			foreach ($cands as $c) {
				$d = levenshtein($t, $c['term']);

				if ($d < $bestD) {
					$bestD = $d;
					$best = $c['term'];
				}
			}

			if ($best !== '') {
				$want[$best][$i] = 0.6;
				$used[] = $best;

				foreach ($this->q("SELECT `term`, `doc`, `id`, `w` FROM " . $this->t('term') . " WHERE `lang` = '" . (int)$lang . "' AND `term` = '" . $this->e($best) . "' LIMIT 5000")->rows as $r) {
					$rows[] = $r;
				}
			}
		}

		if (!$rows) {
			return array();
		}

		$total = max(1, (int)$this->q("SELECT COUNT(*) AS n FROM " . $this->t('doc') . " WHERE `lang` = '" . (int)$lang . "'")->row['n']);
		$df = array();

		foreach ($rows as $r) {
			$df[$r['term']] = (isset($df[$r['term']]) ? $df[$r['term']] : 0) + 1;
		}

		$docs = array();

		foreach ($rows as $r) {
			$term = $r['term'];
			$matches = isset($want[$term]) ? $want[$term] : array();

			foreach ($prefixes as $pr) {
				if (strpos($term, $pr[0]) === 0 && !isset($matches[$pr[1]])) {
					$matches[$pr[1]] = 0.7;
				}
			}

			if (!$matches) {
				continue;
			}

			$idf = log(1 + ($total - $df[$term] + 0.5) / ($df[$term] + 0.5));
			$key = $r['doc'] . $r['id'];

			foreach ($matches as $i => $factor) {
				$s = $factor * $idf * (float)$r['w'];

				if (!isset($docs[$key])) {
					$docs[$key] = array('doc' => $r['doc'], 'id' => (int)$r['id'], 'tok' => array(), 'terms' => array());
				}

				if (!isset($docs[$key]['tok'][$i]) || $docs[$key]['tok'][$i] < $s) {
					$docs[$key]['tok'][$i] = $s;
				}

				$docs[$key]['terms'][$term] = true;
			}
		}

		$n = count($tokens);

		foreach ($docs as $k => $d) {
			$covered = count($d['tok']) / $n;
			$docs[$k]['covered'] = $covered;
			$docs[$k]['score'] = array_sum($d['tok']) * (0.4 + 0.6 * $covered * $covered);
		}

		uasort($docs, function ($a, $b) {
			return $b['score'] == $a['score'] ? 0 : ($b['score'] > $a['score'] ? 1 : -1);
		});

		return $docs;
	}

	/** Every form of the question's words: the words themselves, their same-meaning words, and their stems. */
	private function matchers(array $tokens) {
		$syn = $this->synonymMap();
		$m = array();

		foreach ($tokens as $t) {
			$m[] = $t;

			if (isset($syn[$t])) {
				foreach (array_keys($syn[$t]) as $s) {
					$m[] = $s;
				}
			}

			$pre = self::stemPrefix($t);

			if ($pre !== '') {
				$m[] = $pre;
			}
		}

		return array_values(array_unique($m));
	}

	private static function hits($text, array $matchers) {
		$n = 0;
		$words = self::words($text, true);

		foreach ($matchers as $m) {
			foreach ($words as $w) {
				if ($w === $m || (self::len($m) >= 4 && strpos($w, $m) === 0)) {
					$n++;
					break;
				}
			}
		}

		return $n;
	}

	/** The sentences of a text that best match the question. */
	private static function bestSentences($text, array $matchers, $max = 2) {
		$parts = preg_split('~(?<=[.!?])\s+|\n+~u', self::plain($text), -1, PREG_SPLIT_NO_EMPTY);
		$scored = array();

		foreach ($parts as $i => $s) {
			$s = trim($s);

			if (self::len($s) < 3) {
				continue;
			}

			$h = self::hits($s, $matchers);

			if ($h) {
				$scored[] = array($h, $i, self::len($s) > 280 ? self::sub($s, 0, 277) . '…' : $s);
			}
		}

		usort($scored, function ($a, $b) {
			return $a[0] == $b[0] ? $a[1] - $b[1] : $b[0] - $a[0];
		});

		$out = array();

		foreach (array_slice($scored, 0, $max) as $s) {
			$out[] = $s[2];
		}

		return $out;
	}

	/** Facts about one product that answer the question: attributes, options, size, weight, code, description. */
	private function productFacts($product_id, $lang, array $tokens, array $intent, array $T) {
		$product_id = (int)$product_id;
		$p = $this->q("SELECT p.*, pd.name, pd.description, wcd.unit AS wunit, lcd.unit AS lunit FROM " . $this->o('product') . " p
			JOIN " . $this->o('product_description') . " pd ON (pd.product_id = p.product_id AND pd.language_id = '" . (int)$lang . "')
			LEFT JOIN " . $this->o('weight_class_description') . " wcd ON (wcd.weight_class_id = p.weight_class_id AND wcd.language_id = '" . (int)$lang . "')
			LEFT JOIN " . $this->o('length_class_description') . " lcd ON (lcd.length_class_id = p.length_class_id AND lcd.language_id = '" . (int)$lang . "')
			WHERE p.product_id = '" . $product_id . "'");

		if (!$p->num_rows) {
			return array(null, array());
		}

		$p = $p->row;
		$p['name'] = html_entity_decode($p['name'], ENT_QUOTES, 'UTF-8');
		$m = $this->matchers($tokens);
		$facts = array();
		$allOptions = !empty($intent['options']);

		if (!empty($intent['weight']) && (float)$p['weight'] > 0) {
			$facts[] = array('label' => $T['weight'], 'text' => rtrim(rtrim(number_format((float)$p['weight'], 3, '.', ''), '0'), '.') . ' ' . $p['wunit']);
		}

		if (!empty($intent['size']) && ((float)$p['length'] > 0 || (float)$p['width'] > 0 || (float)$p['height'] > 0)) {
			$f = function ($v) {
				return rtrim(rtrim(number_format((float)$v, 2, '.', ''), '0'), '.');
			};
			$facts[] = array('label' => $T['size'], 'text' => $f($p['length']) . ' × ' . $f($p['width']) . ' × ' . $f($p['height']) . ' ' . $p['lunit']);
		}

		if (!empty($intent['model'])) {
			$facts[] = array('label' => $T['model'], 'text' => $p['model'] . (!empty($p['sku']) ? ' (SKU ' . $p['sku'] . ')' : ''));
		}

		if ($m || $allOptions) {
			$attrs = $this->q("SELECT agd.name AS grp, ad.name, pa.text FROM " . $this->o('product_attribute') . " pa
				JOIN " . $this->o('attribute') . " a ON (a.attribute_id = pa.attribute_id)
				JOIN " . $this->o('attribute_description') . " ad ON (ad.attribute_id = pa.attribute_id AND ad.language_id = '" . (int)$lang . "')
				LEFT JOIN " . $this->o('attribute_group_description') . " agd ON (agd.attribute_group_id = a.attribute_group_id AND agd.language_id = '" . (int)$lang . "')
				WHERE pa.product_id = '" . $product_id . "' AND pa.language_id = '" . (int)$lang . "' ORDER BY a.sort_order, ad.name")->rows;

			foreach ($attrs as $a) {
				if ($m && self::hits($a['grp'] . ' ' . $a['name'] . ' ' . $a['text'], $m)) {
					$facts[] = array('label' => $a['name'], 'text' => self::plain($a['text']));
				}
			}

			$opts = $this->q("SELECT po.product_option_id, od.name, GROUP_CONCAT(ovd.name ORDER BY ov.sort_order SEPARATOR ', ') AS vals FROM " . $this->o('product_option') . " po
				JOIN " . $this->o('option_description') . " od ON (od.option_id = po.option_id AND od.language_id = '" . (int)$lang . "')
				LEFT JOIN " . $this->o('product_option_value') . " pov ON (pov.product_option_id = po.product_option_id)
				LEFT JOIN " . $this->o('option_value') . " ov ON (ov.option_value_id = pov.option_value_id)
				LEFT JOIN " . $this->o('option_value_description') . " ovd ON (ovd.option_value_id = pov.option_value_id AND ovd.language_id = '" . (int)$lang . "')
				WHERE po.product_id = '" . $product_id . "' GROUP BY po.product_option_id")->rows;

			foreach ($opts as $o) {
				if ($o['vals'] !== null && $o['vals'] !== '' && ($allOptions || self::hits($o['name'] . ' ' . $o['vals'], $m))) {
					$facts[] = array('label' => $o['name'], 'text' => $o['vals']);
				}
			}

			foreach ($m ? self::bestSentences($p['description'], $m, $facts ? 1 : 2) : array() as $s) {
				$facts[] = array('label' => '', 'text' => $s);
			}
		}

		return array($p['name'], array_slice($facts, 0, 6));
	}

	private function detectIntent($question) {
		$out = array();

		foreach (self::intents() as $k => $re) {
			if (preg_match($re, $question)) {
				$out[$k] = true;
			}
		}

		$out['amount'] = null;

		if (!empty($out['under']) || !empty($out['over'])) {
			// The number straight after "under" / "over" (the intent pattern already requires one).
			$re = !empty($out['under']) ? self::intents()['under'] : self::intents()['over'];
			$re = substr($re, 0, -5) . '(\d{1,7}(?:[.,]\d{1,2})?)~iu';

			if (preg_match($re, $question, $mm) && preg_match('~(\d{1,7}(?:[.,]\d{1,2})?)$~', $mm[0], $mm)) {
				$out['amount'] = (float)str_replace(',', '.', $mm[1]);
			} else {
				unset($out['under'], $out['over']);
			}
		}

		return $out;
	}

	/** The question's own subject words: without question words, intent words and the price amount. */
	private function subjectTokens($question, array $intent) {
		$q = $question;

		foreach (self::intents() as $k => $re) {
			if ($k === 'under' || $k === 'over') {
				$re = substr($re, 0, -5) . '\d[\d.,]*~iu';
			}

			$q = preg_replace($re, ' ', $q);
		}

		$q = preg_replace('~[€$£]|\b(eur|euro|euros|usd|gbp|dollars?|pounds?|eiro|руб\w*)\b~iu', ' ', $q);

		return array_values(array_unique(self::words($q)));
	}

	private function docTitle($doc, $id, $lang) {
		$q = $this->q("SELECT title FROM " . $this->t('doc') . " WHERE `doc` = '" . $this->e($doc) . "' AND id = '" . (int)$id . "' AND lang = '" . (int)$lang . "'");

		return $q->num_rows ? html_entity_decode($q->row['title'], ENT_QUOTES, 'UTF-8') : '';
	}

	/** Question words that are not part of the product's name: what the shopper wants to know about it. */
	private function restOf(array $tokens, $title) {
		$rest = array();

		foreach ($tokens as $t) {
			if (!self::hits($title, $this->matchers(array($t)))) {
				$rest[] = $t;
			}
		}

		return $rest;
	}

	public function restOfPublic(array $tokens, $title) {
		return $this->restOf($tokens, $title);
	}

	public function docTitlePublic($doc, $id, $lang) {
		return $this->docTitle($doc, $id, $lang);
	}

	private function faqRow($faq_id) {
		$q = $this->q("SELECT * FROM " . $this->t('faq') . " WHERE faq_id = '" . (int)$faq_id . "' AND status = '1'");

		return $q->num_rows ? $q->row : null;
	}

	private function infoRow($information_id, $lang, $store_id) {
		$q = $this->q("SELECT i.information_id, d.title, d.description FROM " . $this->o('information') . " i
			JOIN " . $this->o('information_description') . " d ON (d.information_id = i.information_id AND d.language_id = '" . (int)$lang . "')
			JOIN " . $this->o('information_to_store') . " s ON (s.information_id = i.information_id AND s.store_id = '" . (int)$store_id . "')
			WHERE i.information_id = '" . (int)$information_id . "' AND i.status = '1'");

		return $q->num_rows ? $q->row : null;
	}

	private function productVisible($product_id, $store_id) {
		return $this->q("SELECT 1 FROM " . $this->o('product') . " p JOIN " . $this->o('product_to_store') . " s ON (s.product_id = p.product_id AND s.store_id = '" . (int)$store_id . "') WHERE p.product_id = '" . (int)$product_id . "' AND p.status = '1' AND p.date_available <= NOW()")->num_rows > 0;
	}

	/** Cheapest or dearest products in the shop when the question has no subject ("what is your cheapest product?"). */
	private function productsByPrice($store_id, $dir, $limit, $maxBase = null, $minBase = null) {
		$sql = "SELECT p.product_id FROM " . $this->o('product') . " p JOIN " . $this->o('product_to_store') . " s ON (s.product_id = p.product_id AND s.store_id = '" . (int)$store_id . "') WHERE p.status = '1' AND p.date_available <= NOW() AND p.price > 0";

		if ($maxBase !== null) {
			$sql .= " AND p.price <= '" . (float)$maxBase . "'";
		}

		if ($minBase !== null) {
			$sql .= " AND p.price >= '" . (float)$minBase . "'";
		}

		$sql .= " ORDER BY p.price " . ($dir === 'desc' ? 'DESC' : 'ASC') . ", p.product_id LIMIT " . (int)$limit;
		$out = array();

		foreach ($this->q($sql)->rows as $r) {
			$out[] = (int)$r['product_id'];
		}

		return $out;
	}

	/**
	 * Answers one question.
	 * $ctx: lang, code, store_id, product_id (the product page the question was asked on),
	 *       card(product_id) => array|null with name, href, thumb, price, price_value, stock, in_stock,
	 *       info_href(information_id), contact_href, money(amount), currency_value
	 */
	public function answer($question, array $ctx) {
		$this->nolog = !empty($ctx['nolog']);
		$question = trim(preg_replace('~\s+~u', ' ', (string)$question));
		$question = self::sub($question, 0, 300);
		$lang = (int)$ctx['lang'];
		$store = (int)$ctx['store_id'];
		$cfg = $this->getConfig();
		$T = $this->texts($lang, $ctx['code']);
		$max = (int)$cfg['max_products'];
		$res = array('found' => false, 'kind' => 'none', 'text' => '', 'facts' => array(), 'products' => array(), 'link' => null, 'contact' => array('title' => $T['contact'], 'href' => $ctx['contact_href']));

		if ($question === '') {
			$res['text'] = $T['greeting'];

			return $res;
		}

		$this->refreshChanged();
		$intent = $this->detectIntent(self::lower($question));
		$tokens = $this->subjectTokens(self::lower($question), $intent);
		$used = array();
		$docs = $this->search($tokens, $lang, $used);

		$best = array('p' => null, 'f' => null, 'i' => null);

		foreach ($docs as $d) {
			if ($best[$d['doc']] !== null) {
				continue;
			}

			if ($d['doc'] === 'p' && !$this->productVisible($d['id'], $store)) {
				continue;
			}

			if ($d['doc'] === 'i' && !$this->infoRow($d['id'], $lang, $store)) {
				continue;
			}

			if ($d['doc'] === 'f' && !$this->faqRow($d['id'])) {
				continue;   // switched off or deleted outside the admin page
			}

			$best[$d['doc']] = $d;
		}

		$ctxPid = !empty($ctx['product_id']) ? (int)$ctx['product_id'] : 0;
		$ctxHit = $ctxPid && isset($docs['p' . $ctxPid]) ? $docs['p' . $ctxPid] : null;
		$strong = function ($d) use ($tokens) {
			return $d && ($d['covered'] >= 0.99 || ($d['covered'] >= 0.5 && count($tokens) >= 2));
		};

		$pFirst = $best['p'];
		// On a product page, "it" is that product - unless the question names another product.
		$otherProduct = false;

		if ($pFirst && $pFirst['id'] !== $ctxPid && $strong($pFirst)) {
			$named = count($tokens) - count($this->restOf($tokens, $this->docTitle('p', $pFirst['id'], $lang)));
			$ctxNamed = $ctxPid ? count($tokens) - count($this->restOf($tokens, $this->docTitle('p', $ctxPid, $lang))) : 0;
			$otherProduct = !$ctxPid || ($named > 0 && $named > $ctxNamed);
		}
		$docScore = function ($d) {
			return $d ? $d['score'] : 0;
		};

		// 1. The owner's own answers and the information pages (delivery, returns, payment...).
		$text = $best['f'] && $docScore($best['f']) >= $docScore($best['i']) ? $best['f'] : $best['i'];
		$textWins = $strong($text) && !$intent['amount'] && empty($intent['cheapest']) && empty($intent['dearest'])
			&& ($text['doc'] === 'f' || !$pFirst || $text['score'] >= 0.8 * $pFirst['score'] || $text['covered'] > $pFirst['covered'])
			&& !($ctxPid && !$otherProduct && $ctxHit && $ctxHit['covered'] >= $text['covered'] && $ctxHit['score'] >= $text['score']);

		if ($textWins) {
			if ($text['doc'] === 'f') {
				$f = $this->faqRow($text['id']);
				$this->q("UPDATE " . $this->t('faq') . " SET asked = asked + 1 WHERE faq_id = '" . (int)$text['id'] . "'");
				$res = array_merge($res, array('found' => true, 'kind' => 'answer', 'text' => self::plain($f['answer']), 'title' => $f['question']));

				if ($f['link'] !== '') {
					$res['link'] = array('title' => $T['more'], 'href' => $f['link']);
				}

				return $this->logged($question, $lang, $ctxPid, $res, $f['question']);
			}

			$info = $this->infoRow($text['id'], $lang, $store);
			$sent = self::bestSentences($info['description'], $this->matchers($tokens), 3);
			$res = array_merge($res, array('found' => true, 'kind' => 'page', 'text' => implode(' ', $sent), 'title' => $info['title'], 'link' => array('title' => $info['title'], 'href' => call_user_func($ctx['info_href'], $info['information_id']))));

			return $this->logged($question, $lang, $ctxPid, $res, $info['title']);
		}

		// 2. A question about the product page it was asked on ("does it come in red?", "how heavy is it?").
		$aboutCtx = $ctxPid && !$otherProduct && $this->productVisible($ctxPid, $store)
			&& ($tokens || !empty($intent['price']) || !empty($intent['stock']) || !empty($intent['weight']) || !empty($intent['size']) || !empty($intent['model']) || !empty($intent['options']))
			&& !$intent['amount'] && empty($intent['cheapest']) && empty($intent['dearest']);

		if ($aboutCtx) {
			$rest = $this->restOf($tokens, $this->docTitle('p', $ctxPid, $lang));
			list($name, $facts) = $this->productFacts($ctxPid, $lang, $rest, $intent, $T);
			$card = call_user_func($ctx['card'], $ctxPid);

			if (!empty($intent['price']) && $card) {
				array_unshift($facts, array('label' => $T['price'], 'text' => $card['price']));
			}

			if (!empty($intent['stock']) && $card) {
				array_unshift($facts, array('label' => '', 'text' => $card['stock']));
			}

			if ($facts) {
				$res = array_merge($res, array('found' => true, 'kind' => 'facts', 'text' => str_replace('{name}', $name, $T['facts']), 'facts' => $facts));

				return $this->logged($question, $lang, $ctxPid, $res, $name);
			}

			// Not in this product's details: say so, and show other products that do mention it.
			$res = array_merge($res, array('found' => false, 'kind' => 'nofact', 'text' => str_replace('{name}', $name, $T['no_fact'])));
			$others = array();

			if ($rest) {
				foreach ($docs as $d) {
					if ($d['doc'] === 'p' && $d['id'] !== $ctxPid && $d['covered'] >= 0.99 && $this->productVisible($d['id'], $store)) {
						$c = call_user_func($ctx['card'], $d['id']);

						if ($c) {
							$others[] = $c;
						}

						if (count($others) >= min(3, $max)) {
							break;
						}
					}
				}
			}

			if ($others) {
				$res['products'] = $others;
				$res['more_text'] = $T['products'];
			}

			return $this->logged($question, $lang, $ctxPid, $res, '');
		}

		// 3. Products: by price ("anything under 50?", "cheapest one") and/or by subject.
		$curval = isset($ctx['currency_value']) && (float)$ctx['currency_value'] > 0 ? (float)$ctx['currency_value'] : 1.0;
		$ids = array();
		$byPrice = $intent['amount'] !== null || !empty($intent['cheapest']) || !empty($intent['dearest']);

		if ($tokens) {
			$self = $this;
			// A product counts when it matches every question word, or at least half of them including part of its name.
			$fits = function ($d) use ($self, $tokens, $lang) {
				if ($d['covered'] >= 0.99) {
					return true;
				}

				return $d['covered'] >= 0.5 && count($self->restOfPublic($tokens, $self->docTitlePublic('p', $d['id'], $lang))) < count($tokens);
			};

			foreach ($docs as $d) {
				if ($d['doc'] !== 'p' || !$fits($d)) {
					continue;
				}

				// Keep products that match the question about as well as the best one does.
				if ($pFirst && ($d['covered'] < $pFirst['covered'] - 0.01 || $d['score'] < 0.25 * $pFirst['score'])) {
					continue;
				}

				if ($this->productVisible($d['id'], $store)) {
					$ids[] = $d['id'];
				}

				if (count($ids) >= ($byPrice ? 60 : $max)) {
					break;
				}
			}

		} elseif ($byPrice) {
			$maxBase = !empty($intent['under']) && $intent['amount'] !== null ? $intent['amount'] / $curval : null;
			$minBase = !empty($intent['over']) && empty($intent['under']) && $intent['amount'] !== null ? ($intent['amount'] / $curval) / 2 : null;
			$ids = $this->productsByPrice($store, !empty($intent['dearest']) ? 'desc' : 'asc', 60, $maxBase, $minBase);
		}

		$cards = array();

		foreach ($ids as $id) {
			$c = call_user_func($ctx['card'], $id);

			if (!$c) {
				continue;
			}

			if ($intent['amount'] !== null) {
				if (!empty($intent['under']) && $c['price_value'] > $intent['amount'] + 0.0001) {
					continue;
				}

				if (!empty($intent['over']) && empty($intent['under']) && $c['price_value'] < $intent['amount'] - 0.0001) {
					continue;
				}
			}

			$cards[] = $c;
		}

		if ($byPrice) {
			$desc = !empty($intent['dearest']);
			usort($cards, function ($a, $b) use ($desc) {
				if ($a['price_value'] == $b['price_value']) {
					return 0;
				}

				return (($a['price_value'] < $b['price_value']) xor $desc) ? -1 : 1;
			});
		}

		$cards = array_slice($cards, 0, $max);

		if ($cards) {
			if ($intent['amount'] !== null && (!empty($intent['under']) || !empty($intent['over']))) {
				$head = str_replace('{price}', call_user_func($ctx['money'], $intent['amount']), !empty($intent['under']) ? $T['under'] : $T['over']);
			} elseif (!empty($intent['cheapest'])) {
				$head = $T['cheapest'];
			} else {
				$head = $T['products'];
			}

			$res = array_merge($res, array('found' => true, 'kind' => 'products', 'text' => $head, 'products' => $cards));

			// One clear winner: add the facts that answer the rest of the question.
			if (!$byPrice && $pFirst && $cards && $cards[0]['id'] === $pFirst['id']) {
				$second = null;

				foreach ($docs as $d) {
					if ($d['doc'] === 'p' && $d['id'] !== $pFirst['id']) {
						$second = $d;
						break;
					}
				}

				$rest = $this->restOf($tokens, $this->docTitle('p', $pFirst['id'], $lang));

				if (($rest || !empty($intent['options']) || !empty($intent['weight']) || !empty($intent['size'])) && (!$second || $pFirst['score'] > 1.5 * $second['score'])) {
					list($name, $facts) = $this->productFacts($pFirst['id'], $lang, $rest, $intent, $T);
					$res['facts'] = $facts;
				}
			}

			return $this->logged($question, $lang, $ctxPid, $res, $cards[0]['name'] . (count($cards) > 1 ? ' +' . (count($cards) - 1) : ''));
		}

		// 4. Nothing good enough: say so honestly, offer contact.
		$res['text'] = $T['not_found'];
		$res['kind'] = 'none';

		return $this->logged($question, $lang, $ctxPid, $res, '');
	}

	private function logged($question, $lang, $product_id, array $res, $top) {
		$cfg = $this->getConfig();

		if ($cfg['log'] && !$this->nolog) {
			// Do not keep e-mail addresses or phone numbers people type into the box.
			$q = preg_replace('~[\w.+-]+@[\w-]+\.[\w.-]+~u', '[email]', $question);
			$q = preg_replace('~\+?\d[\d \-()]{7,}\d~', '[number]', $q);
			$this->q("INSERT INTO " . $this->t('log') . " SET q = '" . $this->e(self::sub($q, 0, 300)) . "', lang = '" . (int)$lang . "', product_id = '" . (int)$product_id . "', answered = '" . ($res['found'] ? 1 : 0) . "', kind = '" . $this->e($res['kind']) . "', top = '" . $this->e(self::sub((string)$top, 0, 255)) . "', created = '" . self::now() . "'");

			if (mt_rand(1, 50) === 1) {
				$this->q("DELETE FROM " . $this->t('log') . " WHERE created < '" . date('Y-m-d H:i:s', strtotime('-' . (int)$cfg['log_days'] . ' days')) . "'");
			}
		}

		return $res;
	}

	/** At most 20 questions a minute from one address; protects the shop from scripts. */
	public function allow($ip) {
		$k = sha1('pan' . $ip);
		$minute = (int)floor(time() / 60);
		$this->q("INSERT INTO " . $this->t('rate') . " SET k = '" . $k . "', minute = '" . $minute . "', n = 1 ON DUPLICATE KEY UPDATE n = n + 1");
		$n = (int)$this->q("SELECT n FROM " . $this->t('rate') . " WHERE k = '" . $k . "' AND minute = '" . $minute . "'")->row['n'];

		if (mt_rand(1, 100) === 1) {
			$this->q("DELETE FROM " . $this->t('rate') . " WHERE minute < '" . ($minute - 5) . "'");
		}

		return $n <= 20;
	}

	/* ------------------------------------------------ admin */

	public function bootstrap(array $in) {
		$langs = array();

		foreach ($this->q("SELECT language_id, name, code FROM " . $this->o('language') . " WHERE status = '1' ORDER BY sort_order, language_id")->rows as $l) {
			$langs[] = array('id' => (int)$l['language_id'], 'name' => $l['name'], 'code' => $l['code'], 'defaults' => self::textDefaults($l['code']));
		}

		return array('languages' => $langs, 'settings' => $this->settingsView(), 'index' => $this->indexStatus(), 'stats' => $this->stats(array()));
	}

	private function settingsView() {
		$cfg = $this->getConfig();
		unset($cfg['indexed'], $cfg['checked']);
		$cfg['builtin_synonyms'] = self::builtInSynonyms();

		return $cfg;
	}

	public function stats(array $in) {
		$days = isset($in['days']) ? max(1, min(365, (int)$in['days'])) : 30;
		$from = date('Y-m-d H:i:s', strtotime('-' . $days . ' days'));
		$t = $this->q("SELECT COUNT(*) AS n, SUM(answered) AS a FROM " . $this->t('log') . " WHERE created >= '" . $from . "'")->row;
		$open = $this->q("SELECT MIN(q) AS q, COUNT(*) AS n, MAX(created) AS last, MAX(lang) AS lang FROM " . $this->t('log') . " WHERE created >= '" . $from . "' AND answered = '0' GROUP BY LOWER(q) ORDER BY n DESC, last DESC LIMIT 50")->rows;
		$recent = $this->q("SELECT l.*, pd.name AS page FROM " . $this->t('log') . " l LEFT JOIN " . $this->o('product_description') . " pd ON (pd.product_id = l.product_id AND pd.language_id = l.lang) ORDER BY l.log_id DESC LIMIT 40")->rows;

		foreach ($open as &$o) {
			$o['n'] = (int)$o['n'];
		}

		foreach ($recent as &$r) {
			$r['answered'] = (int)$r['answered'];
			$r['page'] = $r['page'] === null ? null : html_entity_decode($r['page'], ENT_QUOTES, 'UTF-8');
		}

		return array('now' => self::now(), 'days' => $days, 'total' => (int)$t['n'], 'answered' => (int)$t['a'], 'open' => $open, 'recent' => $recent, 'log' => (int)$this->getConfig()['log']);
	}

	public function faqList(array $in) {
		$rows = $this->q("SELECT * FROM " . $this->t('faq') . " ORDER BY faq_id DESC")->rows;

		foreach ($rows as &$r) {
			foreach (array('faq_id', 'lang', 'status', 'asked') as $k) {
				$r[$k] = (int)$r[$k];
			}
		}

		return $rows;
	}

	public function faqSave(array $in) {
		$question = trim((string)(isset($in['question']) ? $in['question'] : ''));
		$answer = trim((string)(isset($in['answer']) ? $in['answer'] : ''));

		if ($question === '' || $answer === '') {
			throw new Exception('Please fill in both the question and the answer.');
		}

		$link = trim((string)(isset($in['link']) ? $in['link'] : ''));

		if ($link !== '' && !preg_match('~^(https?://|/)~i', $link)) {
			throw new Exception('The link must start with https:// or /');
		}

		$set = "lang = '" . (int)(isset($in['lang']) ? $in['lang'] : 0) . "', question = '" . $this->e(self::sub($question, 0, 255)) . "', keywords = '" . $this->e(self::sub(trim((string)(isset($in['keywords']) ? $in['keywords'] : '')), 0, 500)) . "', answer = '" . $this->e(self::sub($answer, 0, 5000)) . "', link = '" . $this->e(self::sub($link, 0, 500)) . "', status = '" . (empty($in['status']) && isset($in['status']) ? 0 : 1) . "', updated = '" . self::now() . "'";

		if (!empty($in['faq_id'])) {
			$id = (int)$in['faq_id'];
			$this->q("UPDATE " . $this->t('faq') . " SET " . $set . " WHERE faq_id = '" . $id . "'");
		} else {
			$this->q("INSERT INTO " . $this->t('faq') . " SET " . $set);
			$id = (int)$this->db->getLastId();
		}

		$this->indexFaq($id);

		// Questions this answer now covers stop showing as unanswered.
		if (!empty($in['resolve']) && is_array($in['resolve'])) {
			foreach ($in['resolve'] as $q) {
				$this->q("UPDATE " . $this->t('log') . " SET answered = '1', kind = 'answer', top = '" . $this->e(self::sub($question, 0, 255)) . "' WHERE LOWER(q) = '" . $this->e(self::lower((string)$q)) . "' AND answered = '0'");
			}
		}

		return array('faq' => $this->faqList(array()), 'index' => $this->indexStatus());
	}

	public function faqDelete(array $in) {
		$id = (int)(isset($in['faq_id']) ? $in['faq_id'] : 0);
		$this->q("DELETE FROM " . $this->t('faq') . " WHERE faq_id = '" . $id . "'");
		$this->removeDoc('f', $id);

		return array('faq' => $this->faqList(array()), 'index' => $this->indexStatus());
	}

	public function dismiss(array $in) {
		$q = (string)(isset($in['q']) ? $in['q'] : '');
		$this->q("DELETE FROM " . $this->t('log') . " WHERE LOWER(q) = '" . $this->e(self::lower($q)) . "' AND answered = '0'");

		return $this->stats(array());
	}

	public function clearLog() {
		$this->q("TRUNCATE TABLE " . $this->t('log'));

		return $this->stats(array());
	}

	public function products(array $in) {
		$lang = (int)(isset($in['lang']) ? $in['lang'] : 0);
		$f = trim((string)(isset($in['q']) ? $in['q'] : ''));
		$sql = "SELECT p.product_id, pd.name FROM " . $this->o('product') . " p JOIN " . $this->o('product_description') . " pd ON (pd.product_id = p.product_id AND pd.language_id = '" . $lang . "') WHERE p.status = '1'";

		if ($f !== '') {
			$sql .= " AND (pd.name LIKE '%" . $this->e(addcslashes($f, '%_\\')) . "%' OR p.model LIKE '%" . $this->e(addcslashes($f, '%_\\')) . "%')";
		}

		$rows = $this->q($sql . " ORDER BY pd.name LIMIT 30")->rows;

		foreach ($rows as &$r) {
			$r['product_id'] = (int)$r['product_id'];
			$r['name'] = html_entity_decode($r['name'], ENT_QUOTES, 'UTF-8');
		}

		return $rows;
	}
}
}
