<?php
/**
 * Product Answers for OpenCart - renders the admin app and the shop's question box,
 * and routes the admin JSON calls.
 */
if (!class_exists('PanUi')) {
class PanUi {
	const VERSION = '1.0.0';

	public static function writeActions() {
		return array('save_settings', 'rebuild', 'faq_save', 'faq_delete', 'dismiss', 'clear_log');
	}

	public static function dispatch(PanService $s, $action, array $in) {
		switch ($action) {
			case 'bootstrap':     return $s->bootstrap($in);
			case 'stats':         return $s->stats($in);
			case 'faq_list':      return $s->faqList($in);
			case 'faq_save':      return $s->faqSave($in);
			case 'faq_delete':    return $s->faqDelete($in);
			case 'dismiss':       return $s->dismiss($in);
			case 'clear_log':     return $s->clearLog();
			case 'save_settings': return $s->saveConfig($in);
			case 'rebuild':       return $s->rebuild($in);
			case 'index_status':  return $s->indexStatus();
			case 'products':      return $s->products($in);
			default: throw new Exception('Unknown action: ' . $action);
		}
	}

	public static function input() {
		$data = json_decode((string)file_get_contents('php://input'), true);

		return is_array($data) ? $data : array();
	}

	public static function json($payload) {
		return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
	}

	public static function api(PanService $s, $action, $can) {
		$perm = in_array($action, self::writeActions(), true) ? 'modify' : 'access';

		if (!call_user_func($can, $perm)) {
			return self::json(array('error' => 'Permission denied: your user group needs "' . $perm . '" permission for Product Answers (System > Users > User Groups).'));
		}

		try {
			return self::json(array('ok' => true, 'data' => self::dispatch($s, $action, self::input())));
		} catch (Exception $e) {
			return self::json(array('error' => $e->getMessage()));
		} catch (Error $e) {
			return self::json(array('error' => 'Server error: ' . $e->getMessage()));
		}
	}

	public static function page($api_url, $oc_major, $shop_url) {
		$boot = array('api' => $api_url, 'oc' => (int)$oc_major, 'version' => self::VERSION, 'shop' => $shop_url);
		$dir = dirname(__FILE__) . '/ui/';

		return '<div id="pan-root" class="pan"><div class="pan-loading">Loading…</div></div>'
			. '<style>' . file_get_contents($dir . 'app.css') . '</style>'
			. '<script>window.PAN_BOOT=' . json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . ';</script>'
			. '<script>' . file_get_contents($dir . 'app.js') . '</script>';
	}

	/** The question box added to shop pages. */
	public static function widget(array $cfg, array $texts, $ask_url, $product_id) {
		$dir = dirname(__FILE__) . '/ui/';
		$examples = array();

		foreach (explode('|', (string)$texts['examples']) as $e) {
			if (trim($e) !== '') {
				$examples[] = trim($e);
			}
		}

		$boot = array(
			'url' => $ask_url, 'product' => (int)$product_id, 'pos' => $cfg['position'], 'colour' => $cfg['colour'],
			't' => array_intersect_key($texts, array_flip(array('button', 'product_button', 'title', 'greeting', 'placeholder', 'send', 'view', 'contact'))),
			'examples' => array_slice($examples, 0, 4)
		);

		return '<style>' . file_get_contents($dir . 'widget.css') . '</style>'
			. '<script>window.PAN_W=' . json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . ';' . file_get_contents($dir . 'widget.js') . '</script>';
	}

	/** Puts $html just before </body>, or at the end. */
	public static function inject($output, $html) {
		$pos = strripos($output, '</body>');

		return $pos !== false ? substr($output, 0, $pos) . $html . substr($output, $pos) : $output . $html;
	}

	/**
	 * A product card for an answer, from OpenCart's own product data (so specials, tax and currency are right).
	 * $p: the row from model_catalog_product->getProduct(); $h: helpers price(amount, tax_class) => array(value, text), thumb(image), href(id), stock(row)
	 */
	public static function card($p, array $h) {
		if (!$p) {
			return null;
		}

		$base = isset($p['special']) && $p['special'] !== null && (float)$p['special'] > 0 ? (float)$p['special'] : (float)$p['price'];
		list($value, $text) = call_user_func($h['price'], $base, $p['tax_class_id']);
		$old = '';

		if ($base < (float)$p['price']) {
			list(, $old) = call_user_func($h['price'], (float)$p['price'], $p['tax_class_id']);
		}

		return array(
			'id' => (int)$p['product_id'],
			'name' => html_entity_decode($p['name'], ENT_QUOTES, 'UTF-8'),
			'href' => call_user_func($h['href'], (int)$p['product_id']),
			'thumb' => call_user_func($h['thumb'], $p['image']),
			'price' => $text,
			'old_price' => $old,
			'price_value' => $value,
			'in_stock' => (int)$p['quantity'] > 0,
			'stock' => call_user_func($h['stock'], $p)
		);
	}

	/** JSON for the shop: only what the box needs. */
	public static function publicAnswer(array $a) {
		$out = array('found' => $a['found'], 'kind' => $a['kind'], 'text' => $a['text'], 'facts' => $a['facts'], 'contact' => $a['contact'], 'link' => $a['link'], 'products' => array());

		if (!empty($a['more_text'])) {
			$out['more_text'] = $a['more_text'];
		}

		if (!empty($a['title'])) {
			$out['title'] = $a['title'];
		}

		foreach ($a['products'] as $p) {
			$out['products'][] = array_intersect_key($p, array_flip(array('name', 'href', 'thumb', 'price', 'old_price', 'stock', 'in_stock')));
		}

		return $out;
	}
}
}
