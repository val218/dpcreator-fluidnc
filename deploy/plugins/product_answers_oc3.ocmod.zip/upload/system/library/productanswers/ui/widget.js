/* Product Answers - the question box on shop pages (vanilla JS, no dependencies). */
(function () {
	'use strict';
	var C = window.PAN_W;
	if (!C || document.getElementById('panw')) return;

	function el(tag, cls, text) {
		var e = document.createElement(tag);
		if (cls) e.className = cls;
		if (text != null) e.textContent = text;
		return e;
	}
	function safe(u) { return typeof u === 'string' && /^(https?:\/\/|\/)/i.test(u) ? u : null; }
	function link(href, text, cls) {
		var a = el('a', cls, text);
		var u = safe(href);
		if (u) a.href = u;
		return a;
	}

	var T = C.t || {};
	var root = el('div', 'panw panw-' + (C.pos === 'left' ? 'left' : 'right'));
	root.id = 'panw';
	root.style.setProperty('--pan-c', C.colour || '#1F6FB8');

	var btn = el('button', 'panw-btn');
	btn.type = 'button';
	btn.setAttribute('aria-expanded', 'false');
	btn.setAttribute('aria-controls', 'panw-box');
	btn.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 3C6.5 3 2 6.8 2 11.5c0 2.4 1.2 4.6 3.1 6.1L4.4 21l3.9-1.9c1.2.4 2.4.5 3.7.5 5.5 0 10-3.8 10-8.5S17.5 3 12 3z"/></svg>';
	btn.appendChild(el('span', null, C.product ? (T.product_button || T.button) : T.button));

	var box = el('div', 'panw-box');
	box.id = 'panw-box';
	box.setAttribute('role', 'dialog');
	box.setAttribute('aria-label', T.title || '');
	box.hidden = true;

	var head = el('div', 'panw-head');
	head.appendChild(el('b', null, T.title));
	var close = el('button', 'panw-x', '×');
	close.type = 'button';
	close.setAttribute('aria-label', 'Close');
	head.appendChild(close);

	var log = el('div', 'panw-log');
	log.setAttribute('aria-live', 'polite');

	var form = el('form', 'panw-form');
	var input = el('input');
	input.type = 'text';
	input.maxLength = 300;
	input.placeholder = T.placeholder || '';
	input.setAttribute('aria-label', T.placeholder || T.title || '');
	input.autocomplete = 'off';
	var send = el('button', 'panw-send', T.send || 'Ask');
	send.type = 'submit';
	form.appendChild(input);
	form.appendChild(send);

	box.appendChild(head);
	box.appendChild(log);
	box.appendChild(form);
	root.appendChild(box);
	root.appendChild(btn);

	function bubble(cls) {
		var b = el('div', 'panw-msg ' + cls);
		log.appendChild(b);
		log.scrollTop = log.scrollHeight;
		return b;
	}

	function greet() {
		var b = bubble('panw-bot');
		b.appendChild(el('p', null, T.greeting));
		if (C.examples && C.examples.length) {
			var chips = el('div', 'panw-chips');
			C.examples.forEach(function (q) {
				var c = el('button', 'panw-chip', q);
				c.type = 'button';
				c.addEventListener('click', function () { ask(q); });
				chips.appendChild(c);
			});
			b.appendChild(chips);
		}
	}

	function render(b, a) {
		b.textContent = '';
		if (a.title) b.appendChild(el('div', 'panw-title', a.title));
		if (a.text) b.appendChild(el('p', null, a.text));
		if (a.facts && a.facts.length) {
			var ul = el('ul', 'panw-facts');
			a.facts.forEach(function (f) {
				var li = el('li');
				if (f.label) { li.appendChild(el('b', null, f.label + ': ')); }
				li.appendChild(document.createTextNode(f.text));
				ul.appendChild(li);
			});
			b.appendChild(ul);
		}
		if (a.products && a.products.length) {
			if (a.more_text) b.appendChild(el('p', 'panw-more', a.more_text));
			var list = el('div', 'panw-products');
			a.products.forEach(function (p) {
				var card = link(p.href, null, 'panw-card');
				if (safe(p.thumb)) {
					var img = el('img');
					img.src = p.thumb;
					img.alt = '';
					img.loading = 'lazy';
					card.appendChild(img);
				}
				var info = el('span', 'panw-info');
				info.appendChild(el('span', 'panw-name', p.name));
				var price = el('span', 'panw-price', p.price);
				if (p.old_price) { price.appendChild(document.createTextNode(' ')); price.appendChild(el('s', null, p.old_price)); }
				info.appendChild(price);
				info.appendChild(el('span', 'panw-stock' + (p.in_stock ? ' ok' : ''), p.stock));
				card.appendChild(info);
				list.appendChild(card);
			});
			b.appendChild(list);
		}
		var links = el('div', 'panw-links');
		if (a.link && safe(a.link.href)) links.appendChild(link(a.link.href, a.link.title + ' →'));
		if (!a.found && a.contact && safe(a.contact.href)) links.appendChild(link(a.contact.href, a.contact.title + ' →'));
		if (links.childNodes.length) b.appendChild(links);
		log.scrollTop = log.scrollHeight;
	}

	var busy = false;
	function ask(q) {
		q = String(q || '').trim();
		if (!q || busy) return;
		busy = true;
		bubble('panw-me').textContent = q;
		var b = bubble('panw-bot panw-wait');
		b.appendChild(el('span', 'panw-dots', '•••'));
		input.value = '';
		var body = 'q=' + encodeURIComponent(q) + '&product_id=' + encodeURIComponent(C.product || 0);
		fetch(C.url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' }, body: body })
			.then(function (r) { return r.json(); })
			.then(function (a) {
				b.classList.remove('panw-wait');
				if (a && a.error) { b.textContent = a.error; return; }
				render(b, a || {});
			})
			.catch(function () { b.classList.remove('panw-wait'); b.textContent = '…'; })
			.then(function () { busy = false; input.focus(); });
	}

	function open(on) {
		box.hidden = !on;
		root.classList.toggle('panw-open', on);
		btn.setAttribute('aria-expanded', on ? 'true' : 'false');
		if (on) {
			if (!log.childNodes.length) greet();
			setTimeout(function () { input.focus(); }, 30);
		} else {
			btn.focus();
		}
	}

	btn.addEventListener('click', function () { open(box.hidden); });
	close.addEventListener('click', function () { open(false); });
	box.addEventListener('keydown', function (e) { if (e.key === 'Escape') open(false); });
	form.addEventListener('submit', function (e) { e.preventDefault(); ask(input.value); });

	function mount() { document.body.appendChild(root); }
	if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
})();
