/* Product Answers for OpenCart - admin app (vanilla JS, no dependencies). */
(function () {
	'use strict';

	var BOOT = window.PAN_BOOT || {};
	var root = document.getElementById('pan-root');
	var S = { loaded: Date.now(), tab: 'questions', boot: null, stats: null, faq: null, edit: null, tryProduct: null, tryLog: [] };
	var TEXT_LABELS = [
		['button', 'Button'], ['product_button', 'Button on product pages'], ['title', 'Box title'], ['greeting', 'Greeting'],
		['placeholder', 'Input hint'], ['send', 'Send button'], ['not_found', 'When there is no answer'], ['contact', 'Contact link'],
		['examples', 'Example questions (separate with |)'], ['products', 'Before the product list'], ['facts', 'Before product facts ({name})'],
		['no_fact', 'When a product detail is missing ({name})'], ['in_stock', 'In stock'], ['weight', 'Weight'], ['size', 'Size'], ['model', 'Model'], ['price', 'Price'], ['cheapest', 'Cheapest first'],
		['under', 'Products up to ({price})'], ['over', 'Products from ({price})'], ['view', 'View'], ['more', 'Read more']
	];

	function h(tag, attrs, kids) {
		var el = document.createElement(tag);
		attrs = attrs || {};
		Object.keys(attrs).forEach(function (k) {
			var v = attrs[k];
			if (v === null || v === undefined || v === false) return;
			if (k === 'class') el.className = v;
			else if (k === 'style') el.setAttribute('style', v);
			else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
			else if (k === 'value') el.value = v;
			else if (k === 'checked' || k === 'disabled' || k === 'selected') el[k] = !!v;
			else el.setAttribute(k, v === true ? '' : v);
		});
		(Array.isArray(kids) ? kids : kids == null ? [] : [kids]).forEach(function (c) {
			if (c == null || c === false) return;
			el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
		});
		return el;
	}

	function api(action, data) {
		var url = BOOT.api + (BOOT.api.indexOf('?') > -1 ? '&' : '?') + 'action=' + action;
		return fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {}) })
			.then(function (r) { return r.text(); })
			.then(function (t) {
				var j;
				try { j = JSON.parse(t); } catch (e) { throw new Error(/login|token/i.test(t) ? 'Your session expired - reload the page and log in.' : 'Unexpected server reply. ' + t.replace(/<[^>]+>/g, ' ').trim().slice(0, 200)); }
				if (j.error) throw new Error(j.error);
				return j.data;
			});
	}

	var toastBox;
	function toast(msg, kind) {
		if (!toastBox) { toastBox = h('div', { class: 'pan-toast' }); document.body.appendChild(toastBox); }
		var t = h('div', { class: kind || '' }, msg);
		toastBox.appendChild(t);
		setTimeout(function () { t.remove(); }, kind === 'bad' ? 7000 : 3500);
	}
	function fail(e) { toast(e.message || String(e), 'bad'); }

	function pd(s) { var p = String(s).split(/[- :]/); return new Date(+p[0], p[1] - 1, +p[2], +p[3] || 0, +p[4] || 0, +p[5] || 0); }
	function when(s) {
		if (!s) return '';
		// Compare with the server's clock, so a different time zone in the browser does not matter.
		var now = S.stats && S.stats.now ? pd(S.stats.now).getTime() + (Date.now() - S.loaded) : Date.now();
		var d = pd(s), m = Math.round((now - d.getTime()) / 60000);
		if (m < 1) return 'just now';
		if (m < 60) return m + ' min ago';
		if (m < 1440) return Math.floor(m / 60) + ' h ago';
		return d.toLocaleDateString();
	}
	function langName(id) {
		var l = (S.boot.languages || []).filter(function (x) { return x.id === +id; })[0];
		return l ? l.name : 'All languages';
	}

	/* ------------------------------------------------ layout */

	function render() {
		root.textContent = '';
		var tabs = [['questions', 'What people ask'], ['try', 'Try it'], ['answers', 'Your answers'], ['settings', 'Settings']];
		root.appendChild(h('div', { class: 'pan-tabs', role: 'tablist' }, tabs.map(function (t) {
			return h('button', { type: 'button', role: 'tab', 'aria-selected': S.tab === t[0] ? 'true' : 'false', onclick: function () { S.tab = t[0]; render(); } }, t[1]);
		})));
		var ix = S.boot.index;
		if (!ix.built) {
			root.appendChild(h('div', { class: 'pan-warn' }, ['The product index has not been built yet. ', h('button', { type: 'button', class: 'pan-btn', onclick: rebuild }, 'Build it now')]));
		} else if (ix.behind > 0) {
			root.appendChild(h('div', { class: 'pan-note' }, [ix.behind + ' products changed since the index was built. The shop picks up changes by itself every few minutes, or ', h('button', { type: 'button', class: 'pan-link', onclick: rebuild }, 'rebuild the index now'), '.']));
		}
		var body = h('div', { class: 'pan-body' });
		root.appendChild(body);
		({ questions: viewQuestions, try: viewTry, answers: viewAnswers, settings: viewSettings })[S.tab](body);
	}

	/* ------------------------------------------------ what people ask */

	function viewQuestions(el) {
		var st = S.stats;
		var pct = st.total ? Math.round(st.answered / st.total * 100) : 0;
		el.appendChild(h('div', { class: 'pan-kpi' }, [
			h('div', null, [h('b', null, String(st.total)), h('span', null, 'questions in the last ' + st.days + ' days')]),
			h('div', null, [h('b', null, st.total ? pct + '%' : '–'), h('span', null, 'answered from your shop data')]),
			h('div', null, [h('b', null, String(st.total - st.answered)), h('span', null, 'without an answer')]),
			h('div', null, [h('b', null, String(S.boot.index.answers)), h('span', null, 'answers you wrote')])
		]));
		if (!st.log) el.appendChild(h('div', { class: 'pan-note' }, 'Keeping questions is switched off in Settings, so this page only shows older questions.'));

		el.appendChild(h('h3', null, 'Questions without an answer'));
		el.appendChild(h('p', { class: 'pan-mut' }, 'These are the questions your shop data could not answer. Write an answer once and the box uses it from then on - or add the missing detail to the product.'));
		if (!st.open.length) {
			el.appendChild(h('div', { class: 'pan-empty' }, st.total ? 'Every question had an answer. Nice.' : 'No questions yet. Open your shop, click the question button and ask something - or use "Try it".'));
		} else {
			el.appendChild(h('table', { class: 'pan-table' }, [
				h('thead', null, h('tr', null, [h('th', null, 'Question'), h('th', { class: 'r' }, 'Asked'), h('th', null, 'Last time'), h('th', null, '')])),
				h('tbody', null, st.open.map(function (o) {
					return h('tr', null, [
						h('td', null, o.q), h('td', { class: 'r' }, o.n + '×'), h('td', { class: 'pan-mut' }, when(o.last)),
						h('td', { class: 'r nowrap' }, [
							h('button', { type: 'button', class: 'pan-btn pan-sm', onclick: function () { S.edit = { question: o.q.charAt(0).toUpperCase() + o.q.slice(1), keywords: '', answer: '', link: '', lang: 0, status: 1, resolve: [o.q] }; S.tab = 'answers'; render(); } }, 'Write an answer'), ' ',
							h('button', { type: 'button', class: 'pan-btn pan-ghost pan-sm', title: 'Remove it from this list', onclick: function () { api('dismiss', { q: o.q }).then(function (d) { S.stats = d; S.loaded = Date.now(); render(); }).catch(fail); } }, 'Dismiss')
						])
					]);
				}))
			]));
		}

		el.appendChild(h('h3', null, 'Latest questions'));
		if (!st.recent.length) { el.appendChild(h('div', { class: 'pan-empty' }, 'Nothing yet.')); return; }
		var kinds = { answer: 'Your answer', page: 'Information page', facts: 'Product details', products: 'Products', none: 'No answer', nofact: 'Not in product details' };
		el.appendChild(h('table', { class: 'pan-table' }, [
			h('thead', null, h('tr', null, [h('th', null, 'When'), h('th', null, 'Question'), h('th', null, 'Asked on'), h('th', null, 'Answered with')])),
			h('tbody', null, st.recent.map(function (r) {
				return h('tr', null, [
					h('td', { class: 'pan-mut nowrap' }, when(r.created)),
					h('td', null, r.q),
					h('td', { class: 'pan-mut' }, r.page || (+r.product_id ? 'product #' + r.product_id : 'any page')),
					h('td', null, [h('span', { class: 'pan-tag ' + (r.answered ? 'ok' : 'bad') }, kinds[r.kind] || r.kind), r.top ? h('span', { class: 'pan-mut' }, ' ' + r.top) : null])
				]);
			}))
		]));
	}

	/* ------------------------------------------------ try it */

	function answerView(a) {
		var box = h('div', { class: 'pan-ans' });
		if (a.error) { box.appendChild(h('p', { class: 'pan-bad' }, a.error)); return box; }
		if (a.title) box.appendChild(h('b', null, a.title));
		if (a.text) box.appendChild(h('p', null, a.text));
		if (a.facts && a.facts.length) box.appendChild(h('ul', null, a.facts.map(function (f) { return h('li', null, [f.label ? h('b', null, f.label + ': ') : null, f.text]); })));
		if (a.products && a.products.length) {
			if (a.more_text) box.appendChild(h('p', { class: 'pan-mut' }, a.more_text));
			box.appendChild(h('div', { class: 'pan-cards' }, a.products.map(function (p) {
				return h('a', { class: 'pan-card', href: p.href, target: '_blank', rel: 'noopener' }, [
					p.thumb ? h('img', { src: p.thumb, alt: '' }) : null,
					h('span', null, [h('b', null, p.name), h('br'), p.price, p.old_price ? h('s', { class: 'pan-mut' }, ' ' + p.old_price) : null, h('br'), h('small', { class: p.in_stock ? 'pan-ok' : 'pan-mut' }, p.stock)])
				]);
			})));
		}
		var links = [];
		if (a.link) links.push(h('a', { href: a.link.href, target: '_blank', rel: 'noopener' }, a.link.title + ' →'));
		if (!a.found && a.contact) links.push(h('a', { href: a.contact.href, target: '_blank', rel: 'noopener' }, a.contact.title + ' →'));
		if (links.length) box.appendChild(h('div', { class: 'pan-links' }, links));
		return box;
	}

	function viewTry(el) {
		el.appendChild(h('p', { class: 'pan-mut' }, 'Ask the way a customer would. The answer comes from your live shop exactly as shoppers see it. Questions asked here are not saved.'));
		var q = h('input', { type: 'text', class: 'pan-input', placeholder: 'e.g. Do you ship to Germany?  ·  Anything under 50?  ·  Is the MacBook in stock?', maxlength: 300 });
		var pick = h('input', { type: 'text', class: 'pan-input', placeholder: 'Type a product name (optional)', value: S.tryProduct ? S.tryProduct.name : '' });
		var list = h('div', { class: 'pan-pick' });
		var timer;
		pick.addEventListener('input', function () {
			clearTimeout(timer);
			S.tryProduct = null;
			var v = pick.value.trim();
			if (!v) { list.textContent = ''; return; }
			timer = setTimeout(function () {
				api('products', { q: v, lang: S.boot.languages[0] ? S.boot.languages[0].id : 1 }).then(function (rows) {
					list.textContent = '';
					rows.slice(0, 8).forEach(function (r) {
						list.appendChild(h('button', { type: 'button', onclick: function () { S.tryProduct = r; pick.value = r.name; list.textContent = ''; } }, r.name));
					});
				}).catch(fail);
			}, 250);
		});
		var out = h('div', { class: 'pan-trylog' });
		function go() {
			var v = q.value.trim();
			if (!v) return;
			var body = 'q=' + encodeURIComponent(v) + '&test=1&product_id=' + (S.tryProduct ? S.tryProduct.product_id : 0);
			fetch(BOOT.ask, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' }, body: body })
				.then(function (r) { return r.json(); })
				.catch(function () { return { error: 'Could not reach the shop at ' + BOOT.shop + '. If your admin and shop use different addresses (www / no www), open the shop and use the question box there.' }; })
				.then(function (a) {
					S.tryLog.unshift({ q: v, p: S.tryProduct ? S.tryProduct.name : '', a: a });
					S.tryLog = S.tryLog.slice(0, 10);
					drawLog();
					q.value = '';
					q.focus();
				});
		}
		function drawLog() {
			out.textContent = '';
			S.tryLog.forEach(function (t) {
				out.appendChild(h('div', { class: 'pan-tryitem' }, [h('div', { class: 'pan-q' }, [t.q, t.p ? h('span', { class: 'pan-mut' }, '  - asked on ' + t.p) : null]), answerView(t.a)]));
			});
		}
		el.appendChild(h('div', { class: 'pan-try' }, [
			h('label', null, ['Question', q]),
			h('label', null, ['Asked on the page of', pick, list]),
			h('button', { type: 'button', class: 'pan-btn', onclick: go }, 'Ask')
		]));
		q.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
		el.appendChild(out);
		drawLog();
		setTimeout(function () { q.focus(); }, 0);
	}

	/* ------------------------------------------------ your answers */

	function viewAnswers(el) {
		if (!S.faq) { el.appendChild(h('div', { class: 'pan-loading' }, 'Loading…')); api('faq_list').then(function (d) { S.faq = d; render(); }).catch(fail); return; }
		el.appendChild(h('p', { class: 'pan-mut' }, 'Answers for questions your product data cannot answer: delivery times, warranty, opening hours, which product suits whom. The box uses them when a question matches the question or the other ways to ask it.'));
		if (S.edit) { el.appendChild(editor()); return; }
		el.appendChild(h('button', { type: 'button', class: 'pan-btn', onclick: function () { S.edit = { question: '', keywords: '', answer: '', link: '', lang: 0, status: 1 }; render(); } }, '+ Add an answer'));
		if (!S.faq.length) { el.appendChild(h('div', { class: 'pan-empty' }, 'No answers yet. Your information pages (delivery, returns, terms) are already used automatically.')); return; }
		el.appendChild(h('div', { class: 'pan-faqs' }, S.faq.map(function (f) {
			return h('div', { class: 'pan-faq' + (f.status ? '' : ' off') }, [
				h('div', { class: 'pan-faq-h' }, [h('b', null, f.question), h('span', { class: 'pan-mut' }, langName(f.lang) + (f.status ? '' : ' · off') + ' · used ' + f.asked + '×')]),
				f.keywords ? h('div', { class: 'pan-mut' }, 'Also: ' + f.keywords) : null,
				h('p', null, f.answer),
				h('div', null, [
					h('button', { type: 'button', class: 'pan-btn pan-sm', onclick: function () { S.edit = JSON.parse(JSON.stringify(f)); render(); } }, 'Edit'), ' ',
					h('button', { type: 'button', class: 'pan-btn pan-ghost pan-sm', onclick: function () { if (window.confirm('Delete this answer?')) api('faq_delete', { faq_id: f.faq_id }).then(function (d) { S.faq = d.faq; S.boot.index = d.index; toast('Deleted.'); render(); }).catch(fail); } }, 'Delete')
				])
			]);
		})));
	}

	function editor() {
		var e = S.edit;
		var f = {
			question: h('input', { type: 'text', class: 'pan-input', value: e.question, maxlength: 255, placeholder: 'How long does delivery take?' }),
			keywords: h('input', { type: 'text', class: 'pan-input', value: e.keywords, maxlength: 500, placeholder: 'shipping time, when will it arrive, dispatch' }),
			answer: h('textarea', { class: 'pan-input', rows: 5, maxlength: 5000, placeholder: 'We ship within 1 working day. Delivery in the UK takes 2-3 days, to the EU 4-7 days.' }, e.answer),
			link: h('input', { type: 'text', class: 'pan-input', value: e.link, maxlength: 500, placeholder: 'https://… (optional "Read more" link)' }),
			lang: h('select', { class: 'pan-input' }, [h('option', { value: 0 }, 'All languages')].concat(S.boot.languages.map(function (l) { return h('option', { value: l.id, selected: +e.lang === l.id }, l.name); }))),
			status: h('input', { type: 'checkbox', checked: !!+e.status })
		};
		return h('div', { class: 'pan-form' }, [
			h('h3', null, e.faq_id ? 'Edit answer' : 'New answer'),
			h('label', null, ['Question', f.question]),
			h('label', null, ['Other ways people ask it (words or phrases, separated by commas)', f.keywords]),
			h('label', null, ['Answer', f.answer]),
			h('div', { class: 'pan-row2' }, [h('label', null, ['Link', f.link]), h('label', null, ['Language', f.lang])]),
			h('label', { class: 'pan-check' }, [f.status, ' Use this answer']),
			h('div', null, [
				h('button', { type: 'button', class: 'pan-btn', onclick: function () {
					var d = { faq_id: e.faq_id || 0, question: f.question.value, keywords: f.keywords.value, answer: f.answer.value, link: f.link.value, lang: +f.lang.value, status: f.status.checked ? 1 : 0, resolve: e.resolve || [] };
					api('faq_save', d).then(function (r) {
						S.faq = r.faq; S.boot.index = r.index; S.edit = null; toast('Saved. The question box uses it straight away.');
						return api('stats');
					}).then(function (st) { if (st) { S.stats = st; S.loaded = Date.now(); } render(); }).catch(fail);
				} }, 'Save'), ' ',
				h('button', { type: 'button', class: 'pan-btn pan-ghost', onclick: function () { S.edit = null; render(); } }, 'Cancel')
			])
		]);
	}

	/* ------------------------------------------------ settings */

	function rebuild() {
		var bar = h('div', { class: 'pan-progress' }, h('i'));
		var msg = h('span', null, 'Building the index…');
		var box = h('div', { class: 'pan-modal' }, h('div', null, [msg, bar]));
		document.body.appendChild(box);
		function step(inp) {
			api('rebuild', inp).then(function (r) {
				if (r.total) { bar.firstChild.style.width = Math.round(r.offset / r.total * 100) + '%'; msg.textContent = 'Building the index… ' + r.offset + ' of ' + r.total + ' products'; }
				if (r.done) { box.remove(); S.boot.index = r.index; toast('Index ready: ' + r.index.products + ' products, ' + r.index.pages + ' information pages, ' + r.index.answers + ' answers.'); render(); return; }
				step({ step: r.step, offset: r.offset });
			}).catch(function (e) { box.remove(); fail(e); });
		}
		step({ step: 'start' });
	}

	function viewSettings(el) {
		var c = JSON.parse(JSON.stringify(S.boot.settings));
		var ix = S.boot.index;

		el.appendChild(h('div', { class: 'pan-card2' }, [
			h('h3', null, 'Index'),
			h('p', null, ix.products + ' of ' + ix.all_products + ' products, ' + ix.pages + ' information pages and ' + ix.answers + ' of your answers are searchable.' + (ix.built ? ' Built ' + when(ix.built) + '.' : '')),
			h('p', { class: 'pan-mut' }, 'Products and pages are updated automatically when you save them. Rebuild after a big import.'),
			h('button', { type: 'button', class: 'pan-btn', onclick: rebuild }, 'Rebuild index')
		]));

		var w = {
			widget: h('input', { type: 'checkbox', checked: !!c.widget }),
			pages: h('select', { class: 'pan-input' }, [h('option', { value: 'all', selected: c.pages === 'all' }, 'Every page'), h('option', { value: 'product', selected: c.pages === 'product' }, 'Product pages only')]),
			position: h('select', { class: 'pan-input' }, [h('option', { value: 'right', selected: c.position === 'right' }, 'Bottom right'), h('option', { value: 'left', selected: c.position === 'left' }, 'Bottom left')]),
			colour: h('input', { type: 'color', value: c.colour }),
			max_products: h('select', { class: 'pan-input' }, [1, 2, 3, 4, 5, 6, 8].map(function (n) { return h('option', { value: n, selected: +c.max_products === n }, String(n)); })),
			log: h('input', { type: 'checkbox', checked: !!c.log }),
			log_days: h('input', { type: 'number', class: 'pan-input', min: 7, max: 730, value: c.log_days }),
			synonyms: h('textarea', { class: 'pan-input', rows: 5, placeholder: 'hoodie, sweatshirt, jumper\nlaptop, notebook' }, c.synonyms)
		};

		el.appendChild(h('div', { class: 'pan-card2' }, [
			h('h3', null, 'Question box on the shop'),
			h('label', { class: 'pan-check' }, [w.widget, ' Show the question box']),
			h('div', { class: 'pan-row3' }, [h('label', null, ['Show on', w.pages]), h('label', null, ['Position', w.position]), h('label', null, ['Colour ', w.colour]), h('label', null, ['Products per answer', w.max_products])])
		]));

		var langBoxes = S.boot.languages.map(function (l) {
			var mine = (c.texts && c.texts[l.id]) || {};
			var inputs = {};
			var det = h('details', { class: 'pan-lang' }, [h('summary', null, 'Words shown to shoppers: ' + l.name)].concat(TEXT_LABELS.map(function (t) {
				inputs[t[0]] = h('input', { type: 'text', class: 'pan-input', value: mine[t[0]] || '', placeholder: l.defaults[t[0]] || '' });
				return h('label', null, [t[1], inputs[t[0]]]);
			})));
			return { id: l.id, el: det, inputs: inputs };
		});
		el.appendChild(h('div', { class: 'pan-card2' }, [h('h3', null, 'Wording'), h('p', { class: 'pan-mut' }, 'Leave a field empty to use the built-in wording shown in grey (English, Latvian, German, Russian, Spanish and French are built in).')].concat(langBoxes.map(function (b) { return b.el; }))));

		el.appendChild(h('div', { class: 'pan-card2' }, [
			h('h3', null, 'Words that mean the same'),
			h('p', { class: 'pan-mut' }, 'One group per line. A question with any word of a group also finds the others - useful for the words your customers use that your product texts do not.'),
			w.synonyms,
			h('details', null, [h('summary', null, 'Built-in groups'), h('div', { class: 'pan-mut pan-small' }, c.builtin_synonyms.join(' · '))])
		]));

		el.appendChild(h('div', { class: 'pan-card2' }, [
			h('h3', null, 'Privacy'),
			h('label', { class: 'pan-check' }, [w.log, ' Keep the questions people ask, so you can see what they want to know']),
			h('label', null, ['Keep them for (days)', w.log_days]),
			h('p', { class: 'pan-mut' }, 'E-mail addresses and phone numbers typed into the box are removed before saving. No names, IP addresses or cookies are stored with the questions.'),
			h('button', { type: 'button', class: 'pan-btn pan-ghost', onclick: function () { if (window.confirm('Delete all saved questions?')) api('clear_log').then(function (d) { S.stats = d; toast('Questions deleted.'); }).catch(fail); } }, 'Delete saved questions')
		]));

		el.appendChild(h('button', { type: 'button', class: 'pan-btn pan-save', onclick: function () {
			var texts = {};
			langBoxes.forEach(function (b) { texts[b.id] = {}; Object.keys(b.inputs).forEach(function (k) { texts[b.id][k] = b.inputs[k].value; }); });
			api('save_settings', {
				widget: w.widget.checked ? 1 : 0, pages: w.pages.value, position: w.position.value, colour: w.colour.value, max_products: +w.max_products.value,
				log: w.log.checked ? 1 : 0, log_days: +w.log_days.value, synonyms: w.synonyms.value, texts: texts
			}).then(function (s) { S.boot.settings = s; toast('Settings saved.'); render(); }).catch(fail);
		} }, 'Save settings'));
	}

	/* ------------------------------------------------ start */

	api('bootstrap').then(function (d) {
		S.boot = d;
		S.stats = d.stats;
		S.loaded = Date.now();
		render();
	}).catch(function (e) {
		root.textContent = '';
		root.appendChild(h('div', { class: 'pan-warn' }, e.message));
	});
})();
