<?php
/**
 * Product Answers for OpenCart 3.0.x - thin adapter around the shared core in system/library/productanswers.
 * No core files are modified: everything is hooked in with OpenCart events.
 */
class ControllerExtensionModuleProductAnswers extends Controller {
	const ROUTE = 'extension/module/product_answers';
	const CODE = 'product_answers';

	private function core() {
		require_once(DIR_SYSTEM . 'library/productanswers/Service.php');
		require_once(DIR_SYSTEM . 'library/productanswers/Ui.php');

		return new PanService($this->db, DB_PREFIX, 3);
	}

	private function shop() {
		return defined('HTTPS_CATALOG') && HTTPS_CATALOG ? HTTPS_CATALOG : (defined('HTTP_CATALOG') ? HTTP_CATALOG : '');
	}

	public function index() {
		$this->load->language(self::ROUTE);
		$this->document->setTitle($this->language->get('heading_title'));

		$data['heading_title'] = $this->language->get('heading_title');
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true))
		);
		$this->core()->ensureTables();
		$api = html_entity_decode($this->url->link(self::ROUTE . '/api', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
		$data['body'] = PanUi::page($api, 3, $this->shop()) . '<script>window.PAN_BOOT.ask=' . json_encode($this->shop() . 'index.php?route=extension/module/product_answers/ask', JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . ';</script>';
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	public function api() {
		$service = $this->core();
		$user = $this->user;
		$action = isset($this->request->get['action']) ? preg_replace('/[^a-z_]/', '', $this->request->get['action']) : '';
		$json = PanUi::api($service, $action, function ($perm) use ($user) {
			return $user->hasPermission($perm, ControllerExtensionModuleProductAnswers::ROUTE);
		});

		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput($json);
	}

	public function install() {
		$core = $this->core();
		$core->install();
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `key` = 'module_product_answers_status'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = '0', `code` = 'module_product_answers', `key` = 'module_product_answers_status', `value` = '1', serialized = '0'");

		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
		$this->model_setting_event->addEvent(self::CODE, 'admin/view/common/column_left/before', self::ROUTE . '/eventMenu');
		$this->model_setting_event->addEvent(self::CODE, 'catalog/view/common/footer/after', self::ROUTE . '/eventWidget');
		$this->model_setting_event->addEvent(self::CODE, 'admin/model/catalog/product/addProduct/after', self::ROUTE . '/eventProductAdd');
		$this->model_setting_event->addEvent(self::CODE, 'admin/model/catalog/product/editProduct/after', self::ROUTE . '/eventProductEdit');
		$this->model_setting_event->addEvent(self::CODE, 'admin/model/catalog/product/deleteProduct/after', self::ROUTE . '/eventProductDelete');
		$this->model_setting_event->addEvent(self::CODE, 'admin/model/catalog/information/addInformation/after', self::ROUTE . '/eventInfoAdd');
		$this->model_setting_event->addEvent(self::CODE, 'admin/model/catalog/information/editInformation/after', self::ROUTE . '/eventInfoEdit');
		$this->model_setting_event->addEvent(self::CODE, 'admin/model/catalog/information/deleteInformation/after', self::ROUTE . '/eventInfoDelete');

		// Build the index straight away for small and medium shops; big ones finish from the admin page.
		try {
			$in = array('step' => 'start');

			for ($i = 0; $i < 30; $i++) {
				$r = $core->rebuild($in);

				if ($r['done']) {
					break;
				}

				$in = array('step' => $r['step'], 'offset' => $r['offset']);
			}
		} catch (Exception $e) {
		}
	}

	public function uninstall() {
		$this->core()->uninstall();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
	}

	/* ------------------------------------------------ events */

	public function eventMenu(&$route, &$data) {
		if (empty($data['menus']) || !$this->user->hasPermission('access', self::ROUTE)) {
			return;
		}

		$this->load->language(self::ROUTE, 'pan');
		$name = $this->language->get('pan')->get('text_menu');
		$item = array('name' => $name, 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true), 'children' => array());

		foreach ($data['menus'] as &$menu) {
			if (isset($menu['id']) && $menu['id'] === 'menu-catalog') {
				$menu['children'][] = $item;

				return;
			}
		}

		$data['menus'][] = array('id' => 'menu-product-answers', 'icon' => 'fa-comments', 'name' => $name, 'href' => $item['href'], 'children' => array());
	}

	private function safely($fn) {
		try {
			$fn($this->core());
		} catch (\Throwable $e) {
			// Never stop the product form from saving; the shop catches up on its own.
		}
	}

	public function eventProductAdd(&$route, &$args, &$output) {
		$this->safely(function ($c) use ($output) { $c->indexProduct((int)$output); });
	}

	public function eventProductEdit(&$route, &$args, &$output) {
		$this->safely(function ($c) use ($args) { $c->indexProduct((int)$args[0]); });
	}

	public function eventProductDelete(&$route, &$args, &$output) {
		$this->safely(function ($c) use ($args) { $c->removeDoc('p', (int)$args[0]); });
	}

	public function eventInfoAdd(&$route, &$args, &$output) {
		$this->safely(function ($c) use ($output) { $c->indexInformation((int)$output); });
	}

	public function eventInfoEdit(&$route, &$args, &$output) {
		$this->safely(function ($c) use ($args) { $c->indexInformation((int)$args[0]); });
	}

	public function eventInfoDelete(&$route, &$args, &$output) {
		$this->safely(function ($c) use ($args) { $c->removeDoc('i', (int)$args[0]); });
	}
}
