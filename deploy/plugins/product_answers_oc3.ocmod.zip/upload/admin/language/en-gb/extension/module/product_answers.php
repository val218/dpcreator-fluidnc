<?php
$_['heading_title'] = 'Product Answers: questions answered from your shop data';
$_['text_menu']     = 'Product Answers';
