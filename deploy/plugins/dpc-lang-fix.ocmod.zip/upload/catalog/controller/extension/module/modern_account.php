<?php
/**
 * Modern Customer Account for OpenCart 3.0.x - shop side. Puts the dashboard inside the theme's account page.
 * Never breaks the page: if anything goes wrong, the shop's own account page is shown.
 */
class ControllerExtensionModuleModernAccount extends Controller {
	private static $service = null;

	private function core() {
		if (!self::$service) {
			require_once(DIR_SYSTEM . 'library/modernaccount/Service.php');
			require_once(DIR_SYSTEM . 'library/modernaccount/Ui.php');
			self::$service = new MaService($this->db, DB_PREFIX, 3);
		}

		return self::$service;
	}

	private function on() {
		$c = $this->core()->getConfig();

		return $this->customer->isLogged() && !empty($c['status']);
	}

	private function link($route, $args = '') {
		return html_entity_decode($this->url->link($route, $args, true), ENT_QUOTES, 'UTF-8');
	}

	/** catalog/view/account/account/before: the dashboard gets the full width of the page. */
	public function eventColumns(&$route, &$data) {
		try {
			$c = $this->core()->getConfig();

			if ($this->on() && !empty($c['hide_columns'])) {
				$data['column_left'] = '';
				$data['column_right'] = '';
			}
		} catch (\Throwable $e) {
		}
	}

	/** catalog/view/account/account/after */
	public function eventPage(&$route, &$data, &$output) {
		set_error_handler(function () { return true; });

		try {
			if (!is_string($output) || !$this->on()) {
				return;
			}

			$s = $this->core();
			$cfg = $s->getConfig();
			$session_currency = isset($this->session->data['currency']) ? $this->session->data['currency'] : $this->config->get('config_currency');
			$this->load->model('catalog/product');
			$this->load->model('tool/image');
			$self = $this;

			$ctx = array(
				'customer_id' => (int)$this->customer->getId(),
				'language_id' => (int)$this->config->get('config_language_id'),
				'money'       => function ($amount, $code, $value) use ($self) { return $self->currency->format((float)$amount, $code, (float)$value); },
				'order_link'  => function ($id) use ($self) { return $self->link('account/order/info', 'order_id=' . (int)$id); },
				'product'     => function ($pid) use ($self, $session_currency) {
					$p = $self->model_catalog_product->getProduct((int)$pid);

					if (!$p || empty($p['status'])) {
						return null;
					}

					$price = !empty($p['special']) && (float)$p['special'] > 0 ? (float)$p['special'] : (float)$p['price'];

					return array(
						'product_id' => (int)$pid,
						'name'  => html_entity_decode((string)$p['name'], ENT_QUOTES, 'UTF-8'),
						'image' => !empty($p['image']) && is_file(DIR_IMAGE . html_entity_decode($p['image'], ENT_QUOTES, 'UTF-8')) ? $self->model_tool_image->resize(html_entity_decode($p['image'], ENT_QUOTES, 'UTF-8'), 400, 300) : '',
						'price' => $self->currency->format($self->tax->calculate($price, $p['tax_class_id'], $self->config->get('config_tax')), $session_currency),
						'href'  => $self->link('product/product', 'product_id=' . (int)$pid)
					);
				},
				'hunt'        => $cfg['sections']['hunt'] ? $this->hunt() : null
			);

			$d = $s->dashboard($ctx);
			$links = array();

			foreach (array('edit', 'password', 'address', 'wishlist', 'order', 'download', 'reward', 'return', 'transaction', 'newsletter', 'recurring', 'affiliate') as $k) {
				$links[$k] = isset($data[$k]) && is_string($data[$k]) ? html_entity_decode($data[$k], ENT_QUOTES, 'UTF-8') : '';
			}

			$links['subscription'] = $links['recurring'];
			$links['logout'] = $this->link('account/logout');
			$links['home'] = $this->link('common/home');

			$html = MaUi::render($d, $links, $cfg, array(
				'language' => (isset($this->session->data['language']) ? (string)$this->session->data['language'] : (string)$this->config->get('config_language')),
				'money'    => function ($amount) use ($self, $session_currency) { return $self->currency->format((float)$amount, $session_currency); }
			));
			$top = isset($data['content_top']) && is_string($data['content_top']) ? $data['content_top'] : '';
			$bottom = isset($data['content_bottom']) && is_string($data['content_bottom']) ? $data['content_bottom'] : '';
			$output = MaUi::place($output, $top . $html . $bottom);
		} catch (\Throwable $e) {
		} finally {
			restore_error_handler();
		}
	}

	/** Treasure Hunt progress, when that extension is installed and a hunt is running. */
	private function hunt() {
		$file = DIR_SYSTEM . 'library/treasurehunt/Service.php';

		if (!is_file($file)) {
			return null;
		}

		require_once($file);

		if (!class_exists('ThService')) {
			return null;
		}

		$th = new ThService($this->db, DB_PREFIX, 3);

		if (!$th->ready()) {
			return null;
		}

		$state = $th->state(array(
			'customer_id' => (int)$this->customer->getId(),
			'product_id'  => 0,
			'language_id' => (int)$this->config->get('config_language_id'),
			'currency'    => $th->currency(),
			'ua'          => isset($this->request->server['HTTP_USER_AGENT']) ? (string)$this->request->server['HTTP_USER_AGENT'] : ''
		));

		return $state ? $state : null;
	}
}
