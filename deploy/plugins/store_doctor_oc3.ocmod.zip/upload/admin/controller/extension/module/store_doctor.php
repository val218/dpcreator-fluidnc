<?php
/**
 * Store Doctor for OpenCart 3.0.x - thin adapter around the shared core in system/library/storedoctor.
 * Admin only: nothing is added to the shop pages. No core files are modified.
 */
class ControllerExtensionModuleStoreDoctor extends Controller {
	const ROUTE = 'extension/module/store_doctor';
	const CODE = 'store_doctor';

	private function core() {
		require_once(DIR_SYSTEM . 'library/storedoctor/Service.php');
		require_once(DIR_SYSTEM . 'library/storedoctor/Ui.php');

		return new SdrService($this->db, DB_PREFIX, 3, array(
			'root'         => rtrim(dirname(DIR_APPLICATION), '/'),
			'admin'        => DIR_APPLICATION,
			'catalog_dir'  => DIR_CATALOG,
			'system'       => DIR_SYSTEM,
			'storage'      => defined('DIR_STORAGE') ? DIR_STORAGE : DIR_SYSTEM . 'storage/',
			'logs'         => DIR_LOGS,
			'image'        => DIR_IMAGE,
			'modification' => defined('DIR_MODIFICATION') ? DIR_MODIFICATION : '',
			'version'      => VERSION,
			'catalog_url'  => defined('HTTPS_CATALOG') && HTTPS_CATALOG ? HTTPS_CATALOG : (defined('HTTP_CATALOG') ? HTTP_CATALOG : ''),
			'admin_user'   => $this->user->getUserName()
		));
	}

	private function apiUrl() {
		return html_entity_decode($this->url->link(self::ROUTE . '/api', 'user_token=' . $this->session->data['user_token'], true), ENT_QUOTES, 'UTF-8');
	}

	public function index() {
		$this->load->language(self::ROUTE);
		$this->document->setTitle($this->language->get('heading_title'));

		$data['heading_title'] = $this->language->get('heading_title');
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true))
		);
		$this->core()->ensureTables();
		$data['body'] = SdrUi::page($this->apiUrl(), 3);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	public function api() {
		$service = $this->core();
		$user = $this->user;
		$action = isset($this->request->get['action']) ? preg_replace('/[^a-z_]/', '', $this->request->get['action']) : '';
		$json = SdrUi::api($service, $action, function ($perm) use ($user) {
			return $user->hasPermission($perm, ControllerExtensionModuleStoreDoctor::ROUTE);
		});

		$this->response->addHeader('Content-Type: application/json; charset=utf-8');
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput($json);
	}

	public function install() {
		$this->core()->install();
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `key` = 'module_store_doctor_status'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET store_id = '0', `code` = 'module_store_doctor', `key` = 'module_store_doctor_status', `value` = '1', serialized = '0'");

		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
		$this->model_setting_event->addEvent(self::CODE, 'admin/view/common/column_left/before', self::ROUTE . '/eventMenu');

		// Turn on the dashboard widget straight away (it can be switched off in Extensions > Dashboard).
		try {
			$q = $this->db->query("SELECT 1 FROM `" . DB_PREFIX . "extension` WHERE `type` = 'dashboard' AND `code` = '" . self::CODE . "'");

			if (!$q->num_rows) {
				$this->load->model('setting/extension');
				$this->model_setting_extension->install('dashboard', self::CODE);
				$this->load->model('user/user_group');
				$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/dashboard/' . self::CODE);
				$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/dashboard/' . self::CODE);
				$this->load->model('setting/setting');
				$this->model_setting_setting->editSetting('dashboard_' . self::CODE, array('dashboard_' . self::CODE . '_width' => 6, 'dashboard_' . self::CODE . '_status' => 1, 'dashboard_' . self::CODE . '_sort_order' => 4));
			}
		} catch (Exception $e) {
		}
	}

	public function uninstall() {
		$this->core()->uninstall();
		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode(self::CODE);
		$this->load->model('setting/extension');
		$this->model_setting_extension->uninstall('dashboard', self::CODE);
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('dashboard_' . self::CODE);
	}

	public function eventMenu(&$route, &$data) {
		if (empty($data['menus']) || !$this->user->hasPermission('access', self::ROUTE)) {
			return;
		}

		$this->load->language(self::ROUTE, 'sdr');
		$name = $this->language->get('sdr')->get('text_menu');
		$item = array('name' => $name, 'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'], true), 'children' => array());

		foreach ($data['menus'] as &$menu) {
			if (isset($menu['id']) && $menu['id'] === 'menu-system') {
				$menu['children'][] = $item;

				return;
			}
		}

		$data['menus'][] = array('id' => 'menu-store-doctor', 'icon' => 'fa-stethoscope', 'name' => $name, 'href' => $item['href'], 'children' => array());
	}
}
