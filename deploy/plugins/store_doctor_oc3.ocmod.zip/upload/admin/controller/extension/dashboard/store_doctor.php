<?php
/**
 * Store Doctor dashboard widget for OpenCart 3.0.x: health score and the most important problems.
 */
class ControllerExtensionDashboardStoreDoctor extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/store_doctor');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');

		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
			$this->model_setting_setting->editSetting('dashboard_store_doctor', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';
		$data['breadcrumbs'] = array(
			array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)),
			array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)),
			array('text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/dashboard/store_doctor', 'user_token=' . $this->session->data['user_token'], true))
		);
		$data['action'] = $this->url->link('extension/dashboard/store_doctor', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		foreach (array('width' => 6, 'status' => 1, 'sort_order' => 4) as $key => $default) {
			$name = 'dashboard_store_doctor_' . $key;

			if (isset($this->request->post[$name])) {
				$data[$name] = $this->request->post[$name];
			} elseif ($this->config->get($name) !== null) {
				$data[$name] = $this->config->get($name);
			} else {
				$data[$name] = $default;
			}
		}

		$data['columns'] = range(3, 12);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/dashboard/store_doctor_form', $data));
	}

	public function install() {
		$this->load->model('setting/setting');

		if ($this->config->get('dashboard_store_doctor_width') === null) {
			$this->model_setting_setting->editSetting('dashboard_store_doctor', array('dashboard_store_doctor_width' => 6, 'dashboard_store_doctor_status' => 1, 'dashboard_store_doctor_sort_order' => 4));
		}
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/store_doctor')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function dashboard() {
		require_once(DIR_SYSTEM . 'library/storedoctor/Service.php');
		require_once(DIR_SYSTEM . 'library/storedoctor/Ui.php');

		$s = new SdrService($this->db, DB_PREFIX, 3);
		$link = $this->url->link('extension/module/store_doctor', 'user_token=' . $this->session->data['user_token'], true);

		return SdrUi::dashboard($s->lastScan(), $link, 3);
	}
}
