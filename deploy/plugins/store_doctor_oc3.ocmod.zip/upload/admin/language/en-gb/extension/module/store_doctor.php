<?php
$_['heading_title'] = 'Store Doctor: shop health check';
$_['text_menu']     = 'Store Doctor';
