<?php
$_['heading_title']    = 'Store Doctor: shop health';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: you have modified the Store Doctor dashboard widget!';
$_['text_edit']        = 'Edit Store Doctor dashboard widget';
$_['entry_width']      = 'Width';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify the Store Doctor dashboard widget!';
