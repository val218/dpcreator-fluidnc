<?php
/**
 * Store Doctor for OpenCart - renders the admin app and the dashboard widget, and routes the admin JSON calls.
 */
if (!class_exists('SdrUi')) {
class SdrUi {
	const VERSION = '1.1.0';

	public static function writeActions() {
		return array('fix', 'undo', 'ignore', 'mark_ready');
	}

	public static function dispatch(SdrService $s, $action, array $in) {
		switch ($action) {
			case 'bootstrap': return $s->bootstrap();
			case 'scan':      return $s->scan();
			case 'errors':    return $s->errors();
			case 'history':   return $s->history();
			case 'fix':
				$msg = $s->fix(isset($in['id']) ? (string)$in['id'] : '');

				return array('message' => $msg, 'scan' => $s->scan());
			case 'undo':
				$msg = $s->undo(isset($in['fix_id']) ? (int)$in['fix_id'] : 0);

				return array('message' => $msg, 'scan' => $s->scan());
			case 'mark_ready':
				$s->markReady(isset($in['code']) ? (string)$in['code'] : '', !empty($in['on']));

				return $s->scan();
			case 'ignore':
				$s->ignore(isset($in['id']) ? (string)$in['id'] : '', !empty($in['on']));

				return $s->scan();
			default: throw new Exception('Unknown action: ' . $action);
		}
	}

	public static function input() {
		$data = json_decode((string)file_get_contents('php://input'), true);

		return is_array($data) ? $data : array();
	}

	public static function json($payload) {
		return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
	}

	public static function api(SdrService $s, $action, $can) {
		$perm = in_array($action, self::writeActions(), true) ? 'modify' : 'access';

		if (!call_user_func($can, $perm)) {
			return self::json(array('error' => 'Permission denied: your user group needs "' . $perm . '" permission for Store Doctor (System > Users > User Groups).'));
		}

		try {
			return self::json(array('ok' => true, 'data' => self::dispatch($s, $action, self::input())));
		} catch (Exception $e) {
			return self::json(array('error' => $e->getMessage()));
		} catch (Error $e) {
			return self::json(array('error' => 'Server error: ' . $e->getMessage()));
		}
	}

	public static function page($api_url, $oc_major) {
		$boot = array('api' => $api_url, 'oc' => (int)$oc_major, 'version' => self::VERSION);
		$dir = dirname(__FILE__) . '/ui/';

		return '<div id="sdr-root" class="sdr"><div class="sdr-loading">Loading…</div></div>'
			. '<style>' . file_get_contents($dir . 'app.css') . '</style>'
			. '<script>window.SDR_BOOT=' . json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . ';</script>'
			. '<script>' . file_get_contents($dir . 'app.js') . '</script>';
	}

	private static function h($s) {
		return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
	}

	public static function scoreColor($score) {
		return $score >= 85 ? '#12805C' : ($score >= 60 ? '#B26A00' : '#C42B1C');
	}

	/** Dashboard widget: health score and the most important problems from the last scan. */
	public static function dashboard($last, $link, $oc_major) {
		// OpenCart returns links already HTML-encoded (&amp;); decode once so they are not encoded twice.
		$link = html_entity_decode((string)$link, ENT_QUOTES, 'UTF-8');

		$card = $oc_major >= 4 ? 'card mb-3' : 'panel panel-default';
		$head = $oc_major >= 4 ? 'card-header' : 'panel-heading';
		$out = '<div class="' . $card . ' sdr-dash"><style>'
			. '.sdr-dash .sdr-dh{display:flex;align-items:center;gap:10px}.sdr-dash .sdr-dh b{flex:1}'
			. '.sdr-dash .sdr-db{display:flex;gap:16px;align-items:center;padding:14px 16px}'
			. '.sdr-dash .sdr-ring{flex:0 0 auto;width:74px;height:74px;border-radius:50%;display:grid;place-items:center;font:700 24px/1 -apple-system,Segoe UI,Roboto,Arial,sans-serif;color:#1E2A35}'
			. '.sdr-dash .sdr-ring span{display:grid;place-items:center;width:58px;height:58px;border-radius:50%;background:#fff}'
			. '.sdr-dash ul{margin:0;padding:0;list-style:none;font-size:13px;flex:1;min-width:0}.sdr-dash li{display:flex;gap:8px;align-items:baseline;padding:3px 0}'
			. '.sdr-dash li i{flex:0 0 auto;width:9px;height:9px;border-radius:50%;display:inline-block}.sdr-dash .m{color:#6B7885;font-size:12px}'
			. '</style>';
		$out .= '<div class="' . $head . ' sdr-dh"><b><i class="fa fa-stethoscope"></i> Store Doctor</b><a href="' . self::h($link) . '">Open</a></div>';

		if (!$last) {
			return $out . '<div class="sdr-db">Your shop has not been checked yet. <a href="' . self::h($link) . '">Run the first check</a> - it takes a few seconds and changes nothing.</div></div>';
		}

		$c = self::scoreColor($last['score']);
		$out .= '<div class="sdr-db"><div class="sdr-ring" style="background:conic-gradient(' . $c . ' ' . (int)$last['score'] . '%,#E3E8ED 0)"><span>' . (int)$last['score'] . '</span></div><ul>';

		if (!$last['top']) {
			$out .= '<li><i style="background:#12805C"></i>No problems found in the last check.</li>';
		}

		foreach ($last['top'] as $t) {
			$out .= '<li><i style="background:' . ($t['status'] === 'bad' ? '#C42B1C' : '#B26A00') . '"></i>' . self::h($t['title']) . '</li>';
		}

		$out .= '<li class="m">' . (int)$last['counts']['bad'] . ' serious · ' . (int)$last['counts']['warn'] . ' to look at · checked ' . self::h(substr($last['scanned'], 0, 16)) . '</li>';

		return $out . '</ul></div></div>';
	}
}
}
