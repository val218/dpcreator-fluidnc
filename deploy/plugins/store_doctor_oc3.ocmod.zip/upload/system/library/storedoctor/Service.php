<?php
/**
 * Store Doctor for OpenCart - a read-only health check of the shop: security, extensions,
 * errors, SEO and content, speed and server, and OpenCart 4 readiness.
 * Every check only reads. Fixes are separate, safe, recorded and undoable.
 */
if (!class_exists('SdrService')) {
class SdrService {
	const CONFIG_CODE = 'module_store_doctor';
	const CONFIG_KEY = 'module_store_doctor_config';
	const SCAN_KEY = 'module_store_doctor_scan';

	/** Latest OpenCart releases known when this version of Store Doctor was made. */
	const LATEST_3 = '3.0.5.1';
	const LATEST_4 = '4.1.0.4';

	/** Extensions that ship with OpenCart 3.0.x (by type), so added ones can be told apart. */
	private static $core3 = array(
		'advertise' => 'google', 'analytics' => 'google', 'captcha' => 'basic google', 'currency' => 'ecb',
		'dashboard' => 'activity chart customer map online order recent sale', 'feed' => 'google_base google_sitemap',
		'fraud' => 'fraudlabspro ip maxmind',
		'module' => 'account amazon_login amazon_pay banner bestseller carousel category featured filter google_hangouts html information latest laybuy_layout paypal_smart_button pilibaba_button pp_braintree_button sagepay_direct_cards sagepay_server_cards slideshow special store',
		'payment' => 'alipay alipay_cross amazon_login_pay authorizenet_aim authorizenet_sim bank_transfer bluepay_hosted bluepay_redirect cardconnect cardinity cheque cod eway firstdata firstdata_remote free_checkout g2apay globalpay globalpay_remote klarna_account klarna_invoice laybuy liqpay nochex opayo paymate paypal paypoint payza perpetual_payments pilibaba realex realex_remote sagepay_direct sagepay_server sagepay_us securetrading_pp securetrading_ws skrill squareup twocheckout web_payment_software wechat_pay worldpay',
		'report' => 'customer_activity customer_order customer_reward customer_search customer_transaction marketing product_purchased product_viewed sale_coupon sale_order sale_return sale_shipping sale_tax',
		'shipping' => 'auspost ec_ship fedex flat free item parcelforce_48 pickup royal_mail ups usps weight',
		'theme' => 'default', 'total' => 'coupon credit handling klarna_fee low_order_fee reward shipping sub_total tax total voucher'
	);

	private $db;
	private $p;
	private $oc;
	private $ctx;
	private $config;
	private $settings;

	/**
	 * ctx: root, admin, catalog_dir, system, storage, logs, image, extension (OC4), modification (OC3),
	 *      version, catalog_url, admin_user
	 */
	public function __construct($db, $prefix, $oc_major, array $ctx = array()) {
		$this->db = $db;
		$this->p = $prefix;
		$this->oc = (int)$oc_major;
		$this->ctx = $ctx;
	}

	private function e($s) {
		return $this->db->escape((string)$s);
	}

	private function c($k, $default = '') {
		return isset($this->ctx[$k]) ? $this->ctx[$k] : $default;
	}

	private function q($sql) {
		return $this->db->query($sql);
	}

	private function tableExists($name) {
		return (bool)$this->q("SHOW TABLES LIKE '" . $this->e($this->p . $name) . "'")->num_rows;
	}

	private function columnExists($table, $col) {
		return (bool)$this->q("SHOW COLUMNS FROM `" . $this->p . $table . "` LIKE '" . $this->e($col) . "'")->num_rows;
	}

	private function setting($key, $default = '') {
		if ($this->settings === null) {
			$this->settings = array();

			foreach ($this->q("SELECT `key`, `value` FROM `" . $this->p . "setting` WHERE store_id = '0' AND `code` = 'config'")->rows as $r) {
				$this->settings[$r['key']] = $r['value'];
			}
		}

		return isset($this->settings[$key]) ? $this->settings[$key] : $default;
	}

	/* ------------------------------------------------ settings, install */

	public static function defaults() {
		return array('ignored' => array());
	}

	public function getConfig() {
		if ($this->config !== null) {
			return $this->config;
		}

		$cfg = self::defaults();
		$q = $this->q("SELECT `value` FROM `" . $this->p . "setting` WHERE store_id = '0' AND `key` = '" . self::CONFIG_KEY . "' LIMIT 1");

		if ($q->num_rows) {
			$saved = json_decode($q->row['value'], true);

			if (is_array($saved)) {
				$cfg = array_merge($cfg, array_intersect_key($saved, $cfg));
			}
		}

		return $this->config = $cfg;
	}

	private function putSetting($key, $value) {
		$this->q("DELETE FROM `" . $this->p . "setting` WHERE store_id = '0' AND `key` = '" . $this->e($key) . "'");
		$this->q("INSERT INTO `" . $this->p . "setting` SET store_id = '0', `code` = '" . self::CONFIG_CODE . "', `key` = '" . $this->e($key) . "', `value` = '" . $this->e($value) . "', serialized = '0'");
	}

	private function saveConfig(array $cfg) {
		$this->putSetting(self::CONFIG_KEY, json_encode($cfg));
		$this->config = $cfg;
	}

	public function install() {
		$this->ensureTables();

		if (!$this->q("SELECT 1 FROM `" . $this->p . "setting` WHERE `key` = '" . self::CONFIG_KEY . "'")->num_rows) {
			$this->saveConfig(self::defaults());
		}
	}

	public function uninstall() {
		$this->q("DELETE FROM `" . $this->p . "setting` WHERE `code` = '" . self::CONFIG_CODE . "'");
	}

	public function ensureTables() {
		// Every fix is recorded here with what is needed to undo it.
		$this->q("CREATE TABLE IF NOT EXISTS `" . $this->p . "store_doctor_fix` (
			`fix_id` INT(11) NOT NULL AUTO_INCREMENT,
			`check_id` VARCHAR(64) NOT NULL,
			`title` VARCHAR(255) NOT NULL,
			`result` VARCHAR(500) NOT NULL DEFAULT '',
			`undo` MEDIUMTEXT NULL,
			`undone` TINYINT(1) NOT NULL DEFAULT 0,
			`user` VARCHAR(64) NOT NULL DEFAULT '',
			`date_added` DATETIME NOT NULL,
			PRIMARY KEY (`fix_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
	}

	/* ------------------------------------------------ scan */

	private $out = array();

	/**
	 * Add a finding. status: bad | warn | ok | info.
	 * $more: detail (plain text), how (how to fix, plain text), items (list of strings), fix (fix id), fix_label
	 */
	private function add($group, $id, $status, $title, array $more = array()) {
		$this->out[] = array_merge(array('group' => $group, 'id' => $id, 'status' => $status, 'title' => $title, 'detail' => '', 'how' => '', 'items' => array(), 'fix' => '', 'fix_label' => ''), $more);
	}

	public function scan() {
		$this->ensureTables();
		$this->out = array();
		$t = microtime(true);

		foreach (array('security', 'extensions', 'errors', 'content', 'speed', 'readiness') as $g) {
			try {
				$this->{'check' . ucfirst($g)}();
			} catch (Exception $e) {
				$this->add($g, $g . '_failed', 'info', 'This part of the scan could not finish', array('detail' => $e->getMessage()));
			} catch (Error $e) {
				$this->add($g, $g . '_failed', 'info', 'This part of the scan could not finish', array('detail' => $e->getMessage()));
			}
		}

		$ignored = $this->getConfig()['ignored'];
		$counts = array('bad' => 0, 'warn' => 0, 'ok' => 0, 'info' => 0, 'ignored' => 0);
		$bad = $warn = 0;

		foreach ($this->out as &$f) {
			$f['ignored'] = in_array($f['id'], $ignored, true);

			if ($f['ignored']) {
				$counts['ignored']++;
				continue;
			}

			$counts[$f['status']]++;

			// OpenCart 4 readiness is advice for later, not a health problem: it does not lower the score.
			if ($f['group'] !== 'readiness') {
				if ($f['status'] === 'bad') {
					$bad++;
				} elseif ($f['status'] === 'warn') {
					$warn++;
				}
			}
		}

		unset($f);

		$score = 100 - min(60, 10 * $bad) - min(30, 3 * $warn);

		$result = array(
			'score' => max(0, min(100, $score)), 'counts' => $counts, 'findings' => $this->out,
			'scanned' => date('Y-m-d H:i:s'), 'seconds' => round(microtime(true) - $t, 2),
			'version' => $this->c('version'), 'oc' => $this->oc
		);

		// Keep a small summary for the dashboard widget.
		$top = array();

		foreach ($this->out as $f) {
			if (!$f['ignored'] && $f['group'] !== 'readiness' && ($f['status'] === 'bad' || $f['status'] === 'warn')) {
				$top[] = array('status' => $f['status'], 'title' => $f['title'], 'group' => $f['group']);
			}
		}

		usort($top, function ($a, $b) {
			return strcmp($a['status'], $b['status']);
		});

		$this->putSetting(self::SCAN_KEY, json_encode(array('score' => $result['score'], 'counts' => $counts, 'scanned' => $result['scanned'], 'top' => array_slice($top, 0, 5))));

		return $result;
	}

	public function lastScan() {
		$q = $this->q("SELECT `value` FROM `" . $this->p . "setting` WHERE store_id = '0' AND `key` = '" . self::SCAN_KEY . "' LIMIT 1");
		$d = $q->num_rows ? json_decode($q->row['value'], true) : null;

		return is_array($d) ? $d : null;
	}

	/* ------------------------------------------------ security */

	private function real($path) {
		$r = @realpath($path);

		return $r === false ? rtrim((string)$path, '/') : $r;
	}

	private function checkSecurity() {
		$g = 'security';
		$root = $this->real($this->c('root'));
		$admin = $this->real($this->c('admin'));

		// OpenCart version
		$v = (string)$this->c('version');
		$latest = $this->oc >= 4 ? self::LATEST_4 : self::LATEST_3;

		if ($v !== '' && version_compare($v, $latest, '<')) {
			$this->add($g, 'oc_version', 'warn', 'OpenCart ' . $v . ' is not the latest release', array(
				'detail' => 'The latest ' . ($this->oc >= 4 ? 'OpenCart 4' : 'OpenCart 3') . ' release known to Store Doctor is ' . $latest . '. Newer releases fix bugs and security problems.',
				'how' => 'Read the release notes on opencart.com, back up your files and database, then upgrade on a test copy of the shop first.'
			));
		} else {
			$this->add($g, 'oc_version', 'ok', 'OpenCart ' . $v . ' is up to date');
		}

		// PHP version
		$php = PHP_VERSION;

		if (version_compare($php, '8.1.0', '<')) {
			$this->add($g, 'php_version', 'bad', 'PHP ' . $php . ' no longer gets security updates', array(
				'detail' => 'Versions older than PHP 8.1 have reached end of life, so security holes found in them are not fixed any more.',
				'how' => 'Ask your host to move the shop to PHP 8.2 or 8.3 (most control panels have a PHP version selector). Test on a copy first - old extensions can break on new PHP; the Errors tab helps you find them.'
			));
		} elseif (version_compare($php, '8.2.0', '<')) {
			$this->add($g, 'php_version', 'warn', 'PHP ' . $php . ' is near the end of its support', array(
				'detail' => 'PHP 8.1 security support ended on 31 December 2025.',
				'how' => 'Plan a move to PHP 8.2 or 8.3 with your host. Test on a copy first.'
			));
		} else {
			$this->add($g, 'php_version', 'ok', 'PHP ' . $php . ' is supported');
		}

		// install folder left behind
		if (is_dir($root . '/install')) {
			$this->add($g, 'install_dir', 'bad', 'The "install" folder is still on the server', array(
				'detail' => 'Anyone who finds it can try to run the OpenCart installer again. OpenCart asks you to delete it after installing.',
				'how' => 'Delete the folder ' . $root . '/install with your host\'s file manager or FTP.'
			));
		} else {
			$this->add($g, 'install_dir', 'ok', 'The install folder has been removed');
		}

		// storage folder inside the public web folder
		$storage = $this->real($this->c('storage'));

		if ($storage !== '' && $root !== '' && strpos($storage . '/', $root . '/') === 0) {
			$this->add($g, 'storage_public', 'warn', 'The storage folder is inside the public web folder', array(
				'detail' => 'It holds logs, cache, uploaded files and session data. If the web server is not set up to block it, those files can be opened from a browser.',
				'how' => $this->oc >= 4 ? 'OpenCart 4 can move it for you: on the admin Dashboard, click the security warning (or the gear button) and use "Move storage directory".' : 'Move system/storage one level above the web folder and change DIR_STORAGE in both config.php files (admin and shop). Back up first, or ask your developer.'
			));
		} else {
			$this->add($g, 'storage_public', 'ok', 'The storage folder is outside the public web folder');
		}

		// admin folder name
		if (basename($admin) === 'admin') {
			$this->add($g, 'admin_name', 'info', 'The admin folder still has the default name "admin"', array(
				'detail' => 'Bots try /admin on every site. Renaming it does not make the shop safe on its own, but it stops a lot of automated password guessing.',
				'how' => $this->oc >= 4 ? 'OpenCart 4 can rename it: on the admin Dashboard use the security dialog, "Move admin directory".' : 'Rename the folder and update the paths in admin/config.php. Ask your developer if unsure.'
			));
		}

		// default / weak admin user names
		$weak = array();

		foreach ($this->q("SELECT `username` FROM `" . $this->p . "user` WHERE `status` = '1'")->rows as $u) {
			if (in_array(strtolower($u['username']), array('admin', 'administrator', 'root', 'test', 'demo', 'user', 'manager', 'shop'), true)) {
				$weak[] = $u['username'];
			}
		}

		if ($weak) {
			$this->add($g, 'admin_users', 'warn', 'Admin login uses an easy-to-guess user name', array(
				'detail' => 'Password-guessing bots try these names first.',
				'items' => $weak,
				'how' => 'In System > Users > Users, create a new administrator with a less obvious user name and a long password, log in with it, then disable the old one.'
			));
		} else {
			$this->add($g, 'admin_users', 'ok', 'Admin user names are not the usual guesses');
		}

		// HTTPS
		$url = (string)$this->c('catalog_url');

		if ($url !== '' && stripos($url, 'https://') !== 0) {
			$this->add($g, 'https', 'bad', 'The shop is not using HTTPS', array(
				'detail' => 'Without HTTPS, passwords and customer details are sent unencrypted, browsers mark the shop "Not secure", and Google ranks it lower.',
				'how' => 'Turn on a free SSL certificate in your hosting panel (Let\'s Encrypt), then change the shop address to https:// in both config.php files' . ($this->oc < 4 ? ' and turn on "Use SSL" in System > Settings > Server' : '') . '.'
			));
		} else {
			$this->add($g, 'https', 'ok', 'The shop uses HTTPS');
		}

		// error display
		if ($this->setting('config_error_display') === '1') {
			$this->add($g, 'error_display', 'warn', 'PHP errors are shown to visitors', array(
				'detail' => 'Error messages on the shop look broken to customers and show file paths that help attackers.',
				'how' => 'Errors can still be written to the error log (the Errors tab reads it). Store Doctor can switch the display off for you.',
				'fix' => 'error_display', 'fix_label' => 'Hide errors from visitors'
			));
		} else {
			$this->add($g, 'error_display', 'ok', 'PHP errors are hidden from visitors');
		}

		// world-writable config files
		$loose = array();

		foreach (array($root . '/config.php', $admin . '/config.php') as $f) {
			if (is_file($f) && (fileperms($f) & 0002)) {
				$loose[] = $f . ' (' . substr(sprintf('%o', fileperms($f)), -3) . ')';
			}
		}

		if ($loose) {
			$this->add($g, 'config_perms', 'bad', 'A config.php file can be changed by any user on the server', array(
				'detail' => 'config.php holds your database password. "World-writable" permissions let other accounts on a shared server change it.',
				'items' => $loose,
				'how' => 'Set these files to 644 (or 444) in your file manager or FTP program.'
			));
		} else {
			$this->add($g, 'config_perms', 'ok', 'config.php files are not world-writable');
		}

		// maintenance mode
		if ($this->setting('config_maintenance') === '1') {
			$this->add($g, 'maintenance', 'warn', 'The shop is in maintenance mode', array(
				'detail' => 'Customers see a maintenance page instead of the shop. Only logged-in admins can browse it.',
				'how' => 'Turn it off in System > Settings > Server > Maintenance Mode when you are finished.'
			));
		}

		// SEO URLs without .htaccess (Apache)
		$apache = stripos((string)(isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : ''), 'nginx') === false;

		if ($this->setting('config_seo_url') === '1' && $apache && !is_file($root . '/.htaccess')) {
			$this->add($g, 'htaccess', 'bad', 'SEO URLs are on, but there is no .htaccess file', array(
				'detail' => 'On Apache servers the friendly product addresses only work with the .htaccess file, so links can lead to "Not Found" pages.',
				'how' => 'Rename .htaccess.txt in the shop folder to .htaccess (or ask your host). If your server is nginx, ignore this.'
			));
		}
	}

	/* ------------------------------------------------ extensions */

	private function isCore3($type, $code) {
		return isset(self::$core3[$type]) && in_array($code, explode(' ', self::$core3[$type]), true);
	}

	/** Controller file for an extension, or '' if unknown. */
	private function extensionFile($row) {
		if ($this->oc >= 4) {
			return rtrim($this->c('extension'), '/') . '/' . $row['extension'] . '/admin/controller/' . $row['type'] . '/' . $row['code'] . '.php';
		}

		return rtrim($this->c('admin'), '/') . '/controller/extension/' . $row['type'] . '/' . $row['code'] . '.php';
	}

	/** Which controller file an event action points to (or '' when it can not be worked out). */
	private function eventFile($trigger, $action) {
		$app = strpos($trigger, 'admin/') === 0 ? 'admin' : (strpos($trigger, 'catalog/') === 0 ? 'catalog' : '');

		if ($app === '') {
			return '';
		}

		$base = $app === 'admin' ? rtrim($this->c('admin'), '/') : rtrim($this->c('catalog_dir'), '/');
		$route = preg_replace('/[^a-zA-Z0-9_\/.|]/', '', $action);

		if ($this->oc >= 4) {
			$route = preg_split('/[.|]/', $route)[0];

			if (preg_match('~^extension/([^/]+)/(.+)$~', $route, $m)) {
				return rtrim($this->c('extension'), '/') . '/' . $m[1] . '/' . $app . '/controller/' . $m[2] . '.php';
			}

			return $base . '/controller/' . $route . '.php';
		}

		// OC3: the last part may be the method name
		$parts = explode('/', $route);

		while ($parts) {
			$f = $base . '/controller/' . implode('/', $parts) . '.php';

			if (is_file($f)) {
				return $f;
			}

			array_pop($parts);
		}

		return $base . '/controller/' . $route . '.php';
	}

	private function checkExtensions() {
		$g = 'extensions';
		$added = array();
		$broken = array();

		foreach ($this->q("SELECT * FROM `" . $this->p . "extension` ORDER BY `type`, `code`")->rows as $r) {
			$core = $this->oc >= 4 ? $r['extension'] === 'opencart' : $this->isCore3($r['type'], $r['code']);
			$file = $this->extensionFile($r);

			if (!is_file($file)) {
				$broken[] = $r['type'] . ' / ' . $r['code'] . ' - missing ' . str_replace($this->real($this->c('root')), '', $file);
			} elseif (!$core) {
				$added[] = ucfirst($r['type']) . ': ' . $r['code'] . ($this->oc >= 4 ? ' (' . $r['extension'] . ')' : '');
			}
		}

		if ($broken) {
			$this->add($g, 'ext_missing', 'bad', count($broken) . ' installed extension' . (count($broken) === 1 ? ' has' : 's have') . ' missing files', array(
				'detail' => 'They are switched on in the database but their files were deleted or never fully uploaded, which can cause errors on the admin and the shop.',
				'items' => $broken,
				'how' => 'Upload the extension again, or uninstall it in Extensions > Extensions (choose its type, then the red Uninstall button).'
			));
		}

		$this->add($g, 'ext_added', 'info', count($added) . ' extension' . (count($added) === 1 ? '' : 's') . ' added to OpenCart', array(
			'detail' => 'Extensions that did not come with OpenCart. Each one is extra code that has to be kept up to date. Remove the ones you no longer use.',
			'items' => $added
		));

		// Events that point to code that is not there
		if ($this->tableExists('event')) {
			$dead = array();

			foreach ($this->q("SELECT * FROM `" . $this->p . "event` WHERE `status` = '1'")->rows as $ev) {
				$f = $this->eventFile($ev['trigger'], $ev['action']);

				if ($f !== '' && !is_file($f)) {
					$dead[] = $ev;
				}
			}

			if ($dead) {
				$items = array();

				foreach ($dead as $ev) {
					$items[] = $ev['code'] . ': ' . $ev['trigger'] . ' -> ' . $ev['action'];
				}

				$this->add($g, 'events_dead', 'bad', count($dead) . ' event' . (count($dead) === 1 ? ' points' : 's point') . ' to an extension that is no longer there', array(
					'detail' => 'Usually left behind when an extension is deleted without uninstalling it first. They can cause errors or blank pages.',
					'items' => $items,
					'how' => 'Store Doctor can switch these events off (they stay in the list and can be switched on again with Undo).',
					'fix' => 'events_dead', 'fix_label' => 'Switch off these events'
				));
			} else {
				$this->add($g, 'events_dead', 'ok', 'All active events point to existing code');
			}
		}

		// OCMOD modifications
		if ($this->tableExists('modification')) {
			$mods = $this->q("SELECT `name`, `author`, `version`, `status`, `date_added` FROM `" . $this->p . "modification` ORDER BY `name`")->rows;
			$on = $off = array();

			foreach ($mods as $m) {
				$line = $m['name'] . ($m['version'] !== '' ? ' ' . $m['version'] : '') . ($m['author'] !== '' ? ' - ' . $m['author'] : '') . ' (' . substr($m['date_added'], 0, 10) . ')';

				if ((int)$m['status']) {
					$on[] = $line;
				} else {
					$off[] = $line;
				}
			}

			if ($on) {
				$this->add($g, 'ocmod_on', 'info', count($on) . ' modification' . (count($on) === 1 ? '' : 's') . ' (OCMOD) change OpenCart files', array(
					'detail' => 'Modifications edit copies of OpenCart\'s own files. They are the most common cause of errors after an update or when two extensions change the same place.',
					'items' => $on,
					'how' => 'After installing, removing or switching one on/off, click the blue Refresh button in Extensions > Modifications.'
				));
			}

			if ($off) {
				$this->add($g, 'ocmod_off', 'info', count($off) . ' modification' . (count($off) === 1 ? ' is' : 's are') . ' switched off', array(
					'detail' => 'Switched-off modifications do nothing. If you do not need them any more, delete them in Extensions > Modifications to keep the list clean.',
					'items' => $off
				));
			}
		}
	}

	/* ------------------------------------------------ errors */

	public static function explainError($type) {
		$t = strtolower($type);

		if (strpos($t, 'fatal') !== false || strpos($t, 'exception') !== false || strpos($t, 'error') === 0) {
			return 'Stops the page from loading - visitors see a blank or broken page.';
		}

		if (strpos($t, 'warning') !== false) {
			return 'Something unexpected happened; the page still loaded but may show wrong or missing information.';
		}

		if (strpos($t, 'deprecated') !== false) {
			return 'Harmless today, but will break when the server moves to a newer PHP version.';
		}

		return 'Minor problem; the page still loaded.';
	}

	/** Which extension or file a path belongs to, in plain words. */
	public function sourceOf($file) {
		$f = str_replace('\\', '/', $file);

		if (preg_match('~/storage/modification/(.+)$~', $f, $m)) {
			return 'Modified copy of ' . $m[1] . ' (an OCMOD modification)';
		}

		$ext = str_replace('\\', '/', rtrim((string)$this->c('extension'), '/'));

		if ($this->oc >= 4 && $ext !== '') {
			$real = str_replace('\\', '/', $this->real($ext));

			foreach (array($ext, $real) as $base) {
				if ($base !== '' && strpos($f, $base . '/') === 0) {
					$name = strtok(substr($f, strlen($base) + 1), '/');

					return $name === 'opencart' ? 'OpenCart (built-in extension)' : 'Extension "' . $name . '"';
				}
			}
		}

		if (preg_match('~/controller/extension/([a-z_]+)/([a-z0-9_]+)\.php$~i', $f, $m) || preg_match('~/model/extension/([a-z_]+)/([a-z0-9_]+)\.php$~i', $f, $m)) {
			return $this->isCore3($m[1], $m[2]) ? 'OpenCart (' . $m[1] . ' ' . $m[2] . ')' : 'Extension "' . $m[2] . '" (' . $m[1] . ')';
		}

		if (strpos($f, '/vendor/') !== false) {
			return 'A library used by OpenCart or an extension';
		}

		if (preg_match('~/(catalog|admin|system)/~', $f) && preg_match('~/(journal3?|theme)/~i', $f)) {
			return 'Theme files';
		}

		return 'OpenCart or theme file';
	}

	private function logFile() {
		$name = basename((string)$this->setting('config_error_filename', 'error.log'));

		return rtrim((string)$this->c('logs'), '/') . '/' . ($name !== '' ? $name : 'error.log');
	}

	/** Read the end of the error log and group the same errors together. */
	public function errors($max_bytes = 2097152) {
		$file = $this->logFile();
		$out = array('file' => $file, 'exists' => is_file($file), 'size' => is_file($file) ? filesize($file) : 0, 'groups' => array(), 'lines' => 0);

		if (!$out['exists'] || !$out['size']) {
			return $out;
		}

		$fh = fopen($file, 'rb');
		$start = max(0, $out['size'] - $max_bytes);
		fseek($fh, $start);
		$data = stream_get_contents($fh);
		fclose($fh);

		if ($start > 0) {
			$data = substr($data, strpos($data, "\n") + 1);
		}

		$groups = array();

		foreach (explode("\n", $data) as $line) {
			$line = trim($line);

			if ($line === '') {
				continue;
			}

			$out['lines']++;

			if (!preg_match('/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+-\s+(.*)$/', $line, $m)) {
				continue;
			}

			$when = $m[1];
			$msg = $m[2];
			$type = 'Message';
			$file_ = '';
			$ln = 0;

			if (preg_match('/^PHP ([A-Za-z ]+?):\s+(.*?) in (\S+) on line (\d+)/', $msg, $mm)) {
				$type = $mm[1];
				$text = $mm[2];
				$file_ = $mm[3];
				$ln = (int)$mm[4];
			} elseif (preg_match('/^(.*?):? in (\S+\.php) on line (\d+)/', $msg, $mm)) {
				$text = $mm[1];
				$file_ = $mm[2];
				$ln = (int)$mm[3];
				$type = stripos($text, 'Uncaught') !== false ? 'Fatal error' : 'Error';
			} else {
				$text = $msg;
			}

			$text = substr($text, 0, 400);
			$key = md5($type . '|' . preg_replace('/\d+/', '#', $text) . '|' . $file_ . '|' . $ln);

			if (!isset($groups[$key])) {
				$groups[$key] = array('type' => $type, 'message' => $text, 'file' => $file_, 'line' => $ln, 'count' => 0, 'first' => $when, 'last' => $when,
					'source' => $file_ !== '' ? $this->sourceOf($file_) : 'Unknown', 'meaning' => self::explainError($type));
			}

			$groups[$key]['count']++;
			$groups[$key]['last'] = $when;
		}

		usort($groups, function ($a, $b) {
			$sa = stripos($a['type'], 'fatal') !== false ? 1 : 0;
			$sb = stripos($b['type'], 'fatal') !== false ? 1 : 0;

			return $sa !== $sb ? $sb - $sa : ($b['count'] - $a['count'] ?: strcmp($b['last'], $a['last']));
		});

		$out['groups'] = array_slice($groups, 0, 100);
		$out['distinct'] = count($groups);
		$out['partial'] = $start > 0;

		return $out;
	}

	private function checkErrors() {
		$g = 'errors';

		if ($this->setting('config_error_log', '1') !== '1') {
			$this->add($g, 'error_log_off', 'warn', 'Error logging is switched off', array(
				'detail' => 'Errors are not written anywhere, so problems on the shop go unnoticed and Store Doctor can not show them.',
				'how' => 'Turn on "Log Errors" in System > Settings > Server.'
			));
		}

		$e = $this->errors();

		if (!$e['exists'] || !$e['size']) {
			$this->add($g, 'errors_none', 'ok', 'The error log is empty');

			return;
		}

		$fatal = $recent = 0;
		$week = date('Y-m-d H:i:s', strtotime('-7 days'));

		foreach ($e['groups'] as $x) {
			if (stripos($x['type'], 'fatal') !== false) {
				$fatal++;
			}

			if ($x['last'] >= $week) {
				$recent++;
			}
		}

		if ($fatal) {
			$this->add($g, 'errors_fatal', 'bad', $fatal . ($fatal === 1 ? ' kind of error stops' : ' kinds of error stop') . ' pages from loading', array(
				'detail' => 'See the Errors tab for where each one comes from and how often it happens.',
				'how' => 'Start with the most frequent one. If it comes from an extension, update it or ask its author; if it comes from a modification, try switching that modification off and refreshing modifications.'
			));
		}

		$this->add($g, 'errors_summary', $recent ? 'warn' : 'info', $e['distinct'] . ' different error' . ($e['distinct'] === 1 ? '' : 's') . ' in the log, ' . $recent . ' seen in the last 7 days', array(
			'detail' => 'The Errors tab groups the same error together and shows which extension or file it comes from.'
		));

		if ($e['size'] > 50 * 1048576) {
			$this->add($g, 'errors_big', 'warn', 'The error log is ' . round($e['size'] / 1048576) . ' MB', array(
				'detail' => 'A very large log wastes disk space and slows down the Error Logs page.',
				'how' => 'Fix the most frequent errors first, then clear the log in System > Maintenance > Error Logs.'
			));
		}
	}

	/* ------------------------------------------------ content & SEO */

	private function languages() {
		return $this->q("SELECT `language_id`, `name`, `code` FROM `" . $this->p . "language` WHERE `status` = '1' ORDER BY `sort_order`")->rows;
	}

	private function checkContent() {
		$g = 'content';
		$p = $this->p;
		$langs = $this->languages();
		$enabled = (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product` WHERE `status` = '1'")->row['n'];

		$this->add($g, 'catalog_size', 'info', $enabled . ' enabled products, ' . (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}category` WHERE `status` = '1'")->row['n'] . ' enabled categories, ' . count($langs) . ' language' . (count($langs) === 1 ? '' : 's'));

		if (!$enabled) {
			return;
		}

		// Missing meta titles and descriptions
		$no_title = $no_desc = array();

		foreach ($langs as $l) {
			$r = $this->q("SELECT p.product_id, pd.name FROM `{$p}product` p JOIN `{$p}product_description` pd ON pd.product_id = p.product_id AND pd.language_id = '" . (int)$l['language_id'] . "' WHERE p.status = '1' AND TRIM(pd.meta_title) = '' ORDER BY pd.name LIMIT 500")->rows;

			foreach ($r as $x) {
				$no_title[] = html_entity_decode($x['name'], ENT_QUOTES, 'UTF-8') . (count($langs) > 1 ? ' (' . $l['code'] . ')' : '');
			}

			$n = (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product` p JOIN `{$p}product_description` pd ON pd.product_id = p.product_id AND pd.language_id = '" . (int)$l['language_id'] . "' WHERE p.status = '1' AND (pd.description IS NULL OR LENGTH(TRIM(REPLACE(REPLACE(pd.description, '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', ''), '&nbsp;', ''))) < 20)")->row['n'];

			if ($n) {
				$no_desc[] = $l['name'] . ': ' . $n . ' product' . ($n === 1 ? '' : 's');
			}
		}

		if ($no_title) {
			$this->add($g, 'meta_title', 'warn', count($no_title) . ' enabled product' . (count($no_title) === 1 ? ' has' : 's have') . ' no meta title', array(
				'detail' => 'The meta title is the headline Google shows in search results. Without it, search results look poor.',
				'items' => array_slice($no_title, 0, 50),
				'how' => 'Store Doctor can fill the empty ones with the product name (you can improve them later; Undo puts them back to empty).',
				'fix' => 'meta_title', 'fix_label' => 'Fill empty meta titles with the product name'
			));
		} else {
			$this->add($g, 'meta_title', 'ok', 'All enabled products have a meta title');
		}

		if ($no_desc) {
			$this->add($g, 'descriptions', 'warn', 'Some enabled products have no description', array(
				'detail' => 'Products without a description convert worse and rank lower in Google.',
				'items' => $no_desc,
				'how' => 'Write descriptions in Catalog > Products (an AI writing extension can draft them in bulk).'
			));
		}

		// SEO keywords
		if ($this->oc >= 4) {
			$dup = $this->q("SELECT `keyword`, `store_id`, `language_id`, COUNT(*) AS n FROM `{$p}seo_url` WHERE `keyword` <> '' GROUP BY `store_id`, `language_id`, `keyword` HAVING n > 1 LIMIT 100")->rows;
			$missing = (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product` p WHERE p.status = '1' AND NOT EXISTS (SELECT 1 FROM `{$p}seo_url` s WHERE s.`key` = 'product_id' AND s.`value` = p.product_id AND s.store_id = '0')")->row['n'];
		} else {
			$dup = $this->q("SELECT `keyword`, `store_id`, `language_id`, COUNT(*) AS n FROM `{$p}seo_url` WHERE `keyword` <> '' GROUP BY `store_id`, `language_id`, `keyword` HAVING n > 1 LIMIT 100")->rows;
			$missing = (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product` p WHERE p.status = '1' AND NOT EXISTS (SELECT 1 FROM `{$p}seo_url` s WHERE s.`query` = CONCAT('product_id=', p.product_id) AND s.store_id = '0')")->row['n'];
		}

		if ($dup) {
			$items = array();

			foreach ($dup as $d) {
				$items[] = $d['keyword'] . ' (used ' . $d['n'] . ' times)';
			}

			$this->add($g, 'seo_dupes', 'bad', count($dup) . ' SEO keyword' . (count($dup) === 1 ? ' is' : 's are') . ' used more than once', array(
				'detail' => 'Two pages with the same SEO keyword means one of them can not be reached by its friendly address.',
				'items' => $items,
				'how' => 'Search for the keyword in Design > SEO URL and give each page its own keyword.'
			));
		} else {
			$this->add($g, 'seo_dupes', 'ok', 'No duplicate SEO keywords');
		}

		if ($this->setting('config_seo_url') === '1' && $missing) {
			$this->add($g, 'seo_missing', 'warn', $missing . ' enabled product' . ($missing === 1 ? ' has' : 's have') . ' no SEO keyword', array(
				'detail' => 'SEO URLs are switched on, but these products still use addresses like index.php?route=product/product&product_id=42.',
				'how' => 'Add a keyword on the product\'s SEO tab, or use an SEO extension to generate them in bulk.'
			));
		}

		// Products without category, image or price
		$nocat = (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product` p WHERE p.status = '1' AND NOT EXISTS (SELECT 1 FROM `{$p}product_to_category` c WHERE c.product_id = p.product_id)")->row['n'];

		if ($nocat) {
			$this->add($g, 'no_category', 'warn', $nocat . ' enabled product' . ($nocat === 1 ? ' is' : 's are') . ' not in any category', array(
				'detail' => 'Visitors can only find them through search or a direct link.',
				'how' => 'Add them to a category on the product\'s Links tab. (Catalog > Products has no filter for this; sort the list by name and check the Links tab.)'
			));
		}

		$noimg = $this->q("SELECT p.product_id, pd.name FROM `{$p}product` p LEFT JOIN `{$p}product_description` pd ON pd.product_id = p.product_id AND pd.language_id = '" . (int)($langs ? $langs[0]['language_id'] : 1) . "' WHERE p.status = '1' AND (p.image IS NULL OR p.image = '') LIMIT 200")->rows;

		if ($noimg) {
			$items = array();

			foreach ($noimg as $x) {
				$items[] = html_entity_decode((string)$x['name'], ENT_QUOTES, 'UTF-8');
			}

			$this->add($g, 'no_image', 'warn', count($noimg) . ' enabled product' . (count($noimg) === 1 ? ' has' : 's have') . ' no main image', array('items' => array_slice($items, 0, 50)));
		}

		// Image files that are set but missing on disk
		$dir = rtrim((string)$this->c('image'), '/') . '/';
		$gone = array();

		foreach ($this->q("SELECT p.image, pd.name FROM `{$p}product` p LEFT JOIN `{$p}product_description` pd ON pd.product_id = p.product_id AND pd.language_id = '" . (int)($langs ? $langs[0]['language_id'] : 1) . "' WHERE p.status = '1' AND p.image <> '' LIMIT 5000")->rows as $x) {
			if (!is_file($dir . $x['image'])) {
				$gone[] = html_entity_decode((string)$x['name'], ENT_QUOTES, 'UTF-8') . ' - ' . $x['image'];
			}
		}

		if ($gone) {
			$this->add($g, 'image_missing', 'bad', count($gone) . ' product image' . (count($gone) === 1 ? ' file is' : ' files are') . ' missing', array(
				'detail' => 'The product points to an image that is not on the server, so the shop shows the "no image" placeholder.',
				'items' => array_slice($gone, 0, 50),
				'how' => 'Upload the image again on the product\'s Image tab.'
			));
		}

		$free = (int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product` WHERE `status` = '1' AND `price` <= 0")->row['n'];

		if ($free) {
			$this->add($g, 'zero_price', 'warn', $free . ' enabled product' . ($free === 1 ? ' costs' : 's cost') . ' 0', array(
				'detail' => 'Unless they are meant to be free, customers can order them without paying.',
				'how' => 'Check the price on the product\'s Data tab (or a discount/special/option price may be meant).'
			));
		}
	}

	/* ------------------------------------------------ speed & server */

	private static function bytes($n) {
		$n = (float)$n;

		foreach (array('B', 'KB', 'MB', 'GB') as $u) {
			if ($n < 1024 || $u === 'GB') {
				return ($u === 'B' ? (int)$n : round($n, 1)) . ' ' . $u;
			}

			$n /= 1024;
		}

		return $n;
	}

	private static function iniBytes($v) {
		$v = trim((string)$v);

		if ($v === '' || $v === '-1') {
			return -1;
		}

		$n = (float)$v;
		$u = strtolower(substr($v, -1));

		return (int)($u === 'g' ? $n * 1073741824 : ($u === 'm' ? $n * 1048576 : ($u === 'k' ? $n * 1024 : $n)));
	}

	private function checkSpeed() {
		$g = 'speed';

		// PHP extensions OpenCart needs
		$need = array('curl' => 'payments, shipping rates and the marketplace', 'gd' => 'product images', 'zip' => 'installing extensions', 'mbstring' => 'non-English text', 'openssl' => 'secure connections', 'zlib' => 'compressed pages');
		$miss = array();

		foreach ($need as $ext => $why) {
			if (!extension_loaded($ext)) {
				$miss[] = $ext . ' (needed for ' . $why . ')';
			}
		}

		if ($miss) {
			$this->add($g, 'php_ext', 'bad', 'PHP is missing ' . count($miss) . ' extension' . (count($miss) === 1 ? '' : 's') . ' OpenCart needs', array('items' => $miss, 'how' => 'Switch them on in your hosting panel\'s PHP settings, or ask your host.'));
		} else {
			$this->add($g, 'php_ext', 'ok', 'All PHP extensions OpenCart needs are installed');
		}

		$op = function_exists('opcache_get_status') ? @opcache_get_status(false) : false;

		if (!$op || empty($op['opcache_enabled'])) {
			$this->add($g, 'opcache', 'warn', 'PHP OPcache is off', array(
				'detail' => 'OPcache keeps compiled PHP in memory. Without it every page is compiled again, often 2-3 times slower.',
				'how' => 'Turn on OPcache in your hosting panel\'s PHP settings (it is free and safe), or ask your host. (If this page itself runs without OPcache but the shop does, you can ignore this.)'
			));
		} else {
			$this->add($g, 'opcache', 'ok', 'PHP OPcache is on');
		}

		$mem = self::iniBytes(ini_get('memory_limit'));

		if ($mem > 0 && $mem < 128 * 1048576) {
			$this->add($g, 'memory', 'warn', 'PHP memory limit is only ' . ini_get('memory_limit'), array('detail' => 'Large product lists, image resizing and imports can fail with "Allowed memory size exhausted".', 'how' => 'Set memory_limit to 256M in your hosting panel.'));
		}

		// Database tables
		$tables = $this->q("SELECT TABLE_NAME AS name, ENGINE AS engine, (DATA_LENGTH + INDEX_LENGTH) AS size, TABLE_ROWS AS row_count FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE '" . $this->e(str_replace('_', '\\_', $this->p)) . "%' ORDER BY size DESC")->rows;
		$total = 0;
		$myisam = array();

		foreach ($tables as $t) {
			$total += (float)$t['size'];

			if (strtolower((string)$t['engine']) === 'myisam') {
				$myisam[] = $t['name'];
			}
		}

		$big = array();

		foreach (array_slice($tables, 0, 6) as $t) {
			$big[] = $t['name'] . ': ' . self::bytes($t['size']) . ', about ' . number_format((float)$t['row_count']) . ' rows';
		}

		$this->add($g, 'db_size', 'info', 'Database: ' . self::bytes($total) . ' in ' . count($tables) . ' tables', array('detail' => 'Largest tables:', 'items' => $big));

		if ($myisam) {
			$this->add($g, 'myisam', 'info', count($myisam) . ' table' . (count($myisam) === 1 ? ' uses' : 's use') . ' the older MyISAM engine', array(
				'detail' => 'MyISAM tables lock the whole table on every write and can be damaged by a crash. InnoDB is the modern default.',
				'items' => array_slice($myisam, 0, 30),
				'how' => 'After a full backup, convert them in phpMyAdmin (Operations > Storage Engine > InnoDB), best at a quiet time.'
			));
		}

		// Expired sessions piling up
		if ($this->tableExists('session')) {
			$old = (int)$this->q("SELECT COUNT(*) AS n FROM `" . $this->p . "session` WHERE `expire` < NOW()")->row['n'];

			if ($old > 5000) {
				$this->add($g, 'sessions', 'warn', number_format($old) . ' expired visitor sessions are still stored', array(
					'detail' => 'Every visit (and every bot) creates a session. Old ones are useless and make the database bigger and slower.',
					'how' => 'Store Doctor can delete the expired ones. Active visitors and logged-in customers are not affected.',
					'fix' => 'sessions', 'fix_label' => 'Delete expired sessions'
				));
			} else {
				$this->add($g, 'sessions', 'ok', 'Old sessions are being cleaned up');
			}
		}

		$missing_orders = (int)$this->q("SELECT COUNT(*) AS n FROM `" . $this->p . "order` WHERE `order_status_id` = '0'")->row['n'];

		if ($missing_orders > 1000) {
			$this->add($g, 'missing_orders', 'info', number_format($missing_orders) . ' unfinished checkouts ("missing orders") are stored', array(
				'detail' => 'OpenCart saves an order when checkout starts. If the customer never pays, it stays with no status. They do no harm but fill the order tables.',
				'how' => 'You can view and delete them in Sales > Orders by filtering for "Missing Orders".'
			));
		}

		// Images
		$dir = rtrim((string)$this->c('image'), '/') . '/';
		$big_img = array();
		$scanned = 0;
		$budget = microtime(true) + 3;

		if (is_dir($dir . 'catalog')) {
			$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir . 'catalog', FilesystemIterator::SKIP_DOTS));

			foreach ($it as $f) {
				if (++$scanned > 30000 || microtime(true) > $budget) {
					break;
				}

				if ($f->isFile() && $f->getSize() > 1048576 && preg_match('/\.(jpe?g|png|webp|gif)$/i', $f->getFilename())) {
					$big_img[] = substr($f->getPathname(), strlen($dir)) . ' (' . self::bytes($f->getSize()) . ')';
				}
			}
		}

		if ($big_img) {
			$this->add($g, 'big_images', 'warn', count($big_img) . ' uploaded image' . (count($big_img) === 1 ? ' is' : 's are') . ' larger than 1 MB', array(
				'detail' => 'OpenCart resizes images for the shop, but huge originals make resizing slow and use disk space. Photos straight from a camera are usually 3-8 MB.',
				'items' => array_slice($big_img, 0, 50),
				'how' => 'Resize them to about 1500-2000 pixels wide before uploading (or use an image compression extension).'
			));
		}

		$cache = 0;
		$cache_files = 0;

		if (is_dir($dir . 'cache')) {
			$budget = microtime(true) + 2;
			$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir . 'cache', FilesystemIterator::SKIP_DOTS));

			foreach ($it as $f) {
				if (microtime(true) > $budget) {
					break;
				}

				if ($f->isFile()) {
					$cache += $f->getSize();
					$cache_files++;
				}
			}
		}

		if ($cache > 1073741824) {
			$this->add($g, 'image_cache', 'warn', 'The resized-image cache uses ' . self::bytes($cache), array(
				'detail' => 'OpenCart keeps every resized copy forever, including sizes from old themes and deleted products.',
				'how' => 'Store Doctor can empty it. OpenCart makes new copies as pages are visited, so the first visits after that are a little slower.',
				'fix' => 'image_cache', 'fix_label' => 'Empty the image cache'
			));
		} else {
			$this->add($g, 'image_cache', 'info', 'Resized-image cache: ' . self::bytes($cache) . ' (' . number_format($cache_files) . ' files)');
		}
	}

	/* ------------------------------------------------ OpenCart 4 readiness */

	private function checkReadiness() {
		$g = 'readiness';

		if ($this->oc >= 4) {
			$this->add($g, 'oc4_already', 'ok', 'This shop already runs OpenCart ' . $this->c('version'), array(
				'detail' => 'Keep it on the newest 4.x release (' . self::LATEST_4 . ' when this version of Store Doctor was made) and check that each extension\'s author supports it before updating.'
			));

			return;
		}

		$points = 0;
		$theme = (string)$this->setting('config_theme', 'default');

		if ($theme !== '' && $theme !== 'default' && $theme !== 'theme_default') {
			$points += 3;
			$this->add($g, 'r_theme', 'warn', 'Theme "' . $theme . '" needs an OpenCart 4 version', array(
				'detail' => 'OpenCart 3 themes do not work on OpenCart 4. Check with the theme author whether an OpenCart 4 version exists and whether your licence covers it.'
			));
		} else {
			$this->add($g, 'r_theme', 'ok', 'The default theme is used, so there is no theme to replace');
		}

		$added = array();

		foreach ($this->q("SELECT `type`, `code` FROM `" . $this->p . "extension` ORDER BY `type`, `code`")->rows as $r) {
			if (!$this->isCore3($r['type'], $r['code'])) {
				$added[] = ucfirst($r['type']) . ': ' . $r['code'];
			}
		}

		$points += count($added);

		$this->add($g, 'r_extensions', $added ? 'warn' : 'ok', $added ? count($added) . ' added extension' . (count($added) === 1 ? ' needs' : 's need') . ' an OpenCart 4 version' : 'No added extensions to replace', array(
			'detail' => $added ? 'OpenCart 3 extensions can not be copied to OpenCart 4; each needs a version made for 4.x. Payment and shipping extensions matter most - without them customers can not check out.' : '',
			'items' => $added,
			'how' => $added ? 'Check each one on its author\'s page or the OpenCart Marketplace (look for 4.x in Compatibility). Remove the ones you no longer need before upgrading.' : ''
		));

		$mods = $this->tableExists('modification') ? $this->q("SELECT `name`, `author` FROM `" . $this->p . "modification` WHERE `status` = '1'")->rows : array();

		if ($mods) {
			$points += 2 * count($mods);
			$items = array();

			foreach ($mods as $m) {
				$items[] = $m['name'] . ($m['author'] !== '' ? ' - ' . $m['author'] : '');
			}

			$this->add($g, 'r_ocmod', 'warn', count($mods) . ' modification' . (count($mods) === 1 ? '' : 's') . ' (OCMOD) will not carry over', array(
				'detail' => 'OpenCart 4 changes files differently (events), so OCMOD changes made for OpenCart 3 have to be redone by the author or a developer.',
				'items' => $items
			));
		}

		$php_ok = version_compare(PHP_VERSION, '8.0.2', '>=');
		$this->add($g, 'r_php', $php_ok ? 'ok' : 'bad', $php_ok ? 'PHP ' . PHP_VERSION . ' is new enough for OpenCart 4' : 'OpenCart 4 needs PHP 8.0.2 or newer (this server has ' . PHP_VERSION . ')');

		$p = $this->p;
		$data = array(
			(int)$this->q("SELECT COUNT(*) AS n FROM `{$p}product`")->row['n'] . ' products',
			(int)$this->q("SELECT COUNT(*) AS n FROM `{$p}category`")->row['n'] . ' categories',
			(int)$this->q("SELECT COUNT(*) AS n FROM `{$p}customer`")->row['n'] . ' customers',
			(int)$this->q("SELECT COUNT(*) AS n FROM `{$p}order` WHERE order_status_id > 0")->row['n'] . ' orders',
			(int)$this->q("SELECT COUNT(*) AS n FROM `{$p}language`")->row['n'] . ' languages',
			(int)$this->q("SELECT COUNT(*) AS n FROM `{$p}store`")->row['n'] + 1 . ' store' . ((int)$this->q("SELECT COUNT(*) AS n FROM `{$p}store`")->row['n'] ? 's' : '')
		);

		$verdict = $points <= 2 ? 'Small' : ($points <= 8 ? 'Medium' : 'Large');
		$this->add($g, 'r_summary', $points <= 2 ? 'ok' : ($points <= 8 ? 'info' : 'warn'), 'Upgrade size: ' . $verdict, array(
			'detail' => $verdict === 'Small' ? 'Few or no parts need replacing. The upgrade is mainly moving your data.' : ($verdict === 'Medium' ? 'Several extensions or changes need OpenCart 4 versions. Plan it and test on a copy of the shop.' : 'Many extensions, modifications or a custom theme need OpenCart 4 versions. Budget for a developer or stay on OpenCart 3 (still maintained) until they are available.'),
			'items' => array_merge(array('Data to move:'), $data),
			'how' => 'Always upgrade on a copy of the shop first, with a full backup of files and database. Staying on the latest OpenCart 3.0.x is a valid choice while it is maintained.'
		));
	}

	/* ------------------------------------------------ fixes */

	public static function fixes() {
		return array('error_display', 'events_dead', 'sessions', 'image_cache', 'meta_title');
	}

	private function record($check, $title, $result, $undo) {
		$this->q("INSERT INTO `" . $this->p . "store_doctor_fix` SET `check_id` = '" . $this->e($check) . "', `title` = '" . $this->e($title) . "', `result` = '" . $this->e(substr($result, 0, 500)) . "', `undo` = " . ($undo === null ? 'NULL' : "'" . $this->e(json_encode($undo)) . "'") . ", `user` = '" . $this->e($this->c('admin_user')) . "', `date_added` = '" . date('Y-m-d H:i:s') . "'");
	}

	public function fix($id) {
		$p = $this->p;

		switch ($id) {
			case 'error_display':
				$this->q("UPDATE `{$p}setting` SET `value` = '0' WHERE store_id = '0' AND `key` = 'config_error_display'");
				$this->record($id, 'Hid PHP errors from visitors', 'Errors are still written to the error log.', array('type' => 'setting', 'key' => 'config_error_display', 'value' => '1'));

				return 'PHP errors are now hidden from visitors.';

			case 'events_dead':
				$ids = array();

				foreach ($this->q("SELECT * FROM `{$p}event` WHERE `status` = '1'")->rows as $ev) {
					$f = $this->eventFile($ev['trigger'], $ev['action']);

					if ($f !== '' && !is_file($f)) {
						$ids[] = (int)$ev['event_id'];
					}
				}

				if (!$ids) {
					return 'Nothing to switch off.';
				}

				$this->q("UPDATE `{$p}event` SET `status` = '0' WHERE `event_id` IN (" . implode(',', $ids) . ")");
				$this->record($id, 'Switched off ' . count($ids) . ' event(s) pointing to missing code', 'Event IDs: ' . implode(', ', $ids), array('type' => 'events', 'ids' => $ids));

				return count($ids) . ' event' . (count($ids) === 1 ? '' : 's') . ' switched off.';

			case 'sessions':
				$this->q("DELETE FROM `{$p}session` WHERE `expire` < NOW()");
				$n = method_exists($this->db, 'countAffected') ? (int)$this->db->countAffected() : 0;
				$this->record($id, 'Deleted expired sessions', $n ? $n . ' expired sessions deleted' : 'Expired sessions deleted', null);

				return 'Expired sessions deleted' . ($n ? ' (' . number_format($n) . ')' : '') . '.';

			case 'image_cache':
				$dir = rtrim((string)$this->c('image'), '/') . '/cache/';
				$n = 0;
				$size = 0;

				if (is_dir($dir)) {
					$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);

					foreach ($it as $f) {
						if ($f->isFile() && preg_match('/\.(jpe?g|png|gif|webp)$/i', $f->getFilename())) {
							$size += $f->getSize();

							if (@unlink($f->getPathname())) {
								$n++;
							}
						}
					}
				}

				$this->record($id, 'Emptied the resized-image cache', $n . ' files, ' . self::bytes($size) . ' freed', null);

				return number_format($n) . ' cached images deleted (' . self::bytes($size) . '). OpenCart will make new ones as pages are visited.';

			case 'meta_title':
				$rows = $this->q("SELECT pd.product_id, pd.language_id, pd.name FROM `{$p}product_description` pd JOIN `{$p}product` pr ON pr.product_id = pd.product_id WHERE pr.status = '1' AND TRIM(pd.meta_title) = ''")->rows;
				$undo = array();

				foreach ($rows as $r) {
					$this->q("UPDATE `{$p}product_description` SET `meta_title` = '" . $this->e(mb_substr($r['name'], 0, 255)) . "' WHERE product_id = '" . (int)$r['product_id'] . "' AND language_id = '" . (int)$r['language_id'] . "' AND TRIM(meta_title) = ''");
					$undo[] = array((int)$r['product_id'], (int)$r['language_id']);
				}

				$this->record($id, 'Filled ' . count($undo) . ' empty meta title(s) with the product name', '', array('type' => 'meta_title', 'rows' => $undo));

				return count($undo) . ' meta title' . (count($undo) === 1 ? '' : 's') . ' filled.';
		}

		throw new Exception('Unknown fix.');
	}

	public function history() {
		$this->ensureTables();

		return $this->q("SELECT `fix_id`, `check_id`, `title`, `result`, (`undo` IS NOT NULL) AS can_undo, `undone`, `user`, `date_added` FROM `" . $this->p . "store_doctor_fix` ORDER BY `fix_id` DESC LIMIT 200")->rows;
	}

	public function undo($fix_id) {
		$p = $this->p;
		$row = $this->q("SELECT * FROM `{$p}store_doctor_fix` WHERE `fix_id` = '" . (int)$fix_id . "'")->row;

		if (!$row || $row['undo'] === null || (int)$row['undone']) {
			throw new Exception('This fix can not be undone (or was already undone).');
		}

		$u = json_decode($row['undo'], true);

		if ($u['type'] === 'setting') {
			$this->q("UPDATE `{$p}setting` SET `value` = '" . $this->e($u['value']) . "' WHERE store_id = '0' AND `key` = '" . $this->e($u['key']) . "'");
		} elseif ($u['type'] === 'events') {
			$this->q("UPDATE `{$p}event` SET `status` = '1' WHERE `event_id` IN (" . implode(',', array_map('intval', $u['ids'])) . ")");
		} elseif ($u['type'] === 'meta_title') {
			foreach ($u['rows'] as $r) {
				$this->q("UPDATE `{$p}product_description` SET `meta_title` = '' WHERE product_id = '" . (int)$r[0] . "' AND language_id = '" . (int)$r[1] . "'");
			}
		}

		$this->q("UPDATE `{$p}store_doctor_fix` SET `undone` = '1' WHERE `fix_id` = '" . (int)$fix_id . "'");

		return 'Undone: ' . $row['title'];
	}

	public function ignore($id, $on) {
		$cfg = $this->getConfig();
		$list = array_values(array_diff($cfg['ignored'], array($id)));

		if ($on) {
			$list[] = preg_replace('/[^a-z0-9_]/', '', $id);
		}

		$cfg['ignored'] = $list;
		$this->saveConfig($cfg);

		return $list;
	}

	public function bootstrap() {
		$this->ensureTables();

		return array('oc' => $this->oc, 'version' => $this->c('version'), 'last' => $this->lastScan(), 'fixes' => self::fixes());
	}
}
}
