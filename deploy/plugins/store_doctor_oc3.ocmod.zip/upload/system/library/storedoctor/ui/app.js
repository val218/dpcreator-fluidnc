/* Store Doctor for OpenCart - admin app (vanilla JS, no dependencies). */
(function () {
	'use strict';

	var BOOT = window.SDR_BOOT || {};
	var root = document.getElementById('sdr-root');
	var GROUPS = [
		['overview', 'Overview'], ['security', 'Security'], ['extensions', 'Extensions'], ['errors', 'Errors'],
		['content', 'SEO & content'], ['speed', 'Speed & server'], ['readiness', 'OpenCart 4 readiness'], ['history', 'Fix history']
	];
	var ST = { bad: ['Serious', '#C42B1C'], warn: ['Look at this', '#B26A00'], info: ['Good to know', '#1F6FB8'], ok: ['OK', '#12805C'] };
	var ORDER = { bad: 0, warn: 1, info: 2, ok: 3 };
	var S = { tab: 'overview', scan: null, errors: null, history: null, busy: false, open: {} };

	function h(tag, attrs, kids) {
		var el = document.createElement(tag);
		attrs = attrs || {};
		Object.keys(attrs).forEach(function (k) {
			var v = attrs[k];
			if (v === null || v === undefined || v === false) return;
			if (k === 'class') el.className = v;
			else if (k === 'style') el.setAttribute('style', v);
			else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
			else if (k === 'disabled') el.disabled = !!v;
			else el.setAttribute(k, v === true ? '' : v);
		});
		(Array.isArray(kids) ? kids : kids == null ? [] : [kids]).forEach(function (c) {
			if (c == null || c === false) return;
			el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
		});
		return el;
	}

	function api(action, data) {
		var url = BOOT.api + (BOOT.api.indexOf('?') > -1 ? '&' : '?') + 'action=' + action;
		return fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {}) })
			.then(function (r) { return r.text(); })
			.then(function (t) {
				var j;
				try { j = JSON.parse(t); } catch (e) { throw new Error(/login|token/i.test(t) ? 'Your session expired - reload the page and log in.' : 'Unexpected server reply. ' + t.replace(/<[^>]+>/g, ' ').trim().slice(0, 200)); }
				if (j.error) throw new Error(j.error);
				return j.data;
			});
	}

	var toastBox;
	function toast(msg, kind) {
		if (!toastBox) { toastBox = h('div', { class: 'sdr-toast' }); document.body.appendChild(toastBox); }
		var t = h('div', { class: kind || '' }, msg);
		toastBox.appendChild(t);
		setTimeout(function () { t.remove(); }, kind === 'bad' ? 7000 : 4000);
	}

	function color(score) { return score >= 85 ? '#12805C' : score >= 60 ? '#B26A00' : '#C42B1C'; }
	function num(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
	function bytes(n) { var u = ['B', 'KB', 'MB', 'GB'], i = 0; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + ' ' + u[i]; }

	/* ------------------------------------------------ layout */

	var tabs, body, head;

	function frame() {
		root.textContent = '';
		head = h('div', { class: 'sdr-head' });
		tabs = h('div', { class: 'sdr-tabs', role: 'tablist' });
		body = h('div', { class: 'sdr-body' });
		root.appendChild(head);
		root.appendChild(tabs);
		root.appendChild(body);
	}

	function groupCount(g) {
		if (!S.scan) return '';
		var n = S.scan.findings.filter(function (f) { return f.group === g && !f.ignored && (f.status === 'bad' || f.status === 'warn'); }).length;
		return n ? String(n) : '';
	}

	function render() {
		head.textContent = '';
		var sc = S.scan;
		var again = h('button', { type: 'button', class: 'sdr-btn sdr-primary', disabled: S.busy, onclick: runScan }, S.busy ? 'Checking…' : sc ? 'Check again' : 'Check my shop');
		if (sc) {
			head.appendChild(h('div', { class: 'sdr-ring', style: 'background:conic-gradient(' + color(sc.score) + ' ' + sc.score + '%,#E3E8ED 0)', role: 'img', 'aria-label': 'Health score ' + sc.score + ' out of 100' }, h('span', {}, String(sc.score))));
			head.appendChild(h('div', { class: 'sdr-sum' }, [
				h('b', {}, sc.score >= 85 ? 'Your shop is in good shape' : sc.score >= 60 ? 'A few things need attention' : 'Your shop needs attention'),
				h('div', { class: 'sdr-pills' }, [
					pill('bad', sc.counts.bad + ' serious'), pill('warn', sc.counts.warn + ' to look at'), pill('info', sc.counts.info + ' good to know'), pill('ok', sc.counts.ok + ' OK')
				]),
				h('small', {}, 'Checked ' + sc.scanned.slice(0, 16) + ' in ' + sc.seconds + ' s · OpenCart ' + sc.version + (sc.counts.ignored ? ' · ' + sc.counts.ignored + ' ignored' : '') + ' · the check only reads, it never changes your shop')
			]));
		} else {
			head.appendChild(h('div', { class: 'sdr-sum' }, [h('b', {}, 'Check the health of your shop'), h('small', {}, 'Security, extensions, errors, SEO, speed and OpenCart 4 readiness. Takes a few seconds and changes nothing.')]));
		}
		head.appendChild(again);

		tabs.textContent = '';
		GROUPS.forEach(function (g) {
			var c = g[0] === 'overview' || g[0] === 'history' ? '' : groupCount(g[0]);
			tabs.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': S.tab === g[0] ? 'true' : 'false', onclick: function () { S.tab = g[0]; render(); } }, [g[1], c ? h('i', {}, c) : null]));
		});

		body.textContent = '';
		if (S.tab === 'history') return history();
		if (!sc) { body.appendChild(h('div', { class: 'sdr-empty' }, S.busy ? 'Checking your shop…' : 'Click "Check my shop" to start.')); return; }
		if (S.tab === 'overview') return overview();
		if (S.tab === 'errors') errorsTab();
		else list(sc.findings.filter(function (f) { return f.group === S.tab; }));
	}

	function pill(st, text) { return h('span', { class: 'sdr-pill', style: '--c:' + ST[st][1] }, text); }

	/* ------------------------------------------------ findings */

	function card(f) {
		var items = f.items || [];
		var key = f.id;
		var openItems = S.open[key] || items.length <= 8;
		var kids = [
			h('div', { class: 'sdr-ct' }, [pill(f.status, ST[f.status][0]), h('b', {}, f.title)]),
			f.detail ? h('p', {}, f.detail) : null
		];
		if (items.length) {
			var ul = h('ul', { class: 'sdr-items' }, (openItems ? items : items.slice(0, 6)).map(function (x) { return h('li', {}, x); }));
			kids.push(ul);
			if (!openItems) kids.push(h('button', { type: 'button', class: 'sdr-link', onclick: function () { S.open[key] = true; render(); } }, 'Show all ' + items.length));
		}
		if (f.how) kids.push(h('p', { class: 'sdr-how' }, [h('b', {}, 'How to fix: '), f.how]));
		var actions = h('div', { class: 'sdr-acts' });
		if (f.fix && !f.ignored && f.status !== 'ok') {
			var b = h('button', { type: 'button', class: 'sdr-btn sdr-primary', onclick: function () { doFix(f, b); } }, f.fix_label || 'Fix it');
			actions.appendChild(b);
		}
		if (f.status === 'bad' || f.status === 'warn' || f.status === 'info' || f.ignored) {
			actions.appendChild(h('button', { type: 'button', class: 'sdr-link', onclick: function () { ignore(f, !f.ignored); } }, f.ignored ? 'Stop ignoring' : 'Ignore this'));
		}
		if (actions.childNodes.length) kids.push(actions);
		return h('div', { class: 'sdr-card' + (f.ignored ? ' is-ignored' : ''), style: '--c:' + ST[f.status][1] }, kids);
	}

	function sorted(fs) {
		return fs.slice().sort(function (a, b) { return (a.ignored ? 9 : ORDER[a.status]) - (b.ignored ? 9 : ORDER[b.status]); });
	}

	function list(fs) {
		if (!fs.length) { body.appendChild(h('div', { class: 'sdr-empty' }, 'Nothing to show here.')); return; }
		sorted(fs).forEach(function (f) { body.appendChild(card(f)); });
	}

	function overview() {
		var important = S.scan.findings.filter(function (f) { return !f.ignored && (f.status === 'bad' || f.status === 'warn'); });
		if (!important.length) {
			body.appendChild(h('div', { class: 'sdr-good' }, [h('b', {}, 'Nothing serious found.'), ' Look through the tabs for "good to know" notes, and check again after you install or update extensions.']));
		} else {
			body.appendChild(h('h3', { class: 'sdr-h3' }, 'What needs attention'));
			sorted(important).forEach(function (f) {
				var c = card(f);
				var g = GROUPS.filter(function (x) { return x[0] === f.group; })[0];
				c.insertBefore(h('div', { class: 'sdr-grp' }, h('a', { href: '#', onclick: function (e) { e.preventDefault(); S.tab = f.group; render(); } }, g ? g[1] : f.group)), c.firstChild);
				body.appendChild(c);
			});
		}
		var good = S.scan.findings.filter(function (f) { return !f.ignored && f.status === 'ok'; });
		if (good.length) {
			body.appendChild(h('h3', { class: 'sdr-h3' }, 'Already fine'));
			body.appendChild(h('ul', { class: 'sdr-oks' }, good.map(function (f) { return h('li', {}, f.title); })));
		}
	}

	function doFix(f, btn) {
		btn.disabled = true;
		btn.textContent = 'Working…';
		api('fix', { id: f.fix }).then(function (r) {
			S.scan = r.scan; S.history = null;
			toast(r.message + ' You can undo it in Fix history.', 'good');
			render();
		}).catch(function (e) { toast(e.message, 'bad'); btn.disabled = false; btn.textContent = f.fix_label; });
	}

	function ignore(f, on) {
		api('ignore', { id: f.id, on: on ? 1 : 0 }).then(function (sc) { S.scan = sc; render(); }).catch(function (e) { toast(e.message, 'bad'); });
	}

	/* ------------------------------------------------ errors */

	function errorsTab() {
		list(S.scan.findings.filter(function (f) { return f.group === 'errors'; }));
		var box = h('div', { class: 'sdr-errs' }, h('div', { class: 'sdr-empty' }, 'Reading the error log…'));
		body.appendChild(box);
		var show = function (e) {
			box.textContent = '';
			if (!e.exists || !e.size) { box.appendChild(h('div', { class: 'sdr-empty' }, 'The error log is empty.')); return; }
			box.appendChild(h('p', { class: 'sdr-muted' }, 'Error log ' + e.file + ' (' + bytes(e.size) + ')' + (e.partial ? ' - showing the newest 2 MB' : '') + '. The same error is grouped together.'));
			var t = h('div', { class: 'sdr-table' });
			e.groups.forEach(function (g, i) {
				var key = 'err' + i;
				var row = h('div', { class: 'sdr-erow', role: 'button', tabindex: '0', 'aria-expanded': S.open[key] ? 'true' : 'false',
					onclick: function () { S.open[key] = !S.open[key]; render(); },
					onkeydown: function (ev) { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); S.open[key] = !S.open[key]; render(); } }
				}, [
					h('span', { class: 'sdr-etype', style: '--c:' + (/fatal/i.test(g.type) ? ST.bad[1] : /warning/i.test(g.type) ? ST.warn[1] : '#6B7885') }, g.type),
					h('div', { class: 'w' }, [h('div', {}, g.message), h('small', {}, g.source)]),
					h('div', { class: 'n' }, [h('b', {}, num(g.count) + '×'), h('small', {}, 'last ' + g.last.slice(0, 16))])
				]);
				t.appendChild(row);
				if (S.open[key]) {
					t.appendChild(h('div', { class: 'sdr-edet' }, [
						h('p', {}, [h('b', {}, 'What it means: '), g.meaning]),
						h('p', {}, [h('b', {}, 'Where: '), (g.file || 'unknown') + (g.line ? ' on line ' + g.line : '')]),
						h('p', {}, [h('b', {}, 'Seen: '), num(g.count) + ' times, first ' + g.first + ', last ' + g.last]),
						h('p', { class: 'sdr-muted' }, 'Send this to the extension author or your developer - the file and line tell them exactly where to look.')
					]));
				}
			});
			box.appendChild(t);
		};
		if (S.errors) show(S.errors);
		else api('errors').then(function (e) { S.errors = e; show(e); }).catch(function (e) { box.textContent = e.message; });
	}

	/* ------------------------------------------------ history */

	function history() {
		var box = h('div', {}, h('div', { class: 'sdr-empty' }, 'Loading…'));
		body.appendChild(box);
		var show = function (rows) {
			box.textContent = '';
			if (!rows.length) { box.appendChild(h('div', { class: 'sdr-empty' }, 'No fixes yet. Fixes made with Store Doctor are listed here, and most can be undone.')); return; }
			rows.forEach(function (r) {
				var undo = +r.can_undo && !+r.undone ? h('button', { type: 'button', class: 'sdr-btn', onclick: function () {
					undo.disabled = true;
					api('undo', { fix_id: +r.fix_id }).then(function (res) { S.scan = res.scan; S.history = null; toast(res.message, 'good'); render(); })
						.catch(function (e) { toast(e.message, 'bad'); undo.disabled = false; });
				} }, 'Undo') : null;
				box.appendChild(h('div', { class: 'sdr-hrow' }, [
					h('div', { class: 'w' }, [h('b', {}, r.title), h('small', {}, r.date_added.slice(0, 16) + (r.user ? ' · ' + r.user : '') + (r.result ? ' · ' + r.result : ''))]),
					+r.undone ? h('span', { class: 'sdr-muted' }, 'Undone') : (+r.can_undo ? undo : h('span', { class: 'sdr-muted' }, 'Nothing to undo'))
				]));
			});
		};
		if (S.history) show(S.history);
		else api('history').then(function (rows) { S.history = rows; show(rows); }).catch(function (e) { box.textContent = e.message; });
	}

	/* ------------------------------------------------ start */

	function runScan() {
		S.busy = true; render();
		api('scan').then(function (sc) { S.scan = sc; S.errors = null; S.busy = false; render(); })
			.catch(function (e) { S.busy = false; render(); toast(e.message, 'bad'); });
	}

	frame();
	api('bootstrap').then(function (b) {
		S.boot = b;
		render();
		runScan();
	}).catch(function (e) { root.textContent = ''; root.appendChild(h('div', { class: 'sdr-empty' }, e.message)); });
})();
